# Feedback Package Manifest

> This feedback targets the Spec Kit framework itself (templates, commands, skills, scripts, docs) — not the LLM, agent CLI, harness, or any user project code.

- **Generated**: 2026-11-27T13:21:14Z
- **Entries**: 5
- **Time range**: 2026-11-24T11:29:19Z → 2026-11-25T17:23:15Z
- **spec-kit version**: unknown
- **Install source**: unknown

| Created | Unit | Partial | Probe | Slice | Summary |
|---------|------|---------|-------|-------|---------|
| 2026-11-24T11:29:19Z | /speckit.team | False | speckit-team-wrapup | commands | [fast-fail] P-SH path-b 容量削减在可行性门停止：TEST MergeShard 对 readonly shard 返回 ParameterInvalid: shard not exist or readonly，c6 |
| 2026-11-24T11:40:07Z | /speckit.team | False | speckit-team-wrapup | commands | [fast-fail] 首轮独立 reviewer 纠正：MergeShard 使总 shard 数 +1（原两个转 readonly 保留 + 新 rw），quota 按 total；故 c6d8/初版报告的 984/184/992 与“ |
| 2026-11-25T01:55:21Z | /speckit.team | False | speckit-team-wrapup | commands | 派发包装器超时导致子席位静默死亡(夜间 4 席:SH收口/provider修/监控试点/pai治理);真因=启动包装器(Bash 工具超时)stop 时连带 SIGTERM 子 qodercli;'&'+wait 分组放大(一包装器多席一起 |
| 2026-11-25T16:56:32Z | /speckit.team | False | speckit-team-wrapup | commands | 续派席位收尾退役 PROD 1145409540763519 / kangaroo-fc / cn-hangzhou 两个 mq-rund 作业（前席完成 StopJob/DeleteDeployment/state rm，本席完成 t1/ |
| 2026-11-25T17:23:15Z | /speckit.team | False | speckit-team-wrapup | commands | run 命令与在飞 T-002 席位合流，未重复派发 |
## Exec-Quant Payload

- **Records**: 87
- **Source forms**: records-dir 80, legacy-jsonl 7
- **Skipped unreadable**: 0
- **Truncated**: 0
- **Cap**: 1000 records / 16777216 bytes (triggered: no)
- **Source project**: xuanji-iac
- **Collected range**: 2026-10-19T03:56:58Z → 2026-11-25T17:23:14Z

