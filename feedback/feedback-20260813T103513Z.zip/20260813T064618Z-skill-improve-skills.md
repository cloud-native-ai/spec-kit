---
id: "20260813T064618Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "dingtalk-recall-doc-20260813"
scope: "local"
partial: false
created: "2026-08-13T06:46:18Z"
summary: "本次用 improve-skills 更新 dingtalk-workspace 的消息撤回章节。纠错本身正确（发现并修正了 capability-limits.md 中「个人身份消息无法撤回」的假限制——该表明示「不要重试，直接告知不支持」，假限制会让 agent 拒绝其实可做的任务），但**编辑风格违规**：我用了「旧文档断言…已证伪」「实测校正」「本条不再是限制」等变更日志式表述，被用户当场"
---

## Review
本次用 improve-skills 更新 dingtalk-workspace 的消息撤回章节。纠错本身正确（发现并修正了 capability-limits.md 中「个人身份消息无法撤回」的假限制——该表明示「不要重试，直接告知不支持」，假限制会让 agent 拒绝其实可做的任务），但**编辑风格违规**：我用了「旧文档断言…已证伪」「实测校正」「本条不再是限制」等变更日志式表述，被用户当场指出「没人关心旧文档怎么说，只保留最新正确描述即可」。已回溯清理全库同类表述 8 处（含 conference/devapp/minutes/pitfalls 中的存量「旧文档误载」「重要勘误」）。

## Optimization Points
- **禁止在技能文档中叙述文档自身的历史**：修正一处错误断言时，只写当前正确事实，不写「旧文档断言…已证伪」「重要勘误」「实测校正」「本条不再是限制」这类框架。技能是给下次执行读的契约，执行者不关心文档曾经怎么说；这类表述纯占 token 且会随时间堆积成噪音。SKILL.md:73 现有的「Avoid adding process logs, changelogs」过于笼统，未点名这个高频具体反模式，本次即在其约束下仍然违规。
- 建议在 SKILL.md Step 5 的该行后补一句具体禁令，并在 references/skill-slimming-principles.md 给出改写示例（错：`> 旧文档断言 X 已证伪——实测 Y`；对：直接陈述 `Y`）。
- 例外应显式声明：`未实测（待验证）` 这类**置信度标记**与「某命令已下线/不存在，改用 X」这类**防误用警示**要保留，它们描述的是当前状态而非文档变更史。
