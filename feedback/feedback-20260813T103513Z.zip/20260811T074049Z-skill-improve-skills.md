---
id: "20260811T074049Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "create-skills-crossssot-20260811"
scope: "local"
partial: false
created: "2026-08-11T07:40:49Z"
summary: "本次用 improve-skills 处理 create-skills 的三条反馈：证据引擎两通道可用但只给出计数/主题类信号（按红线未据此定缺陷），真正的依据是本次执行的直接症状与一条复现主题；据此在上游 spec-kit 落两条契约行 + 一份新 reference，profiles 与 spec-kit 内部镜像同步至三处 md5 一致，shape gate exit 0，契约测试用干净 w"
---

## Review
本次用 improve-skills 处理 create-skills 的三条反馈：证据引擎两通道可用但只给出计数/主题类信号（按红线未据此定缺陷），真正的依据是本次执行的直接症状与一条复现主题；据此在上游 spec-kit 落两条契约行 + 一份新 reference，profiles 与 spec-kit 内部镜像同步至三处 md5 一致，shape gate exit 0，契约测试用干净 worktree 基线对比证明零回归（10 个既有失败保持，我引入的 3 个镜像失败已消除）。摩擦点在 Step 6 的压测环节：首轮场景没能隔离被改分支，二轮 RED 又被 repo 内常驻规则兜底，最终只能把结论限定为「检测从外部规则兜底改为 workflow 内建」，并写入干预台账待下次 compare 判定。

## Optimization Points
- ## Optimization Points
- 1. **Step 6 的 RED-GREEN 未要求场景「能隔离被改的判断分支」**：本次第一轮压测选了
- `yunzhidao-workspace`，但该名字在同目录已存在，命中的是改动前就有的「已存在 →
- improve-skills」规则，RED 与 GREEN 都正确拒绝，结果不具区分度，白跑一轮双 agent。
- 建议在 Step 6 的压测要求里加一句前置校验：**先确认旧文本会走到错误分支**
- （构造场景时验证冲突对旧检查不可见，例如目标名在当前项目 `.specify/skills/`
- 与全局库均不存在、只存在于另一个 SSOT），再派 agent；场景不满足此前置条件时
- 换场景，不要把「两边都合规」当作 GREEN 通过。
- 2. **RED 可能被 repo 内 always-on 规则兜底，导致结论被高估或低估**：第二轮 RED
- （`cws-py-cli`）也没误建，但它把冲突发现明确归因于 `.qoder/rules/skill-management.md`
- 这一 profiles 私有的常驻规则文件——即 workflow 自身步骤仍是盲的。若不追问归因，
- 很容易把「RED 没失败」误读为「改动无必要」。建议 Step 6 要求：解读 RED 前先列出
- 本仓库的**带外规则源**（rules 文件、AGENTS.md、常驻 instructions），并要求 agent
- 报告每个动作是「workflow 指示」还是「自行发挥/外部规则驱动」，据此界定结论范围。
- 3. **镜像同步应在跑契约测试之前**：本次先跑测试得到 13 个失败，其中 3 个纯粹是
- 「改了源、未同步镜像」；先同步镜像再跑，可省一轮基线 worktree 对比。建议 Step 5
- 的 rename/removal 清单之外，为「多镜像技能」补一句：编辑源后**立即**同步镜像并
- `diff -r` 校验，再进入 Step 6 的测试与基线对比。
