---
id: "20260807T134425Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "improve-dispatch-workitem-20260807"
scope: "local"
feature: "dispatch-workitem-decomposition"
partial: false
created: "2026-08-07T13:44:25Z"
summary: "Ran one improvement loop on dispatch-workitem after its decomposition capability expansion. The loop found and fixed the primary shape failure: SKILL.md had grown to ~10,334 tokens / 42% fences becaus"
---

## Review
Ran one improvement loop on dispatch-workitem after its decomposition capability expansion. The loop found and fixed the primary shape failure: SKILL.md had grown to ~10,334 tokens / 42% fences because the new decomposition examples and command sequences were authored inline. Fixed by moving the five worked examples to references/examples.md, the step-by-step workflow details to references/workflow-detail.md, and shortening Workflow/Decomposition Workflow to skeletons with pointer links. skill-shape.py now exits 0 (~3,783 controllable tokens). workitem-tree.py assess/plan were exercised against sample trees. Evidence engine (evidence-utils.py --action latest/collect) was unavailable in this repo, so the loop operated on filesystem ground truth plus the objective shape gate. Assumption: per-project convention, no .specify/instructions.md registry row or .github/skills symlink was added.

## Optimization Points
- The missing evidence engine made the loop fall back to mechanical checks; future runs should confirm whether evidence-utils.py is intended to be installed in this workspace or if improve-skills should degrade more explicitly when it is absent. token-efficiency
