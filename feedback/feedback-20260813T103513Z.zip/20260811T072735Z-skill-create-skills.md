---
id: "20260811T072735Z-skill-create-skills"
unit_id: "skill:create-skills"
unit_type: "skill"
run_id: "aliyun-layering-20260811"
scope: "local"
partial: false
created: "2026-08-11T07:27:35Z"
summary: "本次用 create-skills 创建 profiles 侧 aliyun-workspace/aliyun-document 两个前门技能，并配合 cws-lib-python 侧改名脱敏，完成 R3 分层。skill 的骨架（frontmatter 规范、references 分层、Feedback 段、注册表登记、相对链接与体积约束）都直接可用，产出的两个技能一次通过全部最小检查项。主要摩"
---

## Review
本次用 create-skills 创建 profiles 侧 aliyun-workspace/aliyun-document 两个前门技能，并配合 cws-lib-python 侧改名脱敏，完成 R3 分层。skill 的骨架（frontmatter 规范、references 分层、Feedback 段、注册表登记、相对链接与体积约束）都直接可用，产出的两个技能一次通过全部最小检查项。主要摩擦在前置判定：目标技能名已作为另一个 SSOT 的实体存在且全机接线，workflow 只有「存在则转 improve-skills」这一条出口，无法表达跨 SSOT 同名与分层拆分，只能临时提问定关系；验证阶段真正抓到问题（改名打断 8 条链接）的是项目规则里的悬空链接扫描与拓扑登记对账，而非 skill 自带的检查清单。

## Optimization Points
- ## Optimization Points
- 1. **缺「跨 SSOT 同名冲突」分支**：Step 1 只给了「技能已存在 → 转 improve-skills」
- 一条出口，判定依据是 `.specify/skills/<name>/SKILL.md` 是否存在。本次目标名
- aliyun-workspace 已作为**另一个 SSOT（cws-lib-python 项目实体）**存在且全机四处
- 接线，既不该转 improve-skills，也不能直接新建同名实体——workflow 无路可走，只能
- 临时向用户提问定关系。建议 Step 1 增加冲突扫描：除 `.specify/skills/` 外，一并
- 检查 `config/skills/`、各 Agent 加载目录与已登记的项目实体链接目标；命中同名时
- 列出「实体在哪、谁在引用」，并给出三条决策路径（迁入全局／保留项目实体做链接／
- 拆公开下层+私有前门）。
- 2. **验证清单漏了技能拓扑一致性**：Step 6 有契约套件与其 fallback，但没有「若项目
- 维护技能拓扑登记文件则须同步并复扫」的要求。本次真正能发现问题的终验是悬空链接
- 扫描与 skills-map.lst 计数对账（改名瞬间打断了 8 条链接），这来自项目规则而非本
- skill。建议在 Spec Kit project mode 的最小检查项里补一条：项目若存在技能拓扑登记
- 文件（如 `config/skills/skills-map.lst`）或多 Agent 加载目录，须更新登记并复扫
- 悬空链接归零后才算完成。
- 3. **前门/下层这类分层技能缺少模板支持**：本次产出的两个技能主体是「委托契约 +
- 文档地图 + 私有 overlay」，与 skill 现有的单层结构假设（scripts/references/assets）
- 不冲突但无指引。建议在 Design Principles 里补一小节「分层技能」：下层持细节事实源、
- 前门持私有内容与编排，并要求前门显式写明"不复制下层内容"与 preflight 存在性检查。
