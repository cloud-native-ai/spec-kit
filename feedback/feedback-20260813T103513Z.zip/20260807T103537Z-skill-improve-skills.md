---
id: "20260807T103537Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "dispatch-workitem-decomposition-20260807"
scope: "local"
partial: false
created: "2026-08-07T10:35:37Z"
summary: "针对 dispatch-workitem 的拆解能力缺失做了一轮证据驱动改进。证据来自 09_任务管理 项目 2026-08-07 的真实运行：父需求 85228984 把 5 个子需求作为 prose 章节写进描述、子项用文本行「父需求：…（85228984）」代替关联、拆解止于需求层未产出任务层；MEMORY.md 09:32 的规则记录证明拆解规则是用户运行中临时补充的。先用 a1 --he"
---

## Review
针对 dispatch-workitem 的拆解能力缺失做了一轮证据驱动改进。证据来自 09_任务管理 项目 2026-08-07 的真实运行：父需求 85228984 把 5 个子需求作为 prose 章节写进描述、子项用文本行「父需求：…（85228984）」代替关联、拆解止于需求层未产出任务层；MEMORY.md 09:32 的规则记录证明拆解规则是用户运行中临时补充的。先用 a1 --help 与 project-commands.md 查证能力面，确认 create --relation 与 relation add 均存在而技能全文零覆盖，据此定位根因。改进为：SKILL.md 增加三层层级模型与四类关联语义定义（契约层）、步骤 1.5 复杂度门禁、D1–D5 拆解工作流、6 条硬性要求；方法层落到 references/decomposition.md；确定性逻辑（复杂度评分、树校验、拓扑命令编排）抽到 scripts/workitem-tree.py。脚本已真实运行验证：真实父需求 assess 得分 13 判 decompose、简单缺陷判 single、7 类非法树全部拦截且 fail-closed 不出计划、真实树端到端复现父先子后与关联结构。

## Optimization Points
- 本次改进的根因是「能力面未查证」：dispatch-workitem 全文未出现 `--relation`/`relation add`，
- 导致执行者只能把父子关系写成描述文本。improve-skills 在分析委派型技能时，应把
- 「上游 CLI 的 `--help` 能力面 vs 技能文档覆盖面」做成固定对照动作 —— 一次 grep + 一次
- `--help` 即可暴露此类整类缺失，成本远低于其造成的返工。
- 证据层面，本次最强信号来自**产物文件时间线**（tmp/subreq-1..5-body.md 与
- workitem_body.md 的时间戳差、以及子项描述末尾的「父需求：…」文本行），而非会话记录。
- 建议在证据采集中显式加入「目标技能最近一次运行留下的中间产物目录」作为一条线索来源。
- 为拆解类改进补充了「fail-closed」校验模式：脚本校验失败时清空可执行步骤而非仅报错，
- 避免调用方在带缺陷的树上执行难以撤销的批量创建。此模式适用于所有会产生不可逆外部
- 副作用的技能脚本，可作为通用准则沉淀。
