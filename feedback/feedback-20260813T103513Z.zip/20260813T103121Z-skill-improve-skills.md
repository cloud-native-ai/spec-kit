---
id: "20260813T103121Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "improve-skills-dingtalk-workspace-msg-readability-20260813"
scope: "local"
partial: false
created: "2026-08-13T10:31:21Z"
summary: "本轮为 dingtalk-workspace 增加「发给自然人的消息内容核查」硬约束：SKILL.md 落契约条文 + message-readability.md 承载细则 + message_precheck.py 承载确定性核查，并在 core-rules、lite-recipes send-message、chat-message-send 步骤3、card 流程B 四个真实发送决策点各放"
---

## Review
本轮为 dingtalk-workspace 增加「发给自然人的消息内容核查」硬约束：SKILL.md 落契约条文 + message-readability.md 承载细则 + message_precheck.py 承载确定性核查，并在 core-rules、lite-recipes send-message、chat-message-send 步骤3、card 流程B 四个真实发送决策点各放一行内联指针。证据侧基线为退化证据（无 per-skill 信号），驱动证据是用户显式指令。验证做了脚本实跑（坏稿 exit 10 / 好稿 exit 0 / @占位符反向用例）与 RED/GREEN 压力测试（改前副本子代理明确答「没有强制核查要求」，改后定位到原文并列出 7 处改写）。SKILL.md 形态门禁改前改后均为 exit 10（既存超预算），本轮净增 18 行契约文本，已在报告中显式声明未收敛。

## Optimization Points
- ## Optimization Points
- 1. 证据泳道在 profiles 这类「配置归档型」仓库对 config/skills/ 下的全局技能几乎没有 per-skill 信号（session 泳道 0 user corrections、feedback 泳道复现主题全属其他技能）。improve-skills 应在退化证据分支中显式列出「用户显式指令即一等驱动证据」的处理路径，避免执行者纠结于是否必须先凑出 findings 条目。
- 2. RED/GREEN 压力测试在本轮靠 `git archive HEAD <skill-dir>` 物化改前整棵技能目录后交子代理对照，效果明确（RED 明确回答「没有强制核查要求」）。这一具体物化手法比 references/pressure-testing.md 里的一般描述更可执行，值得沉淀为标准步骤（含「必须整目录物化、不能只喂旧 SKILL.md，否则 references 会污染 RED」这条坑）。
- 3. 新增确定性脚本时，最容易漏的验证不是「能跑」而是「不误伤本域必需语法」——本轮 message_precheck.py 初版把 `<@openDingTalkId>` @占位符误判为裸 ID，若不实跑就会诱导执行者删掉发送必需的占位符。improve-skills 的 Hard Constraint 5 可补一句：脚本类改动必须用「本域合法样本」跑一遍反向用例，而不只是用坏样本验证能报错。
