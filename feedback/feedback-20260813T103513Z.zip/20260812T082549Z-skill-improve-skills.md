---
id: "20260812T082549Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "improve-dingtalk-org-tree-dualmode-20260812"
scope: "local"
partial: false
created: "2026-08-12T08:25:49Z"
summary: "对 dingtalk-org-tree 做双模式（update 默认 / query 新增）改造：明确高阶技能委派定位、query 多格式输出（markdown 默认 + /draw-* 可视化）、Step0 意图识别，并把 111 行单体 SKILL.md 瘦身为 86 行契约、细节下沉到新增 references/6 文件。shape 门控 0 发现通过，引用链与锚点校验通过，双镜像经目录符号"
---

## Review
对 dingtalk-org-tree 做双模式（update 默认 / query 新增）改造：明确高阶技能委派定位、query 多格式输出（markdown 默认 + /draw-* 可视化）、Step0 意图识别，并把 111 行单体 SKILL.md 瘦身为 86 行契约、细节下沉到新增 references/6 文件。shape 门控 0 发现通过，引用链与锚点校验通过，双镜像经目录符号链接自动可见。修正了原文档中不可靠的 contact dept list-children 依赖。

## Optimization Points
- 当技能要求"底层操作全部委派某技能"时，正确做法是先读被委派技能的真实命令面（--help / references）核对能力边界，再写委派清单——本次借此发现 contact dept list-children 未必注册，避免把不可靠命令写进契约。
- 用户要求"多种输出格式 + 按需画图"时，可视化交给现成 /draw-* 技能并只写选型决策表 + 委派契约，比在本技能内复制绘图细节更符合高阶技能定位，也让 SKILL.md 保持契约态。
- 双模式改造中，query 的"默认只读、要沉淀切 update"这条模式边界必须显式写成硬约束，否则容易在查询中顺手写树、破坏模式语义。
