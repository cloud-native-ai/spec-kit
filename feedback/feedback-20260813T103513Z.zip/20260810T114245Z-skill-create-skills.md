---
id: "20260810T114245Z-skill-create-skills"
unit_id: "skill:create-skills"
unit_type: "skill"
run_id: "aso-workspace-20260810"
scope: "local"
partial: false
created: "2026-08-10T11:42:45Z"
summary: "按 create-skills 全流程在 profiles（Spec Kit project mode）创建 aso-workspace 并按 R1 完成 SSOT 固化、双链接扩散、三处登记与终验；悟空注册因会话内无对应 MCP 工具而受控延期并留档交接。"
---

## Review
按 create-skills 全流程在 profiles（Spec Kit project mode）创建 aso-workspace 并按 R1 完成 SSOT 固化、双链接扩散、三处登记与终验；悟空注册因会话内无对应 MCP 工具而受控延期并留档交接。

## Optimization Points
- R1 升格扩散场景中「悟空注册」依赖悟空侧 skill_manage MCP 工具，非悟空会话内无法完成；create-skills 的 profiles 特化流程宜显式声明该步骤的会话前提与交接话术（在 skills-map.lst 留 NOTE + 完成报告交接），避免每次现场推导。
- AskUserQuestion 曾被预填 answers 导致「仍安装到悟空」并非用户真实选择；技能层面应强调禁止预填并在报告中回溯声明。
