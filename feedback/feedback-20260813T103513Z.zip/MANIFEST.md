# Feedback Package Manifest

> This feedback targets the Spec Kit framework itself (templates, commands, skills, scripts, docs) — not the LLM, agent CLI, harness, or any user project code.

- **Generated**: 2026-08-13T10:35:13Z
- **Entries**: 13
- **Time range**: 2026-08-07T10:35:37Z → 2026-08-13T10:31:21Z
- **spec-kit version**: 0.0.22
- **Install source**: https://gitlab.alibaba-inc.com/cloud-native-ai/spec-kit.git @ 127753962c10553206b779ffefed8c7723e01686

| Created | Unit | Partial | Summary |
|---------|------|---------|---------|
| 2026-08-07T10:35:37Z | skill:improve-skills | False | 针对 dispatch-workitem 的拆解能力缺失做了一轮证据驱动改进。证据来自 09_任务管理 项目 2026-08-07 的真实运行：父需求 85228984 把 5 个子需求作为 prose 章节写进描述、子项用文本行「父需求： |
| 2026-08-07T13:38:11Z | skill:improve-team | False | 按 goal-editing.md 完成用户明确的双目标重定义与 5 成员扩编（3 项目采集员+审核员+分解员），结构保形、未触碰无关字段，证据来自 3 份 runs 报告（0.595→0.895 收敛轨迹）。执行干净。 |
| 2026-08-07T13:44:25Z | skill:improve-skills | False | Ran one improvement loop on dispatch-workitem after its decomposition capability expansion. The loop found and fixed the |
| 2026-08-07T14:29:37Z | skill:summarize-project | False | 非交互模式由团队边界触发，稀疏材料（无排期/无里程碑/状态全 unknown）按降级形态完整产出 summary.md + WBS 渲染三件套；生成器 coverage 口径不一致与 CG-0 遗留检查是两个摩擦点。 |
| 2026-08-07T14:29:37Z | skill:create-team | False | run 模式完成：预览确认门禁、3 采集 Agent 单块并行派发、审核→分解→交付流水线、运行报告与 goal summary 全流程走通；混合意图（run 中夹带结构修改）先经 improve-team 落盘再执行，流程顺畅。 |
| 2026-08-10T11:42:45Z | skill:create-skills | False | 按 create-skills 全流程在 profiles（Spec Kit project mode）创建 aso-workspace 并按 R1 完成 SSOT 固化、双链接扩散、三处登记与终验；悟空注册因会话内无对应 MCP 工具而受 |
| 2026-08-11T07:27:35Z | skill:create-skills | False | 本次用 create-skills 创建 profiles 侧 aliyun-workspace/aliyun-document 两个前门技能，并配合 cws-lib-python 侧改名脱敏，完成 R3 分层。skill 的骨架（fron |
| 2026-08-11T07:40:49Z | skill:improve-skills | False | 本次用 improve-skills 处理 create-skills 的三条反馈：证据引擎两通道可用但只给出计数/主题类信号（按红线未据此定缺陷），真正的依据是本次执行的直接症状与一条复现主题；据此在上游 spec-kit 落两条契约行  |
| 2026-08-11T07:44:28Z | skill:improve-skills | False | 以 aso CLI v1.0.6 首轮只读冒烟的实测输出为证据，对 aso-workspace 做最小修改：修正认证缺失的退出码分诊、改用文本判定认证状态、新增坑点 16。改动均有本次命令输出支撑，改后以实跑规则校验（RULE1/RULE2 |
| 2026-08-12T08:25:49Z | skill:improve-skills | False | 对 dingtalk-org-tree 做双模式（update 默认 / query 新增）改造：明确高阶技能委派定位、query 多格式输出（markdown 默认 + /draw-* 可视化）、Step0 意图识别，并把 111 行单体 |
| 2026-08-13T06:26:29Z | skill:improve-skills | False | 优化 dingtalk-workspace 双身份诊断，循环整体顺畅：证据文档完备、事实核查（dws auth/api --help 实测）发现 card.md 旧示例凭证 flag 位置与实测验证形态不一致并顺手修正。唯一波折：收尾 gi |
| 2026-08-13T06:46:18Z | skill:improve-skills | False | 本次用 improve-skills 更新 dingtalk-workspace 的消息撤回章节。纠错本身正确（发现并修正了 capability-limits.md 中「个人身份消息无法撤回」的假限制——该表明示「不要重试，直接告知不支持 |
| 2026-08-13T10:31:21Z | skill:improve-skills | False | 本轮为 dingtalk-workspace 增加「发给自然人的消息内容核查」硬约束：SKILL.md 落契约条文 + message-readability.md 承载细则 + message_precheck.py 承载确定性核查，并在 |
