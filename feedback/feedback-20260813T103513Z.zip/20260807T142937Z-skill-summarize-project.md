---
id: "20260807T142937Z-skill-summarize-project"
unit_id: "skill:summarize-project"
unit_type: "skill"
run_id: "dco-summary-20260807"
scope: "local"
feature: "team-triggered-noninteractive"
partial: false
created: "2026-08-07T14:29:37Z"
summary: "非交互模式由团队边界触发，稀疏材料（无排期/无里程碑/状态全 unknown）按降级形态完整产出 summary.md + WBS 渲染三件套；生成器 coverage 口径不一致与 CG-0 遗留检查是两个摩擦点。"
---

## Review
非交互模式由团队边界触发，稀疏材料（无排期/无里程碑/状态全 unknown）按降级形态完整产出 summary.md + WBS 渲染三件套；生成器 coverage 口径不一致与 CG-0 遗留检查是两个摩擦点。

## Optimization Points
- check-coherence.py 的 CG-0 仍是旧版「源码嵌入正文」检查，与现行「源码只落 assets/*.puml、正文不出现源码块」规范冲突，非交互运行时必然误报 FAIL；建议 CG-0 改为检查 assets/ 内 .puml 与正文引用配对。
