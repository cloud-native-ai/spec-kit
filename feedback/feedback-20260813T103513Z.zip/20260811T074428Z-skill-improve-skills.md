---
id: "20260811T074428Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "aso-workspace-smoke-20260811"
scope: "local"
partial: false
created: "2026-08-11T07:44:28Z"
summary: "以 aso CLI v1.0.6 首轮只读冒烟的实测输出为证据，对 aso-workspace 做最小修改：修正认证缺失的退出码分诊、改用文本判定认证状态、新增坑点 16。改动均有本次命令输出支撑，改后以实跑规则校验（RULE1/RULE2 均 OK），skill-shape 门禁 exit 0。"
---

## Review
以 aso CLI v1.0.6 首轮只读冒烟的实测输出为证据，对 aso-workspace 做最小修改：修正认证缺失的退出码分诊、改用文本判定认证状态、新增坑点 16。改动均有本次命令输出支撑，改后以实跑规则校验（RULE1/RULE2 均 OK），skill-shape 门禁 exit 0。

## Optimization Points
- 退出码分诊表原样照抄上游文档（exit 3 = 认证失败），未经二进制实测校准即写入技能；v1.0.6 实测凭证缺失走 exit 1 + `no credentials found`，exit 3 未观察到。教训：技能创建阶段若二进制缺席，退出码/前置检查类断言应显式标注「文档口径、待实测」，避免以未验证语义驱动 Agent 分诊。
- 前置检查依赖被检命令的退出码（`auth whoami`），未验证该命令是否用退出码表达状态；实测其未登录仍返回 0。教训：状态查询类命令的判定应默认走输出文本匹配，退出码仅作辅助，除非实测确认其编码了状态。
