---
id: "20260818T031107Z-skill-create-team"
unit_id: "skill:create-team"
unit_type: "skill"
run_id: "create-team-goal-based-module-internal-refactor-20260818"
scope: "local"
probe: "skill-create-team-wrapup"
kind: "internal"
slice: "skills"
feature: "025"
partial: false
created: "2026-08-18T03:11:07Z"
summary: "Goal-Based Create 分支端到端走通：引擎 list 精确命中 slug、四要素分析、单团队 parallel 派生、territory 互斥、确认门禁后落盘 team.md。唯一摩擦是 goal 读取缺 CLI 动作。"
---

## Review
Goal-Based Create 分支端到端走通：引擎 list 精确命中 slug、四要素分析、单团队 parallel 派生、territory 互斥、确认门禁后落盘 team.md。唯一摩擦是 goal 读取缺 CLI 动作。

## Optimization Points
- Goal-Based Create 分支要求经引擎 parse_goal 复述 goal，但 goal-utils.py CLI 只暴露 create/validate/list/status/criteria/migrate/targets，无 show/parse 动作，只能退回 cat goal.md 原文注入上下文；建议增加 `show <slug> [--json]`（结构化输出 objective/criteria/status/targets），落实 Summary-First 纪律并避免悬空读取。
