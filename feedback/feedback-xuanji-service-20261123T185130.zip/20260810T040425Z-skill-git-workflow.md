---
id: "20260810T040425Z-skill-git-workflow"
unit_id: "skill:git-workflow"
unit_type: "skill"
run_id: "git-workflow-20260810-bootstrap-checkout"
scope: "local"
feature: "bootstrap-develop-checkout"
partial: false
created: "2026-08-10T04:04:25Z"
summary: "Bootstrap 调谐完成：确认三层分支 main/xuanji/prepub/xuanji/develop，清理破损 doc submodule 残留与符号链接导致的 stash 失败后成功 checkout DEV，生成 .specify/memory/git-workflow.md 并更新 instructions Documentation Map。过程遭遇多次 checkout 中断，"
---

## Review
Bootstrap 调谐完成：确认三层分支 main/xuanji/prepub/xuanji/develop，清理破损 doc submodule 残留与符号链接导致的 stash 失败后成功 checkout DEV，生成 .specify/memory/git-workflow.md 并更新 instructions Documentation Map。过程遭遇多次 checkout 中断，均已安全恢复，用户改动全部保存在 stash 中。

## Optimization Points
- ## Optimization Points
- checkout 大分支前应先探测 submodule 残留状态（`.git/modules/<name>` 是否完整、worktree 是否存在指向破损 gitdir 的 `.git` 文件），本次因 `doc` submodule 残留空壳导致 checkout 反复中断并污染工作区，浪费多轮恢复；Bootstrap/Execute 的前置校验应增加"submodule 健康检查"步骤。
- `git stash push -u` 遇到"beyond a symbolic link"路径会整体失败，技能 troubleshooting 应记录该场景的处置序列（先 `git rm --cached` 或恢复符号链接目标文件再 stash）。
