---
id: "20260818T075109Z-skill-create-team"
unit_id: "skill:create-team"
unit_type: "skill"
run_id: "team-run-module-internal-refactor-20260818T074940Z"
scope: "local"
probe: "skill-create-team-wrapup"
kind: "internal"
slice: "skills"
feature: "025"
partial: false
created: "2026-08-18T07:51:09Z"
summary: "parallel run 端到端成功：4 worker 领土零违规、聚合构建 78 tests 全绿、文档同步、summary produced（降级声明）、run report 落盘。"
---

## Review
parallel run 端到端成功：4 worker 领土零违规、聚合构建 78 tests 全绿、文档同步、summary produced（降级声明）、run report 落盘。

## Optimization Points
- parallel run 的 summary 边界驱动 summarize-project 全量管线（R 档表单 + SQLite + 四图渲染），但 goal 级 run 摘要无工作项表单素材，管线会在 Step 1 阻断；本次依诚实降级手写目标级摘要并声明。建议 create-team/summary-mapping 为 goal 级刷新定义轻量摘要档（区别于全量项目总结），避免每次 run 都触发降级声明。
- token-efficiency: worker 禁 Maven、各自 javac 自检，lead 单次聚合构建——避免了 4 路并行构建对 ~/.m2 的竞争与重复依赖解析开销，实测有效。
