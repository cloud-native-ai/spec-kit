---
id: "20260810T113820Z-skill-create-docs"
unit_id: "skill:create-docs"
unit_type: "skill"
run_id: "authoring-20260810-192134"
scope: "local"
feature: "025"
partial: false
created: "2026-08-10T11:38:20Z"
summary: "Authoring-scope run driven by the input 将模块定义等信息都更新到文档中. Converged the nine-module definition into a new docs/reference/module-structure.md, added the missing reserved root entry ARCHITECTURE.md, fact"
---

## Review
Authoring-scope run driven by the input 将模块定义等信息都更新到文档中. Converged the nine-module definition into a new docs/reference/module-structure.md, added the missing reserved root entry ARCHITECTURE.md, fact-corrected and delinted README (22 validate violations -> 1 tolerated; 134 -> 60 lines; all 20 broken links repaired against the doc/ submodule), and scaffolded the Hugo layer with a successful build. Investigation before acting paid off: the 20 broken links were not dead content but a wrong mount prefix, and the run also incidentally confirmed the as-built module dependency graph matches the contract matrix with zero violations.

## Optimization Points
- The deterministic `validate` reserved-name check flags C-zone compatibility symlinks as violations (`QWEN.md` -> `.specify/instructions.md`), contradicting the skill's own zone rule that such anchors are skipped. It is unfixable by design, so it survives every run and permanently pollutes the violation count, weakening the anti-churn "零收敛" signal. `validate` should skip symlinks (or those resolving into `.specify/`), or emit them under a separate non-actionable kind. Note the current allowlist already tolerates AGENTS/CLAUDE/QODER but not QWEN, so the rule is also internally inconsistent.
- `validate --action` judges links purely by filesystem existence and is blind to git submodules. This repo produced 20 "broken-link" findings that were in fact valid content inside an uninitialized/differently-mounted submodule (`doc/`), so a naive reconcile would have deleted correct links as dead. A submodule-aware distinction (e.g. a `unresolved-submodule-link` kind, or resolving through `.gitmodules`) would make the finding safe to act on.
- The Hugo mount block is computed only from `docs/` subdirectories, so a loose top-level file (`docs/git-workflow.md`) is silently excluded from the published site with no warning. `scaffold-hugo.py --action check` should report unmounted top-level `docs/*.md` as drift, otherwise deferring a taxonomy move quietly costs site coverage.
