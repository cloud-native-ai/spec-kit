---
id: "20260811T065301Z-speckit-instructions"
unit_id: "/speckit.instructions"
unit_type: "command"
run_id: "025-instructions-20260811-144742"
scope: "local"
feature: "025"
partial: false
created: "2026-08-11T06:53:01Z"
summary: "Partial-update run driven by two explicit asks (document the file's own structure; clean leftover doc links). Both delivered: a new 本文结构 section codifying per-section ownership, and removal of stale c"
---

## Review
Partial-update run driven by two explicit asks (document the file's own structure; clean leftover doc links). Both delivered: a new 本文结构 section codifying per-section ownership, and removal of stale cross-doc caveats plus correction of an overstated config fact. The high-value outcome was unplanned — the mandated backup coverage check surfaced two hand-authored items lost in an earlier restructure of this same file, which were verified still valid and restored. Validation ended clean: 9/9 map paths exist, 7/7 symlinks, registry markers intact, no section lost.

## Optimization Points
- The coverage check in Action 6 caught real loss only because it diffed against **every** backup, not the newest: the 2026-08-11 backup was already post-restructure and showed zero drift, while the 2026-08-10 one revealed two hand-authored items silently dropped (`./scripts/build.sh all`, the interface-surface "implemented vs merely declared" warning). The command should state explicitly that section **renames/merges** are the dominant loss vector and that a heading-level diff alone is insufficient — headings matched fine while bullet content vanished. Recommend prescribing a bullet-level diff against the oldest backup too.
- Action 5 tells the agent to run a scripted existence check on Documentation Map Location cells, but in this repo that check is dominated by false positives: shell commands, URL paths (`/api/ui`), and glob patterns (`.specify/memory/features/NNN.md`) all look like paths and report MISS. The guidance should scope the check to the Location column only (as the Documentation Map row check), and note that inline code spans elsewhere are not link targets — otherwise the noise trains the agent to ignore the check.
- The genuinely stale artifacts this run cleaned were not broken paths but **obsolete caveats about other documents** ("README tech-baseline is stale — trust pom.xml") that turn harmful once the referenced doc is fixed. Existence checks cannot detect this class. The command should add an explicit step: re-verify every cross-document quality/staleness assertion against the current target file, since these silently invert from helpful to misleading.
