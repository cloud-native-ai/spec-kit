---
id: "20261030T111409Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261030T101500Z-c3d4"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-30T11:14:09Z"
summary: "Analyze run over a docs-only feature: artifacts are largely self-consistent (29/29 FR rows, 8/8 SC rows, 38 tasks, constitution VII partial disclosed in three places). Two HIGH findings both sit at th"
---

## Review
Analyze run over a docs-only feature: artifacts are largely self-consistent (29/29 FR rows, 8/8 SC rows, 38 tasks, constitution VII partial disclosed in three places). Two HIGH findings both sit at the verification boundary: (1) re-running scaffold-hugo.py changes hugo.toml by 4 mounts (deploy + design), not the declared 'design x2', because the committed hugo.toml is already stale (deploy unmounted) and --action check already reports mounts-synced; (2) the link gate (docs-utils filesystem existence + render-link.html pass-through) cannot detect page-graph breakage, and the mandated docs/deploy/README.md owner pointer is exactly such an unmounted path. Also: coverage-baseline.txt was never frozen (accountant reports baseline-missing, fr-claimed 0/29), and the per-gap checklist accountability had to be reconstructed by hand because the delivered checklist has 0/41 checked.

## Optimization Points
- 1) /speckit.tasks should refuse to finish when account-clause-coverage reports baseline MISSING: the analyze stage inherits an unjudgeable coverage lane and can only report it, never clear it. 2) scaffold-hugo.py --action check should distinguish 'pending generation diff' from 'needs human decision' in a documented field; today clean=false + action=mounts-synced is easy to mis-transcribe as 'all unchanged' (quickstart S1 did exactly that). 3) The analyze skill's checklist-accountability rule needs an explicit answer-form marker: a checklist whose own protocol allows '[ ] + inline fact = answered' leaves 41 boxes that a reader cannot classify. 4) Docs verification should offer a page-graph link check (post-build href resolution) as a first-class gate; filesystem existence plus a pass-through renderer is a green check that cannot go red.
