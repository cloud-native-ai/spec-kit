# Feedback Package Manifest

> This feedback targets the Spec Kit framework itself (templates, commands, skills, scripts, docs) — not the LLM, agent CLI, harness, or any user project code.

- **Generated**: 2026-11-23T10:50:29Z
- **Entries**: 1
- **Time range**: 2026-10-31T22:22:11Z → 2026-10-31T22:22:11Z
- **spec-kit version**: 0.0.22
- **Install source**: https://gitlab.alibaba-inc.com/cloud-native-ai/spec-kit.git @ cdc79cdb52c892e8ed43145860cea2cd6ffdbfdf

| Created | Unit | Partial | Probe | Slice | Summary |
|---------|------|---------|-------|-------|---------|
| 2026-10-31T22:22:11Z | /speckit.requirements | False | speckit-requirements-wrapup | commands | requirements 阶段门禁全部通过；框架侧发现三处降级：flow-class-check 在本仓因缺少框架源码目录返回 framework-source-required；pre-analyze/validate-requireme |
## Exec-Quant Payload

- **Records**: 1
- **Source forms**: records-dir 1, legacy-jsonl 0
- **Skipped unreadable**: 0
- **Truncated**: 0
- **Cap**: 1000 records / 16777216 bytes (triggered: no)
- **Source project**: xuanji-skills
- **Collected range**: 2026-10-31T22:22:06Z → 2026-10-31T22:22:06Z

