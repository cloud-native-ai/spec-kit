---
id: "20261031T222211Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "r20261101T062000Z-s2a0"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-31T22:22:11Z"
summary: "requirements 阶段门禁全部通过；框架侧发现三处降级：flow-class-check 在本仓因缺少框架源码目录返回 framework-source-required；pre-analyze/validate-requirements 需借用外部框架副本（本仓 .specify/scripts/python 未随版本提供这两个脚本）；feedback-utils 因缺 probe-ut"
---

## Review
requirements 阶段门禁全部通过；框架侧发现三处降级：flow-class-check 在本仓因缺少框架源码目录返回 framework-source-required；pre-analyze/validate-requirements 需借用外部框架副本（本仓 .specify/scripts/python 未随版本提供这两个脚本）；feedback-utils 因缺 probe-utils.py 在本仓不可运行。

## Optimization Points
- 建议在框架刷新时把 validate-requirements.py / pre-analyze-check.py / decomposition-check.py 与 probe-utils.py 纳入项目侧 scripts/python，避免跨仓借用；flow-class 对非框架仓应输出稳定的 not-applicable 值域而非 exit 2。
