---
id: "20261016T193050Z-speckit-instructions"
unit_id: "/speckit.instructions"
unit_type: "command"
run_id: "recover-rebuild-20261017"
scope: "local"
probe: "speckit-instructions-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-16T19:30:50Z"
summary: "Recover-mode rebuild completed via manual fallback after the setup script failed on missing cws-lib-bash. All script-equivalent steps were executed by hand (template render, glossary init, skills/tool"
---

## Review
Recover-mode rebuild completed via manual fallback after the setup script failed on missing cws-lib-bash. All script-equivalent steps were executed by hand (template render, glossary init, skills/tools docs, 10 symlinks incl. user-requested QWEN/IFLOW, deprecated-dir cleanup); canonical instructions filled from verified project facts with old-generation content recovered into a new Build & Local Development section. Run reached wrap-up with substantial work. Token efficiency self-check: no raw machine-data dumps, path checks done via scripted loop, no repeated reads — clean; symlink-edit re-injection is harness-side and not avoidable from this unit.

## Optimization Points
- generate-instructions.sh hard-fails when cws-lib-bash is absent (CWS_LIB_BASH_HOME unset) even though its core work (template render, glossary init, skills/tools docs, symlinks) needs only sed/python3/ln. A graceful-degradation mode (warn + continue, per the command template's own Error Handling "warning with fallback") would let recover-mode bootstrap succeed on machines without cws-lib-bash; same applies to refresh-tools.sh JSON manifest generation.
- The command template's doc-map path existence check flags template-prose references (e.g. `.gitexcludes`, `.specify/memory/tools/`, `.specify/specs/<ID>-<slug>/`) as MISSING because the scripted check cannot distinguish normative path claims from explanatory prose; a checked-paths allowlist or structured path column would make the check signal-only.
