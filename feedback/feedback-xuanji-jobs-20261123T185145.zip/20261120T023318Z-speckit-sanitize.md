---
id: "20261120T023318Z-speckit-sanitize"
unit_id: "/speckit.sanitize"
unit_type: "command"
run_id: "20261120T023310Z-sanitize"
scope: "local"
probe: "speckit-sanitize-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-20T02:33:18Z"
summary: "Materials lane ran clean end-to-end: 25 pending findings presented in 3 groups; user released A+B repairs; 5 findings resolved, 20 engine false positives left pending."
---

## Review
Materials lane ran clean end-to-end: 25 pending findings presented in 3 groups; user released A+B repairs; 5 findings resolved, 20 engine false positives left pending.

## Optimization Points
- sanitize-utils.py check_dead_references: command refs are checked against root/templates/commands/<name>.md (pre-layering path; absent today) so /speckit.plan mentions are permanent false positives; REPO_PATH_RE truncates module-prefixed paths (connectors/kafka-connector/src/...) to src/... and tests the substring at workspace root, yielding 18 false dead-refs; apply marks disposition=dismiss as state=resolved instead of dismissed (same-state enum exists), so dismissed findings reopen on the next collect; docs-lane findings (README.md#...) fail is_material_target in apply, so their repairs cannot enter the cleanup plan and rely on auto-resolve.
