---
id: "20260728T025811Z-speckit-instructions"
unit_id: "/speckit.instructions"
unit_type: "command"
run_id: "instructions-2026-07-28-1054"
scope: "local"
partial: false
created: "2026-07-28T02:58:11Z"
summary: "Full reconcile run: restored missing template sections (Task Complexity Rubric, Dogfooding Practice), added Glossary map row, fixed stale root path, preserved all hand-authored sections."
---

## Review
Full reconcile run: restored missing template sections (Task Complexity Rubric, Dogfooding Practice), added Glossary map row, fixed stale root path, preserved all hand-authored sections.

## Optimization Points
- Setup script could auto-detect workspace root drift (recorded Root Path vs actual pwd) and flag it in its output to save a manual check.
