---
id: "20261120T084154Z-speckit-instructions"
unit_id: "/speckit.instructions"
unit_type: "command"
run_id: "20261120T084153Z-a02a60ff"
scope: "local"
probe: "speckit-instructions-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-20T08:41:54Z"
summary: "In-place instructions reconcile: 27 template sections injected, legacy Resource Registry superseded, Documentation Map updated to six-type docs, VVR-first/connector-unification guidance added, no-subm"
---

## Review
In-place instructions reconcile: 27 template sections injected, legacy Resource Registry superseded, Documentation Map updated to six-type docs, VVR-first/connector-unification guidance added, no-submodule state and VVR clone HEAD refreshed; R1 compressed 4 oversized sections. Size 45,896 -> 41,784 B, still 2,872 B over budget.

## Optimization Points
- 1) After all R1 candidates are compressed, the file remains over budget due to project-filled/hand-authored sections (Documentation Map, Tech Stack, Connector Provenance, Project-Specific Guidance); the skill offers no route below the R2 4 KB threshold — consider a route for out-of-budget-but-under-threshold project content; 2) the template's ID Register section references .specify/register.md, which setup does not create; 3) AI agent approval list conflict (Constitution XI vs compatibility list) remains pending; 4) token-efficiency: full-file reads plus injected sections are large; a diff-oriented section read would reduce context.
