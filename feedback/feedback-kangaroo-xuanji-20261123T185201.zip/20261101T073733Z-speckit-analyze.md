---
id: "20261101T073733Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261101T1535Z-l2-metadata-analyze"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
feature: "004-l2-metadata-flow"
feature_id: "004"
partial: false
created: "2026-11-01T07:37:33Z"
summary: "Analyze 004-l2-metadata-flow (read-only): 19 findings (0C/4H/7M/8L) on the spec chain. Deterministic gates green: validate-requirements ok (41 rows), validate-tasks PASS (2 adjudicated parallel-safe W"
---

## Review
Analyze 004-l2-metadata-flow (read-only): 19 findings (0C/4H/7M/8L) on the spec chain. Deterministic gates green: validate-requirements ok (41 rows), validate-tasks PASS (2 adjudicated parallel-safe WARN), pre-analyze requirements/plan/tasks pass, decomposition plan/tasks proceed (30 FR / 34 tasks), doc-consistency reader,evidence,duplicate pass on requirements/plan/checklist and evidence pass on tasks, structure ok (two_way not-run), decision-tensions ok (2 records, high=0), docs-utils violations [], hugo exit 0 / 71 pages. HIGH: FR-003 term list 8 vs 7; FR-011 retryable vs FR-030 rejected non-retryable; FR-016 event_type vs rank ordering key; failure matrix 10 rows vs 10+4. No independent validation wave (no subagent dispatch tool in this runtime); HIGHs use the direct re-read fallback marker.

## Optimization Points
- Fix before implement: (1) reconcile FR-003 to the eight-term list incl. L1/L2 across plan §1.3/XII and tasks T005/T019; (2) split rejected (non-retryable) from failed (retryable) in FR-011 and T008; (3) use (observed_at, rank, batch_id, line) in FR-016 and T010; (4) set the failure matrix to 10 core + 4 new = >=14 rows in DoD-5/T-002/T015/T026/plan 8.1. Then add 'empty' to the producer status vocabulary, refresh stale L1/index/target-structure status notes, and define evidence-list granularity.
