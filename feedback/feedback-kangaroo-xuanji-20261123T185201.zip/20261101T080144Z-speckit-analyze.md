---
id: "20261101T080144Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261101T1605Z-l2-analyze2"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-01T08:01:44Z"
summary: "analyze2 rerun on l2-central-aggregation-design: 11/11 prior closure re-verified independently (10 closed, 1 LOW partial), 7 new findings (0 C / 0 H / 4 M / 3 L), verdict PASS. Two gate-behaviour defe"
---

## Review
analyze2 rerun on l2-central-aggregation-design: 11/11 prior closure re-verified independently (10 closed, 1 LOW partial), 7 new findings (0 C / 0 H / 4 M / 3 L), verdict PASS. Two gate-behaviour defects surfaced: (1) pre-analyze-check.py --repo defaults to empty and check_paths returns immediately, so the documented gate line without --repo silently reports advisories=0 (false green); the canonical --repo . form reports 27. (2) doc-consistency-check.py returns rc 0 for a spec-dir verify where reader is not-applicable, so a 4-face claim made without --path proves only three faces.

## Optimization Points
- pre-analyze-check: make --repo default to the workspace root (or fail closed when absent) instead of skipping the path lane, and print an explicit 'path-lane skipped' degradation line so advisories=0 can never be read as a clean lane. doc-consistency-check: treat reader=not-applicable as a degradation in the faces map (like count's not-evaluated) so the four-face gate cannot pass on three faces.
