---
id: "20261030T063836Z-speckit-clarify"
unit_id: "/speckit.clarify"
unit_type: "command"
run_id: "r20261030T062247Z-99a0"
scope: "local"
probe: "speckit-clarify-wrapup"
kind: "internal"
slice: "commands"
feature: "003-l1-overall-architecture"
partial: false
created: "2026-10-30T06:38:36Z"
summary: "clarify Mode A on requirements.md (flow_class=expression/design-note): 3 underspecified areas decided and written back — (1) the SSOT convergence surface now includes README.md, docs/index.md and docs"
---

## Review
clarify Mode A on requirements.md (flow_class=expression/design-note): 3 underspecified areas decided and written back — (1) the SSOT convergence surface now includes README.md, docs/index.md and docs/concepts/index.md as a closed set (FR-001 amended, SC-003 2/2→5/5), (2) front-page partition labels kept as navigation labels mapped 1:1 to the six canonical slugs (FR-003 amended), (3) design-map.md DM_01 closure + L1 row + as-of refresh in scope (new FR-029/SC-013). Derived counts recounted: 303 lines / 42 definition rows / FR 29 / SC 13; validate-requirements ok with doc-order pass, doc-consistency evidence=pass and reader=pass, pre-analyze rerun pass (0 errors, 21 advisories). Two corrections disclosed: baseline overstated validate-requirements as the only deterministic gate (driver-skill pre-analyze did run), and Key Entities was 9 vs measured 10.

## Optimization Points
- 1) check-prerequisites.sh hard-fails on unset CWS_LIB_BASH_HOME although the flow only needs paths — a paths-only mode should not require the cws-lib dependency. 2) pre-analyze-check.py lives only under the driver skill, not .specify/scripts/python/, so stage gates cite a path that does not resolve in the client runtime; ship or register the canonical path. 3) Mode A integration rules require re-checking checklist derived counts, but nothing re-measures counts that were wrong before the run (Key Entities 9 vs 10) — the checker should recompute every row it can, not only the changed ones. 4) The taxonomy's Completion Signals category has no anchor for 'who may serve as an independent reader in an unattended run'; expression-gates covers judges but not the reader-review staffing, which surfaced as a real ambiguity here.
