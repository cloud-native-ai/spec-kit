---
id: "20261101T080228Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261101T080500Z-l2-metadata-analyze2"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-01T08:02:28Z"
summary: "analyze2 rerun on 004-l2-metadata-flow: 18 of 19 prior findings verified closed at every declared propagation surface by independent re-read + reproduced source commands; AN-12 stays accepted (coverag"
---

## Review
analyze2 rerun on 004-l2-metadata-flow: 18 of 19 prior findings verified closed at every declared propagation surface by independent re-read + reproduced source commands; AN-12 stays accepted (coverage baseline-missing). Rerun found 1 new MEDIUM (requirements FR-024/US4/SC-005-Source still anchor F1 per-item three-state to L1 §8.2, which only holds component-level rows) and 2 new LOW (plan 'two entry pages' vs tasks 'three paths'; CHK-002 internal count 'two places/four places' vs six loci). All 20 gates rerun with recorded rc.

## Optimization Points
- Rerun delta is most useful when each prior finding carries its closure command, not only its landing path: 18 closures reproduced in one pass because the dispositions row named file:line. Two gaps worth framework attention: (1) a finding whose propagation surface is declared narrower than the defect class leaves a stale pointer upstream (AN-06 -> A2-01) - suggest requiring a 'requirements+plan+tasks+checklist+registry' sweep prompt in the remediation checklist; (2) the doc-consistency reader face reports not-applicable at spec-dir scope but fail per-file, so a dir-scope gate run silently loses the tasks.md reader-declaration-missing signal - suggest the dir-scope aggregate surface the worst per-file verdict instead of not-applicable.
