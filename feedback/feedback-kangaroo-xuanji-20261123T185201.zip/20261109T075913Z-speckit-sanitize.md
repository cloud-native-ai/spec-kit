---
id: "20261109T075913Z-speckit-sanitize"
unit_id: "/speckit.sanitize"
unit_type: "command"
run_id: "20261109T071500Z-sanitize-materials"
scope: "local"
probe: "speckit-sanitize-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-09T07:59:13Z"
summary: "Materials lane ran the seven-stage flow on the current ledger (803 findings, 796 pending). Stage 3 found 0 semantic candidates. Stage 4/5 concluded no cleanup plan: the pending backlog is dominated by"
---

## Review
Materials lane ran the seven-stage flow on the current ledger (803 findings, 796 pending). Stage 3 found 0 semantic candidates. Stage 4/5 concluded no cleanup plan: the pending backlog is dominated by engine false-positive classes (client-runtime resolution bases for command/skill refs; repo-qualified cross-repo citations inside dated spec records), so zero destructive items, zero repair candidates, zero deletion/movement. Two prior dismissals had reopened, which the engine's merge rules explain: apply writes state=resolved, and resolved reopens on re-detection; dismissed is unreachable for programmatic findings. Defects reported upstream via this entry. Docs sync evaluation: 无需记录.

## Optimization Points
- sanitize-engine-defect: command refs resolve against <root>/templates/commands/ and skill refs against <root>/skills/ — both absent in client deployments (commands live in .qoder/commands + installed specify_cli; skills in .specify/skills). 315 of 796 pending findings are this false-positive class; prior 2026-10-13 dismissal already documented the same root cause
- sanitize-engine-defect: cross-repo citations written as `<repo>:<path>` (xuanji-doc:docs/design/index.md, xuanji-function:docs/reference/kb-ingestion.md, xuanji-iac:templates/flink_region_map.lst) are extracted without the repo qualifier and checked against this workspace; ~480 pending findings come from dated spec records where cross-repo/未建 paths are deliberate (006 plan-gates.md L38 records the same class as accepted advisories)
- sanitize-engine-defect: disposition dismiss applies as state=resolved, and resolved findings reopen on re-detection; state=dismissed is unreachable for programmatic findings (record accepts semantic verdicts only) — dismissal is non-durable (observed: 00acedccf835 dismissed 2026-10-13, reopened 2026-10-14, pending again today)
- outcome: no cleanup plan written and no apply run; zero deletion/movement; 796 pending findings left in the ledger deliberately (evidence insufficient to warrant material edits; spec artifacts are dated records)
- token-efficiency: sanitize-utils collect JSON envelope is ~75KB because store.pendingTargets enumerates all 796 targets; this run consumed the digest only (collect output redirected to a file and parsed) — engine could offer digest-only output or cap the list
