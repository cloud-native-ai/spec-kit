---
id: "20261023T103842Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261023T1532Z-arch"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-23T10:38:42Z"
summary: "analyze: 0 CRITICAL/0 HIGH after remediation; corrected target-graph protocol-label provenance and hardened GATE-1/2/7/9; coverage accountant baseline-missing remains a process gap."
---

## Review
analyze: 0 CRITICAL/0 HIGH after remediation; corrected target-graph protocol-label provenance and hardened GATE-1/2/7/9; coverage accountant baseline-missing remains a process gap.

## Optimization Points
- protocol-label provenance; plan task-map drift; false-green gates; feature stage record; coverage baseline
