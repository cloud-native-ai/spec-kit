---
id: "20261101T103925Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261101T143600Z-c2a0"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "008-l2-consumption-flow"
feature_id: "008"
partial: false
created: "2026-11-01T10:39:25Z"
summary: "implement 阶段对 Feature 008（28 FR / 10 SC / 34 tasks）执行 S5 收尾：T027 读者判分收口（两名独立读者各 6/6、三路径 2/3/1 跳、blocking 0，读数针对修复前 blob 3b8853e 并披露 S4c-fix 后未重评）、T029 追溯表（28 FR + 10 SC，缺口 0）、T030 verification（SC 全 pa"
---

## Review
implement 阶段对 Feature 008（28 FR / 10 SC / 34 tasks）执行 S5 收尾：T027 读者判分收口（两名独立读者各 6/6、三路径 2/3/1 跳、blocking 0，读数针对修复前 blob 3b8853e 并披露 S4c-fix 后未重评）、T029 追溯表（28 FR + 10 SC，缺口 0）、T030 verification（SC 全 pass / DoD 全 pass / deferred none）、T031 Feature 008 Planned→Implemented、T032 全量门禁 V1–V10+validate-tasks+decomposition+pre-analyze（全绿）、T033 五项范围自检（DM_02 仍 open、事实源未刷新、无组件仓改动、无 apply/deploy/push、无 F1–F4 正文）、T034 按 FR-024 八条白名单提交。

## Optimization Points
- ① GATE-5 的 grep -cE '^\| *[0-9]+ *\|' 判据对首列为编号/带圈序号的表（§7.4、§4.2）恒为 0，应统一改为 awk 数据行计数并加 fixture；② GATE-4/T021 的 --numstat 单文件汇总只数「有改动的文件」，数不到变更行，建议主判据直接用 git diff -U0 | grep -c '^@@'；③ 读者评审与页面修复的时序（读者读 A 版、修成 B 版）需要一个标准字段承载「post-reader correction」，否则 verification 只能自由叙述；④ T027 的判分义务在 tasks 里与 T029/T030 串行，实际可与 T028 并行，建议在模板中标注可并行；⑤ implement 收尾的提交哈希无法自引用，建议模板明确用「本条交付提交 + closeout 记录」的写法。
