---
id: "20261101T080001Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261101T080200Z-analyze2"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-01T08:00:01Z"
summary: "analyze2 rerun on 006: 9/9 prior dispositions independently re-verified; 8 closed, B-01 partial (its replacement wording now contradicts L1 §8.1's three reading readings); one new HIGH (A2-01) and one"
---

## Review
analyze2 rerun on 006: 9/9 prior dispositions independently re-verified; 8 closed, B-01 partial (its replacement wording now contradicts L1 §8.1's three reading readings); one new HIGH (A2-01) and one new MEDIUM (A2-02) found; gates all reproducible with two reading caveats (pre-analyze advisories depend on --repo; doc-consistency reader face needs explicit --path).

## Optimization Points
- Analyze dispatch should require --repo . on pre-analyze and explicit --path on doc-consistency; otherwise a naive rerun reports 0 advisories and reader=not-applicable, which hides the real reading. Also: a remediation that rewrites a count against an owner (three reading 口径 -> four readings) needs the owner's own enumeration quoted, not re-counted.
