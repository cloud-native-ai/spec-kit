---
id: "20261101T073325Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261101T073000Z-analyz"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
feature: "006-l2-regional-processing-flow"
feature_id: "006"
partial: false
created: "2026-11-01T07:33:25Z"
summary: "analyze 阶段完成，六面门禁与确定性门复跑全绿（flow-class expression、validate-requirements 0 error、validate-tasks PASS、decomposition proceed、pre-analyze pass、decision tensions ok、four faces pass、structure ok、docs-utils ["
---

## Review
analyze 阶段完成，六面门禁与确定性门复跑全绿（flow-class expression、validate-requirements 0 error、validate-tasks PASS、decomposition proceed、pre-analyze pass、decision tensions ok、four faces pass、structure ok、docs-utils []、hugo 0/71），但跨产物一致性分析判 FAIL：0C/3H/3M/3L。三个 HIGH 均为计数/数据不一致且会传播到 implement：① plan Evidence List 实际 18 条断言，plan/tasks/checklist/features 五处写成 19 条（19 含表头）；② SC-009 Source 写陈旧清单 8 行，而 FR-028/DoD-6/T023 写 10 行 / 7 文件；③ plan Evidence List 把 cn-huhehaote 写成 0/0，而 requirements/Phase 0/tasks/plan-gates 均写 0/3。MEDIUM：stale-scan 命令在 plan row 17 与 SC-009 Source 用朴素空格式（tasks 已证会漏 data-pipeline、误读 148 条）；global-center 档位未冻结复算命令/期望值（可能是缺失的第 19 条证据行）；clarify 新增 SC-009/010/011 的证据落点不一致。LOW：state 词表把 deprecated 称作第五个状态值；features/006.md 的 plan 摘要把风险/范围行数写成 7/7（实为 8/6）；Evidence List 跨仓说明漏列 1–4/15 行。已只读复跑所有门禁并核 46/10/26、10 枢纽 3/3、三例外与 me-east-1/cn-shanghai-cloudspe 读数；未改任何制品。同作者检测与 C/H 验证未能委派子代理（本环境无派发工具），C/H 以直接复读降级并逐条给 evidence_supported/not_supported。

## Optimization Points
- 1) 建议 create-plan/create-tasks 固定表格行数口径为「数据行 = 匹配行 - 表头行」，并给出可复跑命令，避免 19 vs 18 的 off-by-one 跨五个产物传播。2) clarify 写回 SC Source 时强制引用 clarify-measurements 的最新行数（本次 8 vs 10 即旧口径残留）。3) analyze 的 subagent-unavailable fallback 建议固化「直接复读」的标记与证据字段模板，减少每次自行裁决。
