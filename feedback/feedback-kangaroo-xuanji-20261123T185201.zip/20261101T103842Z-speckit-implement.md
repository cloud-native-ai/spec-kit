---
id: "20261101T103842Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261101T174800Z-l2-metadata-implement"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "004-l2-metadata-flow"
feature_id: "004"
partial: false
created: "2026-11-01T10:38:42Z"
summary: "implement 阶段（S1–S5b，16:11–17:48）跑完 34 行任务但**从未执行三步 wrap-up**：无 run-determination、无 exec-quant、无 feedback 记录，17 份阶段证据与 verification.md 也零提 checklist（48 条 0 已答、无 waivers.md）。review 判 P0/P1 后于 review-fix"
---

## Review
implement 阶段（S1–S5b，16:11–17:48）跑完 34 行任务但**从未执行三步 wrap-up**：无 run-determination、无 exec-quant、无 feedback 记录，17 份阶段证据与 verification.md 也零提 checklist（48 条 0 已答、无 waivers.md）。review 判 P0/P1 后于 review-fix 补跑三步并落 implement-wrapup.md。

## Optimization Points
- ① checklist 豁免门补无人值守分支（无交互时自动写四项 waiver 并把未作答计数带进收尾报告）+ 机器可判探针 checklist unresolved=0 OR waivers.md exists；② 阶段收尾把三步 wrap-up 做成硬门禁（缺任一记录即不得推进下一阶段），并把记录写进运行域目录避免每条特性分支携带 20+ 条越界路径；③ 提交门禁用区间 diff（base...HEAD）核对白名单，不用 git show HEAD。
