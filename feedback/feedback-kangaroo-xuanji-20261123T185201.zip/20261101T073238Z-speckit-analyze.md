---
id: "20261101T073238Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261101T1540Z-l2-analyze"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-01T07:32:38Z"
summary: "analyze stage: read-only cross-artifact check over requirements/plan/tasks/checklist for L2 central-aggregation; all deterministic gates green except one out-of-scope reader face on tasks.md; 11 findi"
---

## Review
analyze stage: read-only cross-artifact check over requirements/plan/tasks/checklist for L2 central-aggregation; all deterministic gates green except one out-of-scope reader face on tasks.md; 11 findings (1 HIGH / 4 MEDIUM / 6 LOW). HIGH: FR-022/SC-003/DOD-6/T015/T025/CHK-031 all use the value set current/target/deprecated/unknown, but L1 §8.1 owns current/target/both/unknown with deprecated as a qualifier — a legitimate both double-read cannot land in the required one-of-four and 'no single-column adjudication' makes the criterion self-contradictory.

## Optimization Points
- When a spec enumerates a vocabulary owned by L1, the analyze pass should diff the enumeration against the owner's value set mechanically (a small check that extracts backticked value sets from the spec and compares with the owner table) instead of relying on reading; this defect was inherited verbatim by six downstream locations. Also: the tasks-stage operator table omits the reader face, so --faces reader on tasks.md fails by construction — record that as out-of-scope explicitly, or add a Readers block to the tasks template.
