---
id: "20261029T034142Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "20261029T034500Z-review-007"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-29T03:41:42Z"
summary: "两段式组合本身可用：过程段与代码段各自落盘、严重后果度不混算。但特性状态停在 Planned 时，命令唯一判定的 Implemented → Ready for Review 没有源状态，只能作为 finding 汇报；同时 statement 要求 Implemented 前置、verification 又把提升排到 review 之后，两步互为前置。"
---

## Review
两段式组合本身可用：过程段与代码段各自落盘、严重后果度不混算。但特性状态停在 Planned 时，命令唯一判定的 Implemented → Ready for Review 没有源状态，只能作为 finding 汇报；同时 statement 要求 Implemented 前置、verification 又把提升排到 review 之后，两步互为前置。

## Optimization Points
- 在 review 命令里显式处理『源状态不是 Implemented』这一分支：给出命名结论（如 status-precondition-unmet）并说明应回哪一步补齐，而不是让执行者自拟处置。
