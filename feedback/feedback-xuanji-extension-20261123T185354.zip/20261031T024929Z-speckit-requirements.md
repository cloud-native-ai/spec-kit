---
id: "20261031T024929Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "r20261031T023000Z-e7a1"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
feature: "008-l3-component-design"
feature_id: "023"
partial: false
created: "2026-10-31T02:49:29Z"
summary: "Requirements stage for the xuanji-extension L3 component design note (expression / design-note). Produced requirements.md with 29 FR / 10 SC / 5 user stories / 12 edge cases, a requirements-quality ch"
---

## Review
Requirements stage for the xuanji-extension L3 component design note (expression / design-note). Produced requirements.md with 29 FR / 10 SC / 5 user stories / 12 edge cases, a requirements-quality checklist, four baseline evidence files and a stage JSONL record. Feature 023 registered (index 22->23 rows, Total Features recomputed). Gates: validate-requirements ok 0 error/0 warning (276 lines, 39 definition rows); pre-analyze-check --stage requirements pass errors=0 advisories=15 (all missing-path on the not-yet-authored docs/design/index.md and the cross-repo docs/modules page); decomposition-check --mode plan proceed (fr_count=29 < 30). Expression faces pre-commit: reader pass, duplicate pass, evidence not-evaluated (no commit history); post-commit re-run: evidence pass, 0 findings, 0 degradations. Committed 2a558c4 with the prescribed single-line message; worktree clean; nothing pushed.

## Optimization Points
- 1) create-new-requirements.sh begins with 'git checkout -b', which fights the line-worktree model where the declared carrier branch must not move; a --no-branch or --branch-current switch (or honoring an existing SPECIFY_LINE_BRANCH) would let the documented scaffold path run unchanged instead of being reproduced by hand. 2) The client runtime ships neither decomposition-check.py nor a feature-level flow-class lookup (spec:<id> is rejected), so an expression line must record owner-unavailable and borrow the driver-side script from the framework source; shipping the three driver gates in the client runtime would remove that asymmetry. 3) doc-consistency-check's evidence face fires on lines that merely quote the marker literal while describing the rule (FR-005/SC-002 tripped themselves); a code-span exemption or an explicit 'quoted marker' escape would prevent self-inflicted findings. 4) The requirements template's 'Measurement Sources' shape invites single-id bullets that the validator parses as duplicate SC definitions; a template hint to keep the id list in one bold span would avoid the three-finding first run.
