---
id: "20261111T111353Z-speckit-sanitize"
unit_id: "/speckit.sanitize"
unit_type: "command"
run_id: "sanitize-20261111T1125Z"
scope: "local"
probe: "speckit-sanitize-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-11T11:13:53Z"
summary: "--lane all: materials 264 pending dead-reference findings all triaged and dismissed (command/skill layout false positives, prefix-omitted paths, sanctioned cross-repo refs, dated records); 285/285 res"
---

## Review
--lane all: materials 264 pending dead-reference findings all triaged and dismissed (command/skill layout false positives, prefix-omitted paths, sanctioned cross-repo refs, dated records); 285/285 resolved, 0 pending, no delete/move. Retention: 1 exec-quant monthly summary + 16 receipts, 1 run-determination summary + 1 receipt, 1 session note promoted ephemeral and retired after user approval; 62 blocked backlog (24 open feedback, 21 unsettled determinations) retained. Renumber: 0 collision groups.

## Optimization Points
- 1) dead-reference checker resolves command refs against templates/commands/ and skill refs against root skills/, neither of which exists in a client install (commands ship under .qoder/commands/, skills under .specify/skills/) -> 180 of 264 findings were layout false positives. 2) apply writes dismiss as state 'resolved', so the next collect reopens dismissed false positives (26 reopened this run); the merge code's 'dismissed' state is never written - make dismiss sticky. 3) token-efficiency: collect inlines all pendingTargets and apply inlines every executed row (73KB this run); add a counts-only mode for large ledgers.
