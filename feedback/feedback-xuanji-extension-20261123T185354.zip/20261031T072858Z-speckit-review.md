---
id: "20261031T072858Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "r20261031T100000Z-e7a1"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-31T07:28:58Z"
summary: "Final review of docs-only feature 008 (expression / design-note). Delivery verified clean: four expression faces pass, GATE-1/3/4/5/6/7 re-ran green, five derived counts reconcile (14/13/4/2.0.0+14/8/"
---

## Review
Final review of docs-only feature 008 (expression / design-note). Delivery verified clean: four expression faces pass, GATE-1/3/4/5/6/7 re-ran green, five derived counts reconcile (14/13/4/2.0.0+14/8/15/46), 31 tasks closed, two independent reader reviews pinned to blob e6b8377 then 87eceb0, src/ untouched and nothing pushed. The failing verdict comes from process defects, all reproducible: (1) the plan Constitution Check enumerates only numbered principle headings, so a constitution MUST in 开发工作流 surfaced only as an analyze CRITICAL and a 项目约束 README MUST was overridden with no Complexity Tracking row; (2) GATE-1 strips chapter numbers before asserting, so a doc numbered 1,3,5..21 still yields GATE1 True 11 (I mutated the delivered page and confirmed); (3) the L1-overlap criterion counts the mandated cross-repo path literal as plagiarism, was unsatisfiable, and was fixed only in tasks/verification while plan.md still publishes the old criterion plus a contaminated non-tautology reading (13 = 12 literal wins + 1 genuine); (4) docs-utils has no orphan/inbound-link check, so a new docs/design/ page shipped with zero product-facing inbound links and the docs gate stayed at its 2-entry baseline.

## Optimization Points
- 1) plan-template Constitution Check: add a second mandatory table enumerating every MUST-bearing bullet of 项目约束与交付标准 / 开发工作流与审查要求 / Governance, each answered met / waived -> CT-n / n-a. 2) tasks-template Completion Gate: every shape gate must assert the labelled form it claims and ship one recorded mutant that makes it red (a gate-mutation-check.py would turn this into a run). 3) implement command: a change to a gate criterion or SC measurement is a decision - rewrite the owning plan/requirements artifact in the same closeout and log criterion_change old->new->why. 4) docs-utils: add orphan-page and unlisted-dir violation kinds so a new page cannot ship entry-less while the docs gate reports zero NEW. 5) ship text-overlap.py --exclude-literal --explain --expect (sdd-loop-driver/overlap-check.py covers path collisions, not text) so cross-repo duplication checks have one inspectable command instead of a hand-rolled one-liner whose total a mandated literal can satisfy. 6) implement Completion Gate: consume the checklist (per-item verdicts or explicit skipped(reason)) and close its Status. 7) analyze round-N reports must end with a machine-readable residual disposition table that implement imports into verification.md. 8) gate evidence paths must be run-scoped or append-only so a pre-delivery baseline survives the delivery. 9) verification-log template: fixed ISO offset for reviewed_at plus commit_map=... for phase-to-commit traceability. 10) review Handoffs: make register-id registration conditional on the register existing (this project has none), or key ids by report path.
