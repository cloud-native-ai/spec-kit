---
id: "20261031T025600Z-speckit-clarify"
unit_id: "/speckit.clarify"
unit_type: "command"
run_id: "r20261031T023000Z-e7a1"
scope: "local"
probe: "speckit-clarify-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-31T02:56:00Z"
summary: "Unattended Mode A clarify: the skill's question loop presupposes a user, so the five decisions were agent-ratified and had to be labelled as such in the Clarifications head; the command template lists"
---

## Review
Unattended Mode A clarify: the skill's question loop presupposes a user, so the five decisions were agent-ratified and had to be labelled as such in the Clarifications head; the command template lists six wrap-up steps while the skill's Wrap-up embeds only two, so the step set had to be reconciled by hand; the append-only invariant on Clarifications rows has no engine assertion and was verified with grep.

## Optimization Points
- Document an unattended mode (decision rows explicitly marked agent-ratified with per-answer evidence, plus a provenance line), so later phases cannot cite them as user approval; align the skill Wrap-up with the command template's six steps or state the subset rule; add a deterministic check for the append-only Clarifications invariant and for the Deferred-by-assumption scan outcome.
