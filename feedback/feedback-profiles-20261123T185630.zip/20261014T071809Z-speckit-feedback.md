---
id: "20261014T071809Z-speckit-feedback"
unit_id: "/speckit.feedback"
unit_type: "command"
run_id: "speckit-feedback-package-20261014T071321Z"
scope: "local"
probe: "speckit-feedback-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-14T07:18:09Z"
summary: "显式 package 请求的 Path B 打包运行：帽子判定为客户项目（仓库根无 templates/shared/scripts/src/specify_cli，框架目录仅在 .specify/ 运行时镜像下），Path B 系显式请求达成而非路由自选。清单 35 条全 open（28 internal + 7 external），均无 introspection_ref，故未提议 --inc"
---

## Review
显式 package 请求的 Path B 打包运行：帽子判定为客户项目（仓库根无 templates/shared/scripts/src/specify_cli，框架目录仅在 .specify/ 运行时镜像下），Path B 系显式请求达成而非路由自选。清单 35 条全 open（28 internal + 7 external），均无 introspection_ref，故未提议 --include-introspection。打包 28 条 internal 入 feedback-20261014T071321Z.zip（上游检出 GitLab spec-kit，零网络，源文件未动）；cleanup 先 dry-run 预览后实删，28 条移除、7 条 external 留守活动库；计数器未重置（mark-submitted 待用户实际送达后执行）。运行判定四轴全部 not_evaluated（token/elapsed source_unavailable、artifact 无 declared checks、satisfaction 待下一回合）、routing bit=false——本评审基于运行实况而非量测轴。

## Optimization Points
- [token-efficiency] 打包运行的清单盘点注入了全库 JSON：`list --limit 0 --format json` 返回 35 条 ×~1KB ≈34.6KB，输出溢出转存后被整体重读一次（同一内容双重注入上下文）。而打包集合本有确定性来源——`cleanup --dry-run` 的 would_remove 恰好就是 28 条 internal 的精确清单，与人工 JSON 盘点冗余。建议：package 运行的 Summary 步默认用 `--kind internal --disposition open` 过滤清单，或直接以 cleanup --dry-run 作为打包集合预览；全量 JSON 仅在需要逐条审阅时使用。
- [determine 收尾旗标试错] 本轮 determine 调用连续两次 exit 2 才补齐 --run-id 与 --complexity（错误信息每次只暴露一个缺失旗标）。建议 determine 在同一条错误中列出全部缺失的必填旗标，或在 feedback-step.md § Run Determination 给出最小旗标集（unit-id/unit-type/run-id/complexity），减少每次收尾的试错调用。
