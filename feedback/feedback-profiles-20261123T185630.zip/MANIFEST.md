# Feedback Package Manifest

> This feedback targets the Spec Kit framework itself (templates, commands, skills, scripts, docs) — not the LLM, agent CLI, harness, or any user project code.

- **Generated**: 2026-11-23T10:56:30Z
- **Entries**: 1
- **Time range**: 2026-10-14T07:18:09Z → 2026-10-14T07:18:09Z
- **spec-kit version**: 0.0.22
- **Install source**: https://gitlab.alibaba-inc.com/cloud-native-ai/spec-kit.git @ cdc79cdb52c892e8ed43145860cea2cd6ffdbfdf
- **Excluded (non-framework, kept local)**: 27 entries — skill:coaching-skills, skill:create-skills, skill:improve-skills, skill:sdd-loop-driver

| Created | Unit | Partial | Probe | Slice | Summary |
|---------|------|---------|-------|-------|---------|
| 2026-10-14T07:18:09Z | /speckit.feedback | False | speckit-feedback-wrapup | commands | 显式 package 请求的 Path B 打包运行：帽子判定为客户项目（仓库根无 templates/shared/scripts/src/specify_cli，框架目录仅在 .specify/ 运行时镜像下），Path B 系显式请求 |
## Exec-Quant Payload

- **Records**: 25
- **Source forms**: records-dir 25, legacy-jsonl 0
- **Skipped unreadable**: 0
- **Truncated**: 0
- **Cap**: 1000 records / 16777216 bytes (triggered: no)
- **Source project**: profiles
- **Collected range**: 2026-10-21T04:34:47Z → 2026-11-20T08:58:35Z

