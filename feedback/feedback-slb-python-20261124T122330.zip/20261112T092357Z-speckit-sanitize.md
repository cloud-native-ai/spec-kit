---
id: "20261112T092357Z-speckit-sanitize"
unit_id: "/speckit.sanitize"
unit_type: "command"
run_id: "20261112T092341Z-sanitize"
scope: "local"
probe: "speckit-sanitize-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-12T09:23:57Z"
summary: "Materials lane run without --auto-reversible. Collect surfaced 303 pending dead-reference findings across 79 spec materials; 59 were anchor citations invalidated by the same-session /speckit.migrate r"
---

## Review
Materials lane run without --auto-reversible. Collect surfaced 303 pending dead-reference findings across 79 spec materials; 59 were anchor citations invalidated by the same-session /speckit.migrate run. Repaired 82 occurrences in 29 spec files, re-collected (59 auto-resolved, 0 new findings), then applied one confirmed single-batch plan dismissing 68 command/skill-token findings. 176 historical path/link findings left pending by user decision. Zero engine failures.

## Optimization Points
- 1) cmd_apply collapses dismiss into state resolved, so dismissed findings reopen on the next collect (216 reopened this run); persist state dismissed (merge machine already honors it) or accept record verdicts for programmatic findings to let repeated runs converge.
- 2) check_dead_references resolves command/skill references against <workspace>/templates/commands and <workspace>/skills (framework-repo roots); in client workspaces installed copies live under .specify/templates/commands and .specify/skills, so every speckit.* and skills/* mention becomes a false positive (68 findings this run). Probe both roots.
- 3) Ledger re-inspection returned the full 300+ row pendingTargets list on both collect and status calls; a count-only projection would avoid dumping machine-managed data into context. token-efficiency
