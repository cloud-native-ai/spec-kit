---
id: "20261125T123744Z-speckit-feedback"
unit_id: "/speckit.feedback"
unit_type: "command"
run_id: "20261125T123750Z-feedback-deliver"
scope: "local"
probe: "speckit-feedback-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-25T12:37:44Z"
summary: "按用户指令执行归属拆分与定向交付：帽子判定=客户项目（根级无 templates/skills/shared/scripts/src/specify_cli）；本项目侧（kind: external）0 条、backlog 无行、无 feedback/ 入站目录 → Path A 无消化材料；1 条 open 条目全为 kind: internal（/speckit.feedback）→ Path"
---

## Review
按用户指令执行归属拆分与定向交付：帽子判定=客户项目（根级无 templates/skills/shared/scripts/src/specify_cli）；本项目侧（kind: external）0 条、backlog 无行、无 feedback/ 入站目录 → Path A 无消化材料；1 条 open 条目全为 kind: internal（/speckit.feedback）→ Path B 打包 feedback-20261125T123658Z.zip（1 条 + 60 条 exec-quant），按入站约定改名 feedback-xuanji-api-20261125T123658Z.zip 拷贝至 cloud-native-ai/spec-kit/feedback/（sha256 双向一致 b4e48ae2…），随后 cleanup 移除该条目并 mark-submitted 重置水位，活动库归零，全程引擎 exit 0、无网络操作。另发现出站孤儿包 feedback-20261125T121944Z.zip 与保留规则/实践不一致，详见优化点。

## Optimization Points
- 出站包缺少可见性：`.specify/memory/feedback/packages/feedback-20261125T121944Z.zip`（今日 20:19 生成）携同一条目但从未送达（入站目录无对应文件）、从未 cleanup、cleanup-log 无登记——是一次半途而废的 package 运行的遗留。盘点步骤只读活动库与 backlog，从不检查 `packages/`，因此这类「已打包未送达/未收口」批次对手工 `ls` 之外的所有流程不可见。建议盘点增加出站孤儿检查：列出 packages/ 中未被 cleanup-log 或 mark-submitted 覆盖的 zip，并在消化报告中作为孤儿批次呈报。
- 打包命名与落位仍为手工确定性步骤：本次仍需人工把 `feedback-<ts>.zip` 改名为 `feedback-<source-project>-<ts>.zip` 并拷贝到入站目录；同一摩擦点于 15:31 的上一条目已记录（建议 `--deliver-to <dir>`），数小时内复发，说明是持续性摩擦而非一次性事件。token-efficiency：该改名是按固定约定执行的确定性变换，却由 LLM 手工完成。建议 package 支持 `--deliver-to <dir>`（纯本地拷贝，零网络红线不变），一次完成打包+按约定命名+落位。
- 出站保留规则与既有实践不一致：path-b 参考第 6 步要求在 mark-submitted 后 `rm` 出站 zip，但本仓库 packages/ 现存 8 个历次 zip 无一被移除，cleanup-log 也将其登记为归档产物。文档应明确唯一保留策略（登记保留或按步删除）；按现文本，每个保留的 zip 都会被上一条孤儿检查误判。
