---
id: "20261018T081723Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "002-embed-dsh-webui-review-20261018"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
feature: "002-embed-dsh-webui"
feature_id: "016"
partial: false
created: "2026-10-18T08:17:23Z"
summary: "Reviewed the 002-embed-dsh-webui SDD chain (requirements→clarify→plan→tasks→implement→verification) as a fresh-context subagent. The report is at .specify/specs/002-embed-dsh-webui/review.md: 0 P0 / 4"
---

## Review
Reviewed the 002-embed-dsh-webui SDD chain (requirements→clarify→plan→tasks→implement→verification) as a fresh-context subagent. The report is at .specify/specs/002-embed-dsh-webui/review.md: 0 P0 / 4 P1 / 6 P2. Main friction: task-state vocabulary cannot express a partially executable task (T010 closed [X] while its bm9 half was unavailable); blockedBy has no waiver form (T027/T028 closed over deferred blockers); the feature index deferred suffix is prose-only; check-prerequisites.sh hard-fails without CWS_LIB_BASH_HOME; and one evidence block contains a self-contradictory timing line.

## Optimization Points
- 1) Add a first-class partial/blocked task state and a blockedBy waiver form to the tasks template + create-tasks/implement skills. 2) Add a machine check for the features.md deferred suffix. 3) Degrade check-prerequisites.sh gracefully when CWS_LIB_BASH_HOME is unset. 4) Extend verification evidence guidance to require coherent command+timing output and a post-commit secret scan.
