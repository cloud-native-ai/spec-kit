---
id: "20261019T164056Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "003-frontend-agent-modules-20261020T0040Z"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
feature: "003-frontend-agent-modules"
feature_id: "017"
partial: false
created: "2026-10-19T16:40:56Z"
summary: "Created requirements for 003-frontend-agent-modules: 6 user stories, 38 FRs, 11 SCs, 36 Shared Strings; deterministic validator 0 error / 0 warning; registered Feature 017 with detail and index cross-"
---

## Review
Created requirements for 003-frontend-agent-modules: 6 user stories, 38 FRs, 11 SCs, 36 Shared Strings; deterministic validator 0 error / 0 warning; registered Feature 017 with detail and index cross-links; committed only the feature artifacts. Friction: the scaffold script required an undocumented CWS_LIB_BASH_HOME path and the Shared Strings consumed-by rule was only discoverable from the validator.

## Optimization Points
- `create-new-requirements.sh` hard-fails with “CWS_LIB_BASH_HOME environment variable is not set” and gives no hint where `cws-lib-bash` might be installed; on this machine it lives at a non-default path, costing a discovery round trip. Add an auto-detect hint (e.g., search known workspace paths) or print the expected install location in the error.
- `validate-requirements.py` enforces bidirectional consistency between a Shared String's `Consumed by` cell and the rows that actually cite `[[STR-NNN]]`, but the requirements template's Shared Strings example does not state that the cell must exactly equal the current citations. Drafts that pre-list future consumers are rejected with a message that reads like a content error. Add a one-line authoring rule to the template/guideline.
