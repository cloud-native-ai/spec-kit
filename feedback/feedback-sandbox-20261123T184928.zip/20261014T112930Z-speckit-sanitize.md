---
id: "20261014T112930Z-speckit-sanitize"
unit_id: "/speckit.sanitize"
unit_type: "command"
run_id: "gate:gate-sanitize-destructive-cleanup:20261014T112930Z"
scope: "local"
probe: "gate-sanitize-destructive-cleanup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-14T11:29:30Z"
summary: "confirm-gate: 破坏性清理批次(24项归档至 .specify/archive/)经 AskUserQuestion 单批前置确认,用户选择『全部执行』后 plan.confirmed=true 才释放执行;首跑因引擎物料根校验拒绝 3 行(零副作用),剔除后重跑成功,零计划外移动。"
---

## Review
confirm-gate: 破坏性清理批次(24项归档至 .specify/archive/)经 AskUserQuestion 单批前置确认,用户选择『全部执行』后 plan.confirmed=true 才释放执行;首跑因引擎物料根校验拒绝 3 行(零副作用),剔除后重跑成功,零计划外移动。

## Optimization Points
- 门控观察:破坏性批次(24 归档)确认前零执行;引擎拒绝(exit 1)亦零副作用
