---
id: "20260911T090022Z-speckit-feedback"
unit_id: "/speckit.feedback"
unit_type: "command"
run_id: "speckit-feedback-package-20260911"
scope: "local"
probe: "speckit-feedback-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-09-11T09:00:22Z"
summary: "Mode 2 package 运行干净完成：默认范围仅打包 submitted_at 之后的新条目（1 条 git-workflow 反馈），10 条已提交批次遗留正确排除；dry-run 预览与实际 cleanup 一致，zip 与 cleanup-log 落盘正常。"
---

## Review
Mode 2 package 运行干净完成：默认范围仅打包 submitted_at 之后的新条目（1 条 git-workflow 反馈），10 条已提交批次遗留正确排除；dry-run 预览与实际 cleanup 一致，zip 与 cleanup-log 落盘正常。

## Optimization Points
- status 输出的 legacy_remaining 字段语义易误读：实为"缺 probe 归因的旧格式条目数"，与 count_since_submission 并列展示时容易误判为"还有 10 条待打包遗留"；建议在 status 输出或命令文档中给出该字段的一句话语义说明，或改名为 legacy_unattributed
