---
id: "20261018T055505Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "2026-10-18-002-embed-dsh-webui-requirements"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-18T05:55:05Z"
summary: "create-requirements run for 002-embed-dsh-webui: scaffold script required CWS_LIB_BASH_HOME manually; validator reported all [[STR-NNN]] citations as missing because they were written inside inline co"
---

## Review
create-requirements run for 002-embed-dsh-webui: scaffold script required CWS_LIB_BASH_HOME manually; validator reported all [[STR-NNN]] citations as missing because they were written inside inline code spans.

## Optimization Points
- Document in create-requirements SKILL.md step 5/6 that [[STR-NNN]] citations must be outside inline code spans, since validate-requirements.py strips code spans before resolving references.
