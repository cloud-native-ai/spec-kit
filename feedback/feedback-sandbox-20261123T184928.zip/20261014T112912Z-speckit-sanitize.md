---
id: "20261014T112912Z-speckit-sanitize"
unit_id: "/speckit.sanitize"
unit_type: "command"
run_id: "run:20261014T112912Z"
scope: "local"
probe: "speckit-sanitize-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-14T11:29:12Z"
summary: "命令生命周期完整:预检/收集/判定/呈报/确认/执行/收尾。破坏性批次经单批确认执行,零中途失败。confirm-gate 门控已单独记录。附引擎缺陷三点(见 points)。"
---

## Review
命令生命周期完整:预检/收集/判定/呈报/确认/执行/收尾。破坏性批次经单批确认执行,零中途失败。confirm-gate 门控已单独记录。附引擎缺陷三点(见 points)。

## Optimization Points
- sanitize-utils apply 对 dismiss 行落 state=resolved,而 merge_findings 有专门 dismissed 终态(注释明示 user verdict stays authoritative)但该态经任何公开动作不可达 —— 销案在下一轮 collect 被重开,本次已手工把 35 条修正为 dismissed;建议 apply 为 dismiss 行落 dismissed 态
- collect 的 dead-reference 检查(经 docs-utils)会扫根级 README.md/CONTRIBUTING.md,但 apply 的 MATERIAL_TARGET_PREFIXES 不含根级文件 —— 同一 target 收录进 ledger 却被 plan 校验拒绝,repair 行不可执行(本次剔除 3 行、由 agent 直接修复后经 auto-resolve 收敛)
- 命令存在性检查不认识本部署的 .qoder/commands/ 位置,导致 speckit.plan/feature/implement/instructions/clarify 共 7 处引用被误报 dead-reference(实际均存在);建议命令注册表按部署兼容层解析
