---
id: "20261111T073642Z-speckit-sanitize"
unit_id: "/speckit.sanitize"
unit_type: "command"
run_id: "20261111T073642Z"
scope: "local"
probe: "speckit-sanitize-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-11T07:36:42Z"
summary: "sanitize materials lane collect: 258 findings (220 pending), 19 semantic candidates; residual probe 0/0; presented for confirmation, nothing applied"
---

## Review
sanitize materials lane collect: 258 findings (220 pending), 19 semantic candidates; residual probe 0/0; presented for confirmation, nothing applied

## Optimization Points
- bulk of dead-reference findings sit in historical .specify/specs/** review and test-evidence documents that cite framework-source-relative paths; they are historical records, not actionable links — bulk repair would corrupt review evidence, so they should be tolerated rather than fixed.
