---
id: "20261101T050929Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261101t050900z-ans2b"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-01T05:09:29Z"
summary: "S2 analyze 第二轮（只读）。上一轮 2 条 HIGH 关闭证据均成立：I-01（iac_whoami 无索引 freshness_note）在 FR-007/FR-025/Edge Cases/envelope C-9/data-model §3+§5.9/tasks T016+T018 六处一致成文；G-01（OUT_OF_SCOPE 唯一触发面）在 FR-021/FR-024/err"
---

## Review
S2 analyze 第二轮（只读）。上一轮 2 条 HIGH 关闭证据均成立：I-01（iac_whoami 无索引 freshness_note）在 FR-007/FR-025/Edge Cases/envelope C-9/data-model §3+§5.9/tasks T016+T018 六处一致成文；G-01（OUT_OF_SCOPE 唯一触发面）在 FR-021/FR-024/errors C-5+C-6/tool C-8/data-model §7+§8/tasks T012+T017/Edge Case 八处一致，七类表已降为 handoff.reason 文案映射并声明可达子集。确定性门重跑：account-clause-coverage ok（65/65 条款、FR 26/26）、validate-tasks PASS 0/0、validate-decision-tensions ok（0 error）。新增 1 条 HIGH：errors-and-handoff C-8 的 INTERNAL 闭集仍只列两类触发（非索引意外异常、终检命中），而 FR-009（修复轮新增的第③类 S1 只读入口不兼容）、data-model §7 与 T017 都是三类，且 FR-009 明令第③类 MUST NOT 归 INDEX_UNAVAILABLE——按 C-8 写测试就无法覆盖第③类。另有 5 MEDIUM / 5 LOW：FR-017 label 的 with_labels=false 与『kind=account 时不得为 null』互斥、FR-022 与 data-model §5.7 的 whoami 新鲜度字段名漂移、FR-022/FR-026 的条款引用组指向无关条款使 FR 26/26 成假阳性、whoami 无索引时 source_commit/worktree_dirty 无空值路径（I-01 例外的残留）、SC-003 取样构成与 200 字符计数单位未定。CRITICAL/HIGH 门判据=1，判 FAIL，建议一轮有界修复后重跑。

## Optimization Points
- 1) 契约闭集（如 INTERNAL 触发面）应从需求单一出处派生并在修复轮做『需求改了、契约是否同步』的反向扫描，避免只改一侧；2) 为『无索引』这类降级场景先枚举 meta 全部 18 键的取值，再写例外，否则每轮只能补几个漏几个；3) FR 覆盖的引用组应校验条款主题与 FR 主题一致（本轮 FR-022→参数表、FR-026→准入矩阵两处误挂使覆盖率门禁成为假阳性）；4) checklist 的『N 条 Shared Strings / N 条 Assumptions』类计数应在追加条目后同批复核；5) 本轮校验波因线路拓扑禁止 qodercli 且执行体无原生子代理工具，退回 direct re-read 并已标注。
