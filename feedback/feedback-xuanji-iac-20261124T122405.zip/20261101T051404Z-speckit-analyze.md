---
id: "20261101T051404Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261101T051300Z-ans3"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-01T05:14:04Z"
summary: "S2 analyze 第三轮（只读确认）。I-08 关闭证据成立：contracts/errors-and-handoff.md C-8 已列三类触发 (a) 非索引意外异常 (b) 响应侧终检命中 (c) S1 只读接口不兼容，六个符号与 FR-003 逐字相同（connect_ro/read_snapshot/refresh_seconds/stale_decision/meta_read/_"
---

## Review
S2 analyze 第三轮（只读确认）。I-08 关闭证据成立：contracts/errors-and-handoff.md C-8 已列三类触发 (a) 非索引意外异常 (b) 响应侧终检命中 (c) S1 只读接口不兼容，六个符号与 FR-003 逐字相同（connect_ro/read_snapshot/refresh_seconds/stale_decision/meta_read/_counts_from_conn），hint 短语与「MUST NOT 归入 INDEX_UNAVAILABLE」齐备，验收补了第③类构造用例；与 requirements FR-009、data-model §7、tasks T017 四处一致（机械比对通过）。确定性门重跑：account-clause-coverage ok（65/65 条款、FR 26/26、0 error）、validate-requirements ok（0/0）、validate-tasks PASS 0/0、validate-decision-tensions ok（3 记录 / 0 error）；零发现下限抽样：6 条单任务行 FR（FR-016→T010、FR-017→T016、FR-019→T011、FR-020→T014、FR-021→T012、FR-022→T016）逐条复核映射属实。CRITICAL 0 / HIGH 0。残留 MEDIUM 6 条：①FR-017 label 末句与 with_labels=false 互斥（carried over）；②FR-022 的 index_available/built_at 与 data-model §5.7 的 index.{available,built_at} 漂移（carried over）；③authz C-5 挂 FR-026、tool-schemas C-2 挂 FR-022 使 FR 26/26 含假阳性（carried over）；④whoami 无索引时 meta.source_commit/worktree_dirty 无空值路径（carried over）；⑤SC-003 取样构成与 FR-007「≤200 字符」计数单位未定（carried over）；⑥requirements Edge Case 与 Clarifications 仍写「INTERNAL 只留给与索引无关的意外异常」，对 FR-009 第②③类是收窄表述（new, surface none）。另 1 LOW：checklist CHK039 前提已由 f2608c768 关闭。工具观察：doc-consistency-check 的 evidence 面在 tasks.md:53 报 grade-asof-unpaired，因该段「证据：」是目录标签而非等级标注，属启发式误报，不计 finding。

## Optimization Points
- 1) 契约/需求/DM/任务四处共用同一封闭集时，可在修复提交后跑一次符号级比对（本轮的六个符号集合比对应固化为校验脚本）；2) 残留 MEDIUM 连续两轮 carried over 说明这些点在无人值守修复轮里不会被顺手处理，建议在断点判定中把「carried over MEDIUM 清单」作为显式输入；3) 文档型校验器的『证据：』标记与路径标签冲突，建议把 evidence 面限定在表格/等级词上下文，减少误报。
