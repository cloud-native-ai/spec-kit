---
id: "20261031T024855Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "r20261031T0249Z-req-1ac1"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
feature: "003-iac-mcp-poc"
feature_id: "020"
partial: false
created: "2026-10-31T02:48:55Z"
summary: "requirements 阶段按 POC 范围裁定产出 41 FR / 12 SC，两个确定性门通过。三处框架摩擦：(1) create-new-requirements.sh 无法用于「分支与 spec 目录已由编排固定」的场景——它无条件 git checkout -b，且编号推导会把当前已存在的 003 分支算进去从而给出 004，只能手工建目录并照模板落盘；(2) flow-class-c"
---

## Review
requirements 阶段按 POC 范围裁定产出 41 FR / 12 SC，两个确定性门通过。三处框架摩擦：(1) create-new-requirements.sh 无法用于「分支与 spec 目录已由编排固定」的场景——它无条件 git checkout -b，且编号推导会把当前已存在的 003 分支算进去从而给出 004，只能手工建目录并照模板落盘；(2) flow-class-check.py 的声明行要求「**Flow Class**: <值>」无尾随空白，而命令模板自身的头部区块用两个尾随空格做 Markdown 换行，照抄模板即得 declaration-malformed；(3) expression-gates.md 记 validate-requirements.py --spec-dir <dir>，实际 CLI 只接受位置参数 path。

## Optimization Points
- (1) 给 create-new-requirements.sh 增 --no-branch/--spec-dir 逃生门，或在分支已存在时降级为「复用当前分支 + 只建目录」；(2) 模板把 Flow Class/Flow Type 两行从尾随空格换行区块中拆出，或在 checker 里容忍行尾空白；(3) 让 owner 文档与 CLI 对齐（要么加 --spec-dir 别名，要么改 expression-gates.md 的调用示例）。
