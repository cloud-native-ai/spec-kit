---
id: "20261101T035251Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "r20261031T101500Z-2bc2"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-01T03:52:51Z"
summary: "S2 requirements 从零产出：26 FR / 10 SC / 21 STR，覆盖 8 工具、信封与 meta 键序、分页两工具、三 header 授权、external/partner 确定性掩码、声明态三态不降级、resource_class 三值、OUT_OF_SCOPE + handoff、七类端到端冒烟；S1 的 23 条 Deferred 全部有归属。validate-req"
---

## Review
S2 requirements 从零产出：26 FR / 10 SC / 21 STR，覆盖 8 工具、信封与 meta 键序、分页两工具、三 header 授权、external/partner 确定性掩码、声明态三态不降级、resource_class 三值、OUT_OF_SCOPE + handoff、七类端到端冒烟；S1 的 23 条 Deferred 全部有归属。validate-requirements 0 error/0 warning，pre-analyze pass 0/0，decomposition proceed 26/30。

## Optimization Points
- 1) create-new-requirements.sh 依赖 CWS_LIB_BASH_HOME，本机未导出时直接退出 1，需临时手动导出 cws-lib-bash 路径才能起跑；建议脚本对缺失依赖给出可执行 hint 而非纯失败。2) 编号派生把当前分支 005-iac-mcp-service 计入已占用，导致脚本自动切到 006 分支并建 006 目录，与线既定 spec 目录 005 冲突；建议在已存在同名目标分支时优先复用分支号而不是 +1。3) flow-class-check 在 requirements.md 尚未存在时返回 owner-unavailable(exit 2)，需要写完声明行后再跑一次才能读到真实类别；建议 lookup 对「尚无文件」与「类别不可解析」给出区分标签。
