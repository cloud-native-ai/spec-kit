---
id: "20261101T052949Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261101T052900z-impl1-tok"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-01T05:29:49Z"
summary: "token-efficiency self-assessment for this run: tasks.md (43 KB / 278 lines) and plan.md (26 KB / 263 lines) were read whole, plus two whole contract files, before any targeted section was needed. The "
---

## Review
token-efficiency self-assessment for this run: tasks.md (43 KB / 278 lines) and plan.md (26 KB / 263 lines) were read whole, plus two whole contract files, before any targeted section was needed. The only sections actually load-bearing for T001-T008 were the task rows, the Environment Prerequisites block, the meta/presentation key tables in data-model 2-5, and the C-1..C-10 clauses. A section-level read (grep the headings, then read the cited ranges) would have cut roughly half of the consumed context without losing any fact — the headings were already visible from the first grep.

## Optimization Points
- For an implement part that covers a contiguous task range, derive the read set from the task rows first and open only the contract/data-model sections those rows cite, instead of opening the whole spec trio. Keep whole-file reads for the file being edited (tasks.md checkboxes) and for any file whose key order is itself the contract (envelope/meta constructors).
