---
id: "20261031T081347Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261031t1615z-implement-p1-s1"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-31T08:13:47Z"
summary: "S1 implement Part 1 (T001-T008): three real red blocks then green; 15 targeted cases OK. Two contract-level ambiguities surfaced: (a) extraction-rules C-4/C-5 never name the discovery root for config/"
---

## Review
S1 implement Part 1 (T001-T008): three real red blocks then green; 15 targeted cases OK. Two contract-level ambiguities surfaced: (a) extraction-rules C-4/C-5 never name the discovery root for config/** and dump/** - scanning the repo root picks up tests/fixtures (1,610 config dirs) while the frozen measurement (1,578) is workdir-only, so the scope had to be inferred; (b) the artifact-correctness axis of run-determination stays not_evaluated because no names baseline exists and the segment budget forbids a full-suite rerun, even though the declared targeted check is green.

## Optimization Points
- 1) State the discovery root explicitly in C-4/C-5 (e.g. 'walk workdir/'), so the measured count and the rule cannot diverge. 2) Let a narrow declared check (single test module) satisfy the green-evidence axis when the run budget forbids the full suite, instead of requiring a full-suite failed-name baseline. 3) T002's red block asserts the closed meta key set, which needs a seeded index before build_index exists; consider stating in T003 that connect_rw seeds the meta closed set (it was inferred here).
