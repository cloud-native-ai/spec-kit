---
id: "20261031T090550Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261031T0905Z-impl-p4-2"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "003-iac-mcp-poc"
feature_id: "020"
partial: false
created: "2026-10-31T09:05:50Z"
summary: "T028's task row embeds 'the full python3 -m unittest discover -s tests -t . output' as part of its evidence, while the stage brief forbids re-running the full suite before the closure slot (budget rul"
---

## Review
T028's task row embeds 'the full python3 -m unittest discover -s tests -t . output' as part of its evidence, while the stage brief forbids re-running the full suite before the closure slot (budget rule: one full run at the implement baseline, one after review). The row therefore asks for an artifact the run is not allowed to produce, and the run had to record a deviation (verification.md DEV-01) instead of ticking the row honestly.

## Optimization Points
- Keep the full-suite check on the closure/DoD row, not on an implementation task row; implementation rows should name only the targeted batch they are permitted to run, so 'all tasks [X]' and the test budget never contradict each other.
