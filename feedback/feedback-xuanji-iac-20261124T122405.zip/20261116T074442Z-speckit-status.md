---
id: "20261116T074442Z-speckit-status"
unit_id: "/speckit.status"
unit_type: "command"
run_id: "20261116T074442Z"
scope: "local"
probe: "speckit-status-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-16T07:44:42Z"
summary: "digest answered nothing-running (exit 3) — no active line in the registry"
---

## Review
digest answered nothing-running (exit 3) — no active line in the registry

## Optimization Points
- none
