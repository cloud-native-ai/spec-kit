---
id: "20261101T043718Z-speckit-checklist"
unit_id: "/speckit.checklist"
unit_type: "command"
run_id: "r20261101T043700Z-s2ck"
scope: "local"
probe: "speckit-checklist-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-01T04:37:18Z"
summary: "checklist 阶段按 brief 的八簇生成 service-quality.md：39 条（CHK001–CHK039），traceability 39/39，FR 26/26；顺带用程序核对了条目编号连续性、覆盖分布表与条目行的一致性、以及与 requirements 的计数（24 Edge Cases / 22 STR / 4 处展开小节）。发现若干可下推到 requirements "
---

## Review
checklist 阶段按 brief 的八簇生成 service-quality.md：39 条（CHK001–CHK039），traceability 39/39，FR 26/26；顺带用程序核对了条目编号连续性、覆盖分布表与条目行的一致性、以及与 requirements 的计数（24 Edge Cases / 22 STR / 4 处展开小节）。发现若干可下推到 requirements 的真缺陷（如 FR-005 与 FR-006 对 aggregate.total 空值口径不一致、FR-007 的 freshness_note 在 whoami 无索引时与 FR-005 冲突、FR-023 query_hint 非空与 FR-013 投影置 null 冲突、FR-024 的 OUT_OF_SCOPE 触发面在八工具 schema 中不可表达）。

## Optimization Points
- （1）check-prerequisites.sh 在本机缺 CWS_LIB_BASH_HOME 时直接退出，命令模板把该脚本列为声明前置，却在 macOS 工作副本上必然失败；建议模板补一条降级说明（或让 common.sh 在缺库时以只读模式继续，仅在需要 cws 函数时失败）。（2）run-determination 的 --collected 只接受整数、--names-current 只接受文件路径，但 probe 编译出的占位说明（'<COLLECTED>'）未提示参数形态，首次调用必踩两次参数类型错误；建议在 manifest 或命令模板里标注参数形态。（3）checklist 方法学要求 ≥80% traceability 与软上限 40，但未给'同一个 FR 被多条条目引用'的计数口径，覆盖分布表只能自定正则；建议 owner 明确'引用计数以条目行为准'。
