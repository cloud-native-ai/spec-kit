---
id: "20261101T055844Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261101T0600Z-impl3"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-01T05:58:44Z"
summary: "Part 3/4 (T017-T024): error surface, presentation/handoff, MCP mount and two-stage projection landed; 213 targeted tests green across three runs, declaration red block red by design."
---

## Review
Part 3/4 (T017-T024): error surface, presentation/handoff, MCP mount and two-stage projection landed; 213 targeted tests green across three runs, declaration red block red by design.

## Optimization Points
- Two tensions worth surfacing upstream: (1) SC-003's 16-digit scan hunts a pattern that random ids and hex digests can hit by chance - new_trace_id had to drop its 32-hex run, and source_commit could trip it on another commit; a scan definition that excludes known-opaque fields would be more robust than making every id scan-safe. (2) A path-valued search hit cannot satisfy both 'zero workdir/ literal' and 'path fields are null, not truncated' - the slice needed a third rule (reduce to the trailing business name) that neither contract names.
