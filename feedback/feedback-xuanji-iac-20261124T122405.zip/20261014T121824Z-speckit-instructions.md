---
id: "20261014T121824Z-speckit-instructions"
unit_id: "/speckit.instructions"
unit_type: "command"
run_id: "instructions-team-discoverability-20261014"
scope: "local"
probe: "speckit-instructions-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-14T12:18:24Z"
summary: "定向部分刷新按用户参数执行：只动新团队/团队技能可发现性相关面，其余节逐字节未动。Setup 注入 3 个缺失模板节（与模板逐字节一致）；覆盖检查对 8 份备份按节标题集合成员比对，备份独有仅 ## Resource Registry（归因为被 Skills & Tools 取代的 legacy 注册表，无用户内容丢失）；记忆召回还原 0920/0921 两轮既往决策并全部遵守（未重压已压缩节、未"
---

## Review
定向部分刷新按用户参数执行：只动新团队/团队技能可发现性相关面，其余节逐字节未动。Setup 注入 3 个缺失模板节（与模板逐字节一致）；覆盖检查对 8 份备份按节标题集合成员比对，备份独有仅 ## Resource Registry（归因为被 Skills & Tools 取代的 legacy 注册表，无用户内容丢失）；记忆召回还原 0920/0921 两轮既往决策并全部遵守（未重压已压缩节、未补当时刻意留薄的两节）。实质收敛仅一处且落在 owner 文档：framework-map.md 补 Goal archive 行（新团队 prod-workdir-align 经 goal_slug 绑定到 .specify/goal/，而 owner 表只有 Teams 行）。预算超 6141B 判为结构性 pending 而非静默忽略。run-determination 四轴均 not_evaluated（如实），trigger_feedback=false。

## Optimization Points
- **预算收敛机制对「模板自身增长」无路由**：本次 setup 注入 3 个新模板节（5197B）直接把文件顶过预算（38909B / 32768B，超 6141B），而 R1 过滤后只剩 77B 可压、R2 池为空（所有 project-owned 节均 < 4KB）——即预算警告会成为**每次运行都报、但文档化路由永远收敛不掉**的常驻噪音。0920/0921 两轮已把可压缩面吃完。建议补一条 R3 路由：当 R1/R2 均无候选时，报告应明确「结构性超支 + 三个候选处置（接受并调 INSTRUCTIONS_BUDGET_BYTES / 用户裁决搬某节 / 上游模板瘦身）」，而不是每次都给同一条 generic warning。
- **Action 5 的 Documentation Map 存在性校验口径对 glob 行有缺陷**：Map 里 `.specify/memory/features/*.md`、`docs/manual/` 一类 Location 是设计内的 glob/目录形态，字面 `test -e` 对 glob 行必误报 MISSING。skill 正文写的是「loop every Location cell through `test -e`」，照做就会把不存在的假象报成 drift。建议口径改为 glob 语义（shell 展开或 Python glob），并在 skill 里写明。
- **内联 highlights 与 owner 表的职责边界执行良好但有暗坑**：本次在 owner（framework-map.md）补 Goal archive 行后，instructions.md 的内联 highlights 仍不含该词——按 Action 5 规则这是对的（新增框架位置进外部文档），但读者在内联层搜 "goal" 会搜不到。可考虑让内联 highlights 的括注里带上「含 goal 档案」三字级的提示（仍是 summary+pointer 形态，不破 map-not-manual）。
- token-efficiency：本轮全程程序化校验（存在性/标题集合/模板逐字节比对/记忆库关键词召回），未发生原文转储与重复读取；一处小失误是覆盖检查统计用了 `wc -w` 而非 `wc -l` 导致首读误读为「当前独有 70 节」，实为词数，已当场用备份独有清单的实际内容复核纠正。
