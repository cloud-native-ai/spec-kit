---
id: "20261101T054108Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261101T054000Z-impl2"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "005-iac-mcp-service"
feature_id: "021"
partial: false
created: "2026-11-01T05:41:08Z"
summary: "A red block that is designed to stay red across a phase boundary cannot validate its own arithmetic. tests/test_iac_mcp_tools.py was authored in Part 1 (T008) with 98 expected errors, every one an Att"
---

## Review
A red block that is designed to stay red across a phase boundary cannot validate its own arithmetic. tests/test_iac_mcp_tools.py was authored in Part 1 (T008) with 98 expected errors, every one an AttributeError on a missing symbol, so no assertion was ever evaluated; when Part 2 implemented the surface, one literal was wrong (expected 3 groups where the fixture builds 4 distinct resource types summing to the 7 its sibling case asserts). The block was green everywhere else on the first run, so the red-first evidence as recorded could not have caught it, and the fix had to be disclosed as an in-passing correction during implementation.

## Optimization Points
- When a Tests-Mode-ON red block must remain red past the current phase (its green partners are later tasks), require the arithmetic-bearing assertions to be pinned at authoring time by an executable reference rather than by missing-symbol errors: run the fixture's own arithmetic table (counts per row, expected totals, expected group count) as a plain script and paste its output into the red-first evidence next to the failing run. A block whose every case is an ImportError/AttributeError proves only that the surface is absent; it says nothing about whether the expected numbers are right, and the first implementation run is then the first time they are tested - the exact place where a wrong literal silently converts into a test edit.
