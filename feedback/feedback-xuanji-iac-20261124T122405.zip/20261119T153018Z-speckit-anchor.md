---
id: "20261119T153018Z-speckit-anchor"
unit_id: "/speckit.anchor"
unit_type: "command"
run_id: "r20261119T153017Z-0c2d"
scope: "local"
probe: "speckit-anchor-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-19T15:30:18Z"
summary: "cms2 单账号 goal 改造为扩范围 anchor xuanji-resource-monitoring（两账号 xuanji 资源全量监控+实际运转可查），4 判据经引擎写入并 validate。"
---

## Review
cms2 单账号 goal 改造为扩范围 anchor xuanji-resource-monitoring（两账号 xuanji 资源全量监控+实际运转可查），4 判据经引擎写入并 validate。

## Optimization Points
- criteria 多条须单次调用传多个 --criterion（分开调用会替换）;legacy .specify/goal 路径不被 migrate-archive 识别须走 create
