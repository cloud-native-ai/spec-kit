---
id: "20261031T024933Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "r20261031T023000Z-1ac3"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
feature: "004-l3-component-design"
feature_id: "020"
partial: false
created: "2026-10-31T02:49:33Z"
summary: "requirements 阶段完成：编号 004 按目录+归档+顶层分支推导（003 被 003-iac-mcp-poc 占用）；create-new-requirements.sh 因 CWS_LIB_BASH_HOME 未导出且其步骤会 git checkout -b 切走工作线分支而失败，改为同一编号算法与模板的手工等价落地（A8 记录）；expression/design-note 声明后"
---

## Review
requirements 阶段完成：编号 004 按目录+归档+顶层分支推导（003 被 003-iac-mcp-poc 占用）；create-new-requirements.sh 因 CWS_LIB_BASH_HOME 未导出且其步骤会 git checkout -b 切走工作线分支而失败，改为同一编号算法与模板的手工等价落地（A8 记录）；expression/design-note 声明后 flow-class-check 读到 source=declaration；validate-requirements ok（38 定义行 / 4 STR）、pre-analyze pass 0 error（8 条 advisory 全为目标文件 docs/design 待创建）、decomposition proceed（FR=30 恰为上限）、doc-consistency evidence 面经一次 as-of 修正后 pass；另实测出既有文档 7 处陈旧读数（14 账号/32 区域/9 资源组/6 本地模块/五个域）并写入设计页的禁用清单。

## Optimization Points
- ① create-new-requirements.sh 在缺 CWS_LIB_BASH_HOME 时直接 exit 1，且无条件 git checkout -b；建议提供 --no-branch 或在分支已由编排固定时跳过建分支，否则每条 SDD 线都要手工等价落地；② doc-consistency 的 evidence 面把「引用外部仓内容的 as-of」与「本文件的测量日」混为一个值，导致引用型断言必须把 as-of 写成提交当天才不触发 as-of-stale，建议区分 measured-as-of 与 cited-as-of；③ run-determination 在未传 --declared-check 时把 artifact_correctness 记为 not_evaluated，建议在输出里提示可登记的检查名，减少欠报；④ pre-analyze 的 missing-path 对本特性将创建的目标文件应为可声明的 planned-path，避免每轮恒有 advisory 噪音。
