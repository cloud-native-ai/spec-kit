---
id: "20261101T052942Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261101T052900Z-impl1"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-01T05:29:42Z"
summary: "Part 1/4 of /speckit.implement on 005-iac-mcp-service: authored four red blocks, took three to green (100 cases), left the tool-surface block red by design. Friction met while running the wrap-up: run"
---

## Review
Part 1/4 of /speckit.implement on 005-iac-mcp-service: authored four red blocks, took three to green (100 cases), left the tool-surface block red by design. Friction met while running the wrap-up: run-determination.py's --declared-check / --green-check / --red-first-refs are append-style repeatable flags and --collected is an int, but the rendered usage line shows them as ordinary single-valued options, so four invocations were rejected (invalid int, green-check outside declared set, unrecognized argument, names-current not a file) before a working call. --qualification has no value that means 'this completed phase is one part of a larger command', so a fully closed part either declares itself partial and gets every axis reported not_evaluated, or over-claims qualified.

## Optimization Points
- Render the value shape next to each option (repeatable / int / path) or accept a comma-separated set for the three check flags; and add a qualification value for a phase-scoped run so a closed part can be measured on the axes it actually has, instead of trading measurement for honesty.
