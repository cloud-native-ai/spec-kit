---
id: "20261013T030812Z-speckit-sanitize"
unit_id: "/speckit.sanitize"
unit_type: "command"
run_id: "sanitize-2026-10-13-full"
scope: "local"
probe: "speckit-sanitize-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-13T03:08:12Z"
summary: "Full-run /speckit.sanitize on the whole workspace: 55 deterministic findings collected; judged and executed a user-confirmed plan — 38 auto-resolved (spec-dir archive move, constitution reword, 3 lega"
---

## Review
Full-run /speckit.sanitize on the whole workspace: 55 deterministic findings collected; judged and executed a user-confirmed plan — 38 auto-resolved (spec-dir archive move, constitution reword, 3 legacy index retirements via owning-engine reindex), 17 verified false positives left pending by design (engine has no dismissed-state writer), 6 semantic candidates got no verdict (insufficient evidence, per red line). Three engine calibration gaps and one apply/convention divergence identified — see points.

## Optimization Points
- # Optimization Points — /speckit.sanitize full run 2026-10-13
- [framework: sanitize-utils.py check_index_consistency] reads the features.md "Feature Details" cell as a literal repo path, but the registry uses markdown-link cells `[001.md](features/001.md)` whose targets all exist — 16 false positives per run. token-efficiency: each run re-verifies and re-reports them.
- [framework: sanitize-utils.py check_dead_references rule 3] resolves `templates/commands/<name>.md` against the workspace root; correct only for a framework-source layout. In client projects (root `templates/` holds user content) every `speckit.<name>` prose mention is a false positive (2 this run: glossary `/speckit.instructions`, archived checklist `/speckit.clarify`).
- [framework: sanitize-utils.py] the `dismissed` state is declared in STATES and honored by merge, but no code path writes it: apply-dismiss flips findings to `resolved`, so re-detection reopens them. False positives therefore cannot be durably closed and re-verify every run.
- [framework: sanitize-utils.py apply] generic archive destination `.specify/archive/<rel>` diverges from the framework's own archived-spec convention `.specify/specs/.archive/` (SPECS_ARCHIVE_PREFIX + create-requirements numbering). The spec-dir move had to be executed as a manual git mv to avoid an invisible-to-numbering archive location.
- [token-efficiency] the 55-finding ledger was projected into context as a full 55-line list; a grouped projection (by material x reference pattern, ~6 lines) would have carried the same decision information for the presentation stage.
