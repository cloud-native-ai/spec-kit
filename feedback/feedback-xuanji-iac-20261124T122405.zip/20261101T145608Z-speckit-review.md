---
id: "20261101T145608Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "r20261101T1450Z-s2rev2"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-01T14:56:08Z"
summary: "review 第二轮：先按脚本解析区间 2c92934e6..56f8c9f97（简报仍写 f740002a6..HEAD，F2 第二轮复发），再复核 B-1 与 SC-010。B-1 用真实索引 HTTP/JSON-RPC 复现关闭（q=\",\" scope=config → 0/0/null，四组 loop-to-null 对账 360/24/7242/56 页页满足 truncated 与 n"
---

## Review
review 第二轮：先按脚本解析区间 2c92934e6..56f8c9f97（简报仍写 f740002a6..HEAD，F2 第二轮复发），再复核 B-1 与 SC-010。B-1 用真实索引 HTTP/JSON-RPC 复现关闭（q="," scope=config → 0/0/null，四组 loop-to-null 对账 360/24/7242/56 页页满足 truncated 与 next_offset 算术），SC-010 独立复跑单发九档全 <200ms、并发档仅记录。代码段 0 blocking/0 important、gate=allow、段裁决 pass；过程段 P0 0/P1 4/P2 7（新增 F10 裁决文本插入破坏 requirements 结构而 validate-requirements 全绿、F11 判据改成同一 200ms 后证据脚本仍按旧分档且 declaration_status 放宽到 300ms）。状态迁移三条件齐备。同时发现一处证据目录卫生问题：未跟踪的 probe_perf-direct-output.txt 是中间失败运行（failed: 3），与最终证据结论相反。

## Optimization Points
- ① /speckit.review 的驱动方区间应被脚本 base 输出覆盖并强制披露差异（F2 两轮复发）；② clarify/review 往既有 spec 追加裁决必须落在结构化锚点，validate-requirements 应加标题唯一性与引用块完整性两项结构检查（F10）；③ 证据脚本的判定阈值应打印来源并禁止复制字面量，避免判据改后尺子没换（F11）；④ 评审收尾应提示清理证据目录中的中间运行产物。
