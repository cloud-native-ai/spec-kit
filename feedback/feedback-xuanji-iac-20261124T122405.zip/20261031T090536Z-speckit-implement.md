---
id: "20261031T090536Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261031T0905Z-impl-p4"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "003-iac-mcp-poc"
feature_id: "020"
partial: false
created: "2026-10-31T09:05:36Z"
summary: "The registered gate 'gate-implement-evidence-binding' cannot be executed in this project: gate-check.py aborts with 'gate file not found: .specify/gate.yaml', yet implement-feature Step 9 instructs th"
---

## Review
The registered gate 'gate-implement-evidence-binding' cannot be executed in this project: gate-check.py aborts with 'gate file not found: .specify/gate.yaml', yet implement-feature Step 9 instructs the run to fire it. The manual equivalent (parse each sample_id/evidence_path/evidence_sha256/verdict row, recompute sha256, compare) was done by hand and passed 10/10, but nothing machine-enforces it.

## Optimization Points
- Either ship a default .specify/gate.yaml with the built-in gates registered, or make the template's Step 9 fall back to a documented deterministic check (e.g. a verification-log binding subcommand) when gate.yaml is absent; as-is the gate reads as active but silently has no engine.
