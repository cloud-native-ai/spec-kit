---
id: "20261116T074201Z-speckit-anchor"
unit_id: "/speckit.anchor"
unit_type: "command"
run_id: "20261116T074200Z"
scope: "local"
probe: "speckit-anchor-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-16T07:42:01Z"
summary: "anchor 'run' intent fell back to read-only view per the seven-mode contract; no writes"
---

## Review
anchor 'run' intent fell back to read-only view per the seven-mode contract; no writes

## Optimization Points
- the anchor command exposes seven modes but 'run' is a natural verb from /speckit.team; consider accepting 'run' as a documented alias for view to avoid a silent fallback.
