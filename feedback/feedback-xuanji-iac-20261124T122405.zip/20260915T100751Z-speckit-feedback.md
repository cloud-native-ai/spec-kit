---
id: "20260915T100751Z-speckit-feedback"
unit_id: "/speckit.feedback"
unit_type: "command"
run_id: "feedback-package-20260915T100649Z"
scope: "local"
probe: "speckit-feedback-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-09-15T10:07:51Z"
summary: "Mode 2 完整执行：status（24 条 ≥ 阈值 10）→ list 全量核对（39 条，16 legacy）→ package（24 条入 zip，无 introspection_ref 故未附自省报告）→ cleanup dry-run + 实删（24 条移除，store 余 15 条 legacy）。全部本地操作、零网络。发现两点边界事实（旧 zip 冗余、ignored 条目仍入包"
---

## Review
Mode 2 完整执行：status（24 条 ≥ 阈值 10）→ list 全量核对（39 条，16 legacy）→ package（24 条入 zip，无 introspection_ref 故未附自省报告）→ cleanup dry-run + 实删（24 条移除，store 余 15 条 legacy）。全部本地操作、零网络。发现两点边界事实（旧 zip 冗余、ignored 条目仍入包）已入优化点。

## Optimization Points
- Stale outbox zip handling: packages/ held a superseded zip (feedback-20260831T133336Z.zip) whose 13 entries were all re-included in today's package zip as a strict subset; the engine re-packages un-submitted entries correctly but leaves the older zip on disk, making the outbox ambiguous (two zips, one redundant). Suggest: at package time, detect prior zips whose entry set is subsumed by the new one and offer/perform outbox replacement, or document the manual rule.
- Disposition vs package scope: entry 20260828T150216Z-skill-database-utils carried disposition=ignored yet was included in the packaged zip (local disposition is metadata-only, not a package filter). Worth clarifying in Mode 2 docs whether 'ignored' entries should still go upstream, or whether package should default to excluding them.
- Counter semantics observation: count_since_submission dropped to 0 immediately after post-package cleanup (store-driven count), before any mark-submitted; this is coherent with the design (counter mirrors store state) but means the counter does not track actual manual delivery — the doc's 'reset the local counter' phrasing for mark-submitted could mislead readers into thinking the counter only resets there.
