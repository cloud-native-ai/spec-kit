---
id: "20261031T063550Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "r20261031T0636Z-req-s1"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-31T06:35:50Z"
summary: "Slice re-run of requirements: the brief required keeping the original FR numbering (011-027 + 040, gapless by removal) while also requiring validate-requirements.py to report 0 errors. Those two are m"
---

## Review
Slice re-run of requirements: the brief required keeping the original FR numbering (011-027 + 040, gapless by removal) while also requiring validate-requirements.py to report 0 errors. Those two are mutually exclusive: id-contiguous computes range(1, max+1) and reports every gap, and pre-analyze-check flags every FR-nnn mention whose definition is absent - including the mentions inside a 'Deferred to S2' table and inside the append-only Clarifications history.

## Optimization Points
- When a requirements artifact is re-derived for a slice, state the numbering policy as 'renumber contiguous + emit old->new map' (clarify-taxonomy Removal & renumbering) instead of 'keep numbers'; and say explicitly that deferred items must be listed WITHOUT the FR-nnn token, because both checkers scan raw lines and neither exempts Clarifications or deferred tables.
