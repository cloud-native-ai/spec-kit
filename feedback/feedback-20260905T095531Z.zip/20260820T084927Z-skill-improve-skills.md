---
id: "20260820T084927Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "improve-skills-qoderwork-project-cloud-mapping-2026-08-20"
scope: "local"
probe: "skill-improve-skills-wrapup"
kind: "internal"
slice: "skills"
partial: false
created: "2026-08-20T08:49:27Z"
summary: "优化 qoderwork-project：将散落在 01/04/09 的云端映射正规化为中央 SSOT references/cloud-mapping.md（Aone 迭代/标签/模块三维 + KB 14 根目录映射总表 + 整理计划 P1-P4），01 同步方向按用户决策升级为双向（写前确认），registry 联动并跑 panorama_sync 分发（18 目标 changed→0）。SK"
---

## Review
优化 qoderwork-project：将散落在 01/04/09 的云端映射正规化为中央 SSOT references/cloud-mapping.md（Aone 迭代/标签/模块三维 + KB 14 根目录映射总表 + 整理计划 P1-P4），01 同步方向按用户决策升级为双向（写前确认），registry 联动并跑 panorama_sync 分发（18 目标 changed→0）。SKILL.md 仅 +2 行指针，shape 门禁维持存量 exit 10（7558→7692 tokens），未新增超标。

## Optimization Points
- 中央映射文档类改进必须实测云端两侧真值再落笔：本轮先跑 `dws wiki node list` 全量树 + `a1 field options sprint/tag/module`，再写映射表，使 9=9=9 三方对照可核验；纯靠既有项目文件转述会把旧设计（如 01 单向）当成现状固化。
- 能力声明落笔前必须用 `--help` 仲裁：初稿写「标签与模块定义 CLI 不支持」，实测发现 `a1 project sprint create/close` 存在（迭代定义可 CLI），`a1 project module` 不存在——同一句能力声明内两个子项一真一假，应逐个子命令验证。
