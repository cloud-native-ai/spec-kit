---
id: "20260818T055721Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "improve-skills-2026-08-18-qoderwork-project-routing"
scope: "local"
probe: "skill-improve-skills-wrapup"
kind: "internal"
slice: "skills"
partial: false
created: "2026-08-18T05:57:21Z"
summary: "改进 qoderwork-project 技能：为委派契约补通道无关性（外部 IM 中转纯内容路由）与项目规划步骤，涉及规格/模板双副本/数据文件/脚本四处同步，全部实测通过。"
---

## Review
改进 qoderwork-project 技能：为委派契约补通道无关性（外部 IM 中转纯内容路由）与项目规划步骤，涉及规格/模板双副本/数据文件/脚本四处同步，全部实测通过。

## Optimization Points
- 契约类技能（如 qoderwork-project 的委派契约）一次改动需同步「规格 reference + 模板（含框架与示例双副本）+ 运行时数据文件」三处，极易漏改；可考虑在 scripts/ 增加契约段一致性校验脚本（diff 模板契约段与根级 AGENTS.md 对应段），纳入 R3 或独立 verify 子命令，替代人工逐处比对。
