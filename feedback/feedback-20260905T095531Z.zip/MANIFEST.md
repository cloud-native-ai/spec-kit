# Feedback Package Manifest

> This feedback targets the Spec Kit framework itself (templates, commands, skills, scripts, docs) — not the LLM, agent CLI, harness, or any user project code.

- **Generated**: 2026-09-05T09:55:31Z
- **Entries**: 26
- **Time range**: 2026-08-07T10:35:37Z → 2026-09-05T04:06:50Z
- **spec-kit version**: 0.0.22
- **Install source**: https://gitlab.alibaba-inc.com/cloud-native-ai/spec-kit.git @ 127753962c10553206b779ffefed8c7723e01686

| Created | Unit | Partial | Probe | Slice | Summary |
|---------|------|---------|-------|-------|---------|
| 2026-08-07T10:35:37Z | skill:improve-skills | False | - | - | 针对 dispatch-workitem 的拆解能力缺失做了一轮证据驱动改进。证据来自 09_任务管理 项目 2026-08-07 的真实运行：父需求 85228984 把 5 个子需求作为 prose 章节写进描述、子项用文本行「父需求： |
| 2026-08-07T13:38:11Z | skill:improve-team | False | - | - | 按 goal-editing.md 完成用户明确的双目标重定义与 5 成员扩编（3 项目采集员+审核员+分解员），结构保形、未触碰无关字段，证据来自 3 份 runs 报告（0.595→0.895 收敛轨迹）。执行干净。 |
| 2026-08-07T13:44:25Z | skill:improve-skills | False | - | - | Ran one improvement loop on dispatch-workitem after its decomposition capability expansion. The loop found and fixed the |
| 2026-08-07T14:29:37Z | skill:summarize-project | False | - | - | 非交互模式由团队边界触发，稀疏材料（无排期/无里程碑/状态全 unknown）按降级形态完整产出 summary.md + WBS 渲染三件套；生成器 coverage 口径不一致与 CG-0 遗留检查是两个摩擦点。 |
| 2026-08-07T14:29:37Z | skill:create-team | False | - | - | run 模式完成：预览确认门禁、3 采集 Agent 单块并行派发、审核→分解→交付流水线、运行报告与 goal summary 全流程走通；混合意图（run 中夹带结构修改）先经 improve-team 落盘再执行，流程顺畅。 |
| 2026-08-10T11:42:45Z | skill:create-skills | False | - | - | 按 create-skills 全流程在 profiles（Spec Kit project mode）创建 aso-workspace 并按 R1 完成 SSOT 固化、双链接扩散、三处登记与终验；悟空注册因会话内无对应 MCP 工具而受 |
| 2026-08-11T07:27:35Z | skill:create-skills | False | - | - | 本次用 create-skills 创建 profiles 侧 aliyun-workspace/aliyun-document 两个前门技能，并配合 cws-lib-python 侧改名脱敏，完成 R3 分层。skill 的骨架（fron |
| 2026-08-11T07:40:49Z | skill:improve-skills | False | - | - | 本次用 improve-skills 处理 create-skills 的三条反馈：证据引擎两通道可用但只给出计数/主题类信号（按红线未据此定缺陷），真正的依据是本次执行的直接症状与一条复现主题；据此在上游 spec-kit 落两条契约行  |
| 2026-08-11T07:44:28Z | skill:improve-skills | False | - | - | 以 aso CLI v1.0.6 首轮只读冒烟的实测输出为证据，对 aso-workspace 做最小修改：修正认证缺失的退出码分诊、改用文本判定认证状态、新增坑点 16。改动均有本次命令输出支撑，改后以实跑规则校验（RULE1/RULE2 |
| 2026-08-11T17:57:16Z | skill:create-agent | False | - | - | OpenCode 1.18 启动报 agent frontmatter 配置无效：create-agent 模板统一生成 tools 数组+大写工具名+颜色英文名（如 yellow），而 OpenCode 强校验要求 tools 为对象映射 |
| 2026-08-17T08:26:11Z | skill:create-skills | False | skill-create-skills-wrapup | skills | 用 create-skills 为 /usr/local/bin/normandy 与 /usr/local/bin/zeus 两个新 CLI 创建 wrapper 技能（normandy-workspace/zeus-workspace） |
| 2026-08-18T05:57:21Z | skill:improve-skills | False | skill-improve-skills-wrapup | skills | 改进 qoderwork-project 技能：为委派契约补通道无关性（外部 IM 中转纯内容路由）与项目规划步骤，涉及规格/模板双副本/数据文件/脚本四处同步，全部实测通过。 |
| 2026-08-18T06:14:12Z | skill:improve-skills | False | skill-improve-skills-wrapup | skills | qoderwork-project 委派路由第二轮改进：按用户反馈建立显式为主隐式为辅的三层路由（T2a ROUTE.md/T2b PANORAMA 基线/T2c 语义兜底+晋升闭环），脚本与契约三方同步并全路径实测。 |
| 2026-08-20T08:49:27Z | skill:improve-skills | False | skill-improve-skills-wrapup | skills | 优化 qoderwork-project：将散落在 01/04/09 的云端映射正规化为中央 SSOT references/cloud-mapping.md（Aone 迭代/标签/模块三维 + KB 14 根目录映射总表 + 整理计划 P |
| 2026-08-20T13:18:12Z | skill:improve-skills | False | skill-improve-skills-wrapup | skills | 为 qoderwork-project 增加用户友好呈现契约：新建 references/presentation.md（超链接规则+实测 URL 模板表+说人话规范+机器间数据豁免）；根级 AGENTS.md 新增第三个固定契约段「呈现契 |
| 2026-08-24T12:50:40Z | /speckit.goal | False | speckit-goal-wrapup | commands | create 模式顺利完成：先查引擎 GD-2/GD-3 语法再拟 objective，避免了拒绝往返。 |
| 2026-08-26T02:50:27Z | /speckit.goal | False | speckit-goal-wrapup | commands | create 模式全程顺畅：查重既有档案、访谈补齐 slug 与判据、引擎 create+targets 落档、validate 通过。两点摩擦见 points 文件。 |
| 2026-08-26T04:42:50Z | skill:summarize-project | False | skill-summarize-project-wrapup | skills | 非交互团队收尾刷新：表单一次通过校验与装载（status=ready），引擎退出码 0，check-coherence FAIL=0/WARN=0（首轮 WARN=1 为 CG-8 基准日字面量缺失，补写后归零）。稀疏材料降级路径（无里程碑 |
| 2026-08-26T04:43:31Z | skill:create-team | False | skill-create-team-wrapup | skills | serial 五阶段 run 顺利闭环：交接验证全部通过，S5 8/8 PASS，台账/报告/summary 三件套齐备。一点机制观察见 points。 |
| 2026-08-27T04:06:10Z | skill:improve-skills | False | skill-improve-skills-wrapup | skills | 为 documents-collect 引入 topic-index.yaml + discovery-methods.md + topic_index.py 三件套，解决'去哪找什么'的经验沉淀问题；SKILL.md 新增步骤 1.5（前 |
| 2026-08-27T16:16:44Z | skill:improve-skills | False | skill-improve-skills-wrapup | skills | 本次以用户需求驱动优化 manage-agents：添加 QoderWake 接线目标（二进制取证定位加载路径 ~/.qoderwake/qodercli/skills，kind=abs 门控接入，33 链接复验归零）并定性新版 Qoder |
| 2026-08-28T13:27:34Z | skill:improve-skills | False | skill-improve-skills-wrapup | skills | 为 macos-agents 补齐 CLI 运行时依赖层：新增 references/cli-dependencies.md 登记表 + scripts/check_cli_deps.sh 只读核查脚本，并接入 global-check 的 |
| 2026-09-02T03:12:27Z | skill:improve-skills | False | skill-improve-skills-wrapup | skills | Improved profiles-project with an evidenced physical/logical code-group model, deterministic validation, routed data con |
| 2026-09-02T12:21:14Z | skill:create-skills | False | skill-create-skills-wrapup | skills | Created the requested global browser-management skill, verified local browser facts, completed managed distribution, and |
| 2026-09-02T14:26:21Z | skill:improve-skills | False | skill-improve-skills-wrapup | skills | Restructured the target skill from a single manual into a contract plus three ownership layers. The explicit user correc |
| 2026-09-05T04:06:50Z | skill:create-skills | False | skill-create-skills-wrapup | skills | 创建 profiles-bookmarks 全局技能（书签 JSON 规范库 + CRUD/查找/整理/导入导出），从既有 profiles-browsers 拆出书签数据层并令后者委派；引擎逐字节 diff 与 organize 幂等门禁 |
