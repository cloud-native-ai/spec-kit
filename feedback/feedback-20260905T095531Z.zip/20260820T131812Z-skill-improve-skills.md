---
id: "20260820T131812Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "improve-skills-qoderwork-project-presentation-2026-08-20"
scope: "local"
probe: "skill-improve-skills-wrapup"
kind: "internal"
slice: "skills"
partial: false
created: "2026-08-20T13:18:12Z"
summary: "为 qoderwork-project 增加用户友好呈现契约：新建 references/presentation.md（超链接规则+实测 URL 模板表+说人话规范+机器间数据豁免）；根级 AGENTS.md 新增第三个固定契约段「呈现契约 / Presentation」（模板双份+运行时三处 md5 一致）；SKILL.md 约束 21（+179 tokens，存量 exit 10 不变）；c"
---

## Review
为 qoderwork-project 增加用户友好呈现契约：新建 references/presentation.md（超链接规则+实测 URL 模板表+说人话规范+机器间数据豁免）；根级 AGENTS.md 新增第三个固定契约段「呈现契约 / Presentation」（模板双份+运行时三处 md5 一致）；SKILL.md 约束 21（+179 tokens，存量 exit 10 不变）；cloud-mapping.md 登记表链接化示范。用户本轮手工改动的 14_消息管理 registry 行完整保留，全景复验 changed=0。

## Optimization Points
- 行为规则类改进（非结构/数据类）的生效通道是「固定契约段」而非 references 指针：本轮把呈现规则做成根级 AGENTS.md 第三个固定契约段（与项目委派/反馈机制同纪律：模板框架+示例双份、初始化必渲染、R3 比对重写、不计入行数阈值、内容自足内联 URL 模板），并同步运行时 data/projects/AGENTS.md 使其立即生效——只写 references 不装契约段等于没下发。
- 契约段多副本写入后必须逐段哈希比对：awk 行区间提取在一份文件含两个同名段时会串段，改用正则分段 + md5 集合判等才可证「模板两处 + 运行时一处」byte-identical。
