---
id: "20260902T122114Z-skill-create-skills"
unit_id: "skill:create-skills"
unit_type: "skill"
run_id: "profiles-browsers-20260902"
scope: "local"
probe: "skill-create-skills-wrapup"
kind: "internal"
slice: "skills"
feature: "profiles-browsers"
partial: false
created: "2026-09-02T12:21:14Z"
summary: "Created the requested global browser-management skill, verified local browser facts, completed managed distribution, and synchronized affected documentation. The repository-specific R0/R1 rules requir"
---

## Review
Created the requested global browser-management skill, verified local browser facts, completed managed distribution, and synchronized affected documentation. The repository-specific R0/R1 rules required a global target rather than the generic project-level scaffold.

## Optimization Points
- Detect repository-specific global-skill promotion rules before scaffolding, then derive documentation counts from wire_agents.sh rather than copied snapshots.
