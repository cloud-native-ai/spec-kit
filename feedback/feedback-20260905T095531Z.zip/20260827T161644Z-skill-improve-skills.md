---
id: "20260827T161644Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "improve-skills-manage-agents-qoderwake-20260828"
scope: "local"
probe: "skill-improve-skills-wrapup"
kind: "internal"
slice: "skills"
feature: "manage-agents-qoderwake-wiring"
partial: false
created: "2026-08-27T16:16:44Z"
summary: "本次以用户需求驱动优化 manage-agents：添加 QoderWake 接线目标（二进制取证定位加载路径 ~/.qoderwake/qodercli/skills，kind=abs 门控接入，33 链接复验归零）并定性新版 Qoder 共用 ~/.qoder。全链路证据先行（硬约束 6 满足）、脚本实跑验证、四份权威记录同步、S9 终验通过。流程顺畅无失败。"
---

## Review
本次以用户需求驱动优化 manage-agents：添加 QoderWake 接线目标（二进制取证定位加载路径 ~/.qoderwake/qodercli/skills，kind=abs 门控接入，33 链接复验归零）并定性新版 Qoder 共用 ~/.qoder。全链路证据先行（硬约束 6 满足）、脚本实跑验证、四份权威记录同步、S9 终验通过。流程顺畅无失败。

## Optimization Points
- 新增 Agent 接线目标时，若其执行引擎复用既有 Agent 的 config home（如 qodercli-wake 交互式默认走 ~/.qoder），须在 SKILL.md 加载机制表与 docs 中显式写明「哪些场景已被既有目标覆盖」，避免后续误判为缺口重复接线
