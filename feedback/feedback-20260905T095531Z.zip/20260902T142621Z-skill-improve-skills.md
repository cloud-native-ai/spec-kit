---
id: "20260902T142621Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "profiles-browsers-three-layer-20260902"
scope: "local"
probe: "skill-improve-skills-wrapup"
kind: "internal"
slice: "skills"
feature: "profiles-browsers"
partial: false
created: "2026-09-02T14:26:21Z"
summary: "Restructured the target skill from a single manual into a contract plus three ownership layers. The explicit user correction was the actionable evidence; collected evidence was generic and was not use"
---

## Review
Restructured the target skill from a single manual into a contract plus three ownership layers. The explicit user correction was the actionable evidence; collected evidence was generic and was not used to invent additional defects.

## Optimization Points
- When evidence collection for a newly created skill returns only generic project signals, explicitly freeze candidates from the current user correction and avoid attributing the structural edit to unrelated evidence findings.
