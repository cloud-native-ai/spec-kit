---
id: "20260827T040610Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "documents-collect-topic-index-20260827"
scope: "local"
probe: "skill-improve-skills-wrapup"
kind: "internal"
slice: "skills"
partial: false
created: "2026-08-27T04:06:10Z"
summary: "为 documents-collect 引入 topic-index.yaml + discovery-methods.md + topic_index.py 三件套，解决'去哪找什么'的经验沉淀问题；SKILL.md 新增步骤 1.5（前置主题源匹配）与步骤 6（回写主题索引），遵守 skill-shape 契约层职责，flag-outside-contract 净减 6，脚本 8 动作实测全 "
---

## Review
为 documents-collect 引入 topic-index.yaml + discovery-methods.md + topic_index.py 三件套，解决'去哪找什么'的经验沉淀问题；SKILL.md 新增步骤 1.5（前置主题源匹配）与步骤 6（回写主题索引），遵守 skill-shape 契约层职责，flag-outside-contract 净减 6，脚本 8 动作实测全 GREEN。ASO 主题已登记 4 个入口（含用户点名的 alipaas/hagq7u 与 uialyw/user_guide）与关联主题 OpenKruise SidecarSet。

## Optimization Points
- 收集类技能原本缺乏"发现路径"的沉淀机制：每次调研都要重新推理"这个主题去哪找"，导致同一主题（如 ASO）在跨源搜索零命中时无法回退到已知的稳定入口。本次引入的 topic-index.yaml + discovery-methods.md 双层机制把"入口的知识"与"发现的方法"分开——前者随经验积累（数据层），后者稳定不变（方法层）。教训泛化：任何"多源检索类技能"都应有此结构，避免把"某主题的具体入口"和"通用检索算法"糊在一起。
- SKILL.md 严守契约层，把 CLI flag 细节（--action add-topic 等）压回 references/scripts；改后 flag-outside-contract 从 15 降至 9（净减 6）。教训：workflow 步骤里出现 --xxx flag 通常是把手册夹带进契约的信号，应用语义化动作名替代。
- topic_index.py 的 8 个动作在实测中全部 GREEN（含 add-topic/add-source/add-keywords/verify/mark-stale/match/show/list）；YAML 头部注释保留策略经过验证（保存后 schema 说明未丢失）。教训：涉及配置文件的确定性脚本必须验证"注释持久化"，否则用户手写的语义注解会被 yaml.safe_dump 清空。
