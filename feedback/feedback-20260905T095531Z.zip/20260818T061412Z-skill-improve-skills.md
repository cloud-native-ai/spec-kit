---
id: "20260818T061412Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "improve-skills-2026-08-18-route-md-explicit"
scope: "local"
probe: "skill-improve-skills-wrapup"
kind: "internal"
slice: "skills"
partial: false
created: "2026-08-18T06:14:12Z"
summary: "qoderwork-project 委派路由第二轮改进：按用户反馈建立显式为主隐式为辅的三层路由（T2a ROUTE.md/T2b PANORAMA 基线/T2c 语义兜底+晋升闭环），脚本与契约三方同步并全路径实测。"
---

## Review
qoderwork-project 委派路由第二轮改进：按用户反馈建立显式为主隐式为辅的三层路由（T2a ROUTE.md/T2b PANORAMA 基线/T2c 语义兜底+晋升闭环），脚本与契约三方同步并全路径实测。

## Optimization Points
- 路由/分诊类契约设计须默认「显式规则为主、隐式规则为辅」：显式层（路径/点名/已登记概念映射）永远优先于语义推断，且要为隐式命中提供「经用户确认晋升为显式规则」的登记闭环（本次落地为 ROUTE.md + detect_workdir.py T2a/T2b/T2c 三层），使确定性随使用单调不降。
