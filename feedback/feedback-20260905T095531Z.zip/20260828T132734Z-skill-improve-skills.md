---
id: "20260828T132734Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "macos-agents-cli-deps-20260828"
scope: "local"
probe: "skill-improve-skills-wrapup"
kind: "internal"
slice: "skills"
partial: false
created: "2026-08-28T13:27:34Z"
summary: "为 macos-agents 补齐 CLI 运行时依赖层：新增 references/cli-dependencies.md 登记表 + scripts/check_cli_deps.sh 只读核查脚本，并接入 global-check 的 S1/S4；同时修掉 zeus/normandy 两个技能前置检查里「无可执行安装命令」的实证缺陷。用户给的 6 条命令全部 curl 实测 200 后才落文"
---

## Review
为 macos-agents 补齐 CLI 运行时依赖层：新增 references/cli-dependencies.md 登记表 + scripts/check_cli_deps.sh 只读核查脚本，并接入 global-check 的 S1/S4；同时修掉 zeus/normandy 两个技能前置检查里「无可执行安装命令」的实证缺陷。用户给的 6 条命令全部 curl 实测 200 后才落文档，脚本三个退出码与三条可达性分支均实跑验证。

## Optimization Points
- Step 3 的证据采集默认走 `.specify` 的 session/feedback lane，但本次目标技能
- 实体在 `config/skills/`（全局技能库，standalone 模式），该目标没有任何 lane
- 证据。实际可用的证据来源是「实现内 grep + 活体环境探测」：grep 六个
- `*-workspace` 技能的前置检查块定位到 zeus/normandy 只有占位文案没有命令、
- grep references/ 证明 normandy 的指针目标里没有安装章节、curl 实测 8 条安装
- URL 与脚本内 `INSTALL_DIR=` 赋值行、`readlink` 实测 `/usr/local/bin/<cmd>`
- 软链与 `type -t` 实测 staragent 是 rc 注入函数。建议 Step 3 显式补一条
- standalone 目标的证据路径，避免因 lane 为空而误判「证据不足」并转去提问。
- Step 8 的 shape gate 要求「每个改过的 SKILL.md 收在 exit 0」，但本次为修一行
- 占位文案而触碰的 zeus/normandy SKILL.md 改前就已是 exit 10（6300+ tokens），
- 改后仍是 10。建议把「改前基线已超预算 + 本次增量极小」明确列为 Hard
- Constraint 3 的具名例外，并要求报告给出 before/after token 增量数字，
- 否则每次顺手修一行都要为存量超标写一段解释。
