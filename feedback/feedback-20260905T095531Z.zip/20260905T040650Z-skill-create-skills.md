---
id: "20260905T040650Z-skill-create-skills"
unit_id: "skill:create-skills"
unit_type: "skill"
run_id: "create-skills-profiles-bookmarks-20260903"
scope: "local"
probe: "skill-create-skills-wrapup"
kind: "internal"
slice: "skills"
partial: false
created: "2026-09-05T04:06:50Z"
summary: "创建 profiles-bookmarks 全局技能（书签 JSON 规范库 + CRUD/查找/整理/导入导出），从既有 profiles-browsers 拆出书签数据层并令后者委派；引擎逐字节 diff 与 organize 幂等门禁通过；按 R1 完成全系统级接线（wire_agents 缺口=0、千问注册表、悟空 db）、6+ 文档计数与清单同步、数据根迁移 data/browser→d"
---

## Review
创建 profiles-bookmarks 全局技能（书签 JSON 规范库 + CRUD/查找/整理/导入导出），从既有 profiles-browsers 拆出书签数据层并令后者委派；引擎逐字节 diff 与 organize 幂等门禁通过；按 R1 完成全系统级接线（wire_agents 缺口=0、千问注册表、悟空 db）、6+ 文档计数与清单同步、数据根迁移 data/browser→data/bookmarks。运行干净，达成 wrap-up。

## Optimization Points
- 能力重叠（非同名冲突）应在 Step 1 触发边界分析：本次新技能 profiles-bookmarks 与既有同级技能 profiles-browsers 存在能力重叠（后者原持有 reorganize/install 引擎与 bookmarks.md 目录），但名称不冲突。create-skills 的 Cross-SSOT 冲突检查只在「同名命中」时触发决策表，未覆盖「能力重叠 → 定义委派边界并重构同级技能」这一常见情形。建议在 Step 1 增补：发现能力重叠时，显式产出「数据层/实例层」职责切分与双向 description 边界声明，避免两个技能触发词重叠、引擎双份漂移。
- token-efficiency：多文件机械式文档计数更新（6+ 个 docs 文件的 32→33 及派生总数）委派给单个 subagent 一次完成，避免约 30 次 Edit 调用（每次调用都会把完整技能清单 system-reminder 灌入主上下文）。这是值得固化的实践——把「规则明确、跨多文件、低判断含量」的计数/清单同步类编辑交给 subagent，主代理只做一次 grep 终验。
- 确定性引擎移植优先复用而非重写：profiles-bookmarks 的 bookmarks_lib.py 直接沿用 profiles-browsers 已验证的解析/分类/落位逻辑，并以「导出对既有权威 HTML 逐字节 diff（仅生成器注释行不同）+ organize 重跑 sha 不变」作为回归门禁，确保拆分零行为漂移。建议 create-skills 在「从既有技能拆分/派生」场景把这类 diff+幂等门禁列为推荐验证手段。
