---
id: "20260826T044250Z-skill-summarize-project"
unit_id: "skill:summarize-project"
unit_type: "skill"
run_id: "20260826T124500Z-browser-skill-split-summary"
scope: "local"
probe: "skill-summarize-project-wrapup"
kind: "internal"
slice: "skills"
feature: "browser-skill-split-delegation"
partial: false
created: "2026-08-26T04:42:50Z"
summary: "非交互团队收尾刷新：表单一次通过校验与装载（status=ready），引擎退出码 0，check-coherence FAIL=0/WARN=0（首轮 WARN=1 为 CG-8 基准日字面量缺失，补写后归零）。稀疏材料降级路径（无里程碑/无排期/无特性/人员全缺失）按 degradation 规则完整落地，仅出 WBS 一张图。"
---

## Review
非交互团队收尾刷新：表单一次通过校验与装载（status=ready），引擎退出码 0，check-coherence FAIL=0/WARN=0（首轮 WARN=1 为 CG-8 基准日字面量缺失，补写后归零）。稀疏材料降级路径（无里程碑/无排期/无特性/人员全缺失）按 degradation 规则完整落地，仅出 WBS 一张图。

## Optimization Points
- 稀疏全完成项目（无排期/无里程碑/无特性）下，降级模板（「截至 <baseline>」句式）不会产出 CG-8 所需的「基准日 = yyyy-mm-dd」字面量，执行器须自行在元信息补写该字面量才能消 WARN；建议在 progress-presentation.md §3.1/§6 的降级模板或 degradation.md 声明句模板中直接内置「基准日：yyyy-mm-dd」字面量。
