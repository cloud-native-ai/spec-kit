---
id: "20260811T175716Z-skill-create-agent"
unit_id: "skill:create-agent"
unit_type: "skill"
run_id: "opencode-agent-frontmatter-20260812"
scope: "local"
partial: false
created: "2026-08-11T17:57:16Z"
summary: "OpenCode 1.18 启动报 agent frontmatter 配置无效：create-agent 模板统一生成 tools 数组+大写工具名+颜色英文名（如 yellow），而 OpenCode 强校验要求 tools 为对象映射（小写工具名→bool）、color 为 #RRGGBB 或主题枚举。关键发现：.opencode/.qoder/.qwen/.github 四个 agents"
---

## Review
OpenCode 1.18 启动报 agent frontmatter 配置无效：create-agent 模板统一生成 tools 数组+大写工具名+颜色英文名（如 yellow），而 OpenCode 强校验要求 tools 为对象映射（小写工具名→bool）、color 为 #RRGGBB 或主题枚举。关键发现：.opencode/.qoder/.qwen/.github 四个 agents 目录全部符号链接到同一批 .specify/agents/ 实体，一份格式喂四个工具，OpenCode 硬失败、其余容忍——共享格式无法跨工具通用。复现：opencode debug config（逐文件报错）。受影响：profiles 7 个 agent 文件 + cws-lib-python/cws-lib-bash 各 8 个 + create-agent 17 个生成模板与 1 个参考文档。详见 points 文件。

## Optimization Points
- # Feedback: create-agent 模板生成的 frontmatter 无法跨 Agent 工具通用
- ## Review
- 2026-08-12 在 profiles 项目运行 `opencode_yolo`（OpenCode 1.18.0）时报配置无效：
- ```
- Configuration is invalid at .opencode/agents/test-engineer.agent.md
- ↳ Expected object | undefined, got ["Read","Grep","Glob","Bash","Write","Edit"] tools
- ↳ Expected a string matching the RegExp ^#[0-9a-fA-F]{6}$, got "yellow" color
- ↳ Expected "primary" | "secondary" | "accent" | "success" | "warning" | "error" | "info", got "yellow" color
- ```
- 复现命令：`opencode debug config`（逐文件报错，修一个暴露下一个）。
- ## 根因
- create-agent 技能模板（`.specify/skills/create-agent/templates/*.md` 共 17 个文件
- + `references/template-authoring.md`）统一生成如下 frontmatter：
- ```yaml
- tools: [Read, Grep, Glob, Bash, Write, Edit]   # 数组 + 大写工具名
- color: yellow                                   # 颜色英文名
- ```
- 而各项目（profiles / cws-lib-python / cws-lib-bash）的
- `.opencode/agents/`、`.qoder/agents/`、`.qwen/agents/`、`.github/agents/`
- 四个目录全部是**指向同一批 `.specify/agents/` 实体的符号链接**——
- 一份 frontmatter 喂四个工具。OpenCode 1.18 对 frontmatter 做强 schema 校验
- （硬失败，拒绝启动），Qoder/Qwen/Copilot 容忍数组格式，导致共享文件无法同时
- 满足所有工具。
- ## OpenCode 1.18 实测接受的格式（已验证通过）
- ```yaml
- tools:                  # 必须是对象映射，工具名小写
- read: true
- grep: true
- glob: true
- bash: true
- write: true
- edit: true
- color: "#FFFF00"        # 必须是 #RRGGBB hex，或主题枚举
- # primary|secondary|accent|success|warning|error|info
- ```
- 未知键（`skills`/`maxTurns`/`supervisor`/`user-invocable`/`capacity-scope`/
- `model: auto`）不触发校验错误，会被保留或忽略。
- ## 受影响面（三个项目内容完全一致）
- profiles：`.specify/agents/templates/` 7 个 agent 文件
- cws-lib-python：`.specify/agents/` 8 个（多 code-reviewer）
- cws-lib-bash：`.specify/agents/` 8 个（多 code-reviewer）
- 生成器：profiles `.specify/skills/create-agent/` 17 个模板 + 1 个参考文档
- （其他项目同款技能为复制关系，同病）
- ## Optimization points
- 1. **框架应做 per-tool 渲染**：`.specify/agents/` 存工具中立的规范格式，
- 分发到 `.opencode/` 时渲染为 OpenCode schema（tools 对象化 + 工具名小写 +
- color 转 hex/主题枚举），分发到 `.qoder/` 等保持数组格式；不要四目录同链接。
- 2. **或在模板层取最大公约数**：tools 统一对象映射（多数工具对未知 frontmatter
- 键容忍度高，数组反而是 OpenCode 唯一不支持的形式），color 一律用 hex。
- 3. **模板与参考文档同步修**：create-agent 的 17 个模板与 template-authoring.md
- 是复发源，框架修复时必须一并覆盖。
