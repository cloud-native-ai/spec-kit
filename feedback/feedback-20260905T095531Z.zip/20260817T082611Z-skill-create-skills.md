---
id: "20260817T082611Z-skill-create-skills"
unit_id: "skill:create-skills"
unit_type: "skill"
run_id: "create-normandy-zeus-workspace-2026-08-17"
scope: "local"
probe: "skill-create-skills-wrapup"
kind: "internal"
slice: "skills"
partial: false
created: "2026-08-17T08:26:11Z"
summary: "用 create-skills 为 /usr/local/bin/normandy 与 /usr/local/bin/zeus 两个新 CLI 创建 wrapper 技能（normandy-workspace/zeus-workspace），仿 aone-workspace 模式。流程顺畅：命名遵循 R4 前缀规则、跨 SSOT 碰撞检查通过、Feedback canonical block 与 "
---

## Review
用 create-skills 为 /usr/local/bin/normandy 与 /usr/local/bin/zeus 两个新 CLI 创建 wrapper 技能（normandy-workspace/zeus-workspace），仿 aone-workspace 模式。流程顺畅：命名遵循 R4 前缀规则、跨 SSOT 碰撞检查通过、Feedback canonical block 与 runtime-mode gate 按规范内嵌、压力测试按 utility 技能以 smoke invocation 替代（harvest-help 基线抓取复跑 + quota list-account + zeus --dry-run 均通过）。profiles 项目无 tests/contract/，契约套件声明不适用；Step 7 内置 role agents 仅 skill-verifier/structure-adjuster 两个且均与 CLI wrapper 无角色相关性，无传播对象。

## Optimization Points
- create-skills Step 2 的 SKILL_HOME 选项未覆盖 profiles 项目 R1 特例：在 profiles 项目创建的通用技能终局实体必须在 config/skills/，`.specify/skills/` 只是符号链接入口；本次按 R1 直接落实体到 config/skills/ 再反向建链，避免了"先建项目级再迁移"的二遍工，建议 SKILL.md Step 2 增加一条 profiles 项目分流提示（token-efficiency：避免二次迁移的重复文件读写）。
- create-skills 完成报告模板未含 profiles 特有扩散面（QoderWork/千问注册表/悟空 install-local + skills-map.lst 计数回写），本次靠 always_on 规则 R1 补齐；建议 Step 6 质量清单在 profiles 项目追加一行 R1 扩散检查指针。
