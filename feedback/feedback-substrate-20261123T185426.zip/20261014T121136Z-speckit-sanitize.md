---
id: "20261014T121136Z-speckit-sanitize"
unit_id: "/speckit.sanitize"
unit_type: "command"
run_id: "20261014T121135Z"
scope: "local"
probe: "speckit-sanitize-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-14T12:11:36Z"
summary: "/speckit.sanitize 全量运行:dead-reference 检查的 speckit.* 命令引用校验在用户工作区产生 7 项误报(本次运行中占 13 项发现的 54%)"
---

## Review
/speckit.sanitize 全量运行:dead-reference 检查的 speckit.* 命令引用校验在用户工作区产生 7 项误报(本次运行中占 13 项发现的 54%)

## Optimization Points
- sanitize-utils.py check_dead_references 第 3 分支以工作区根 templates/commands/<name>.md 判定命令存在性 —— 该布局仅存在于框架源仓库,用户工作区命令副本在 .qoder/commands/、.claude/commands/、.github/prompts/ 等平台目录;建议改为任一已安装命令面存在即通过(或回退 .specify/skills/<name> 目录判定)
