---
id: "20261012T161200Z-speckit-sanitize"
unit_id: "/speckit.sanitize"
unit_type: "command"
run_id: "sanitize-20261012-hygiene"
scope: "local"
probe: "speckit-sanitize-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-12T16:12:00Z"
summary: "Full-tree hygiene run on a downstream client project. Collect returned 12 deterministic findings, 0 semantic candidates. Verified 10 dead-reference findings as FALSE POSITIVES before acting: the flagg"
---

## Review
Full-tree hygiene run on a downstream client project. Collect returned 12 deterministic findings, 0 semantic candidates. Verified 10 dead-reference findings as FALSE POSITIVES before acting: the flagged commands are live in .qoder/commands/ and .claude/commands/ and invocable this session; the checker resolves a path that cannot exist downstream. Withheld the recorded repair disposition because executing it would delete valid command references from constitution.md/features.md/glossary.md. The 2 index-inconsistency findings were genuine req-055 legacy residue; user confirmed the destructive bucket, both legacy index.json retired via the sanctioned engine remedy with zero data loss (feedback 2 entries + threshold scalar migrated to state/, knowledge 1 entry preserved as scan-derived .md). Ledger now 2 resolved / 10 pending. .specify/scripts is a strict framework-owned mirror, so the detector defects are upstream-owned and reported here rather than patched locally.

## Optimization Points
- 命令引用存在性检查(`.specify/scripts/python/sanitize-utils.py:413-415`)以 `<workspace>/templates/commands/<name>.md` 解析,在任何下游 client 项目中都不可能命中:`regen-command-copies.py:2,4` 声明真源是 `.specify/templates/commands/`(缺 `.specify` 前缀),且 `sync-mirrors.py:83` 把 `commands` 从 templates pair 双向排除("mirror is intentionally NO LONGER maintained",`:18-21`),`specify init` 根本不下发该子树。后果:每次 collect 对 `constitution.md` / `features.md` / `glossary.md` 产出 10 条 dead-reference 假阳性,而其建议处置 `repair` 若被执行会删除宪章中合法的命令引用。修复方向:改为解析 per-tool 生成副本目录(`_ASSISTANT_COMMAND_DIRS`,即 `.qoder/commands/`、`.claude/commands/` 等),`.specify/templates/commands/` 存在时作为回退。
- 技能引用检查(`sanitize-utils.py:417-419`)同源缺陷:解析 `<root>/skills/<name>` 而非 `.specify/skills/<name>`。本次未触发只因 `_iter_reference_materials`(`:320`)扫描面窄(`.specify/memory/*.md` + todo/draft/specs),属潜在假阳性面。
- `cmd_apply`(`sanitize-utils.py:1017-1022`)对 `repair` 与 `dismiss` 一律写 `f["state"] = "resolved"`,使 `merge_findings:237` 的 sticky `dismissed` 分支("user verdict stays authoritative")不可达 —— 被 dismiss 的假阳性会在下次 collect 经 `:231-236` 重新 reopen。修复方向:dismiss 项应落 `dismissed` 状态。正因如此本次未对 10 条假阳性下 dismiss,而是留 pending。
- index-inconsistency 发现项记录的 knowledge 域修复命令不完整:finding summary 给出 `memory-utils.py --action reindex`,但 `_collect_scopes`(`memory-utils.py:372-373`)在无 `--scope` 时只返回默认 `session`,该命令对 `knowledge` 静默 no-op(实测首轮返回 `{"reindexed": {"session": 0}, "migrated": []}`)。必须 `--scope all` 或 `--scope knowledge` 才真正退役 `knowledge/index.json`。修复方向:finding 的 remedy 文案带上 `--scope all`。
- token-efficiency:`collect` 之后紧接一次 `--action status`,返回与 collect 的 `store` 摘要完全相同(约 40 行重复注入上下文)。skill Stage 4 措辞"ledger digest can be re-inspected at any time"易被读成 Present 前需再取一次;建议明确 collect 输出即 Present 所需摘要,无需追加 status 调用。
