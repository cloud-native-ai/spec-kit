# Feedback Package Manifest

> This feedback targets the Spec Kit framework itself (templates, commands, skills, scripts, docs) — not the LLM, agent CLI, harness, or any user project code.

- **Generated**: 2026-11-23T10:53:06Z
- **Entries**: 4
- **Time range**: 2026-08-19T02:24:02Z → 2026-10-14T15:47:03Z
- **spec-kit version**: 0.0.22
- **Install source**: https://gitlab.alibaba-inc.com/cloud-native-ai/spec-kit.git @ cdc79cdb52c892e8ed43145860cea2cd6ffdbfdf
- **Excluded (non-framework, kept local)**: 2 entries — skill:create-docs, skill:sanitize-materials

| Created | Unit | Partial | Probe | Slice | Summary |
|---------|------|---------|-------|-------|---------|
| 2026-08-19T02:24:02Z | /speckit.instructions | False | speckit-instructions-wrapup | commands | Bootstrap run: instructions.md generated from template and filled with project facts; user directive (Go stack + macOS/L |
| 2026-10-12T16:12:00Z | /speckit.sanitize | False | speckit-sanitize-wrapup | commands | Full-tree hygiene run on a downstream client project. Collect returned 12 deterministic findings, 0 semantic candidates. |
| 2026-10-12T16:12:55Z | /speckit.sanitize | False | gate-sanitize-destructive-cleanup | commands | confirm-gate observation — gate-sanitize-destructive-cleanup fired once during run sanitize-20261012-hygiene of /speckit |
| 2026-10-14T15:47:03Z | /speckit.sanitize | False | speckit-sanitize-wrapup | commands | 命令生命周期:Preflight→Collect→Judge(空)→Present→用户确认方案A→Apply(引擎判据修复+重收敛)→Wrap-up 全程完成;台账收敛 0 pending;docs 无需同步(修复仅在引擎脚本,skill |
## Exec-Quant Payload

Exec-Quant Payload: none (无量化数据).
The source store had no readable exec-quant records at package time.
- **Skipped unreadable**: 0
- **Truncated**: 0
- **Cap**: 1000 records / 16777216 bytes (triggered: no)
- **Source project**: xuanji-cli

