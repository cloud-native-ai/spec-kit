---
id: "20261014T154703Z-speckit-sanitize"
unit_id: "/speckit.sanitize"
unit_type: "command"
run_id: "sanitize:20261014T154623Z"
scope: "local"
probe: "speckit-sanitize-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-14T15:47:03Z"
summary: "命令生命周期:Preflight→Collect→Judge(空)→Present→用户确认方案A→Apply(引擎判据修复+重收敛)→Wrap-up 全程完成;台账收敛 0 pending;docs 无需同步(修复仅在引擎脚本,skill/command 文档均以引擎 --help 为真源)。"
---

## Review
命令生命周期:Preflight→Collect→Judge(空)→Present→用户确认方案A→Apply(引擎判据修复+重收敛)→Wrap-up 全程完成;台账收敛 0 pending;docs 无需同步(修复仅在引擎脚本,skill/command 文档均以引擎 --help 为真源)。

## Optimization Points
- 全根扫描:12 条台账(10 pending dead-reference + 2 resolved req-055),无语义候选
- 10 条判定为检测器假阳性并经用户确认走根因修复(方案 A),重跑 collect auto_resolved 10,0 pending
- 无破坏性项,未建 cleanup-plan,门控未触发;delegate 分诊无项
