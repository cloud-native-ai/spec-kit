---
id: "20261012T161255Z-speckit-sanitize"
unit_id: "/speckit.sanitize"
unit_type: "command"
run_id: "gate:gate-sanitize-destructive-cleanup:20261012T161231Z"
scope: "local"
probe: "gate-sanitize-destructive-cleanup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-12T16:12:55Z"
summary: "confirm-gate observation — gate-sanitize-destructive-cleanup fired once during run sanitize-20261012-hygiene of /speckit.sanitize (actual trigger: delegated internal skill sanitize-materials Stage 5)."
---

## Review
confirm-gate observation — gate-sanitize-destructive-cleanup fired once during run sanitize-20261012-hygiene of /speckit.sanitize (actual trigger: delegated internal skill sanitize-materials Stage 5). Context: 2 of 12 collected findings were genuine req-055 legacy index.json residue whose sanctioned remedy deletes a file, landing in the destructive bucket. Presented as ONE batch of 2 items with per-item effect/bucket/recovery. User decision signal: approved-as-is — no modification, no follow-up questions, no veto. The gate caught no agent error (both items were independently verified genuine before presentation); its value was front-loading the authority to delete two git-tracked files. Also observed: 10 dead-reference findings were judged false positive and actively excluded from the plan before the confirmation batch, showing the two-level criteria分流 operates ahead of the destructive bucket — but that same case exposes a risk, since engine-assigned disposition repair sits in the reversible bucket and would have executed a content-destroying edit without any confirmation had the agent not re-verified it.

## Optimization Points
- `gate_id`: `gate-sanitize-destructive-cleanup`。
- `fired_during`: 注册归属单元 `/speckit.sanitize`(command),运行 `sanitize-20261012-hygiene`;实际触发单元为其委派的 internal 技能 `sanitize-materials` Stage 5(Confirm)。
- 触发上下文:collect 产出 12 条发现,其中 2 条 index-inconsistency(req-055 legacy `index.json` 残留)的既定修复途径 `--action reindex` 会删除文件,落入破坏性桶,故前置批量确认一次。
- 用户决定与决策信号:**approved-as-is**(照单放行)。计划以单批呈现 2 项,逐项含 effect / bucket / recovery 三要素;用户未修改、未追问、未否决。
- 观察事实:门控未拦截到 agent 判断错误——2 项在呈现前已由 agent 独立核实为真(`feedback-utils.py:20-24,378-397`、`memory-utils.py:233-247` 均明文记载 legacy index 为只读回退并由 reindex 退役删除)。门控的实际价值在于把「删除两个 git 跟踪文件」这一不可撤销动作的决定权前置给用户,而非纠错。
- 观察事实:同批呈现中另有 10 条 dead-reference 被 agent 判为假阳性并**主动排除出计划**(未进入确认批次),说明两级判据的分流在破坏性桶之前已生效——假阳性若被当作 `repair` 执行,会删除宪章中合法的命令引用,而 `repair` 属可逆桶、本不需确认。此处暴露的风险是:引擎给出的 `disposition` 未经 agent 复核时,可逆桶会绕过确认执行内容破坏性修改。
- 观察事实:执行期一处 remedy 文案不准确(knowledge 域需 `--scope all`,finding summary 未带),首轮 reindex 静默 no-op;由 agent 复核落盘结果时发现并纠正,未造成数据损失。
