---
id: "20260813T134132Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "improve-create-pages-restructure-20260813"
scope: "local"
feature: "create-pages"
partial: false
created: "2026-08-13T13:41:32Z"
summary: "按用户方向重构 create-pages：SKILL.md 346→143 行（契约化、五步工作流分解）；确定性脚手架逻辑抽为 scripts/scaffold.sh（参数化、幂等、JSON 输出）并通过 docker 运行时实测（构建 8 页/标题提取/无泄漏/no-docs 守卫均通过）；设计原理与验证步骤下沉 references/。同时修复原 Verification 中无效命令 bash"
---

## Review
按用户方向重构 create-pages：SKILL.md 346→143 行（契约化、五步工作流分解）；确定性脚手架逻辑抽为 scripts/scaffold.sh（参数化、幂等、JSON 输出）并通过 docker 运行时实测（构建 8 页/标题提取/无泄漏/no-docs 守卫均通过）；设计原理与验证步骤下沉 references/。同时修复原 Verification 中无效命令 bash .aoneci/deploy-pages.yaml。

## Optimization Points
- **优化点 1（create-skills 缺失瘦身门禁）**：本次 create-pages 由 create-skills 生成时产出了 346 行 SKILL.md（约 250 行内联模板代码），随即需要 improve-skills 全量返工为「契约 + 脚本 + references」结构。建议 create-skills 工作流增加创建后瘦身检查：>5 行代码块必须下沉 scripts/ 或 references/，确定性文件生成逻辑直接产出脚手架脚本（token-efficiency：L1 膨胀使每次技能触发都把全部模板重注入上下文，且模板转录易错）。
