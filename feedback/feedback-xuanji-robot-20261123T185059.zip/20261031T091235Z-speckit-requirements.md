---
id: "20261031T091235Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "r20261031T090000Z-7b01"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
feature: "014-author-robot-design"
feature_id: "024"
partial: false
created: "2026-10-31T09:12:35Z"
summary: "create-new-requirements.sh 在本机直接失败于 CWS_LIB_BASH_HOME 未设置（common.sh 硬依赖 cws_bash_env），只能临时造一个空 stub 才能跑通；脚本还会 git checkout -b 新分支，与 sdd 线 worktree 的 line/* 分支模型冲突，需要手工切回并删除临时分支。validate-requirements 通"
---

## Review
create-new-requirements.sh 在本机直接失败于 CWS_LIB_BASH_HOME 未设置（common.sh 硬依赖 cws_bash_env），只能临时造一个空 stub 才能跑通；脚本还会 git checkout -b 新分支，与 sdd 线 worktree 的 line/* 分支模型冲突，需要手工切回并删除临时分支。validate-requirements 通过；pre-analyze 0 error/0 advisory；decomposition proceed。给 Shared Strings 登记证据行标记（证据：）会被 doc-consistency 的 evidence 面误读为断言行并报 grade-asof-unpaired，最终只能删掉该行改为引用表达式门禁 owner。doc-consistency 的 evidence 面在文件提交前一律 not-evaluated（无提交历史），因此提交前无法拿到该面绿灯。

## Optimization Points
- 1) 脚手架脚本把 CWS_LIB_BASH_HOME 当硬依赖却只用于 source 一个可选环境文件：缺省时应降级为 no-op 而不是 exit 1；2) 脚手架创建分支前应支持 --no-branch 或以当前分支为准，适配 worktree/line 分支模型；3) doc-consistency 的 evidence 面应把未跟踪文件按 as-of 与当前日期比较，或明确把 not-evaluated 排除出 blocking 退出码；4) Shared Strings 表行含证据标记时应跳过证据面解析（表格行不是断言行）。
