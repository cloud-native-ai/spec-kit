---
id: "20260915T131232Z-speckit-feature"
unit_id: "/speckit.feature"
unit_type: "command"
run_id: "gate:gate-feature-status-regression:20260915T131232Z"
scope: "local"
probe: "gate-feature-status-regression"
kind: "internal"
slice: "commands"
partial: false
created: "2026-09-15T13:12:32Z"
summary: "confirm-gate | gate-feature-status-regression fired during /speckit.feature full-registry reconcile (2026-09-15). 宪法 v2.0.0.1 定位变更后依代码事实对账，发现 003/004/005 三行 Implemented 宣称与仓库实况不符（005 为硬编码桩且 go.mod 无阿里"
---

## Review
confirm-gate | gate-feature-status-regression fired during /speckit.feature full-registry reconcile (2026-09-15). 宪法 v2.0.0.1 定位变更后依代码事实对账，发现 003/004/005 三行 Implemented 宣称与仓库实况不符（005 为硬编码桩且 go.mod 无阿里云 SDK；003 写接口为 mock 无持久化；004 服务端派发 GetInternal 零调用点）。用户在四选一问卷中显式裁决后状态方回退。决策信号 modified：005 选「降级 Draft 保留待建」而非建议的「标注退役候选」，003/004 选「两行都降级 Planned」而非建议的「保留 Implemented 收窄描述」。

## Optimization Points
- gate_id: gate-feature-status-regression
- 决策信号: modified（用户放行但对两项建议方案作了修改）
- 触发上下文: 宪法 v2.0.0.1 重新定位后全注册表对账，代码事实与三行 Implemented 宣称不符
- 用户裁决: 005 Implemented→Draft（选「保留待建」而非建议的「标注退役候选」）；003/004 Implemented→Planned（选「两行都降级」而非建议的「保留 Implemented 收窄描述」）；008 保持 Implemented 仅收窄描述并拆出 017/018
- 观察: 门控有效——三处回退均先取得显式确认后才写入，未发生静默回退
