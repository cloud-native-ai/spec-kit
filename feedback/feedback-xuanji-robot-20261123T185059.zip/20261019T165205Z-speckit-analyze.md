---
id: "20261019T165205Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "009-analyze-20261020-round3"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
feature: "009-upstream-delegation-streaming"
feature_id: "014"
partial: false
created: "2026-10-19T16:52:05Z"
summary: "Completed the third /speckit.analyze pass for feature 009/014. Closed the prior flaky cmd/server HIGH with repeated full-suite evidence; full rescan found 1 new CRITICAL (task graph does not enforce t"
---

## Review
Completed the third /speckit.analyze pass for feature 009/014. Closed the prior flaky cmd/server HIGH with repeated full-suite evidence; full rescan found 1 new CRITICAL (task graph does not enforce tests-first for T032/T035/T049) and 1 new HIGH (attempts field domain excludes zero-attempt terminals). Eight candidates were validated: 2 confirm, 6 downgrade, 0 reject. Friction: check-prerequisites.sh still hard-fails without CWS_LIB_BASH_HOME; quickstart escaped-pipe test commands run zero tests and exit 0.

## Optimization Points
- 1) Apply the propagation-surface cap before the validation wave: 6 of 8 candidates were downgraded (75%), mostly because detection rated docs-only/field-label issues as HIGH. Starting those at MEDIUM would have halved the validation wave.
- 2) Make `check-prerequisites.sh` auto-detect a local cws-lib-bash or print a one-line remediation; it still hard-fails when CWS_LIB_BASH_HOME is unset.
- 3) Add a template-level guard for quickstart test commands: require real regex alternation (`|`) and reject/flag `\|`, which matches zero tests and exits 0, enabling false-pass verification.
- 4) Token efficiency: full artifact reads were necessary for the cross-artifact pass; a small Python mapping script replaced manual FR coverage counting (no avoidable raw-data dumping observed).
