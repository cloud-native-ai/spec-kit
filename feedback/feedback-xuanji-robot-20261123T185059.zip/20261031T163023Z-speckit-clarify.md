---
id: "20261031T163023Z-speckit-clarify"
unit_id: "/speckit.clarify"
unit_type: "command"
run_id: "r20261101T002900Z-c1a1"
scope: "local"
probe: "speckit-clarify-wrapup"
kind: "internal"
slice: "commands"
feature: "024"
partial: false
created: "2026-10-31T16:30:23Z"
summary: "Clarify stage: the dispatch brief asked for --complexity standard, but the engine's value domain is complex|simple (simple emits no record); passed complex so a record exists, and axes with no sensor "
---

## Review
Clarify stage: the dispatch brief asked for --complexity standard, but the engine's value domain is complex|simple (simple emits no record); passed complex so a record exists, and axes with no sensor honestly reported not_evaluated. Also --feature 024 was split into --feature 014-author-robot-design plus --feature-id 024 because the engine distinguishes requirement key from registry ID. Five ambiguities were real (KB unconfigured vs three-state, hot-reload atomic scope, redaction list, state vocabulary owner, L1 two-hop pointer); the first gate run was green but self-review caught drifting file:line citations in the clarify evidence itself.

## Optimization Points
- Brief-to-tool-contract drift: when a dispatch template hardcodes a flag value, derive it from the engine's own --help value domain instead of trusting the brief, and record the substitution. For expression/design stages, consider declaring the run's complexity from the task-complexity rubric rather than an ad-hoc label, so the record's axes match the real scope.
