---
id: "20261024T131230Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "20261024-s-b-mcp-requirements"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
feature: "009-mcp-business-tools"
partial: false
created: "2026-10-24T13:12:30Z"
summary: "Requirements for the MCP business-tool slice were produced, validated (24 FR / 7 SC, 0 markers, checker exit 0) and committed. One framework friction surfaced: create-new-requirements.sh derived 20260"
---

## Review
Requirements for the MCP business-tool slice were produced, validated (24 FR / 7 SC, 0 markers, checker exit 0) and committed. One framework friction surfaced: create-new-requirements.sh derived 20260106 because it treats any top-level branch with leading digits (origin/20260105_...) as spec numbering, contradicting the skill's exact <NNN>-<slug> rule; it also auto-switched branches. The run recovered to 009 manually.

## Optimization Points
- create-new-requirements.sh should apply the exact top-level <NNN>-<slug> form check (currently underscore/8-digit branches like origin/20260105_27872861_test_1 inflate the next number) and should not auto-create and switch branches when the caller already has a working branch.
