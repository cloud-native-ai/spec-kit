---
id: "20261113T070409Z-speckit-sanitize"
unit_id: "/speckit.sanitize"
unit_type: "command"
run_id: "sanitize-20261113T0710Z"
scope: "local"
probe: "speckit-sanitize-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-13T07:04:09Z"
summary: "Default materials lane: collect found 126 pending dead-reference findings concentrated in 007 spec artifacts plus README; adjudicated 6 real anchor breaks (post-migrate), 101 dismissals (command-invoc"
---

## Review
Default materials lane: collect found 126 pending dead-reference findings concentrated in 007 spec artifacts plus README; adjudicated 6 real anchor breaks (post-migrate), 101 dismissals (command-invocation mentions, brace/submodule extraction tails, dated evidence), 19 README doc/draft refs left pending and delegated to /speckit.docs; apply 107/107 ok.

## Optimization Points
- 1) engine probes root templates/commands for speckit.* refs — always false-positive in client workspaces where templates live under .specify/; 2) brace-form and submodule-prefixed path extraction produces tail fragments as dead refs; 3) dismissals cannot be recorded for programmatic findings via record (semantic-only), so plan-time override is the only channel; 4) an external process deleted .specify/skills/git-workflow-sync mid-run (restored from HEAD)
