---
id: "20261013T124722Z-speckit-feedback"
unit_id: "/speckit.feedback"
unit_type: "command"
run_id: "package-20261013-clienthat"
scope: "local"
probe: "speckit-feedback-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-13T12:47:22Z"
summary: "以显式 package 请求执行 Path B。帽子判定：根级 templates/skills/shared/src/specify_cli 均缺失，仅 scripts 存在且经核实是本项目自身的构建脚本目录（build.sh / generate-mybatis-plus.sh / test.sh，无 scripts/python），属同名巧合而非框架源目录 → 判定为**客户项目**；故 P"
---

## Review
以显式 package 请求执行 Path B。帽子判定：根级 templates/skills/shared/src/specify_cli 均缺失，仅 scripts 存在且经核实是本项目自身的构建脚本目录（build.sh / generate-mybatis-plus.sh / test.sh，无 scripts/python），属同名巧合而非框架源目录 → 判定为**客户项目**；故 Path B 既是显式请求、也是 kind 判定的自然结果（external_count=0，Path A 无材料）。清点：14 条全部 open（disposition 全空），internal 11 + legacy 3，覆盖 9 个框架单元（/speckit.sanitize·goal·instructions·docs 各 2 或 1，create-docs·create-team·improve-skills·create-pages·git-workflow）；introspection_ref 全为 0，故未提议 --include-introspection；backlog.md 不存在（无「已路由未执行」积压）。Path B step1 的 Introspection 属建议非强制，本次因用户显式 package 且 short-circuit 跳过 routing step2-5 而未跑，已如实报告为跳过。执行：package dry-run → 真实 package → 删除 dry-run 重复产物 → cleanup dry-run 预览（would_remove 14 / remaining_after 0）→ cleanup 落地。收尾核验：status 计数归 0、should_prompt=false、list 0 条、cleanup-log.md 逐条记录移除并标注归档 zip、zip 完好（15 files/25866 bytes）、submitted_at 仍为 null（mark-submitted 属投递后步骤，未代跑）。全程零网络。术语表已查阅，本次无同音/易混词需纠正，亦无新术语可提议。

## Optimization Points
- **`--action package --dry-run` 并非无副作用：它照样生成了 zip**（严重度：中，引擎行为与 flag 语义不符）。
- 实测证据：先跑 `--action package --dry-run`，输出自称「Packaged 14 feedback entries (**sources
- untouched**)」并打印 zip 路径 `packages/feedback-20261013T124427Z.zip`；随后跑真实
- `--action package` 得到 `feedback-20261013T124502Z.zip`。`ls packages/` 显示**两个 zip 并存**，
- 经 `unzip -l` 比对二者文件清单**完全一致**（15 files / 25866 bytes / Entries: 14），仅 MANIFEST 的
- Generated 时间戳不同。即 dry-run 已落盘产物，"sources untouched" 只覆盖了「不改动 feedback 条目源文件」，
- 未覆盖「不产生交付物」。
- 影响：① outbox 里出现内容重复的多个 zip，投递时无法判断该发哪个（本次靠人工比对 + 删除 dry-run 产物消歧）；
- ② 反复 dry-run 会持续堆积 zip；③ 与 `--action cleanup --dry-run` 的行为不一致——后者的 dry-run
- 只输出 `would_remove`/`remaining_entries` 计划、`removed: []` 且**不改动 store**，是真正的无副作用预览。
- 期望改进方向：让 `package` 的 `--dry-run` 与 `cleanup` 对齐——只打印将要生成的 zip 路径、条目数与
- 清单预览，**不落盘 zip**；若为兼容性必须落盘，则应写入临时目录或在输出中显式标注
- 「dry-run 已产生文件，需自行清理」，并在文案里去掉会被误读为「无任何产物」的 "sources untouched"。
- **legacy 条目（`kind`/`slice` 为空）被照常打包，但汇总视图无法据 `kind` 归类**（严重度：低，观察项）。
- 实测：`--action list --limit 0 --format json` 得 14 条，`kind` 分布为 `{'internal': 11, '': 3}`、
- `slice` 为 `{'skills': 5, 'commands': 6, '': 3}`，与 `--action status` 的 `legacy_remaining: 3` 吻合；
- `--action package` 未报 `excluded_external`，14 条全部入包。行为本身合理（legacy 属框架早期条目，
- 应随包上行），但路由判定要求「报告每侧各多少条」时，这 3 条既不是 internal 也不是 external，
- 只能靠 `legacy_remaining` 交叉印证。建议在 `list` 输出里给 legacy 条目一个显式标记（如
- `kind: "legacy"` 或独立计数字段），使分类汇总可直接程序化，无需与 status 的 `legacy_remaining` 对账。
