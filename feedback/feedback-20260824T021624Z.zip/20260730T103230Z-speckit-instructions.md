---
id: "20260730T103230Z-speckit-instructions"
unit_id: "/speckit.instructions"
unit_type: "command"
run_id: "instructions-refresh-20260730T1831"
scope: "local"
partial: false
created: "2026-07-30T10:32:30Z"
summary: "Directed follow-up reconcile after /speckit.docs restructured docs/ into the six-type taxonomy. Setup script exited 0 with backup; memory-recall surfaced the taxonomy knowledge entry recorded by /spec"
---

## Review
Directed follow-up reconcile after /speckit.docs restructured docs/ into the six-type taxonomy. Setup script exited 0 with backup; memory-recall surfaced the taxonomy knowledge entry recorded by /speckit.docs, which matched observation. Convergence was minimal and precise: 6 Documentation Map rows repointed, 1 Dependencies row added, 1 Key Directories bullet updated; every other section within tolerance and untouched. Scripted test -e verified all 11 map paths; heading-set coverage diff against backups shows nothing lost; registries and all 6 compatibility symlinks intact.

## Optimization Points
- Two same-day runs of this command each re-ran the full setup script and produced a new full backup, though the second run's real drift was known in advance (the /speckit.docs handoff explicitly said "Documentation Map paths moved"). A lightweight handoff channel — e.g. the invoking command recording a machine-readable "sections likely stale" hint that this command reads before the full observation pass — would let directed follow-up runs skip re-verifying sections that were within tolerance hours earlier.
