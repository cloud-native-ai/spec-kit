---
id: "20260730T082408Z-speckit-instructions"
unit_id: "/speckit.instructions"
unit_type: "command"
run_id: "instructions-refresh-20260730T0819"
scope: "local"
partial: false
created: "2026-07-30T08:24:08Z"
summary: "Full reconcile with empty ARGUMENTS on an existing v-base instructions file. Setup script exited 0, wrote backup .specify/instructions.md-2026-07-30-161937, kept the base in place, refreshed symlinks."
---

## Review
Full reconcile with empty ARGUMENTS on an existing v-base instructions file. Setup script exited 0, wrote backup .specify/instructions.md-2026-07-30-161937, kept the base in place, refreshed symlinks. Observation snapshot classified 9 base sections; backup diff found no lost user-authored content. Six sections converged on stale facts (all traceable to the recent vendoring commit and a Python baseline bump to 3.11), three template sections were absent and inserted (H1 title, Task Complexity Rubric, Dogfooding Practice), registry ranges left untouched, glossary seeded with 7 project-specific proposed terms. One cross-artifact inconsistency surfaced that this command cannot fix in scope: constitution Principle X still quotes pyproject as '>=3.8'.

## Optimization Points
- The Documentation Map path-existence check is scripted, but numeric/asserted facts in `## Tech Stack & Resources` are not. This run found `Python 3.8+`, `Runtime Dependencies: click, pyyaml, requests, python-dotenv`, and the pytest marker list all stale — every one of them is mechanically checkable against `pyproject.toml` (`requires-python`, `dependencies`, `[tool.pytest.ini_options].markers`, `[project.optional-dependencies]` keys). The command should mandate a scripted config-vs-instructions fact diff for these specific keys, the same way it already mandates `test -e` for Location cells, instead of leaving them to eyeball comparison.
- Action 6's coverage check ("diff the result against every backup") produces false positives when a section is reordered rather than deleted: a line-based diff flagged `## Fact, Correctness & Logic Checks` as "missing" purely because it moved, and flagged the replaced `| None yet. |` registry placeholder. The instruction should specify set-membership comparison of section headings (not positional diff) and should explicitly exempt `None yet.` placeholder rows, so the check does not train the agent to dismiss its own warnings.
