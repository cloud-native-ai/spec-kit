---
id: "20260806T115604Z-skill-cws-py-cli"
unit_id: "skill:cws-py-cli"
unit_type: "skill"
run_id: "cms2-support-2026-08-06"
scope: "local"
feature: "aliyun-cms2-support"
partial: false
created: "2026-08-06T11:56:04Z"
summary: "Vendored alibabacloud-cms20240330 and built cms2 library/CLI/tests; smooth overall, friction only in vendor sync crash."
---

## Review
Vendored alibabacloud-cms20240330 and built cms2 library/CLI/tests; smooth overall, friction only in vendor sync crash.

## Optimization Points
- cws_py_vendor sync aborts mid-run with PermissionError when lib/ contains root-owned __pycache__ dirs (h11/httpx/httpcore/readchar), after it has already deleted tracked lib files; needed targeted wheel vendoring as workaround. Suggest clean_targets ignore __pycache__/pyc entries or pre-clean them.
