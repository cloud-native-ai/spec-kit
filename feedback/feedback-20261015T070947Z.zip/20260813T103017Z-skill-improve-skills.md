---
id: "20260813T103017Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "xuanji-extension-run-config-injection-2026-08-13"
scope: "local"
partial: false
created: "2026-08-13T10:30:17Z"
summary: "Added config read/inject/modify capability to xuanji-extension-run. Corrected the user's localStorage premise against source (chrome.storage.local only), enumerated the real key catalog (region/bucket"
---

## Review
Added config read/inject/modify capability to xuanji-extension-run. Corrected the user's localStorage premise against source (chrome.storage.local only), enumerated the real key catalog (region/bucket/stsUrl/storage/retry*/autoClip/*WorkloadFilter), and live-verified read+set+remove via CDP on options.html. Detailed recipe → references/config-injection.md; SKILL.md got compact Step 4b + a Resources row. Shape gate exit 0; links resolve.

## Optimization Points
- User premise ("plugin uses localStorage") was factually wrong; the fact-check gate (grep src) caught it — the extension uses chrome.storage.local exclusively (0 localStorage hits). Documenting the corrected mechanism + key catalog from source (get_oss_config_fields / OSSConfig / options.tsx) prevented shipping a localStorage-based recipe that would never read/write the real config.
- Config is only accessible from an extension-origin page (chrome-extension://<id>) or the SW, not a normal web page; the read/inject recipe must open options.html first. Verified live: read {bucket,region,stsUrl} + set/remove probe round-trip = CONFIG R/W VERIFIED.
