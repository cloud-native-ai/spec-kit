---
id: "20260922T172025Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "reorg-profiles-browsers-2026-09-23"
scope: "local"
probe: "skill-improve-skills-wrapup"
kind: "internal"
slice: "skills"
partial: false
created: "2026-09-22T17:20:25Z"
summary: "Restructured profiles-browsers per user direction: clone-ui→design (reframed to web-design-analysis producing reproducible design docs, clone as optional application), xuanji-extension/ folded into ex"
---

## Review
Restructured profiles-browsers per user direction: clone-ui→design (reframed to web-design-analysis producing reproducible design docs, clone as optional application), xuanji-extension/ folded into extension/ (unified extension-automation area, overview routes generic-MV3 vs xuanji channel, articulating extension-vs-page automation difference). Downstream updated: SKILL.md description/intent-table/routing-criteria/maintenance-model/capability-table/E-constraints, browser-automation-core.md, instructions.md registry, Feature 019, profiles skill-system.md. Gates: 5 forward coverage probes re-run against git-HEAD-reconstructed source all exit 0; links all resolve; stale area refs cleared. Shape exit 10 (pre-existing over-budget baseline 12071→12161, +90); redline RL-FOCUS-01 TRIGGERED with the same 2 pre-existing signals (focus-guard prohibition lists) recorded as sanctioned exceptions.

## Optimization Points
- 结构重整（目录改名/合并）后，最易漏的是「文档内 Resources 小节标题里硬编码的旧目录路径」——它不是 markdown 链接，链接检查器抓不到，只有 grep 旧目录名才能发现（本次 channel-run/test 的 `References (${SKILL_HOME}/references/xuanji-extension/)` 即此类）。建议 improve-skills 的 rename/removal 下游清单显式加入「grep 旧目录名字面量（含非链接的代码跨度路径）」。
- token-efficiency: 重整前先用一条 grep 抓全所有跨引用再批量 sed，比逐文件 Read+Edit 省大量往返；本次 5 源覆盖复测直接从 git HEAD 重建源材料（`git show HEAD:<path>`），避免保留上一轮 scratch，属可复用的「无 scratch 复测」模式。
