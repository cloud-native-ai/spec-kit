---
id: "20260813T132752Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "xuanji-run-step6-platform-options-2026-08-13"
scope: "local"
partial: false
created: "2026-08-13T13:27:52Z"
summary: "Added Step 6 to xuanji-extension-run (park on a supported platform page + pop up options), renumbered handoff to Step 7 with an OPEN line. Verified live before documenting: asiops.alibaba-inc.com/home"
---

## Review
Added Step 6 to xuanji-extension-run (park on a supported platform page + pop up options), renumbered handoff to Step 7 with an OPEN line. Verified live before documenting: asiops.alibaba-inc.com/home loaded logged-in (no SSO redirect), chrome.windows.create returned type=popup, and the popup rendered all three OSS fields from chrome.storage.local; screenshots captured. Recipe + stale-session branch went to references/platform-and-options.md; manual-handoff.md now says those two surfaces are already open. Shape gate exit 0; 4/4 links resolve.

## Optimization Points
- The user asked for a "popup options window", and the obvious API (chrome.runtime.openOptionsPage) would NOT have delivered it: the manifest declares options_page (legacy key) with no options_ui.open_in_tab, so openOptionsPage opens a TAB. The fact-check gate on the manifest caught this before writing; chrome.windows.create({type:'popup'}) is the honest way to satisfy the request without changing the manifest. Worth generalizing: when a request names a UI affordance ("popup", "window", "sidebar"), verify the manifest key that governs it rather than assuming the common API does it.
- Navigating to a live internal platform needed an explicit "did we land on SSO?" assertion, otherwise a stale-session login page would be handed off as a "ready" state and produce false failures downstream. Any skill step that parks a browser on an authenticated page should carry a login-page guard in the step itself, not only in prose.
