---
id: "20260813T084415Z-skill-create-skills"
unit_id: "skill:create-skills"
unit_type: "skill"
run_id: "xuanji-extension-run-2026-08-13"
scope: "local"
partial: false
created: "2026-08-13T08:44:15Z"
summary: "Created the xuanji-extension-run skill layered on extension-e2e-test, overriding only the browser channel to the project-mandated stock Chrome + agent profile (connectOverCDP / MCP), with Chrome-for-T"
---

## Review
Created the xuanji-extension-run skill layered on extension-e2e-test, overriding only the browser channel to the project-mandated stock Chrome + agent profile (connectOverCDP / MCP), with Chrome-for-Testing demoted to fallback. Registered in the Skills table and propagated to test-engineer + qa-engineer templates. Validation clean (name/dir match, 208 lines, Feedback section, links resolve, node --check OK). Contract suite N/A (no tests/). Pressure test waived by user.

## Optimization Points
- The base skill (extension-e2e-test) hard-codes Chrome for Testing; a project that mandates stock Chrome + a login-bearing profile needs a layered skill, not an edit. create-skills handled the "layer on a sibling skill and override one dimension" case well, but a short reference template for "override skill" (reuse sibling patterns, replace only the differing step) would speed this pattern.
- RED-GREEN pressure test was offered but WAIVED by the user; this discipline skill relies on MUST/MUST NOT lines validated only by manual review, not empirical subagent compliance.
