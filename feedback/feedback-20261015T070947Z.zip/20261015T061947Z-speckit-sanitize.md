---
id: "20261015T061947Z-speckit-sanitize"
unit_id: "/speckit.sanitize"
unit_type: "command"
run_id: "sanitize-20261015T061928Z"
scope: "local"
probe: "speckit-sanitize-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-15T06:19:47Z"
summary: "Full sanitize run: 47 pending findings collected, all medium. 30 judged false positives (19 command-name mentions in prose, 8 doc-omitted .specify/ prefixes with targets verified existing, 2 upstream-"
---

## Review
Full sanitize run: 47 pending findings collected, all medium. 30 judged false positives (19 command-name mentions in prose, 8 doc-omitted .specify/ prefixes with targets verified existing, 2 upstream-repo REC targets, 1 brace-expansion, 1 truncated grep recipe) — dismissed. 2 legacy index residues repaired via feedback-utils/memory-utils reindex (old index.json retired, stores migrated to state/). 15 findings belonged to migrated-archive specs 001-rund-schema-design/002-http-call-inventory (old-project directories colliding with this repo's features.md 001/002); user chose archive — both directories git-mv'd to .specify/archive/spec/, findings dismissed as faithful historical records. Apply 47/47 ok, zero failures; final ledger fully resolved. No delete executed anywhere; destructive-cleanup gate did not fire (plan had no delete/archive rows; directory move was separately user-approved via explicit question).

## Optimization Points
- sanitize-utils dead-reference checker: consider whitelisting /speckit.<cmd> prose mentions, brace-expansion paths (src/__tests__/akeops-{a,b}), truncated src/... grep recipes, and resolving doc-omitted .specify/ prefix before flagging — 30/47 findings this run were checker false positives, masking the 2 real residues and 15 archive findings
