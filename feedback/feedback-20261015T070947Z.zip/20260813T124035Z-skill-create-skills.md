---
id: "20260813T124035Z-skill-create-skills"
unit_id: "skill:create-skills"
unit_type: "skill"
run_id: "xuanji-extension-split-2026-08-13"
scope: "local"
partial: false
created: "2026-08-13T12:40:35Z"
summary: "Split xuanji-extension-run into a prep/launch/handoff front door (run) plus a new automated-testing layer (test). Moved config-injection.md + run-attach-template.js to test via git mv (delete-and-abso"
---

## Review
Split xuanji-extension-run into a prep/launch/handoff front door (run) plus a new automated-testing layer (test). Moved config-injection.md + run-attach-template.js to test via git mv (delete-and-absorb, no content lost), added references/manual-handoff.md (Option 1) and references/surface-tests.md (fixture technique + observable signals from a verified run). Defined an explicit HANDOFF contract as the seam. Registry now has both rows; both agent templates updated. Gates: both SKILL.md exit 0 (run needed 3 fences compressed from exit 10), 0 broken links, no stale refs to moved files, node --check OK; contract suite not applicable (no tests/).

## Optimization Points
- A split needs an explicit machine-readable seam, not just prose. Defining a "HANDOFF block" (STS / CDP / EXT_ID / BUILD) as run's output and test's documented entry contract — with a stop rule ("if CDP is absent, hand back; do not launch a browser here") — is what keeps the two halves from both trying to own the browser. create-skills' split guidance would be stronger with an explicit "define the handoff contract" step.
- Compressing the front-door skill tripped the shape gate's long-fence rule (3 fences >5 lines, exit 10) even though total tokens were well under budget. Splitting a skill tends to concentrate command blocks in the surviving prep steps, so the gate should be re-run on BOTH halves right after the split, not only on the new skill — the pre-existing skill is the one that regresses.
