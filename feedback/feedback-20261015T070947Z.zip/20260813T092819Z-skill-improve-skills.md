---
id: "20260813T092819Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "xuanji-extension-run-sts-prereq-2026-08-13"
scope: "local"
partial: false
created: "2026-08-13T09:28:19Z"
summary: "Added Step 0 (account env + local STS token service) to xuanji-extension-run per explicit user request. Verified every component live (PROFILES account dir, aliyun_account_setenv function, cws_py_daem"
---

## Review
Added Step 0 (account env + local STS token service) to xuanji-extension-run per explicit user request. Verified every component live (PROFILES account dir, aliyun_account_setenv function, cws_py_daemon, :8900 STS) and executed the full sequence — STS returned HTTP 200 {ak,sk,token}. Detailed recipe + gotchas went to references/prerequisites-sts.md; SKILL.md got a compact Step 0, Strict Requirement 10, a resource row, and a dependency. Shape gate exit 0; links resolve.

## Optimization Points
- The user-described prep sequence was accurate but had a non-obvious failure mode only caught by executing it: aliyun_account_setenv in a pipeline/subshell (aliyun_account_setenv | head) loses its exports, so cws_py_daemon starts credential-less and the STS endpoint returns HTTP 500. Documenting the ordering AND the subshell/HTTP-200 gotchas (not just the happy-path commands) is what makes the Step 0 addition reliable.
- curl -s exits 0 on connection-refused and 500; asserting on the exit code (not %{http_code}) produced a false "endpoint up" reading earlier. Skill guidance now assert on HTTP 200 + body keys.
