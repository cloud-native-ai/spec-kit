---
id: "20260805T022957Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "improve-aliyun-document-infotable-20260805"
scope: "local"
partial: false
created: "2026-08-05T02:29:57Z"
summary: "按用户明确需求为 aliyun-document 增加服务信息表：从缓存 meta 提取真实 endpoint 建立 references/service-info-table.md（含数据来源 MUST 规则与维护规则），SKILL.md 工作流接入（俗名映射、首次同步回写、endpoint 直答），同步更新 frontmatter 触发词与注册表描述。skills-utils validate"
---

## Review
按用户明确需求为 aliyun-document 增加服务信息表：从缓存 meta 提取真实 endpoint 建立 references/service-info-table.md（含数据来源 MUST 规则与维护规则），SKILL.md 工作流接入（俗名映射、首次同步回写、endpoint 直答），同步更新 frontmatter 触发词与注册表描述。skills-utils validate 通过。

## Optimization Points
- 为"维护信息表"类需求改进技能时，先从已缓存的事实源（本例为 meta api-docs.json 的 endpoints 字段）提取真实数据再建表，避免了凭记忆编造 endpoint；该"事实源优先建表"做法可作为 improve-skills 处理数据表类需求的标准前置步骤写入工作流。
