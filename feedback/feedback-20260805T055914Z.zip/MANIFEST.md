# Feedback Package Manifest

> This feedback targets the Spec Kit framework itself (templates, commands, skills, scripts, docs) — not the LLM, agent CLI, harness, or any user project code.

- **Generated**: 2026-08-05T05:59:14Z
- **Entries**: 12
- **Time range**: 2026-08-01T12:14:16Z → 2026-08-05T05:57:00Z
- **spec-kit version**: 0.0.22
- **Install source**: https://gitlab.alibaba-inc.com/cloud-native-ai/spec-kit.git @ 127753962c10553206b779ffefed8c7723e01686

| Created | Unit | Partial | Summary |
|---------|------|---------|---------|
| 2026-08-01T12:14:16Z | skill:draw-plantuml | False | 完成 mac-home LiteLLM+本地Agent 整体架构部署图：12 核心元素，经多轮渲染排错循环（语法二分定位、彩色标记陷阱、布局调整）定稿，PNG/SVG/puml/HTML 四件套交付 data/machome/archite |
| 2026-08-01T15:11:59Z | skill:improve-skills | False | Single-target improvement of dingtalk-meeting per explicit user direction: repositioned from a booking-operations manual |
| 2026-08-01T15:27:54Z | skill:improve-skills | False | Incremental improvement of dingtalk-meeting per user follow-up: added the modify-booked-meeting action as a sixth lifecy |
| 2026-08-01T15:43:43Z | skill:dingtalk-follow-up | False | 按用户显式需求对 dingtalk-follow-up 完成事项中心重设计：SKILL.md 从 447 行双区模型（群聊区 6 步 + Diary 区 D0-D6）重写为 282 行单一事项工作流（S0-S7），三层输入金字塔（L1 日志 |
| 2026-08-01T16:20:13Z | skill:dingtalk-follow-up | False | 按用户需求把 dingtalk-follow-up 改造为可移植技能：输出根目录从「自动探测 $PWD/memory → ~/.qoderwork/memory → 兜底」改为 S0 硬门控下的可变 ${OUTPUT_ROOT}——三级解析 |
| 2026-08-04T17:38:17Z | skill:create-skills | False | 为 profiles 项目创建了 aliyun-workspace 技能:探索 cws-lib-python 的 cmdline/aliyun 域(16 个子域、约 106 条命令),批量抓取全量 --help 生成 references/ |
| 2026-08-05T02:25:47Z | skill:create-skills | False | 创建 aliyun-document 技能全流程完成：模式探测（Spec Kit 项目模式）、底层命令 smoke 测试通过、SKILL.md 编写、skills-utils validate 通过、注册表登记、传播至 2 个角色 agen |
| 2026-08-05T02:29:57Z | skill:improve-skills | False | 按用户明确需求为 aliyun-document 增加服务信息表：从缓存 meta 提取真实 endpoint 建立 references/service-info-table.md（含数据来源 MUST 规则与维护规则），SKILL.md |
| 2026-08-05T02:44:00Z | skill:improve-skills | False | 为 aliyun-workspace 增加四级服务支持分级：新建 references/service-tiers.md（分级定义+实际覆盖状态+4 条行为规则），SKILL.md 新增「服务支持分级」章节并改写工作流步骤 1 接入分级表。 |
| 2026-08-05T05:38:15Z | /speckit.instructions | False | Targeted partial update: setup script ran clean (backup written, symlinks updated, glossary ensured); additive changes o |
| 2026-08-05T05:57:00Z | skill:improve-skills | False | 用户要求将 cws-lib-python 新合入功能按分级结构合入 aliyun-workspace 技能并拆分 reference。执行窗口为 cws-lib-python git 历史（ae33311/436b68e/9e220c2/c |
| 2026-08-05T05:57:00Z | skill:aliyun-workspace | False | 本次为技能内容更新（非执行运行），由 /improve-skills 驱动：合入 cws-lib-python 四级全覆盖的 146 条命令，references 拆分为分级子文档，修复 venv 入口与 aliyun_account 参数 |
