---
id: "20260805T055700Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "improve-skills-aliyun-workspace-20260805-1355"
scope: "local"
partial: false
created: "2026-08-05T05:57:00Z"
summary: "用户要求将 cws-lib-python 新合入功能按分级结构合入 aliyun-workspace 技能并拆分 reference。执行窗口为 cws-lib-python git 历史（ae33311/436b68e/9e220c2/cbd8a83 四个 tier 相关提交）+ 实测 --help。关键运行时证据：(1) 系统 Python 3.9 下 19 条新命令静默加载失败，必须用项目 "
---

## Review
用户要求将 cws-lib-python 新合入功能按分级结构合入 aliyun-workspace 技能并拆分 reference。执行窗口为 cws-lib-python git 历史（ae33311/436b68e/9e220c2/cbd8a83 四个 tier 相关提交）+ 实测 --help。关键运行时证据：(1) 系统 Python 3.9 下 19 条新命令静默加载失败，必须用项目 venv——已写入 SKILL.md 硬约束；(2) 旧 SKILL.md 声称 RDS/ACK 未实现，实际已全覆盖——分级表已更新；(3) 实测发现 FC 需 ALIBABA_CLOUD_UID、RDS 403 属授权问题而非命令缺陷。产出：SKILL.md 精简为契约（129 行），references 按四级分级拆为 7 个子文档，删除过时的单文件 commands.md（1449 行）。验证：sts/rm/ack/resource-center 命令实测通过，SSOT 实体编辑经链接全局可见，悬空链接归零。

## Optimization Points
- 大规模「上游新功能合入」型改进缺少确定性脚本支撑：本次 146 条命令的 --help 采集、分域落盘、region 枚举折叠全靠临时 shell 循环完成，下次同类更新会重做一遍。可在 improve-skills 或本技能 scripts/ 中沉淀 dump-help-by-domain.sh。
