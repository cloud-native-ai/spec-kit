---
id: "20260801T162013Z-skill-dingtalk-follow-up"
unit_id: "skill:dingtalk-follow-up"
unit_type: "skill"
run_id: "improve-skills-dingtalk-follow-up-portable-root-20260802"
scope: "local"
partial: false
created: "2026-08-01T16:20:13Z"
summary: "按用户需求把 dingtalk-follow-up 改造为可移植技能：输出根目录从「自动探测 $PWD/memory → ~/.qoderwork/memory → 兜底」改为 S0 硬门控下的可变 ${OUTPUT_ROOT}——三级解析（A 本次显式指定 / B 上下文明确可得 / C 其余必须追问用户），并把路径规范化、可写校验、库状态检测（initialized/legacy/empty/"
---

## Review
按用户需求把 dingtalk-follow-up 改造为可移植技能：输出根目录从「自动探测 $PWD/memory → ~/.qoderwork/memory → 兜底」改为 S0 硬门控下的可变 ${OUTPUT_ROOT}——三级解析（A 本次显式指定 / B 上下文明确可得 / C 其余必须追问用户），并把路径规范化、可写校验、库状态检测（initialized/legacy/empty/new/non-empty-foreign）、骨架初始化与根标记写入、候选发现等确定性逻辑固化为 scripts/resolve-output-root.sh（输出单行 JSON，不做自动采用决策）。新增 references/output-root.md（判据/追问模板/状态处置矩阵/根标记/可移植保证）；硬约束新增第 1 条门控红线与第 9 条「库内不写绝对路径」；S7 摘要强制回显根目录绝对路径；镜像输出改为仅用户显式指定。脚本经真实运行验证 12 类场景（含边界），过程中发现并修复了 pipefail + && 导致 --remember 静默失效的缺陷。

## Optimization Points
- 本轮把「输出根目录」从自动探测改为 S0 硬门控（三级解析 A/B/C）+ 确定性脚本校验。脚本在真实运行验证中暴露了一个静默 no-op 缺陷：`set -o pipefail` 与 `cmd && mv` 组合下，首次运行时 `[ -f "$RECENT_FILE" ]`（或 grep 无匹配）返回 1 会让整个管道判定失败，`mv` 被短路、临时文件被删，`--remember` 完全不生效且无任何报错。教训：pipefail 环境下把「允许失败的判断/过滤」放进管道，必须用 `|| true` 吸收；且此类缺陷只有真跑才暴露（文件存在性检查和语法检查都看不出来）。
- 技能改可移植后，SKILL.md 与所有 reference 中的路径必须统一为「相对 ${OUTPUT_ROOT}」表述，且旧文档里遗留的固定路径（tracked-groups.md 的历史路径列、迁移章节的旧 memory 根）要显式标注为失效/需用户给出，否则会与门控红线冲突、诱导 agent 重新猜测默认位置。改可移植时应把「全库 grep 旧路径变量名」作为收尾必做项。
- 本次仍未经真实钉钉数据端到端运行；S0 门控的追问交互（候选呈现 + 用户选择）与 L2/L3 契约一样，需要在下次真实执行中验证是否顺畅（尤其候选为空时的追问措辞）。
