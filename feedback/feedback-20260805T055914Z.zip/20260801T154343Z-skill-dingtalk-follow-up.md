---
id: "20260801T154343Z-skill-dingtalk-follow-up"
unit_id: "skill:dingtalk-follow-up"
unit_type: "skill"
run_id: "improve-skills-dingtalk-follow-up-item-redesign-20260801"
scope: "local"
partial: false
created: "2026-08-01T15:43:43Z"
summary: "按用户显式需求对 dingtalk-follow-up 完成事项中心重设计：SKILL.md 从 447 行双区模型（群聊区 6 步 + Diary 区 D0-D6）重写为 282 行单一事项工作流（S0-S7），三层输入金字塔（L1 日志主线索/L2 邮件过滤/L3 消息先映射后拉取+14 天硬顶）落为 8 条硬约束块；references 从 10 文件重组为 7 文件（新建 6 个：item"
---

## Review
按用户显式需求对 dingtalk-follow-up 完成事项中心重设计：SKILL.md 从 447 行双区模型（群聊区 6 步 + Diary 区 D0-D6）重写为 282 行单一事项工作流（S0-S7），三层输入金字塔（L1 日志主线索/L2 邮件过滤/L3 消息先映射后拉取+14 天硬顶）落为 8 条硬约束块；references 从 10 文件重组为 7 文件（新建 6 个：item-model、input-l1/l2/l3、output-format、sources-and-config；delete-and-absorb 删除 9 个旧文件；保留 tracked-groups.md 作迁移种子）。dws 契约能力（mail KQL/chat category/group notice/单聊拉取）均已按 dingtalk-workspace 现有文档核实存在。源目录与运行时目录（~/.qoder/skills）diff -rq 验证一致。

## Optimization Points
- 本次为用户主导的输入/输出全面重设计（事项中心 + 三层输入），evidence 引擎仅有项目级退化证据（0 per-skill findings），改动全部锚定用户显式需求与 dws 契约文件系统事实；新工作流 S0–S7（尤其 L2 邮件 KQL 检索与 L3 四要素映射）尚未经过真实钉钉数据运行，需在下次真实执行中验证 mail message search 的 KQL 模板与 chat category list 返回结构是否与预期 JSON 一致。
- 旧三表模型（items.md 表格行）升级为每事项一档案（items/<事项名>.md）后，S5 写盘成本随事项数线性增长；若下次运行发现档案写入成为主要耗时，可考虑将"本期无变化事项"跳过重写。
