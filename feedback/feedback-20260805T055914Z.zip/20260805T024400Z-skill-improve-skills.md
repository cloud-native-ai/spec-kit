---
id: "20260805T024400Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "improve-aliyun-workspace-tiers-20260805"
scope: "local"
partial: false
created: "2026-08-05T02:44:00Z"
summary: "为 aliyun-workspace 增加四级服务支持分级：新建 references/service-tiers.md（分级定义+实际覆盖状态+4 条行为规则），SKILL.md 新增「服务支持分级」章节并改写工作流步骤 1 接入分级表。关键核实：cws_py_cmd 实际无 rds/ack 命令，分级表如实标注未覆盖并规定回落行为。skills-utils validate 通过。"
---

## Review
为 aliyun-workspace 增加四级服务支持分级：新建 references/service-tiers.md（分级定义+实际覆盖状态+4 条行为规则），SKILL.md 新增「服务支持分级」章节并改写工作流步骤 1 接入分级表。关键核实：cws_py_cmd 实际无 rds/ack 命令，分级表如实标注未覆盖并规定回落行为。skills-utils validate 通过。

## Optimization Points
- 用户需求中的分级服务清单（rds、ack）与工具集实际命令覆盖不一致时，先跑 cws_py_cmd --help 核实真实覆盖再建分级表，并显式标注"已分级但命令未实现"，避免分级表虚报能力；该"需求清单 vs 实际覆盖核对"应作为分级/能力表类改进的标准前置步骤。
