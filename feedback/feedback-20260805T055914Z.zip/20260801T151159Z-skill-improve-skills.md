---
id: "20260801T151159Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "improve-skills-dingtalk-meeting-restructure-20260801"
scope: "local"
partial: false
created: "2026-08-01T15:11:59Z"
summary: "Single-target improvement of dingtalk-meeting per explicit user direction: repositioned from a booking-operations manual to a high-level meeting-lifecycle management skill. SKILL.md rewritten as a con"
---

## Review
Single-target improvement of dingtalk-meeting per explicit user direction: repositioned from a booking-operations manual to a high-level meeting-lifecycle management skill. SKILL.md rewritten as a contract-only framework (125 lines, zero dws command details, delegation convention + lifecycle table + intent routing + consolidated hard-constraint block placed late per constraint-placement guidance); five per-action reference docs created (2 pre-meeting existing capabilities re-homed, 1 room-booking doc absorbing the 120-line inline Step 6, 2 new post-meeting docs for summarize/send-minutes); 3 legacy docs absorbed-then-deleted; validation passed (links, frontmatter YAML, no stale refs, no dws detail leakage, symlink chain write-through to ~/.qoder/skills verified via diff -rq). Evidence lane was degenerate (project-level, 0 findings) so scope was locked to user directive + filesystem ground truth; no fabricated defects.

## Optimization Points
- 1. 本次重构基于用户明确方向 + 文件现状 ground truth（evidence 引擎对 config/skills 目标仍输出项目级同质 findings，无 per-skill 信号）；会后两个子文档（post-summarize/post-send-minutes）为新增能力，尚无真实执行证据，需在下一次真实会议管理运行中验证素材采集链路（听记定位→摘要导出）与发送确认门是否可执行。
- 2. 子文档委托描述采用「能力级意图」（如"日历能力""听记能力"）而非命令名，依赖 dingtalk-workspace 的意图路由兜底；若下次运行观察到路由歧义（如"查空闲会议室"被误路由），应在对应子文档补充产品域提示词，而不是回退到命令名。
