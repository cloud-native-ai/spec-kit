---
id: "20260801T121416Z-skill-draw-plantuml"
unit_id: "skill:draw-plantuml"
unit_type: "skill"
run_id: "machome-litellm-arch-2026-08-01"
scope: "local"
partial: false
created: "2026-08-01T12:14:16Z"
summary: "完成 mac-home LiteLLM+本地Agent 整体架构部署图：12 核心元素，经多轮渲染排错循环（语法二分定位、彩色标记陷阱、布局调整）定稿，PNG/SVG/puml/HTML 四件套交付 data/machome/architecture/。"
---

## Review
完成 mac-home LiteLLM+本地Agent 整体架构部署图：12 核心元素，经多轮渲染排错循环（语法二分定位、彩色标记陷阱、布局调整）定稿，PNG/SVG/puml/HTML 四件套交付 data/machome/architecture/。

## Optimization Points
- ## Review
- 完成 mac-home「LiteLLM + 本地 Agent」整体架构部署图：从本会话实测上下文（HANDOFF + launchd/配置/巡检）提炼 12 个核心元素，经多轮渲染-排错循环定稿，PNG/SVG/puml/HTML 四件套交付。过程中暴露的排错点全部具有可复用性。
- ## Optimization Points
- 1. **渲染脚本存在「彩色标记循环陷阱」**：`render-plantuml.sh` 的 use_mono 检测（grep 原始输入找 `<color:`/`monochrome false`）发生在 strip_style 之前，但 strip_style 会删除 `skinparam monochrome false` 行；当输入/输出同路径（脚本默认覆盖源 .puml 为注入版）时标记丢失，下一次渲染 monochrome true 又被注入、彩色被抹掉。workaround 是在源文件放一行含 `<color:` 的注释（注释不被 strip）。建议：strip_style 不排除 `monochrome false`，或注入版输出时自动回写彩色标记注释。
- 2. **部署图 component 的颜色与 stereotype 顺序约束未记载**：`component "X" as c #DCEEFF <<stereo>>` 在 plantuml.com（1.2026.7beta11）直接 400 语法错误，必须写成 `<<stereo>> #DCEEFF`。syntax-reference 与 04-deployment 指南均未记载此顺序约束；且服务器 400 错误图只给行号、无错误描述，定位成本高（本次靠最小二分 3 轮才锁定）。建议在 syntax-reference.md 与 04-deployment-diagram.md 补充「颜色必须位于 stereotype 之后」及「400 错误二分定位法」。
- 3. **PlantUML 字符串中 `~` 会被吞掉**（tilde 是转义前导符）：路径类标签（`~/wiki`、`~/.config/...`）渲染后 `~` 消失，须写 `\\~/` 才输出 `~/`。content.md/syntax-reference 未提及。运维/部署图大量出现 home 路径，建议补充该转义规则。
- 4. **`frame` 不能嵌套在部署图 `node` 内**（语法错误行指向 frame 声明行），主机内逻辑分组应改用 `node` 嵌 `node`。04-deployment-diagram.md 的示例 frame 均在顶层，未说明嵌套限制，建议补充。
- 5. **脚本默认渲染服务器（内网 xuanji-plantuml.aliyun-inc.com）在节点家庭网络不可达**，回退 plantuml.com 公共实例可用但需注意 UA 拦截（urllib 默认 UA 被 403，curl 正常）与速率限制；建议脚本内置公共服务器回退顺序与 UA 头。
