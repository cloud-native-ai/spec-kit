---
id: "20260801T152754Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "improve-skills-dingtalk-meeting-modify-20260801"
scope: "local"
partial: false
created: "2026-08-01T15:27:54Z"
summary: "Incremental improvement of dingtalk-meeting per user follow-up: added the modify-booked-meeting action as a sixth lifecycle step. Fact-checked the delegate's capability surface first (dingtalk-workspa"
---

## Review
Incremental improvement of dingtalk-meeting per user follow-up: added the modify-booked-meeting action as a sixth lifecycle step. Fact-checked the delegate's capability surface first (dingtalk-workspace calendar domain: event modification exists covering title/time/desc/location/recurrence; attendee add/remove separate; NO single-occurrence recurrence edit; intranet room system has no cancel API) and encoded only verified capabilities — including two honest limitation branches (single-occurrence workaround, manual intranet room refund). Created references/pre-modify-meeting.md (91 lines); de-duplicated by migrating the change/cancel table out of pre-notify-attendees.md to a pointer; SKILL.md updated (lifecycle table, routing, resource index, description triggers). Validation passed: links resolve, zero dws command-detail leakage, symlink write-through confirmed, routing-document consistency verified.

## Optimization Points
- 1. 设计"修改已预定会议"前先核查了 dingtalk-workspace calendar 域真实能力面（存在日程修改能力；无单次例外修改），据此写入"周期会议单次修改不支持须走变通方案"的诚实分支——高阶委托技能新增能力时，"先核查被委托方能力面再设计流程"应成为固定前置步骤，避免设计必然失败的委托路径。
- 2. pre-modify-meeting.md 的会议室联动分支（内网无取消 API、只能重订+提示手动退订）尚无真实执行证据，需在下次真实改期场景验证提示是否足够醒目、用户是否理解需手动退订。
