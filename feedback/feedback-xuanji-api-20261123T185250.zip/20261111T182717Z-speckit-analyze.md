---
id: "20261111T182717Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261111T182659Z-536e"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-11T18:27:17Z"
summary: "Read-only analyze completed with all four deterministic gates green (clause coverage 134/134, FR 32/32, 0 beyond baseline; requirements/tasks/decision-tensions validators 0 error). 17 findings: 2 HIGH"
---

## Review
Read-only analyze completed with all four deterministic gates green (clause coverage 134/134, FR 32/32, 0 beyond baseline; requirements/tasks/decision-tensions validators 0 error). 17 findings: 2 HIGH, both confirmed by independent read-only external-process validators (change-surface guard referent conflict; T036/T062 sources/state universal assertions vs the PRG two-field payload), 6 MEDIUM, 9 LOW, 0 CRITICAL. No artifact writes and no commit; the validation wave left git status byte-identical.

## Optimization Points
- The analyze template documents account-clause-coverage.py --spec, but the engine only accepts --spec-dir or a positional target (documented invocation exits 2); check-prerequisites.sh still fails without CWS_LIB_BASH_HOME; the validation wave is correctly specified as external-process workers, but the dispatch recipe lives under create-team and is only reachable by indirection; the checklist H-pass disposition format is prose-only with no machine check; the report has no slot for a checklist disposition table even though the H pass requires one.
