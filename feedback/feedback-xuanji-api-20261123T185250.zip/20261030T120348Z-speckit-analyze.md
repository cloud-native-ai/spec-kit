---
id: "20261030T120348Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261030T121500Z-a1b2"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-30T12:03:48Z"
summary: "analyze 第三轮复核（011-l3-component-design，reviewed 32850c7）：第二轮 8 条 findings（H2-01 + M2-01..03 + L2-01..04）全部按声明落点核验关闭，证明方式是逐条 file:line + 命令复算，非自述采信；H2-01 的三连判定在临时仓库模拟下算术正确。但独立复算推翻其事实前提：FR-019/FR-015 的「再"
---

## Review
analyze 第三轮复核（011-l3-component-design，reviewed 32850c7）：第二轮 8 条 findings（H2-01 + M2-01..03 + L2-01..04）全部按声明落点核验关闭，证明方式是逐条 file:line + 命令复算，非自述采信；H2-01 的三连判定在临时仓库模拟下算术正确。但独立复算推翻其事实前提：FR-019/FR-015 的「再生成豁免集」只登记 generated/metadata/openapi-commit.txt 一个文件，而真实全量重跑会改动 322 个文件（1 metadata + 321 个 generated/sdk/java/**/*.java 的 @Generated(date=…) 行，SpringCodegen 7.7.0 模板内嵌、无 hideGenerationTimestamp），本仓 008 的零漂移双跑记录早已实证 changed=322。结果是「porcelain 恰 1 行 / 命中集合 = 一个文件」永不成立，且该集合字面被复制到 8 处（T013/T015/CHK-035/CHK-040/plan §4.3/§6.2）一起错。另发现浅克隆会让 OPENAPI_COMMIT_HASH/SDK_VERSION 反转（触发条件是完整 git 历史，spec 未声明）。Verdict=FAIL（1C/0H/1M/2L）。

## Optimization Points
- ① 涉及「重跑生成后的漂移集合」这类判据时，先检索本仓既有实测记录（如 008 的 zero-drift-exemptions.md）再用，不要只读生成脚本文本推断漂移面——脚本能看出「谁写时间戳」，看不出「生成器模板也给每个产物文件内嵌时间戳」；② 判据的「可执行性验证」不能只在合成临时仓库里模拟自己设想的漂移，必须至少对照一次真实产物的形态（grep 产物里是否已内嵌 volatile 字段）；③ 同一事实（豁免集/条目数/词表）只在一处定义，下游用引用式表述——本特性两轮问题（H2-01、C3-01）都出在同一条被复制的字面上；④ 判据给出的取数方式（clone/worktree）要写明隐含前提（完整历史、时区、locale），否则主流 CI 形态会把断言反转。
