---
id: "20261111T113610Z-speckit-sanitize"
unit_id: "/speckit.sanitize"
unit_type: "command"
run_id: "r20261111T113547Z-sanitize"
scope: "local"
probe: "speckit-sanitize-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-11T11:36:10Z"
summary: "materials lane on xuanji-api: collect -> 564 pending (543 dead-reference / 21 index-inconsistency), 0 semantic candidates. Adjudicated: 115 docs-mirror data-URI FPs, 133 command-ref FPs, 23 skill-ref "
---

## Review
materials lane on xuanji-api: collect -> 564 pending (543 dead-reference / 21 index-inconsistency), 0 semantic candidates. Adjudicated: 115 docs-mirror data-URI FPs, 133 command-ref FPs, 23 skill-ref FPs, 21 feature-index cell-parse FPs; genuine defects: 21 broken relative hrefs in .specify/memory/features.md (delegated to /speckit.feature) and 1 stale build entry in .specify/memory/constitution.md:172 (delegated to a constitution amendment PR); 250 dated spec-record refs accepted as history. No cleanup plan, apply not run, zero deletion/movement. Residual probe: goal 0 / teams 0.

## Optimization Points
- sanitize-utils.py dead-reference check resolves /speckit.* names against workspace-root `templates/commands/`, a path that never exists in a client workspace — all 133 command mentions here were false positives; resolve against `.specify/templates/commands/` or the installed command copies (`.qoder/commands`, `.claude/commands`, `.github/prompts`).
- SKILL_REF_RE matches the bare substring `skills/<name>`, so a valid `.specify/skills/internal/...` path yields a false `skills/internal` finding — require a path boundary or probe `.specify/skills/`.
- check_index_consistency feeds the whole Feature Details cell (`[path](href)`) into a filesystem existence test; parse the link target or accept both the plain-path and link forms (all 21 rows here were false positives).
- docs-utils broken_links flags `data:image/...;base64,...` URIs as broken links (115 hits in docs/mirrors); skip data:/mailto: schemes before link resolution.
- When a cross-generation update leaves new root anchor placeholders alongside legacy `.specify/memory/` anchors, the command should surface `/speckit.migrate` (or `--lane layout`) before the ledger is read as material truth — this run needed that context to adjudicate 21 index-cell findings.
