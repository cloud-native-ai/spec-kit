---
id: "20261111T165412Z-speckit-clarify"
unit_id: "/speckit.clarify"
unit_type: "command"
run_id: "r20261111T163052Z-c457"
scope: "local"
probe: "speckit-clarify-wrapup"
kind: "internal"
slice: "commands"
feature: "013-canonical-v1-1"
feature_id: "022"
partial: false
created: "2026-11-11T16:54:12Z"
summary: "clarify 阶段完成并提交 33967313d：Mode A 无人值守，5 项裁决写回 requirements.md（16/16 版本口径、owner=生产系统+validator 逐 dataset 期望、extra 恒空为 producer 语义并保留 extra:present 夹具、新增 FR-032 修正 README 布局/版本叙述、gen_mysql_data.py 出切片），"
---

## Review
clarify 阶段完成并提交 33967313d：Mode A 无人值守，5 项裁决写回 requirements.md（16/16 版本口径、owner=生产系统+validator 逐 dataset 期望、extra 恒空为 producer 语义并保留 extra:present 夹具、新增 FR-032 修正 README 布局/版本叙述、gen_mysql_data.py 出切片），Open Items 5/5 闭环，checker 复跑 status=ok 0 error（32 FR / 303 行 / 38 定义行）；额外完成 fc details 20/46/6 的 extension 现树机械重导核对，并发现 README 的 design/data/mysql/info 路径在 HEAD 已不存在。分支保持 data-pipeline-align，pre-existing dirty 未提交未还原；features.md 与 features/022.md 的 clarify 记录留未提交待 driver 对账。

## Optimization Points
- 1) 事实前置：把 extension 现树的字段字典计数（RESOURCE_FIELDS 51 - X 4 - AccountID 1 = 46、SITE_EXTRA_KEYS 19 + planes_state = 20）在写 spec 前就推导出来，可避免 FR-010/SC-004 的硬编码计数在 implement 阶段才发现漂移；2) 一致性扫描要跨到交付物本体：README 的 DDL 路径与版本叙述是 spec 之外的事实源，本轮靠读 README 才发现与 FR-029 矛盾，下次在 clarify 扫描时固定读一次被交付文件的自述；3) validator 常量与 FR 的可满足性要成对检查：FR-026 的 owner 变更会撞上 C04 全局常量，本轮通过读 EXPECTED_DATASETS/OWNER 才发现，建议把「新增/修改 registry 期望值」与「validator 常量」的成对核对列入 Mode A 的 Integration & External Dependencies 类。
