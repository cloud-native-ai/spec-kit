---
id: "20261030T170357Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261031T030000Z-a1b2"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-30T17:03:57Z"
summary: "011-l3-component-design 的 analyze 连续六轮 FAIL，且 r5→r6 由「修复 H5-01」直接引入两条新 HIGH（H6-01 / H6-02）；七轮共 15 个提交、4.5 小时，交付页实现只用 49 分钟。根因有二：每轮只复核上一轮 finding，已关闭 finding 从不组成回归集重跑；修复前不做阴性对照（判据会红的最小反例），所以「把判据改对了」与「"
---

## Review
011-l3-component-design 的 analyze 连续六轮 FAIL，且 r5→r6 由「修复 H5-01」直接引入两条新 HIGH（H6-01 / H6-02）；七轮共 15 个提交、4.5 小时，交付页实现只用 49 分钟。根因有二：每轮只复核上一轮 finding，已关闭 finding 从不组成回归集重跑；修复前不做阴性对照（判据会红的最小反例），所以「把判据改对了」与「把判据改成恒绿」在记录上无法区分。

## Optimization Points
- 1) analyze 的修复步 MUST 重跑全部 prior findings（回归集），不只复核上一轮；2) 每条修复 MUST 声明它改了哪些判据语义，并把该语义的下游副本一起复核（fix-impact 字段）；3) requirements/tasks 冻结前，凡 MUST 判据含矩阵/集合/文件集，MUST 先用一个最小反例证明判据会红（阴性对照），且该反例在修复之后 MUST 再跑一次；4) review 阶段增加「规格 MUST NOT 条款 ↔ 交付页断言」的禁止式核查——011 的 F1（交付页把 porcelain 空集当一致性判据）被 FR-015 明文禁止，却穿过了表达四面、路径/命令审计、7 轮 analyze 与 2 份读者评审。
