---
id: "20261030T165259Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261030T120500Z-a101-impl-s1"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "010-xuanji-doc-stable-api"
feature_id: "018"
partial: true
created: "2026-10-30T16:52:59Z"
summary: "Segment 1 (T001-T008) of the implement run completed and committed at feec5eaf6. Created design/api/xuanji-doc/openapi.yaml (owner skeleton, security/headers/parameters, Error contract with 15-code en"
---

## Review
**Partial run** — Segment 1 (T001-T008) of the implement run completed and committed at feec5eaf6. Created design/api/xuanji-doc/openapi.yaml (owner skeleton, security/headers/parameters, Error contract with 15-code enum and 10 shared error responses, Citation/CodeLocator/DocLocator with a kind-discriminated oneOf locator) and redocly.yaml with the seven mandated error rules. Every authoring row carries a red/green evidence pair under notes/; foundational measurements and the first coverage baseline (base-sha cfb9a677fa45) are frozen; protected paths and generated/ are untouched; GATE-4 and GATE-5 are green, GATE-1/2/3/6 are red by segment design. Frictions: redocly recommended rejects nullable without type and null examples for nullable enums, forcing oneOf null-branch modeling (settled by an isolated probe before authoring); GATE-2/T035's grep '$ref:'=0 premise is false for default redocly bundle (24 internal refs; --dereferenced yields 0); a missed T007 row flip required a post-hoc audit before GATE-6 matched.

## Optimization Points
- 1) Add a mechanical post-flip audit to implement-feature: before the phase commit, compare [X] count and open-row count against the tasks worked; a missed row flip should be caught before GATE-6, not after.
- 2) Fix the GATE-2/T035 bundle premise in task generation: default redocly bundle preserves internal $ref, so the 0-ref assertion must use 'bundle --dereferenced' or an unresolved-ref resolver check; encode the measured form.
- 3) Add redocly-aware authoring guidance for contract features: nullable requires type; nullable enums need a oneOf null branch; every operation needs summary; a license declaration (or a reasoned allowlist) is required for a 0-warning target.
- 4) Provide a segment-boundary gate mode: when a run deliberately stops mid-feature, report GATE-1/2/3/6 as expected-red with the owning later task, instead of leaving the record ambiguous between defect and design.
- 5) For single-owner-files (one openapi.yaml), keep per-row red evidence but standardize a JSON-pointer section assertion so 'section absent' red is provable without whole-file absence.
- 6) Record toolchain probes (redocly behavior fixtures) as reusable notes so later segments do not repeat the nullable/union experiments.
