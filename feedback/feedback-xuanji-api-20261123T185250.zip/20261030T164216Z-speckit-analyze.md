---
id: "20261030T164216Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261030T120500Z-a101-analyze2"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
feature: "010-xuanji-doc-stable-api"
feature_id: "018"
partial: false
created: "2026-10-30T16:42:16Z"
summary: "Analyze2 read-only rerun at HEAD 6b6804e0d verified the analyze-fix commit 24da1cd59: F-01 FIXED (all documented redocly commands now use ../../design/... from the repo root; old form exits 1, correct"
---

## Review
Analyze2 read-only rerun at HEAD 6b6804e0d verified the analyze-fix commit 24da1cd59: F-01 FIXED (all documented redocly commands now use ../../design/... from the repo root; old form exits 1, corrected surrogate lint exits 0 twice, bundle exits 0 with 10 internal refs); F-02 FIXED (CodeResolve.reason is exactly unmapped_repo/unresolved_ref/invalid_path; cgit disable is citation-only; no resolve-level code_url_disabled remains); F-03 FIXED core (AdminConfig 9 fields, AdminConfigUpdate 5 fields, exactly four writable items, consistent across normative artifacts and tasks; 023 rerank alignment registered but its worktree is uncommitted); F-07 FIXED for the cross-line overclaim (SC-012 limited to 010-owned wire semantics with a named four-item 023 gate). Independent validation wave: 3 confirm, 1 downgrade (F-03 universal-consistency sub-claim), 0 reject; downgrade rate 25%. Severity recalculated to CRITICAL 0 / HIGH 0 / MEDIUM 14 / LOW 13. Six new findings: N-01 plan.md:16 stale abbreviated command; N-02 US4 narrative omits rerank_enabled; N-03 023 clause citation lists inconsistent; N-04 C-54 unconditional found=true vs miss precedence (MEDIUM); N-05 SC-012 010-owned zero still includes open F-05/F-06/F-11/F-15; N-06 T035 record-to-run wording regression. No new CRITICAL/HIGH. validate-requirements status ok, 0 error/0 warning; coverage accountant still baseline-missing (F-16). No design/generated/runtime/CI changes; no fixes applied; run-record 2ce1571d6.

## Optimization Points
- Validate the exact documented command target, not only a same-depth surrogate; when the target is an implement-phase deliverable, mark the 0-warning acceptance as unverified in the run record.
- After changing a shared field set, sweep narrative sections and cross-repo clause citation lists, not only normative schema tables; F-03 left requirements.md:73 and four inconsistent 023 reference lists.
- Add an explicit precedence/tie-breaker sentence when a degradation rule and a miss rule can coincide; F-02 cgit-disabled parenthetical remained unconditional.
- Qualify success criteria with an adjudication scope (010-adjudicated) or enumerate known exceptions rather than a broad ownership scope; SC-012 still reads as zero while 010-owned findings remain open.
- Keep evidence-recording verbs in task text intact when editing adjacent command paths; T035 regressed from record to run.
- Do not treat uncommitted cross-repo alignment as closure evidence; the 023 worktree was dirty and its gate remained open.
