---
id: "20261030T102310Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "r20261030T101500Z-a1b2"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
feature: "011-l3-component-design"
partial: false
created: "2026-10-30T10:23:10Z"
summary: "requirements 阶段（L3 组件设计，expression/design-note）：产出 29 条 FR / 8 条 SC，validate-requirements 0 error、pre-analyze pass（5 条 missing-path advisory 全为未创建的目标路径）、decomposition proceed；同批登记 feature 018。两处需注意：fl"
---

## Review
requirements 阶段（L3 组件设计，expression/design-note）：产出 29 条 FR / 8 条 SC，validate-requirements 0 error、pre-analyze pass（5 条 missing-path advisory 全为未创建的目标路径）、decomposition proceed；同批登记 feature 018。两处需注意：flow-class-check 的 lookup 不接受 spec: 命名空间（exit 2），类别只能取驱动声明；create-new-requirements.sh 依赖 CWS_LIB_BASH_HOME，非交互 shell 下需先 source ~/.bashrc。

## Optimization Points
- ① flow-class-check 增加 spec:<dir> 命名空间或提供 artifact 级读取入口，避免每个 design-note 线都记 unit-namespace-unsupported；② create-new-requirements.sh 的依赖检查应在 CWS_LIB_BASH_HOME 缺失时给出可执行的修复提示（当前仅报 'Dependency check failed'），并考虑在非交互场景回退到不依赖 cws-lib 的路径；③ requirements 阶段的 pre-analyze 会把目标文档路径报为 missing-path advisory，可对声明为交付物的路径加白名单或 'planned-path' 语义，减少噪声。
