---
id: "20261030T184143Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "r20261030T120500Z-a101-review-fix"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
feature: "010-xuanji-doc-stable-api"
feature_id: "018"
partial: false
created: "2026-10-30T18:41:43Z"
summary: "# Review Fix Dispositions — 010-xuanji-doc-stable-api"
---

## Review
# Review Fix Dispositions — 010-xuanji-doc-stable-api

**Run ID**: `r20261030T120500Z-a101-review-fix`
**Stage**: review-fix（收敛 `.specify/specs/010-xuanji-doc-stable-api/review.md` 的 8 条 P1）
**Feature**: `010-xuanji-doc-stable-api` → Feature `018` xuanji-doc 稳定 API 契约
**Base HEAD**: `e46ae2793`（review 报告与账本提交；worktree 起点 clean）
**Scope**: F1–F8；P2（F9–F11）未处置（保留为框架改进输入）。未修改 spec-kit 框架本体、`design/` 契约、`generated/`、`src/`、CI、依赖或 lockfile；未触碰主 checkout 的 5 个 modified generated DDL。

## 0. Verdict Summary

| ID | Review severity | Disposition | Evidence anchor |
|---|---|---|---|
| F1 | P1 | **fixed** — C-09 四类具名 carve-out；T027 恢复递归断言并如实标注 clause 绿 | `contracts/01-owner-and-surface.md` C-09/C-11；`requirements.md` Schema Matrix/FR-005/FR-007；`data-model.md` §1；`tasks.md` T027；`notes/review-fix-T027.txt` |
| F2 | P1 | **fixed** — 新增 `analyze-carryover.md`，27/27 MEDIUM/LOW 逐条处置并在 tasks 引用 | `analyze-carryover.md`；`tasks.md` §Analyze Carry-Over；`requirements.md` SC-012 |
| F3 | P1 | **fixed (ratified waiver)** — GATE-5 恢复具名 ratified waiver `W-GATE5-FRLANE-001`，工具 `uncovered` 状态保持可见 | `tasks.md` GATE-5 + §Waivers；`register.md`；`notes/review-fix-gates.txt` |
| F4 | P1 | **fixed** — 统一 PLAN-EDIT 协议；quickstart Scenario 3 改为 path-count 机器判据并移出假场景 | `tasks.md` Plan Constraint + §PLAN-EDIT Declarations；`quickstart.md` Scenario 1/3；`notes/review-fix-quickstart-S3.txt` |
| F5 | P1 | **fixed (ratified waiver)** — lint 忽略项具名 `LINT-IGNORE-001`，GATE-1/DoD 逐项计数 | `contracts/01-owner-and-surface.md` C-18/C-19；`tasks.md` DoD-2/GATE-1/T035 + §Waivers；`quickstart.md` Scenario 1 |
| F6 | P1 | **fixed** — xuanji-images 051 SC-005 作为具名 External Obligation 登记，含 owner/冲突措辞/关闭证据/验证点 | `tasks.md` §External Obligations |
| F7 | P1 | **fixed** — 创建 `.specify/memory/register.md`，本轮 REC 与 waiver 以指针行登记 | `register.md` §1/§2 |
| F8 | P1 | **fixed** — Pre-Status-Flip Gate 通过后补记 `Planned → Implemented`，review 执行 `Implemented → Ready for Review` | `features.md` row 018；`features/018.md` Latest Review / Status Tracking |

**Gate summary**: GATE-1 pass (exit 0, 0 error / 0 warning / 1 counted ignore)；GATE-2 pass (default 218 resolved internal refs, dereferenced 0 refs)；GATE-3 pass (17/17 operations, 0 `/api/kb` paths, 34/34 FR-003 names)；GATE-4 pass (protected diff empty)；GATE-5 pass **under ratified waiver** (`claimed 78`, textual FR 28 / SC 14, tool `status: uncovered`)；GATE-6 pass (0 open rows)。`validate-requirements` 0 error/0 warning；`validate-tasks` 0 error/0 warning；`pre-analyze-check` requirements/plan/tasks 均 `decision=pass errors=0`。

## 1. F1 — C-09 named carve-outs + recursive assertion

**Decision**: 不缩小条款、不放宽严格性；把原本隐含的三处形状歧义显式命名为 carve-out，并让 T027 递归扫描整份文档，断言“非严格 object 集合”**恰好等于**四个具名位置。

**为什么不是“定义形状”**: `rerank`/`layer_filter` 的形状由检索引擎与 022/028 拥有，写进本契约会制造第二事实源；`systemOpenapi` 200 体是 owner 文档的完整 JSON 投影，其键集天然等于 owner 文档键集，无法用封闭对象表达。因此采用四类具名 carve-out，且 carve-out 只豁免 `additionalProperties: false`，不豁免零秘密/编码/时间规则。

**改动位置**:

| 文件 | 位置 | 改动 |
|---|---|---|
| `contracts/01-owner-and-surface.md` | C-09 | 四类具名 carve-out：`Error.details`、`QueryResponse.rerank`、`QueryResponse.layer_filter`、`systemOpenapi` 200 body；carve-out 边界声明 |
| `contracts/01-owner-and-surface.md` | C-11 | `details` 改为“C-09 具名 carve-out 之一”，删除“唯一豁免” |
| `requirements.md` | Schema Matrix 通用规则、Error Contract、Error 表 `details` 行、FR-005、FR-007、Clarifications `Error` 答案 | 同步四类 carve-out，删除“唯一例外/唯一豁免”表述 |
| `data-model.md` | §1 严格对象/例外、§2.2 注、§5 `details` | 同步 carve-out 清单 |
| `tasks.md` | T027 | 断言改为递归遍历全部 dict/list 节点，并断言非严格 object 集合 == 四个具名路径；`Error.details` 单独断言无 `additionalProperties` |

**验证证据** (`notes/review-fix-T027.txt`):

```text
strict-objects=recursive; carve-outs=exact-4
T027_EXIT=0
negative-probe-extra= [('components', 'schemas', 'QueryRequest', 'properties', 'probe')]
```

负向探针证明断言非空转：新增任一非豁免 object 会被捕获。review 的“三处”计数被独立复核：递归扫描发现恰好 3 个非严格 object schema（`rerank`/`layer_filter`/`systemOpenapi` 200 body）+ `Error.details` 的无 `additionalProperties` 形态；现四者全部具名，其余 object 全部 `false`。

**Clause 绿的口径**: T027 仍以 `[green: C-09]` 计入 78/78；该绿现在成立的前提是 C-09 明文列出 carve-out，而非断言范围缩小。T027 行内已如实标注该变更。

## 2. F2 — Analyze carry-over disposition ledger

**Decision**: 新增一份持久账本，逐条覆盖 analyze/analyze2 的全部开放 MEDIUM/LOW（含 6 条 remediation residual），每行恰有一个处置：`fixed`（附位置）/`waived`（具名 waiver + owner + 复审条件）/`deferred-to-review`（附 review 项）。tasks 与 SC-012 引用该账本；未处置项不得算绿。

**改动位置**:

- 新建 `analyze-carryover.md`：27 行（13 MEDIUM + 8 LOW + 6 residuals）。
- `tasks.md` §Analyze Carry-Over：指向账本并声明 waived 项的 ID。
- `requirements.md` SC-012 与 Source：零口径改为“每项均有处置行，无未处置项”。

**处置统计**: `fixed` 26（其中 F-11/F-15/F-18 附 delegation waivers `W-ANALYZE-02/03/04`，F-16 附 `W-GATE5-FRLANE-001`）；`waived` 1（F-09 / `W-ANALYZE-01`）；`deferred-to-review` 0。review 的 8 条 P1 不在账本内（它们是 review findings，本文件逐条处置）。

**验证证据**: 账本行数与 analyze2 §5 的 27 个开放 ID 一一对应；`grep -c '^| F-\|^| N-' analyze-carryover.md` = 27（见 `run-record-review-fix.md` §4 的计数复核）。

## 3. F3 — GATE-5 accountant gate (ratified waiver)

**Decision**: spec-kit 框架脚本不在本仓修改范围（用户约束），因此不“教会”会计器，也不再用一段文本替代门禁语义；改为**具名 ratified waiver**，并在 GATE-5/tasks/register 三处如实表述工具状态。

**改动位置**:

- `tasks.md` GATE-5：明确 `status: uncovered`、FR lane 失败可见、文本覆盖 28/14、clause 78/78；GATE-5 仅在 `W-GATE5-FRLANE-001` 下为绿。
- `tasks.md` §Waivers：owner（xuanji-api maintainers / Feature 018 owner）、范围、证据、复审条件（会计器或 `contract-clause-definitions` §4.2 支持 `Refs:` 行，或下一个复用该语法的特性；每特性需重新 ratify）。
- `tasks.md` DoD-6 / Notes：从 “ANOMALY” 改为 “WAIVER (not ANOMALY)”，指向 waiver。
- `.specify/memory/register.md`：`W-GATE5-FRLANE-001` 指针行。
- `verification.md` SC-001/SC-002/notes：同步。

**验证证据** (`notes/review-fix-gates.txt`):

```text
claimed clauses 78 ... [fr-uncovered] fail (27) ... status: uncovered
GATE5_TOOL_EXIT=0
FR_IDS=28
SC_IDS=14
CLAUSES=78
```

**框架反馈**: REC-A1（会计器识别 `*Refs:*` 行）保持 open；本仓不修改框架脚本。

## 4. F4 — One PLAN-EDIT protocol + real quickstart Scenario 3

**Decision**: 全流程统一一条规则——**已确认缺陷**允许声明式修订（`PLAN-EDIT: file:loc — reason; scope/invariants preserved`），记录在运行账本；只有 scope/design/实体集/接口变更才是 ANOMALY 停线。Scenario 3 改为机器判据（`/api/kb` path-key 计数 = 0），并移出“字符串缺席”这一与 C-02 冲突的假场景。

**改动位置**:

| 文件 | 位置 | 改动 |
|---|---|---|
| `tasks.md` | Plan Constraint | 单一协议文本；废除“PLAN-EDIT: none，任何编辑停线”的严苛读法 |
| `tasks.md` | §PLAN-EDIT Declarations | PE-01…PE-08 声明表（文件、改动、保持的不变量） |
| `tasks.md` | T040 note | 记录 Scenario 3 已修正，旧假场景移出验收 |
| `quickstart.md` | Scenario 1 | lint 目标加入“1 个具名忽略” |
| `quickstart.md` | Scenario 3 | path-count 断言；operation 级 `deprecated` 计数改为 YAML 计数（避免文件级 `x-deprecated` 误命中）；premise 说明退役文本合规 |
| `analyze-fix-dispositions.md` | §7 | 标注“规则文本已被统一协议取代”，保留历史声明清单 |

**验证证据** (`notes/review-fix-quickstart-S3.txt`):

```text
0            # /api/kb path keys
S3_PATHS_EXIT=0
26:x-deprecated: true
27:x-superseded-by: ../xuanji-doc/openapi.yaml
3            # operation-level deprecated flags
S3_OP_DEPRECATED_COUNT_EXIT=0
```

**PLAN-EDIT 声明**: 见 §7；无 scope/design/实体集/接口变更，故无 ANOMALY。

## 5. F5 — Lint ignore waiver with counted evidence

**Decision**: 不隐藏、不放宽规则——`no-unused-components` 仍为 `error`；唯一忽略项登记为 `LINT-IGNORE-001`，GATE-1 与 DoD 必须打印并计数 “1 problem is explicitly ignored”。未采用“合法 `$ref` 绑定 PushMetadata”的替代方案，因为 OpenAPI 3.0 无法从 string-typed multipart part `$ref` 一个 object schema，任何强制绑定都会改变 wire 语义。

**改动位置**:

- `contracts/01-owner-and-surface.md` C-18：允许具名 error 级忽略，但必须逐项记录规则/路径/理由并计数；忽略数不得增长。
- 同文件 C-19：lint 忽略项必须按 C-18 计数，不得读作 0 error 空白。
- `tasks.md` DoD-2 / GATE-1 / T035 / §Waivers / register：具名、计数、owner、复审条件。
- `quickstart.md` Scenario 1 premise；`verification.md` SC-001。

**验证证据** (GATE-1): `GATE1_EXIT=0`，输出 `1 problem is explicitly ignored.`；无 warning。忽略项身份由 `.redocly.lint-ignore.yaml` 与 `redocly.yaml` 注释固定，未改 `design/`。

## 6. F6 — xuanji-images 051 SC-005 as an External Obligation

**Decision**: 010 不修改 051（跨仓），但把该验收口径冲突登记为具名 External Obligation，包含：冲突原文、owner、010 条款权威（C-06/C-07/C-21）、关闭证据（051 SC-005 修订或签署对账记录）、验证点（051 requirements SC-005/FR-020 引用 010 条款 ID）。在此之前，010 SC-004 只覆盖 010-owned wire，不得被引作 051 的测试判据。

**改动位置**: `tasks.md` §External Obligations 新增 “xuanji-images Feature 051 SC-005” 条目。

**验证证据**: `grep -n "051 SC-005" tasks.md` 命中该条；条目含 owner/closure artifact/verification point 四要素（见 §4 计数复核）。

## 7. F7 — Register bootstrap and pointer rows

**Decision**: 创建 `.specify/memory/register.md`，定义指针行形式（ID → 一行含义 → 权威路径 → 状态），并登记本 feature 的 REC 与 waiver。历史 008/009 的 REC 因跨 feature 命名空间且缺少行级证据，列入 backlog 而不伪造回填。

**改动位置**: 新建 `.specify/memory/register.md`：
- §1：`REC-T1…T3`、`REC-C1…C4`、`REC-A1/A2`、`REC-W1`、`REC-D1`（11 行，均指向 `review.md#5.x` 的权威锚点）。
- §2：`LINT-IGNORE-001`、`W-GATE5-FRLANE-001`、`W-ANALYZE-01…04`（6 行）。
- §3：legacy unregistered IDs backlog（008/009）。

**验证证据**: 文件存在；11 REC 行 + 6 waiver 行；每行有权威路径（`grep -c '^| REC-\|^| LINT-IGNORE-001\|^| W-'` = 17）。review 命令的 “same commit” 义务在本轮补记（review 报告提交于 `e46ae2793` 时 register 尚不存在——这正是 F7 的问题；本轮 commit 一并落地）。

## 8. F8 — Feature 018 implement record and status transitions

**Decision**: 先执行 Pre-Status-Flip Gate，再补记 `/speckit.implement` 拥有的 `Planned → Implemented`（无值守模式下由 orchestrator 记录为具名 implement 条目），随后由 `/speckit.review` 执行 `Implemented → Ready for Review`（review.md 已提交、deferred 为空、P1 全部有处置）。

**Pre-Status-Flip Gate 实测**:

```text
open tasks = 0
[~] deferred = 0
SC status rows = 14
deferred_tasks= (empty)
```

**改动位置**:

- `.specify/memory/features.md` row 018：Status `Planned → Ready for Review`；Last Updated 注明 implement 与 review-fix。
- `.specify/memory/features/018.md`：Status 同步；Latest Review 追加 implement 条目与 review-fix 条目；Status Tracking 勾选 Implemented / Ready for Review 并注明日期与证据。

**验证证据**: `grep` 状态字段；`features/018.md` 中含 `Planned → Implemented` 与 `Implemented → Ready for Review` 两条显式记录。P2 F9–F11 未处置，已在条目中注明。

## 9. PLAN-EDIT Declarations

| ID | Location | Change | Invariants preserved |
|---|---|---|---|
| PE-01 | `contracts/01-owner-and-surface.md` C-09/C-11/C-12/C-18/C-19 | carve-out、request-id 冻结、忽略计数 | 78 条款与 Refs 不变；无 schema 增删 |
| PE-02 | `contracts/03-knowledge.md` C-35/C-47 | 派生与规范化委托 | wire shape 不变 |
| PE-03 | `contracts/04-documents-code.md` C-49/C-52/C-54 | `q` 语义委托；miss 优先 | wire shape 不变 |
| PE-04 | `contracts/05-admin-system.md` C-58/C-62 | 023 引用清单；health 503 例外 | admin/health wire 不变 |
| PE-05 | `contracts/README.md` §2 FR-003 行 | 覆盖单元扩至全部 schema 条款 | 覆盖总数不变 |
| PE-06 | `data-model.md` §1/§2.2/§2.4/§2.6/§2.7/§5 | carve-out、分节计数、health 例外、request-id | 实体集与关系不变 |
| PE-07 | `quickstart.md` Scenario 1/3 | 忽略计数 premise；Scenario 3 机器判据 | 场景数仍为 8 |
| PE-08 | `plan.md` Technical Context / Project Structure | 可执行命令；7→8 场景 | 阶段/依赖不变 |

`requirements.md` 属 requirements-stage 产物，其 analyze carry-over 修正记录在 `analyze-carryover.md`，不在此表重复声明。`research.md`：无修改。

## 10. Framework Feedback (spec-kit level)

| ID | Observation from this run | Target |
|---|---|---|
| REC-C1 / REC-T1 | F1 的根因是“implement 未消费 analyze 开放项 + 断言可静默缩小”；建议 implement 上下文加载 analyze 报告并强制 disposition 表，tasks 模板要求断言声明覆盖模式（exact/recursive/textual） | `.qoder/commands/speckit.implement.md`；`.specify/templates/tasks-template.md` |
| REC-A1 | F3 的根因是会计器只认括号引用组；建议支持 `*Refs:*` 块或将 `Refs:` 形式写入 contract-clause-definitions | `.specify/scripts/python/account-clause-coverage.py`；`.specify/shared/definitions/contract-clause-definitions.md` |
| REC-T2 | F5 的根因是 verification 模板没有 `ignored_problems` 字段；建议字段化（rule/path/reason/count）并规定 error 级规则能否忽略 | `.specify/templates/verification-log-template.md` |
| REC-C3 | F7 的根因是 review 命令要求登记到不存在的 register；建议 instructions 初始化时 bootstrap 或条件化 handoff，并在 wrap-up 列出未登记 REC | `.qoder/commands/speckit.review.md`；`.specify/templates/instructions-template.md` |
| REC-C4 | F8 的根因是 implement 状态迁移可被静默遗留给“orchestrator”；建议最终 implement 段强制过渡或产出具名 handoff，review 先校验状态 | `.qoder/commands/speckit.implement.md`；`.specify/shared/workflow/feature-integration.md` |
| REC-C2 | F4 的根因是 tasks/implement/analyze-fix 三处 PLAN-EDIT 规则不一致；建议统一为“声明式缺陷修复 + scope/design 停线” | `.qoder/commands/speckit.tasks.md`；`.qoder/commands/speckit.implement.md` |
| REC-W1 | F6 的根因是跨仓验收冲突只存在于 analyze 运行记录；建议 analyze 的跨线 finding 逐条进入持久 ledger | `.specify/shared/workflow/feature-integration.md`；`.specify/templates/feature-details-template.md` |

P2 review findings F9（SC 计数 24 vs 28）、F10（clean-checkout/baseline 标签）、F11（determination 全 `not_evaluated`）未在本轮处置，对应 REC-D1/REC-T3/REC-A2 保持 open。

## 11. ANOMALY

- **无阻断性 ANOMALY**：所有 plan-stage 编辑均为声明式缺陷修复，无 scope/design/实体集/接口变更，未触发停线。
- **Evidence boundary**: GATE-5 的工具状态仍为 `uncovered`；本轮的绿是 waiver 下的绿，已在 GATE-5/DoD/verification 三处显式陈述，未改写为工具绿。
- **Scope boundary**: xuanji-images 051、xuanji-doc 023/028 均未修改（跨仓只读）；F6 只登记义务与验证点，不声称外部已关闭。
- **P2 boundary**: F9–F11 明确未处置，不纳入本轮完成声明。

## Optimization Points
- F1 named C-09 carve-outs + recursive T027; F2 analyze-carryover 27/27; F3 W-GATE5-FRLANE-001 ratified waiver; F4 unified PLAN-EDIT + real quickstart Scenario 3; F5 LINT-IGNORE-001 counted; F6 051 SC-005 external obligation; F7 register.md bootstrapped; F8 feature 018 Implemented -> Ready for Review
