---
id: "20261021T202641Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "008-canonical-data-contract-20261022T0425Z"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
feature: "008-canonical-data-contract"
feature_id: "017"
partial: false
created: "2026-10-21T20:26:41Z"
summary: "Review produced review.md with 13 findings (P0=0, P1=9, P2=4); two P0 candidates were independently validated and downgraded to P1. The command's evidence-first structure worked, but it needs claim re"
---

## Review
Review produced review.md with 13 findings (P0=0, P1=9, P2=4); two P0 candidates were independently validated and downgraded to P1. The command's evidence-first structure worked, but it needs claim reproduction (not only artifact reads), a reusable prerequisite bootstrap, and a stronger bulk-commit guard.

## Optimization Points
- Review command should reproduce invariant claims (`100%`, `only`, `none`) with a command or mutation before accepting implement-stage evidence; the current flow can accept `SC-012 = 100%` while no-payload tombstones skip UID checks.
- Prerequisite scripts should auto-discover or document `CWS_LIB_BASH_HOME`; `check-prerequisites.sh` fails in a fresh shell before review starts.
- The implement commit gate should enforce phase-boundary commits in long-run mode; this feature landed as one 65-file bulk commit, so the review timeline could not be attributed per task.
