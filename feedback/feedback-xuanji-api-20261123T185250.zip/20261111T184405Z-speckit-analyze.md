---
id: "20261111T184405Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261111T184343Z-b7e2"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
feature: "013-canonical-v1-1"
partial: false
created: "2026-11-11T18:44:05Z"
summary: "Incremental analyze round 2 (read-only) after remediation eeb754dd8: all four deterministic gates green (requirements 0 error/0 warning; coverage 134 claimed / FR 32/32 / 0 beyond baseline; decision t"
---

## Review
Incremental analyze round 2 (read-only) after remediation eeb754dd8: all four deterministic gates green (requirements 0 error/0 warning; coverage 134 claimed / FR 32/32 / 0 beyond baseline; decision tensions ok 3 records; pre-analyze-check tasks pass 0 error/13 advisory). 15 of 17 round-1 findings fully closed; C-05 and C-09 partially closed with LOW residue; one new LOW finding (stale IMPL_START_SHA pin 0ddc0662d while HEAD is eeb754dd8). Verdict pass: 0 CRITICAL / 0 HIGH / 0 MEDIUM / 3 LOW open.

## Optimization Points
- Incremental re-check kept the read domain to 7 touched paths + one-hop neighbors and reused 9 files whose sha256 equal the round-1 HEAD (declared in the report); the change-surface guard is now a single referent across FR-030/SC-006/C-12.1/GATE-7/T079/Notes, with guard-external paths excluded from both sides; the guard's pinned instance SHA lags the dispatch-HEAD definition and should be dropped or refreshed at dispatch; data-model §2's 'field-for-field' preamble is not met by four grouped-shorthand rows (pod/container/workload/template); requirements Shared Strings still names contracts/tasks/tests as convention subjects while its Scope paragraph exempts them; the checklist's CHK028/Notes retain dated pre-remediation premises (legitimate dated record, not a finding).
