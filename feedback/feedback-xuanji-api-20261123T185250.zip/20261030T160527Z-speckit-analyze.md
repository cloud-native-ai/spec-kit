---
id: "20261030T160527Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261030T120500Z-a101-analyze"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
feature: "010-xuanji-doc-stable-api"
feature_id: "018"
partial: false
created: "2026-10-30T16:05:27Z"
summary: "Analyze run completed at HEAD 1596b834b: read 28 FR / 14 SC / 78 clauses / 40 tasks against requirements, plan, research, data-model, contracts, quickstart and Feature 018. 25 findings: 0 CRITICAL / 3"
---

## Review
Analyze run completed at HEAD 1596b834b: read 28 FR / 14 SC / 78 clauses / 40 tasks against requirements, plan, research, data-model, contracts, quickstart and Feature 018. 25 findings: 0 CRITICAL / 3 HIGH / 14 MEDIUM / 8 LOW. 13 checklist FAILs independently rechecked: 9 upheld, 4 downgraded, 0 retracted. 7 HIGH candidates validated by 3 fresh-context subagents: 3 confirmed, 4 downgraded (57.1%); no CRITICAL. Top issues: the documented pnpm --dir lint command cannot resolve design paths from the repo root; cgit-disabled code/resolve has two incompatible wire outcomes; xuanji-doc 023 requires a query-default rerank switch absent from AdminConfigUpdate; Job.error.request_id freeze-vs-restamp is undefined; the coverage baseline is missing and the accountant FR lane reports 0/28 by syntax mismatch. No repairs; only the run record and bookkeeping were written.

## Optimization Points
- 1) Execute any documented validation command at least once during plan/tasks (or mark it unverified); the pnpm --dir cwd defect would have been caught by one probe. 2) Generate per-operation error response sets and task schema assertions from the Schema Matrix instead of hand-writing them; hand-written counts drifted (T017 9-vs-8, T026 401-on-health, GATE-2 ref-total). 3) Add a named cross-line reconciliation gate before implement: the 023/010 register is missing the admin rerank-switch divergence and SC-012 overclaims zero unresolved issues. 4) Freeze coverage-baseline.txt in /speckit.tasks rather than deferring to an implementation task, and normalize contract Refs to the accountant citation-group form. 5) Separate illustrative examples from normative response samples (or label poll results as GET) to prevent 200-vs-202 drift.
