---
id: "20261030T162654Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261030T120500Z-a101-analyze-fix"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
feature: "010-xuanji-doc-stable-api"
feature_id: "018"
partial: false
created: "2026-10-30T16:26:54Z"
summary: "Analyze-fix run completed at base HEAD 79ce6ef46: closed the three analyze HIGHs plus connected F-07 within the authorized scope. F-01: all documented redocly commands now use the repo-root-executable"
---

## Review
Analyze-fix run completed at base HEAD 79ce6ef46: closed the three analyze HIGHs plus connected F-07 within the authorized scope. F-01: all documented redocly commands now use the repo-root-executable ../../design/... form relative to src/nodejs; cwd probe showed src/nodejs, old form exited 1 with does not exist or is invalid, corrected form linted twice with exit 0 / 0 error / 0 warning and bundled with 0 unresolved refs (evidence archived in notes/f01-lint-smoke.md; target owner file is an implement-phase deliverable, so a same-depth temporary fixture was used). F-02: single-point adjudication makes cgit disable citation-only; CodeResolve keeps found=true/reason=null and code_url_disabled was removed from its closed reason enum across requirements, contracts/04, data-model and tasks. F-03: AdminConfigUpdate and AdminConfig now carry rerank_enabled; the runtime writable set is exactly citation_enabled, doc_url_enabled, rerank_enabled and query_defaults{mode,min_score}, wire-owned by 010 with 023 C-18/A-014/FR-015 referencing these names. F-07: SC-012 now claims zero unresolved 010-owned wire semantics only and names the 3 cross-line ANOMALYs plus rerank alignment as a gated pre-implement obligation with 023 clause evidence. validate-requirements returned 0 error/0 warning; pre-analyze-check passed all three stages with 0 errors and 3 pre-existing advisories. No design/, generated/, runtime, CI, dependency or lockfile changes; F-04/F-05/F-06/F-08-F-25 remain open.

## Optimization Points
- Smoke-test every documented validation command (or mark it unverified) before analyze; the pnpm --dir cwd defect was detectable in one probe.
- Give every cross-line register entry a named closure gate and evidence requirement at registration time, not after analyze flags it.
- Keep wire-owner field names in one place (010 Schema Matrix) and make consumer lines reference them; the rerank divergence came from capability names without wire field names.
- Treat historical checklist text as immutable evidence; stale command paths there should not keep producing missing-path advisories.
