---
id: "20261030T185943Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "r20261030T120500Z-a101-review2"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
feature: "010-xuanji-doc-stable-api"
feature_id: "018"
partial: false
created: "2026-10-30T18:59:43Z"
summary: "# SDD Process Review Report — Review2 (review-fix closure recheck): 010 xuanji-doc 稳定 API 契约（OpenAPI v1）"
---

## Review
# SDD Process Review Report — Review2 (review-fix closure recheck): 010 xuanji-doc 稳定 API 契约（OpenAPI v1）

> **Audience**: spec-kit framework maintainers.
> **Purpose**: Read-only recheck of `.specify/specs/010-xuanji-doc-stable-api/review.md` P1 findings F1–F8 after review-fix commit `fad0e32bc`, plus a full rescan for newly introduced P0/P1. This report critiques the SDD process, not the feature's business merits.
> **Intentionally problem-first**: closure verdicts and residual defects only; no narrative summary of the feature.

**Re-review verdict**: F1–F8 are **closed** — each disposition is backed by an amended artifact and, where applicable, a live re-run reproduced in this review. No new P0 or P1 was found. Six P2 remain: three carried from the first review (F9–F11, still undispositioned) and three new residual-consistency findings (N1–N3) created by imperfect propagation of the review-fix edits. The completion-gate evidence chain is now internally honest: GATE-5 still prints `status: uncovered` and is green only under the named waiver `W-GATE5-FRLANE-001`; lint is green with exactly one counted ignore (`LINT-IGNORE-001`); C-09's four carve-outs are explicit and the T027 assertion asserts the exact set recursively.

## 0. Portable Project Context (Self-Contained Snapshot)

| Field | Value |
|-------|-------|
| Requirement ID | 010 |
| Requirement Key | `010-xuanji-doc-stable-api` |
| Requirement Name | xuanji-doc 稳定 API 契约（OpenAPI v1） |
| Related Feature | 018 xuanji-doc 稳定 API 契约 |
| Repository | `xuanji-api` |
| Repository URL | `git@gitlab.alibaba-inc.com:kangaroo-xuanji/xuanji-api.git` (SSH; not HTTPS-web-renderable) |
| Reachability of COMMIT_SHA | **UNRESOLVABLE** — `git branch -r --contains HEAD` is empty; the branch is unpushed. Evidence below uses absolute paths plus `git show 5b4398f59:<relative-path>` recovery. |
| Branch | `010-xuanji-doc-stable-api` |
| Commit SHA | `5b4398f596d77ee901a8c32674146134e2e2d87a` (short: `5b4398f59`) |
| Rechecked fix commit | `fad0e32bcfc84cae7147bd6d1707e52a4cf1d973` (short: `fad0e32bc`) |
| Repo Root (absolute) | `/storage/project/kangaroo-xuanji/worktrees/xuanji-api-010` |
| Review Date | 2026-10-31 |
| Reviewer (Agent) | Qoder review2 stage, read-only; no repair performed |
| Environment | Linux 5.10.134-19.3.1.al8.x86_64 (x64), bash; Node.js v26.7.0; pnpm 10.32.1; `@redocly/cli` 1.34.16; Python 3 with PyYAML 6.0.3 |
| spec-kit Source Snapshot | `spec-kit` @ `4f73c21d257fe7e263bbbf2e1797e4c38adc4b3d` (`.specify/source.json`, stamped `20261025T104429Z`) |

### Artifact Inventory (review2 inputs)

| Artifact | Lines | Absolute Path | One-line Summary |
|----------|------:|---------------|-------------------|
| review.md | 497 | `/storage/project/kangaroo-xuanji/worktrees/xuanji-api-010/.specify/specs/010-xuanji-doc-stable-api/review.md` | First review: P0 0 / P1 8 (F1–F8) / P2 3 (F9–F11) |
| review-fix-dispositions.md | 205 | `/storage/project/kangaroo-xuanji/worktrees/xuanji-api-010/.specify/specs/010-xuanji-doc-stable-api/review-fix-dispositions.md` | F1–F8 dispositions with evidence anchors |
| analyze-carryover.md | 66 | `/storage/project/kangaroo-xuanji/worktrees/xuanji-api-010/.specify/specs/010-xuanji-doc-stable-api/analyze-carryover.md` | 27-row analyze MEDIUM/LOW disposition ledger |
| tasks.md | 295 | `/storage/project/kangaroo-xuanji/worktrees/xuanji-api-010/.specify/specs/010-xuanji-doc-stable-api/tasks.md` | DoD, GATE-1–6, §Waivers, §Analyze Carry-Over, PLAN-EDIT declarations |
| requirements.md | 1178 | `/storage/project/kangaroo-xuanji/worktrees/xuanji-api-010/.specify/specs/010-xuanji-doc-stable-api/requirements.md` | 28 FR / 14 SC; carve-out and error-contract amendments |
| contracts/01-owner-and-surface.md | 84 | `/storage/project/kangaroo-xuanji/worktrees/xuanji-api-010/.specify/specs/010-xuanji-doc-stable-api/contracts/01-owner-and-surface.md` | C-09 four carve-outs; C-12 freeze; C-18/C-19 ignore accounting |
| quickstart.md | 173 | `/storage/project/kangaroo-xuanji/worktrees/xuanji-api-010/.specify/specs/010-xuanji-doc-stable-api/quickstart.md` | 8 scenarios; Scenario 3 machine criterion |
| research.md | 156 | `/storage/project/kangaroo-xuanji/worktrees/xuanji-api-010/.specify/specs/010-xuanji-doc-stable-api/research.md` | Decisions; D-03 still carries the old sole-exception text |
| verification.md | 137 | `/storage/project/kangaroo-xuanji/worktrees/xuanji-api-010/.specify/specs/010-xuanji-doc-stable-api/verification.md` | SC status/evidence bindings; ignore counted in SC-001 |
| register.md | 47 | `/storage/project/kangaroo-xuanji/worktrees/xuanji-api-010/.specify/memory/register.md` | 11 REC + 6 waiver pointer rows + legacy backlog |
| features/018.md | 85 | `/storage/project/kangaroo-xuanji/worktrees/xuanji-api-010/.specify/memory/features/018.md` | Feature detail: Status Ready for Review; implement/review entries |
| notes/review-fix-gates.txt | 60 | `/storage/project/kangaroo-xuanji/worktrees/xuanji-api-010/.specify/specs/010-xuanji-doc-stable-api/notes/review-fix-gates.txt` | Review-fix gate output; HEAD and exit labels inaccurate (N2) |

## 1. Process Execution Timeline

| # | Step / Event | Evidence (commit SHA, file, or quoted excerpt) | Deviation from prescribed flow? |
|---|--------------|------------------------------------------------|---------------------------------|
| 1 | First review report committed | `e46ae2793`; `review.md`; P0 0 / P1 8 / P2 3 | None |
| 2 | Review-fix commit | `fad0e32bc` (24 files, +943/−102): C-09 carve-outs + recursive T027, analyze-carryover ledger, GATE-5 waiver, quickstart S3, LINT-IGNORE-001, 051 obligation, register, Feature 018 records | None at the fix level; residual copy drift (N1) |
| 3 | Review-fix bookkeeping | `5b4398f59`: `run-record-review-fix.md` + disposition hash | None |
| 4 | Review2 (this run) | HEAD `5b4398f59`; live re-runs of GATE-1/2/3/4/5/6, T027 and quickstart S3; no writes except this report and bookkeeping | Review stage; read-only |

### 1.1 Gate re-runs performed in this review2 (real output)

| Check | Command (repo root) | Result |
|-------|---------------------|--------|
| GATE-1 | `pnpm --dir src/nodejs exec redocly lint ../../design/api/xuanji-doc/openapi.yaml --config ../../design/api/xuanji-doc/redocly.yaml` | exit 0; no warning; `1 problem is explicitly ignored` (`LINT-IGNORE-001`) |
| GATE-2 default | `redocly bundle ../../design/api/xuanji-doc/openapi.yaml -o /tmp/r2-bundle.yaml` | exit 0; 218 internal `$ref` (all resolved) |
| GATE-2 dereferenced | `redocly bundle --dereferenced ... -o /tmp/r2-deref.yaml` | exit 0; `grep -c '\$ref:'` = 0 |
| GATE-3 | Python surface assertion (17 operationIds, 5 tags, `/api/v1` only, 0 `/api/kb`, 34 FR-003 names) | `surface=17/17` |
| GATE-4 | `git diff --name-only 7bbacf9a2 -- <protected paths>` | empty |
| GATE-5 | `python3 .specify/scripts/python/account-clause-coverage.py .specify/specs/010-xuanji-doc-stable-api` | `claimed clauses (this feature): 78`; `FR claimed: 1`; `FR uncovered: 27`; `status: uncovered`; **exit 1** (waiver `W-GATE5-FRLANE-001`) |
| GATE-6 | `grep -cE '^- \[[ >]\]' tasks.md` | 0 |
| T027 | Recursive strict-object assertion (exact-4 carve-outs) | `strict-objects=recursive; carve-outs=exact-4`; exit 0 |
| Quickstart S3 | `/api/kb` path-key count; operation-level `deprecated` count | `0`; `3` |

A recursive scan independent of the task text finds exactly four non-strict object schemas, at exactly the four named C-09 carve-out paths:
`paths./api/v1/system/openapi.json.get.responses.200.content.application/json.schema`,
`components.schemas.Error.properties.details`,
`components.schemas.QueryResponse.properties.rerank`,
`components.schemas.QueryResponse.properties.layer_filter`.

## 2. Findings Summary (recomputed)

| Severity | Count | Definition |
|----------|------:|------------|
| P0 | 0 | Blocks correct use of spec-kit, or creates silent corruption risk. |
| P1 | 0 | Recurring friction across specs. |
| P2 | 6 | Quality-of-life; compounding gains across many specs. |

| Category | Count |
|----------|------:|
| Template | 0 |
| Command Prompt | 0 |
| Automation / Scripts | 2 (N2, F11) |
| Workflow | 1 (N1) |
| Documentation | 3 (N3, F9, F10) |

Recompute basis:
- P1 8 → 0: F1–F8 each have a closure verdict below with reproduced evidence.
- P2 3 → 6: F9–F11 carried unchanged; N1–N3 are new residual-consistency findings introduced by the review-fix propagation, none gate-blocking.

## 3. Findings

### 3.1 Closure recheck of the first review's P1 findings

| ID | First-review severity | Review2 verdict | Primary evidence | Residual |
|----|----------------------|-----------------|------------------|----------|
| F1 | P1 | **CLOSED** | C-09 names four carve-outs; T027 recurses and asserts the exact set; live re-run green | N1 (stale copies) |
| F2 | P1 | **CLOSED** | `analyze-carryover.md` 27 rows; tasks §Analyze Carry-Over; SC-012 cites the ledger | N1 (F-08 disposition anchored at stale T026) |
| F3 | P1 | **CLOSED** | Named ratified waiver `W-GATE5-FRLANE-001`; tool `uncovered` status left visible; live re-run confirms it | N2 (evidence exit label) |
| F4 | P1 | **CLOSED** | One PLAN-EDIT protocol in tasks; Scenario 3 machine criterion; live re-run path=0 / op-deprecated=3 | None |
| F5 | P1 | **CLOSED** | `LINT-IGNORE-001` named and counted in C-18/DoD-2/GATE-1; live lint exit 0 with `1 problem is explicitly ignored` | N1 (FR-021/SC-001 not updated) |
| F6 | P1 | **CLOSED (010 side)** | xuanji-images 051 SC-005 obligation with owner, conflict wording, closure artifact, verification point | External closure pending by design |
| F7 | P1 | **CLOSED** | `register.md` exists with 11 REC + 6 waiver pointer rows + legacy backlog; bootstrap miss disclosed | N3 (anchor/ID form) |
| F8 | P1 | **CLOSED** | Feature 018 `Ready for Review`; implement and review entries in `features/018.md`; Pre-Status-Flip evidence re-verified | N3 (accounting count) |

#### F1 — C-09 carve-outs and recursive assertion: closed

The clause now enumerates its exceptions instead of hiding them behind a narrowed test:

```
- **C-09** 所有 JSON 响应 MUST 使用 `application/json`（UTF-8）。除下列具名 carve-out 外，所有 object schema MUST 显式 `additionalProperties: false`：(i) `Error.details` ... (ii) `QueryResponse.rerank` 与 (iii) `QueryResponse.layer_filter` ... (iv) `systemOpenapi` 200 响应体 ...
```

T027's verification command walks every dict/list node and asserts the non-strict object set equals exactly those four paths. A live re-run prints `strict-objects=recursive; carve-outs=exact-4` with exit 0, and an independent recursive scan in this review found the same four nodes and no others. The recorded negative probe (`negative-probe-extra= [('components','schemas','QueryRequest','properties','probe')]`) shows the assertion is not vacuous. The first review's "three places" count is superseded by the exact-four assertion. **Closed.** Residual stale copies: see N1.

#### F2 — Analyze carry-over ledger: closed

`analyze-carryover.md` has 27 disposition rows (13 MEDIUM + 8 LOW + 6 residuals; mechanically counted `27`), and §5 states `fixed: 26`, `waived: 1`, `deferred-to-review: 0`. `tasks.md` §Analyze Carry-Over points to the ledger; `requirements.md` SC-012 now requires every open item to have a disposition row instead of claiming an unqualified zero. The mechanism the first review asked for exists and is inspectable. **Closed.** One disposition is inaccurate at its cited location: see N1.

#### F3 — GATE-5 accountant gate: closed under a named ratified waiver

The gate no longer substitutes text for the tool's verdict; it states the tool's verdict and the waiver:

```
**Honest status**: the accountant's overall `status` is `uncovered` because its FR lane recognizes only parenthetical citation groups ... that FR lane is **waived** by `W-GATE5-FRLANE-001` (§ Waivers), not redefined away.
```

The live re-run reproduces `claimed clauses (this feature): 78`, `FR claimed: 1`, `FR uncovered: 27`, `status: uncovered`. The waiver row in `tasks.md` §Waivers has scope, reason, owner, evidence and a review/expiry condition; it is also registered in `register.md`. FR/SC textual coverage remains 28/14. The one incidentally matched FR is `FR-008`, introduced by the legitimate parenthetical in C-58 (`（FR-008 是字段名的主证据）`), exactly as the waiver describes. **Closed.** Evidence-label defect: see N2.

#### F4 — Unified PLAN-EDIT protocol and quickstart Scenario 3: closed

`tasks.md` now defines one protocol:

```
a declared amendment — `PLAN-EDIT: <file>:<loc> — <reason>; scope/invariants preserved` — is allowed for confirmed defects and is recorded in the run's disposition ledger; only scope, design, entity-set or interface changes are an ANOMALY and stop the line.
```

The review-fix edits are declared as PE-01…PE-08, and `analyze-fix-dispositions.md` §7 is marked superseded by this protocol. Quickstart Scenario 3 now asserts `/api/kb` path-key count = 0 and operation-level `deprecated` = 3 via YAML counting; a live re-run prints `0` and `3`. **Closed.**

#### F5 — Lint ignore counted: closed

C-18 now permits named error-severity ignores only with per-item rule/path/reason and counting, and DoD-2/GATE-1 require exactly one counted ignore. Live lint prints `Woohoo! Your API description is valid.` and `1 problem is explicitly ignored.` with exit 0 and no warning; `no-unused-components` remains `error` for every other component. **Closed at the gate/DoD/contract level.** The requirements-level lint criterion (FR-021 / SC-001) still states the unqualified `0 error` objective: see N1.

#### F6 — xuanji-images 051 SC-005 obligation: closed on the 010 side

`tasks.md` §External Obligations contains the named row with the conflicting 051 wording, the 010 clause authority (C-06/C-07/C-21), the owner, the closure artifact and the verification point. The obligation is explicitly external and is not claimed closed. **Closed on the 010 side.**

#### F7 — Register bootstrap: closed

`.specify/memory/register.md` exists, defines the pointer-row form (`ID → one-line meaning → authoritative path#anchor → status`), registers 11 REC rows and 6 waiver rows (mechanically counted `17`), and lists 008/009 legacy IDs as a backlog rather than fabricating evidence. The review-fix dispositions disclose that the original "same commit" obligation was missed and landed in the fix commit. **Closed.** Pointer-form defects: see N3.

#### F8 — Feature 018 state transition: closed

`features.md` row 018 is `Ready for Review`; `features/018.md` carries `Status: Ready for Review`, an implement entry recording `Planned → Implemented`, and a review entry recording `Implemented → Ready for Review`. The Pre-Status-Flip evidence re-verifies in this review: 0 open task rows, 0 `[~]` deferred rows, 14 SC status rows. **Closed.** Accounting mismatch in the feature detail: see N3.

### 3.2 New findings

#### N1 — Review-fix corrections were not propagated to every copy (P2, Workflow)

- **Severity**: P2
- **Category**: Workflow
- **Propagation surface**: `requirements.md` FR-021/SC-001, `tasks.md` T026/T028, `research.md` D-03, `quickstart.md` Scenario 4 (no downstream gate inherits the error; each is a stale copy of an amended rule).
- **Location**:
  - `/storage/project/kangaroo-xuanji/worktrees/xuanji-api-010/.specify/specs/010-xuanji-doc-stable-api/tasks.md` line 153 (T026)
  - same file line 155 (T028)
  - `/storage/project/kangaroo-xuanji/worktrees/xuanji-api-010/.specify/specs/010-xuanji-doc-stable-api/research.md` line 38 (D-03)
  - `/storage/project/kangaroo-xuanji/worktrees/xuanji-api-010/.specify/specs/010-xuanji-doc-stable-api/quickstart.md` line 98 (Scenario 4)
  - `/storage/project/kangaroo-xuanji/worktrees/xuanji-api-010/.specify/specs/010-xuanji-doc-stable-api/requirements.md` lines 1021 (FR-021) and 1049 (SC-001)
- **Evidence** (verbatim quotes):

  ```
  - [X] T026 [US4] Verify the authentication matrix across all 17 operations ... admin GET/PUT only `basicAuth`, four health endpoints `security: []`, the other 12 accept both schemes, every 401 response references the `WWWAuthenticate` header ...
  ```

  ```
  - [X] T028 [US4] Verify the error contract ... 401/403/405/409/413/415 mapping is present, and `details` is the only exempt object — verify: ...
  ```

  ```
  - 每个 object schema 显式写 `additionalProperties: false`；`Error.details` 是唯一例外（`type: object` + `nullable: true`，不设 `additionalProperties`）。
  ```

  ```
  - `components.schemas.Error` 恰好四字段；`details` 是唯一未设 `additionalProperties: false` 的 object。
  ```

  ```
  - **FR-021**: 契约 MUST 通过确定性 lint ... 退出码 0 且 0 error（...）；1.0.0 目标 0 warning，未来 warning 必须在该配置中显式 allowlist 并注明理由 ...
  ...
  - **SC-001**: ... redocly lint 退出码 0 且 0 error。
  ```

- **Why it's a problem**: these are stale copies of rules the review-fix amended. T026's "other 12" is arithmetically wrong (17 − 2 admin − 4 health = 11); it is the exact anchor the analyze carry-over row F-08 cites, while the Phase 6 Independent Test on the same page was corrected to 11. T028, research D-03 and quickstart Scenario 4 still claim `Error.details` is the *only* exempt object, contradicting C-09's four named carve-outs. FR-021/SC-001 still state the unqualified "0 error" objective while C-18/DoD-2/GATE-1 now require the counted ignore. None of these is machine-enforced, so no gate is false-green; but a reader following any copy gets a different rule from the one the contract and gates now implement — the same-author copy-drift class the review-fix was meant to close.
- **Proposed fix**: sweep every copy of the amended rules, and add a mechanical pre-close check to the feature's task template: for each amended clause, grep the superseded phrases (`唯一例外`, `only exempt object`, `唯一未设`, `other 12`) and fail if any survives outside historical run records. Add the `fixed` disposition to the ledger with a post-fix quote of the cited line (see REC-C1 extension).

#### N2 — Gate evidence file binds the wrong HEAD and records an unreproducible exit code (P2, Automation)

- **Severity**: P2
- **Category**: Automation
- **Propagation surface**: `notes/review-fix-gates.txt` → `review-fix-dispositions.md` §3/§5 → `run-record-review-fix.md` §3 (the evidence file is cited as the proof for F3/F5/gates).
- **Location**:
  - `/storage/project/kangaroo-xuanji/worktrees/xuanji-api-010/.specify/specs/010-xuanji-doc-stable-api/notes/review-fix-gates.txt` line 2
  - same file line 54
- **Evidence** (verbatim quotes):

  ```
  HEAD: e46ae2793  date: 2026-10-30T18:39:11Z
  ```

  ```
  GATE5_TOOL_EXIT=0
  ```

- **Why it's a problem**: `e46ae2793` is the **base** commit (the first review report), not the fix commit `fad0e32bc`; the same file's GATE-5 output reflects the post-fix contracts (the FR-008 parenthetical was introduced in C-58 by the fix), so the HEAD label is wrong, not merely stale. Independently, a live re-run of the accountant returns **exit 1** with `status: uncovered`; `GATE5_TOOL_EXIT=0` is not reproducible and looks like a pipeline exit code captured instead of the tool's. The gate text does not require exit 0, so this is an evidence-label defect, not a gate failure — the same class as carried F10.
- **Proposed fix**: capture `$?` immediately after each tool invocation (no pipe), commit the evidence file with the fix commit (or label it `working tree at <base> + uncommitted fixes`), and add a check that an evidence file's HEAD equals the commit it is cited from. Extend REC-T3 to cover evidence-HEAD binding, not only clean-checkout labels.

#### N3 — Durable bookkeeping records disagree with the ledger and with their own declared forms (P2, Documentation)

- **Severity**: P2
- **Category**: Documentation
- **Propagation surface**: `features/018.md` and `register.md` (the durable state later sessions and reviews read); no gate inherits the error.
- **Location**:
  - `/storage/project/kangaroo-xuanji/worktrees/xuanji-api-010/.specify/memory/features/018.md` line 30
  - `/storage/project/kangaroo-xuanji/worktrees/xuanji-api-010/.specify/memory/register.md` lines 3, 17–27
  - `/storage/project/kangaroo-xuanji/worktrees/xuanji-api-010/.specify/specs/010-xuanji-doc-stable-api/analyze-carryover.md` lines 59–65
- **Evidence** (verbatim quotes):

  ```
  新增 `analyze-carryover.md`（27/27 analyze MEDIUM/LOW 处置，23 fixed / 4 具名豁免项）
  ```

  ```
  - `fixed`: **26** — of which F-11/F-15/F-18 carry delegation waivers `W-ANALYZE-02`/`03`/`04` ... and F-16 carries `W-GATE5-FRLANE-001` ...
  - `waived`: **1** (F-09 / `W-ANALYZE-01`).
  - `deferred-to-review`: **0**.
  ```

  ```
  | REC-T1 | Clause-scope assertions must state coverage mode and recurse through nested/inline schemas | `.specify/specs/010-xuanji-doc-stable-api/review.md#5.1` → `.specify/templates/tasks-template.md` | open (framework feedback) |
  ```

  ```
  waiver (`…-WAIVER-…` / `…-IGNORE-…`)
  ```

- **Why it's a problem**: both totals reach 27, but the compositions disagree (`23 + 4` vs `26 + 1`), and the feature detail is the registry state a later session reads. The register's anchors `review.md#5.1`…`#5.5` do not resolve to the actual headings (`### 5.1 Template Improvements` renders as `#51-template-improvements`), and `analyze-carryover.md#4` renders as `#4-waiver-registry-analyze-carry-over`; the row form requires `<authoritative path#anchor>`. The declared waiver-ID pattern (`…-WAIVER-…` / `…-IGNORE-…`) does not cover the IDs actually registered (`W-GATE5-FRLANE-001`, `W-ANALYZE-01…04`). These are small, but they are the traceability surface F7 was created to provide.
- **Proposed fix**: make the feature detail cite the ledger's §5 counts verbatim (or generate them); use the real heading anchors; align the register's ID pattern with the actual waiver namespace (`W-…`).

### 3.3 Carried P2 findings (not dispositioned by review-fix)

- **F9 — SC-count anomaly recorded as 24 and 28** (P2, Documentation): `checklists/requirements.md:60` says `入口指令的 SC 计数为 24`; `feature-ref.md:60` and `tasks.md:42` say 28. Still present; no canonical anomaly table was added.
- **F10 — Evidence labels overstate their basis** (P2, Documentation): `verification.md:3` still labels `34d7f2537` (the S4 bookkeeping commit) as `# -- Baseline (recorded once, BEFORE any /speckit.implement work changes the tree) --`; `notes/quickstart-run.md:224` still titles a run with a dirty tree `Post-commit clean-checkout lint (SC-011)`.
- **F11 — Three-piece records remain `not_evaluated` on all axes** (P2, Automation): `run-record-implement-s5.md:94` still says `determination 四轴均为 not_evaluated`; the review-fix determination record in `.specify/memory/session/` likewise records all four `not_evaluated`. No `verdict_available` signal exists.

## 4. What Worked — Preserve (Brief)

- The review-fix chose to **amend the clause** (four named carve-outs) **and restore the assertion to full scope** (recursive exact-set), rather than re-narrowing the test; the negative probe proves the assertion bites.
- Analyze carry-over is now a real 27-row ledger, referenced from tasks and SC-012, with named waivers for implementation-owned algorithms.
- Both gate exceptions are named, owned, evidenced and re-ratifiable: `LINT-IGNORE-001` and `W-GATE5-FRLANE-001`; the accountant's `uncovered` status stays visible.
- Quickstart Scenario 3 is now a machine criterion (`/api/kb` path keys = 0) rather than an unsatisfiable string-absence expectation.
- The register bootstrapped with an explicit legacy backlog instead of fabricating row-level evidence for 008/009.
- All gates reproduced in this review at HEAD `5b4398f59` (GATE-1/2/3/4/6 green, GATE-5 green only under its waiver), so the review-fix did not disturb the design tree.
- The review-fix commit touched no `design/`, `generated/`, `src/`, CI, dependency or lockfile path; the worktree is clean.

## 5. spec-kit / SDD Improvement Recommendations

### 5.1 Template Improvements

- **REC-T1 (extended) — Make clause amendments propagate to every copy** — Target: `templates/tasks-template.md` (absolute supplement: `/storage/project/kangaroo-xuanji/worktrees/xuanji-api-010/.specify/templates/tasks-template.md`). Change: alongside the coverage-mode declaration, require a "copy sweep" line for every amended clause: list each artifact that restates the rule and assert none retains the superseded phrase; fail the close-out if a copy survives. Source: N1. Expected impact: the T026/T028/research/D-03/quickstart-4/SC-001 drift cannot recur silently.
- **REC-T3 (extended) — Bind evidence files to the commit they prove and capture the tool's own exit code** — Target: `templates/verification-log-template.md` (absolute supplement: `/storage/project/kangaroo-xuanji/worktrees/xuanji-api-010/.specify/templates/verification-log-template.md`). Change: require an evidence `head_commit` field equal to the commit under review and a `tool_exit` captured directly after the command (no pipe); reject a recorded exit that a re-run does not reproduce. Source: N2, F10. Expected impact: evidence labels stop overstating or mis-binding their basis.

### 5.2 Command Prompt Improvements

- **REC-C1 (extended) — Verify each `fixed` disposition at its cited post-fix line** — Target: `templates/commands/implement.md` (external to this checkout) and `.specify/skills/internal/implement-feature/SKILL.md` (absolute supplement: `/storage/project/kangaroo-xuanji/worktrees/xuanji-api-010/.specify/skills/internal/implement-feature/SKILL.md`). Change: a carry-over row may be marked `fixed` only with a quoted post-fix line from the location the finding cited, not merely a nearby line that was corrected; the close-out checks each quote. Source: N1 (the F-08 row). Expected impact: a disposition cannot claim closure while the cited line still carries the defect.

### 5.3 Automation / Script Improvements

- **REC-A2 (carried) — Give unattended runs a real determination verdict or an explicit out-of-scope state** — Target: `scripts/python/run-determination.py` (absolute supplement: `/storage/project/kangaroo-xuanji/worktrees/xuanji-api-010/.specify/scripts/python/run-determination.py`) and `shared/workflow/feedback-step.md`. Change unchanged from the first review: wire available sources or emit `out_of_scope` with a reason; add `verdict_available`. Source: F11. Expected impact: three-piece records become distinguishable evidence.

### 5.4 Documentation Improvements

- **REC-D1 (extended) — One canonical accounting and resolvable pointer form** — Target: `templates/feature-details-template.md` (absolute supplement: `/storage/project/kangaroo-xuanji/worktrees/xuanji-api-010/.specify/templates/feature-details-template.md`). Change: require the feature detail to quote the disposition ledger's accounting, generate heading anchors instead of section numbers, and align the register's waiver-ID pattern with the actual `W-…` namespace. Source: N3, F9. Expected impact: the durable registry and the ledger cannot disagree, and every pointer resolves.

## 6. Priority Roadmap

| Priority | Recommendation | Target File / Subsystem | Source Finding(s) |
|----------|----------------|--------------------------|-------------------|
| P2 | Propagate amended clause rules to every copy and mechanize the sweep | `templates/tasks-template.md` | N1 |
| P2 | Verify `fixed` dispositions at the cited post-fix line | `templates/commands/implement.md`; `.specify/skills/internal/implement-feature/SKILL.md` | N1 |
| P2 | Bind evidence files to the proved commit and the real exit code | `templates/verification-log-template.md` | N2, F10 |
| P2 | One canonical disposition accounting and resolvable register pointers | `templates/feature-details-template.md`; `.specify/memory/register.md` | N3, F9 |
| P2 | Give determination a verdict or explicit out-of-scope state | `scripts/python/run-determination.py`; `shared/workflow/feedback-step.md` | F11 |

## 7. Self-Containment Check

- [x] Every `REC-…` target is repo-relative (primary), with an absolute path only as a parenthetical supplement; targets with no repo-relative form are marked external with a reason.
- [x] Every finding has a quoted excerpt that lets the reader judge the problem without opening the source file.
- [x] No bullet says "see attached", "as discussed earlier", or otherwise references context outside this document.
- [x] No placeholder tokens remain anywhere in the report.
- [x] Section 4 is short and bullet-only.
- [x] Section 5 recommendations each cite an exact target file and at least one source finding ID.
- [x] P0 validation status is stated explicitly: **No P0 findings were raised; the P0 independent-validation pass is vacuously satisfied.** P1/P2 skip validation.
- [x] Same-author delegation gate: not fired — the artifacts under review predate this session (produced by earlier unattended runs); the recheck used live re-execution for every gate claim.
- [x] Counts are enumerated, not asserted: the four non-strict object paths, the 27 ledger rows, the 17 register rows and the five stale-copy locations each carry an anchor.

## 8. Feedback

The highest-value signal from this recheck is that the review-fix got the *mechanism* right — amended clauses, restored assertions, named waivers, counted ignores, a real carry-over ledger — and lost only on *propagation*: four artifacts still quote the superseded rules, one ledger row claims a fix at a line that still says "the other 12", one evidence file binds the wrong HEAD and an unreproducible exit code, and the durable registry summarizes the ledger with different numbers. The framework already asks reviewers to treat mapping tables as assertions; the same discipline should apply to *every copy of an amended rule*, and the cheapest enforcement is a required copy-sweep line in the task template plus a post-fix quote for every `fixed` disposition.

## Optimization Points
- F1–F8 closed with live gate reproduction; P0/P1 recomputed 0/0; new P2: N1 stale copy-drift, N2 evidence HEAD/exit labels, N3 bookkeeping accounting; carried P2: F9–F11.
- token-efficiency: the recheck read whole machine-managed determination/exec-quant JSON records to replicate wrap-up parameters; prefer extracting only the needed fields.
