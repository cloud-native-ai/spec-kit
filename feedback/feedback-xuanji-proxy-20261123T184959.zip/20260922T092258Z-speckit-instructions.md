---
id: "20260922T092258Z-speckit-instructions"
unit_id: "/speckit.instructions"
unit_type: "command"
run_id: "20260922T0923Z-instructions"
scope: "local"
probe: "speckit-instructions-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-09-22T09:22:58Z"
summary: "Bootstrap run of /speckit.instructions on a JVM project; three harness observations recorded as points, all scoped to this command's own machinery."
---

## Review
Bootstrap run of /speckit.instructions on a JVM project; three harness observations recorded as points, all scoped to this command's own machinery.

## Optimization Points
- Symlink conversion reads as content loss on first run: the setup script turned CLAUDE.md and .qoder/project_rules.md (both carrying hand-authored project instructions) into symlinks to .specify/instructions.md, and deleted .clinerules/, .lingma/, .trae/. The command documents a non-destructive guarantee for .specify/instructions.md but says nothing about these compatibility paths, so an operator sees 55 lines of real content disappear with no notice. It is recoverable (git history plus untouched duplicates in QWEN.md/IFLOW.md), but the script could print what it converted and confirm preservation rather than leaving the agent to reconstruct trust after the fact.
- Default Documentation Map ships rows pointing at files that usually do not exist: CONTRIBUTING.md, README.md and docs/ are pre-filled with only a reviewer note to drop them when absent, so every fresh project starts with a map whose rows are wrong until an agent notices. Either ship those rows commented out, or have the setup script probe and pre-drop them — the script already walks the tree, so the check is nearly free.
- run-tests.sh is structurally unusable outside Python: .specify/scripts/bash/run-tests.sh hardcodes a pytest interpreter (SPECKIT_PYTHON -> .venv/bin/python -> python3), so the framework's canonical test runner cannot run this Maven project at all; the Token Efficiency Discipline's Program-First rule has the same Python-toolchain assumption. A Java/Kotlin/Node project is therefore nudged toward hand-rolled test invocation with no framework guidance, which is where the harness loses its Change Validation loop.
