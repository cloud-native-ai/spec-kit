---
id: "20260922T174015Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "002-upgrade-implement-20260923"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-09-22T17:40:15Z"
summary: "Stack-upgrade implement run walled by pre-existing incomplete code in an untouched module; scoped verification accepted by the user. Two attribution disciplines were load-bearing."
---

## Review
Stack-upgrade implement run walled by pre-existing incomplete code in an untouched module; scoped verification accepted by the user. Two attribution disciplines were load-bearing.

## Optimization Points
- When a convergence-build task hits a compile wall in a module the run never touched, prove pre-existing vs caused-by-this-run with 'git diff HEAD -- <module>/src' (EMPTY = pre-existing) plus checking whether the errors are source-level facts about the project's own classes (interface instantiated, abstract class missing a caller's constructor) that a version bump cannot cause — before spending any budget 'fixing' another author's unfinished code.
- Treat the accept-scoped-verification vs complete-the-wall fork as a genuine USER decision (surface it), not a sensible default — completing an unfinished refactor violates a no-functional-changes constraint and invents design.
- Pair the git-diff wall attribution with javap/jar-tf premise checks against primary artifacts: a task whose premise is a public API existing (e.g. a public Netty logging SPI) can be falsified by inspecting the jar, and the correct outcome is defer-with-cited-measurement, not a workaround.
