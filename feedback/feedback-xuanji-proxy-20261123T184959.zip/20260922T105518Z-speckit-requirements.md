---
id: "20260922T105518Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "20260922T1000Z-upgrade-software-stack"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-09-22T10:55:18Z"
summary: "Drafted the software-stack-upgrade requirements (4 stories, 15 FRs, 8 SCs) and settled both clarification markers in-session. Four harness observations recorded as points, all scoped to this command's"
---

## Review
Drafted the software-stack-upgrade requirements (4 stories, 15 FRs, 8 SCs) and settled both clarification markers in-session. Four harness observations recorded as points, all scoped to this command's template and validation flow.

## Optimization Points
- The requirements quality checklist has three items that are structurally unsatisfiable for a whole class of features, with no sanctioned way to record that. "No implementation details", "Written for non-technical stakeholders", and (partly) "Success criteria are technology-agnostic" cannot be satisfied by a feature whose subject matter IS the technology baseline - a stack upgrade, a dependency migration, a platform change, a rename. The guidelines offer no "not applicable + rationale" state, so every project invents its own convention: this repository's feature 001 recorded a prose rationale under Notes, and the run for feature 002 had to reproduce that pattern. A sanctioned N/A-with-rationale marker would stop both silent ticking and this per-project re-derivation.
- Clarification ownership is split across two commands without a stated boundary. This command's validation section owns the [NEEDS CLARIFICATION] resolution flow (limit to 3, table format, update spec), while /speckit.clarify also exists and the handoff says to run it whenever markers remain. The "sanctioned variant" paragraph permits settling markers in-session and then passing the checklist green, but the ownership boundary between "settle here" and "defer to clarify" is never stated once, so an agent has to infer it. Stating the rule once - in-session markers are settled and recorded here; anything needing external input defers - would remove the inference.
- The requirements template has no slot for a decision input that constrains the whole feature. For an upgrade feature the agreed target baseline (which versions, and why) is the single most load-bearing fact, and it fits none of the template's sections: it is not a user story, not a functional requirement, and the optional "Shared Strings" section is for literals consumed verbatim by tests. The run had to add a "Targeted Baseline & Upgrade Constraints" subsection under Requirements to hold it, flagged with an explicit ownership handoff so it does not become a permanent second copy of the build file. A recognised "Decisions & Inputs" slot would make that placement conventional instead of improvised.
- Verification evidence for this class of feature depends on a baseline that does not exist yet, and nothing in the flow prompts for it. The run wrote SC-002 as a test-name set comparison against a pre-upgrade run, which is the honest way to make "no regression" checkable - but the project's packaging build skips tests, so no baseline has ever been captured. The template's Success Criteria section asks for measurable outcomes and their sources; it does not ask whether the measurement's baseline is captured, which is the step most likely to be skipped and most damaging to skip.
