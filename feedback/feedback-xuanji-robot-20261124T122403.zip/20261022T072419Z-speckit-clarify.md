---
id: "20261022T072419Z-speckit-clarify"
unit_id: "/speckit.clarify"
unit_type: "command"
run_id: "clarify-011-api-auth-rate-limit-20261022"
scope: "local"
probe: "speckit-clarify-wrapup"
kind: "internal"
slice: "commands"
feature: "011-api-auth-rate-limit"
feature_id: "017"
partial: false
created: "2026-10-22T07:24:19Z"
summary: "Mode A clarify on requirements.md completed. Independent detection and a disjoint validation pass found five material ambiguities, all adjudicated and integrated: admin IP allowlist denial (pre-auth 4"
---

## Review
Mode A clarify on requirements.md completed. Independent detection and a disjoint validation pass found five material ambiguities, all adjudicated and integrated: admin IP allowlist denial (pre-auth 403 + STR-010 + source_ip_not_allowed), middleware order and 403 credential-bucket accounting, limiter-capacity 429 (Retry-After 1, cause=bucket_capacity), 021 callback 401/413 exclusion from security events and reconciliation, and event path excluding query strings. A low-impact RFC 7235 header-parsing decision was recorded as an assumption rather than consuming a question slot. Deterministic validator: 726 lines, 70 definitions, 10 shared strings, 0 error/0 warning. Artifact committed as cecdf12.

## Optimization Points
- 1) Preserve the 021 callback 401/413 exclusion when plan derives the event/reconciliation test matrix; it is the easiest boundary to regress. 2) The allowlist denial is pre-auth by design: plan must not reorder it after token validation, or token-validity leakage returns. 3) Capacity-exhaustion 429 needs its own test branch (cause=bucket_capacity, Retry-After 1); it is not covered by quota tests. 4) Keep the header-parsing assumption (RFC 7235 scheme case-insensitivity) synchronized between FR-002, A2 and tests.
