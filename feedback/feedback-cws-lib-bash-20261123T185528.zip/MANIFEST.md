# Feedback Package Manifest

> This feedback targets the Spec Kit framework itself (templates, commands, skills, scripts, docs) — not the LLM, agent CLI, harness, or any user project code.

- **Generated**: 2026-11-23T10:55:28Z
- **Entries**: 4
- **Time range**: 2026-07-30T11:53:59Z → 2026-11-12T09:19:30Z
- **spec-kit version**: 0.0.22
- **Install source**: https://gitlab.alibaba-inc.com/cloud-native-ai/spec-kit.git @ cdc79cdb52c892e8ed43145860cea2cd6ffdbfdf
- **Excluded (non-framework, kept local)**: 3 entries — skill:cli-setup, skill:memory-record, skill:sanitize-materials

| Created | Unit | Partial | Probe | Slice | Summary |
|---------|------|---------|-------|-------|---------|
| 2026-07-30T11:53:59Z | /speckit.docs | False | - | - | Bootstrap sweep on cws-lib-bash: generated full docs/ skeleton (6 type dirs + notes + decisions index/template), created |
| 2026-07-30T11:57:56Z | /speckit.instructions | False | - | - | Directed refresh after /speckit.docs bootstrap: Documentation Map gained Glossary/Architecture/Docs-Space rows and updat |
| 2026-11-12T09:19:21Z | /speckit.sanitize | False | speckit-sanitize-wrapup | commands | Materials lane run: collect surfaced 2 pending index-inconsistency findings (legacy feedback/session index.json, req 055 |
| 2026-11-12T09:19:30Z | /speckit.sanitize | False | gate-sanitize-destructive-cleanup | commands | confirm-gate fired: single-batch cleanup plan (2 repair items, confirmed:false) presented; user released the batch via t |
## Exec-Quant Payload

- **Records**: 2
- **Source forms**: records-dir 2, legacy-jsonl 0
- **Skipped unreadable**: 0
- **Truncated**: 0
- **Cap**: 1000 records / 16777216 bytes (triggered: no)
- **Source project**: `cws-lib-bash`
- **Collected range**: 2026-11-12T09:19:16Z → 2026-11-12T09:19:17Z

