---
id: "20261016T191642Z-speckit-instructions"
unit_id: "/speckit.instructions"
unit_type: "command"
run_id: "instructions-recover-2026-10-17"
scope: "local"
probe: "speckit-instructions-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-16T19:16:42Z"
summary: "Recover-mode run on kdbg (spec-kit client, stamped c8d2908): canonical .specify/instructions.md had never existed; established the refresh base from the repo's accumulated legacy instructions (CLAUDE."
---

## Review
Recover-mode run on kdbg (spec-kit client, stamped c8d2908): canonical .specify/instructions.md had never existed; established the refresh base from the repo's accumulated legacy instructions (CLAUDE.md/QWEN.md/.ai/instructions.md, fullest = 12462 B), ran generate-instructions.sh (backup + 18 template sections injected), then converged section-by-section: 12 legacy manual sections folded with attribution into Project Overview / Documentation Map / Tech Stack & Resources / a new Build & Test Quick Reference; stale facts corrected (go.work, VERSION, unit_test_list, deploy/daemonset.yaml, rpm/SOURCES, scripts/shared/version_utils.sh, legacy make target names). Size 33284 B → 25198 B (budget 32768 B). 11 compat symlinks rebuilt and verified; 15/15 framework sections byte-identical to template; glossary seeded with 6 proposed terms.

## Optimization Points
- .specify/scripts/bash/common.sh 在 CWS_LIB_BASH_HOME 未设置时直接 exit 1，导致 /speckit.instructions 在未安装 cws-lib-bash 的机器上完全无法运行（尽管文件前置条件全部满足）；建议按脚本自身的非破坏设计降级为 warning + 继续，或在输出中给出初始化指引。本次绕行：export CWS_LIB_BASH_HOME=$HOME/project/cloud-native-tools/cws-lib-bash
- generate-instructions.sh 的符号链接族不覆盖真实仓库中存在的遗留兼容文件（本仓 QWEN.md/IFLOW.md/.ai/instructions.md，其中 .ai/instructions.md 是旧 canonical）；recover 模式跑完后这些文件仍指向旧内容或保持为游离的普通文件，需 agent 手工重指。建议脚本内维护一份 managed-legacy-links 清单使 recover 完全收敛
- 当刷新基线为非模板形态（如旧版中文手册）时，additive reconcile 把全部模板段追加到文件尾部，产生重复的概述/技术栈节，需 agent 手工合并；若能对已知等价节（概述↔Project Overview、技术栈↔Tech Stack & Resources）做映射式插入可减少手工手术
