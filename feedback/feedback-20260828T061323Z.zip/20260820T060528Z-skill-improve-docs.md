---
id: "20260820T060528Z-skill-improve-docs"
unit_id: "skill:improve-docs"
unit_type: "skill"
run_id: "improve-docs-20260820-readme-ai-tracing-rename"
scope: "local"
probe: "skill-improve-docs-wrapup"
kind: "internal"
slice: "skills"
partial: false
created: "2026-08-20T06:05:28Z"
summary: "Staleness refresh on README.md: renamed project title ai-coding-trace → ai-tracing per constitution v1.2.0.1 and user-confirmed glossary, refreshed intro to session-aggregation positioning with collec"
---

## Review
Staleness refresh on README.md: renamed project title ai-coding-trace → ai-tracing per constitution v1.2.0.1 and user-confirmed glossary, refreshed intro to session-aggregation positioning with collect/storage implemented vs export/analysis planned, and added explicit reference-only clause for @ali/ai-coding-trace. Port 45200 assertion verified against src/config/index.ts; validate and Hugo build both green after edit.

## Optimization Points
- docs-utils.py validate 将 QWEN.md（Spec Kit 工具强制的兼容符号链接，已在 instructions.md Symlink Model 中登记）持续报告为 reserved-name-misuse——校验引擎应豁免符号链接型工具兼容文件，否则该误报会永久存在于每次基线，掩盖真实验证信号。
