---
id: "20261118T131338Z-speckit-sanitize"
unit_id: "/speckit.sanitize"
unit_type: "command"
run_id: "20261118T131321Z-san"
scope: "local"
probe: "speckit-sanitize-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-18T13:13:38Z"
summary: "materials lane 一次完整闭环：collect 新增 389 条 pending（全部 dead-reference，全部位于 .specify/specs/002–007 历史制品）；语义候选 0、引擎 notes 0、其它确定性检查（镜像/符号链接/索引/迁移残留）干净；残余探测 goal=0/team=0。经核对根因是 016 Java 标准化（4470a19 移除 Python"
---

## Review
materials lane 一次完整闭环：collect 新增 389 条 pending（全部 dead-reference，全部位于 .specify/specs/002–007 历史制品）；语义候选 0、引擎 notes 0、其它确定性检查（镜像/符号链接/索引/迁移残留）干净；残余探测 goal=0/team=0。经核对根因是 016 Java 标准化（4470a19 移除 Python 测试栈、application.properties→application.yml、src 布局收敛）有意移除的旧路径被历史记录引述。按平台七类拆分（removed-python-stack 291 / src-other 35 / framework-relative-shorthand 32 / replaced-config-file 13 / intended-or-tmp-path 8 / ellipsis-shorthand 7 / other 3），写入单一批次计划（389×dismiss，可逆、无 delete/archive），用户一次性放行后 apply 389/389 ok、失败 0，台账 802/802 resolved、pending 0。确认门与回执纪律按预期工作。

## Optimization Points
- 1) 检测器精度：39/389（约 10%）为缩写/省略号误报——'src/test/java/.../XTest.java' 完整路径实际存在、'skills/config-nginx-for-buc' 等为框架相对简写；建议 dead-reference 检测对含 '...' 的缩写形式与框架相对前缀（skills/agents/templates/shared/speckit.*）做归一化或降级排除。2) 按日期记录不做内容改写是既有红线，但 test-evidence/review/checklist 仍会被每轮重复检出（本次 291 条源于一次迁移），建议为「历史工件旧身份」提供可一次裁决的排除类或根级豁免，避免每次迁移后重复批量确认。3) 薄判断：本轮确定性部分全部交引擎/脚本（37KB collect 包络未注入上下文，改为本地脚本提取摘要），未出现原文转储或重复读取。
