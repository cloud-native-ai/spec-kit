---
id: "20261118T025956Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "20261118t025919z-impl016-s2"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "007-java-project-standardization"
partial: false
created: "2026-11-18T02:59:56Z"
summary: "PKG-S2 能力等价完成：test-assets.json v2（63 test/10 support/4 integration，findings=0 coverage_ratio=1.0 expected=75）、baselines/java-tests.txt（源码扫描 419 名称，missing=0 added=0）、tool-selftest-disposition.json（62 "
---

## Review
PKG-S2 能力等价完成：test-assets.json v2（63 test/10 support/4 integration，findings=0 coverage_ratio=1.0 expected=75）、baselines/java-tests.txt（源码扫描 419 名称，missing=0 added=0）、tool-selftest-disposition.json（62 行，19/24/16/3，replaced=59/deleted=3）、bin/verify-all.sh（五步、0/1/2 退出码、名称级空车道守卫、blocked 不改码）；5 套能力契约测试 52/52 绿，宽定向集 301/301 绿；golden/Python/生产代码零 diff；门 pass

## Optimization Points
- 1) 测试夹具内嵌 @Test 字面量被词法扫描器计入名称集（429→419），夹具改用常量拼接；2) 受控删除演练若把 @Test 注释保留 token 会失效，改为无 token 替换；3) --with-integration 实机执行留待 S4 入口就位，S2 只钉调用契约与预检 blocked 语义；4) 全量 ./mvnw -B test 未动（slot-2 留给 S8/review），仅定向集取证
