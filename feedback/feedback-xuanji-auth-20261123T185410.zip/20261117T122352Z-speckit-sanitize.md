---
id: "20261117T122352Z-speckit-sanitize"
unit_id: "/speckit.sanitize"
unit_type: "command"
run_id: "20261117T122340Z-sanitize-full-rewrite"
scope: "local"
probe: "speckit-sanitize-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-17T12:23:52Z"
summary: "本轮在客户端工作区执行材料治理：collect 得到 311 条 pending（115 个材料文件、129 个唯一引用），按用户确认执行全量重写，三轮回改后 413/413 resolved、0 pending，115 份原文件已归档。过程中发现两处框架侧判定口径问题：命令/技能引用根按工作区根探测，以及 test-evidence 日志未按日期化记录排除。"
---

## Review
本轮在客户端工作区执行材料治理：collect 得到 311 条 pending（115 个材料文件、129 个唯一引用），按用户确认执行全量重写，三轮回改后 413/413 resolved、0 pending，115 份原文件已归档。过程中发现两处框架侧判定口径问题：命令/技能引用根按工作区根探测，以及 test-evidence 日志未按日期化记录排除。

## Optimization Points
- sanitize-utils 的命令与技能引用根应解析到已安装布局（`.specify/templates/commands` 或命令副本目录、`.specify/skills`），而不是工作区根的 `templates/commands` 与 `skills/`，避免客户端工作区把全部 `speckit.*` 与 `skills/*` 引用判死。
- collect 应把 `test-evidence/` 日志与日期化记录按 `excluded_hits` 报告（与 renumber lane 的日期化记录红线一致），不进入可修复台账。
