---
id: "20261117T191615Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "20261117T191000Z-ana016-w1"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
feature: "007-java-project-standardization"
partial: false
created: "2026-11-17T19:16:15Z"
summary: "W1 read-only analyze: 17 findings (2 HIGH / 7 MEDIUM / 8 LOW). Coverage +106 and S0 freeze baseline are aligned; residual drifts concentrate in layout oracle, config carrier scope, reason-code set, wh"
---

## Review
W1 read-only analyze: 17 findings (2 HIGH / 7 MEDIUM / 8 LOW). Coverage +106 and S0 freeze baseline are aligned; residual drifts concentrate in layout oracle, config carrier scope, reason-code set, whitelist commands, notes anchoring, and constitution evidence.

## Optimization Points
- F01 SC-001 layout allowlist oracle mixes git ls-files with .git/.vscode (requirements FR-009/FR-017/SC-001, A-13, data-model E-8)
- F02 FR-035 requires profile-specific .yml layering but plan retains src/test/resources/application-{test,default}.properties (requirements FR-035; plan lines 142/367)
- F03 data-model E-6 reason_code closed set has 7 values and omits shellcheck-absent required by FR-027 (data-model line 88; requirements line 274)
- F04 plan run-tests.sh whitelist command adds deletion-face excludes pytest.ini/scripts/tests beyond the 8 agent projections + .specify/** whitelist (plan line 297)
- F05 plan recompute commands append || true, masking the rc=1 reading SC-012 requires for conifg post-migration (plan lines 290-297)
- F06 Whitelist definitions drift: FR-005 omits .specify/history; Clarifications Q9 omits archive/history/state/features.md; plan old-test-stack grep excludes all .specify/** (requirements lines 119/246/360; plan line 292)
- F07 notes/ anchoring residual: SC-017, plan S1 and feature detail use bare notes/migration-drops.md instead of the full spec path (requirements line 365; plan line 240; feature detail line 35)
- F08 Constitution Check VI only records new warnings, not total compiler warnings required by Constitution VI (plan lines 36/247; constitution line 97)
- F09 FR-015 says entry scripts MUST NOT record blocked, while FR-034 keeps the 015 probe blocked semantics/JSON unchanged; scope needs reconciliation (requirements lines 27/259/284)
- F10 Plan Constitution Check V says two validation classes are deleted; only XuanjiBucEnvironmentValidator is a class (plan line 35 vs line 329)
- F11 Plan Constitution Check VII cites requirements Out of Scope for the health probe, but the exclusion is in Related Feature (plan line 37; requirements line 28)
- F12 Plan line 21 says 7 capability contract test classes; Deliverable Inventory has 6 capability + 2 layout/config classes (plan lines 21/412-413)
- F13 Feature detail Latest Review says 12 STR while R2 says 13; features.md clarify note also carries 12 STR (feature detail lines 17/35; features.md line 47)
- F14 Coverage baseline rendered as 73.0% in requirements and 72.95% in plan/feature detail; +106 arithmetic is unaffected (requirements lines 85/269/356/430; plan line 16)
- F15 Data-model E-5 omits the dropped<=10 and 012-both-migrated invariants stated by FR-033/SC-017 (data-model line 81)
- F16 SC-004 allows unregistered downgrades without SC-017's dropped cap and 012 restriction (requirements line 352 vs line 365)
- F17 Plan hard-edge list omits S3->S4 although S4 entry requires the S3 exit (plan lines 235/243)
