---
id: "20261118T055130Z-speckit-measure"
unit_id: "/speckit.measure"
unit_type: "command"
run_id: "20261118T055054Z-meas"
scope: "local"
probe: "speckit-measure-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-18T05:51:30Z"
summary: "默认 summary 动作一次成功（exit 0）：脚本渲染 15 个 unit 的聚合读数、cap=200、excluded 五类全 0（read=58）、11 figures measurable；全程只读，未改写任何存储。执行按薄入口契约进行，未在命令侧二次投影数字。wrap-up 两条引擎实际行为：run-determination 因声明 complexity=simple 输出 ski"
---

## Review
默认 summary 动作一次成功（exit 0）：脚本渲染 15 个 unit 的聚合读数、cap=200、excluded 五类全 0（read=58）、11 figures measurable；全程只读，未改写任何存储。执行按薄入口契约进行，未在命令侧二次投影数字。wrap-up 两条引擎实际行为：run-determination 因声明 complexity=simple 输出 skipped: simple-unit（无判定记录），而随后 exec-quant collect 仍写入一条 qualification=not_evaluated 的记录，elapsed/tokens 全为 not_evaluated——scope 门只作用于判定引擎，未传导到采集引擎。

## Optimization Points
- 1) 薄命令运行（如本命令的 summary 动作）的 wrap-up 中，complexity 门未传导到 exec-quant collect：determine 已按 simple 跳过，collect 仍落一条全 not_evaluated 的 store 记录，建议在 probe 注册表的编译产物中声明「simple-unit 时跳过 collect」或显式传导 complexity 参数。2) 本会话拿不到 --session-file/--session-rows/--elapsed-ms 等采集来源，collect 记录质量轴全空；建议 wrap-up 模板对来源不可得的情形给出降级提示，避免全空记录无声积累。
