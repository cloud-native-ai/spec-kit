---
id: "20261118T043049Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "20261118T043032Z-impl016-s7"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "007-java-project-standardization"
partial: false
created: "2026-11-18T04:30:49Z"
summary: "PKG-S7 完成：bin/verify-all.sh 收敛为最终形态（新增 va_entry_blocked_reason/va_format_entry_line/va_aggregate_exit_code/va_write_executed_names/va_emit_failure_lines/va_coverage_record，步骤④ 与全局完整性解耦，VA-07 测量记录落证据目录"
---

## Review
PKG-S7 完成：bin/verify-all.sh 收敛为最终形态（新增 va_entry_blocked_reason/va_format_entry_line/va_aggregate_exit_code/va_write_executed_names/va_emit_failure_lines/va_coverage_record，步骤④ 与全局完整性解耦，VA-07 测量记录落证据目录 coverage.txt，删除死变量 VA_ERROR 后 shellcheck warning 0）；契约测试 12→15 方法（blocked 不改退出码且无 pass 伪造、名称级守卫失踪用例必红、VA-09 失败行文法），红先：旧脚本 15 跑 3 败 → 新脚本 15/15 绿；基线 507→510 同提交 append-only 登记（探针红 bl03/bl12/bl13 → 绿 missing=0 added=0），清单 91 assets findings=0；SC-011 四次真实演练 dry-run/0/1/2 全备（rc=1 为受控删除 XuanjiDpopPropertiesTest#settersRoundTripEveryKnob，git checkout -- 单文件恢复、sha256 恒等、git diff --stat 空）；SC-015 blocked 演练 rc=0 且两条入口各一行 blocked、入口未执行、预检为唯一 owner；docs/testing.md 命令与 integration 口径对齐；golden/src-main+pom/deploy(CS-11)/框架面 diff 全 0；门 decision=pass errors=0 advisories=74。

## Optimization Points
- 1) 收敛聚合程序时先把「步骤间不截断」做成语义边界（entries_present 只守入口存在性），否则任一早期完整性错误都会静默跳过步骤④，VA-05 的「任一步失败不截断后续」就落不了地。
- 2) VA-11 守卫演练必须用 Surefire XML 展开名做端到端输入：只断言 normalize 函数会漏掉「展开数=5 但名称集=3」这一事实，删除用例后的 rc=1 才是名称级口径不回退的证明。
- 3) rc=1 破坏性演练要先把本包改动 git add 暂存，`git diff --stat` 才是「工作树相对索引」的干净读数；恢复只许 scoped checkout 并记 sha256，广谱恢复命令会连带吞掉未提交成果。
