---
id: "20261117T174756Z-speckit-clarify"
unit_id: "/speckit.clarify"
unit_type: "command"
run_id: "r20261117T172128Z-9205"
scope: "local"
probe: "speckit-clarify-wrapup"
kind: "internal"
slice: "commands"
feature: "007-java-project-standardization"
feature_id: "016"
partial: false
created: "2026-11-17T17:47:56Z"
summary: "clarify 阶段完成：9 项高风险歧义逐项自行裁决并回写 `## Clarifications`，涉及集成测试执行路线、契约断言迁移顺序与计数口径、target 与顶层布局冲突、006 四项能力的量化承接、echo 后端豁免边界、Spring Boot 配置面、JUnit 覆盖目标、行为不变性口径、conifg 引用闭环。三项事实口径被更正：com/aliyun 行覆盖基线 71.3% 改为 "
---

## Review
clarify 阶段完成：9 项高风险歧义逐项自行裁决并回写 `## Clarifications`，涉及集成测试执行路线、契约断言迁移顺序与计数口径、target 与顶层布局冲突、006 四项能力的量化承接、echo 后端豁免边界、Spring Boot 配置面、JUnit 覆盖目标、行为不变性口径、conifg 引用闭环。三项事实口径被更正：com/aliyun 行覆盖基线 71.3% 改为 73.0%（1327/1819）、docs/design 的 conifg 引用 7 处改为 11 行（全仓 16 行）、迁移目标集明确为 211（209 已含 hook_render 34，不重复计入 245）。产物：新增 FR-049、SC-015 至 SC-017、STR-011/STR-012、A-20 至 A-25，修订 15 条 FR 与 2 条 SC；validate-requirements exit 0（435 lines / 66 definition rows / 12 shared strings），pre-analyze-check decision=pass（errors=0 / advisories=6，均为尚未创建的交付物路径）。

## Optimization Points
- plan 阶段应把 M1 的 211 条迁移落成模块到测试类的可执行清单，并复用 FR-033 的映射契约测试作为进度标尺；工具类迁移（manifest/baseline/verify-all）必须先于静态断言与运行时断言。
- 行为基线取证必须在第一次代码改动前完成：先提交黄金契约测试并跑绿，再动生产代码，否则 SC-016 的文件未改动判据失效。
- 空车道守卫与 blocked 集合的计数口径需在 plan 定成可实现算法（Surefire 汇总对比源码扫描基线），避免出现第二套判定逻辑。
- token-efficiency：本轮证据来自 5 组只读探测（jacoco 复算、pytest 基线分组、配置与校验路径、conifg 引用面、manifest schema），plan 阶段可复用同一组命令。
