---
id: "20261118T034148Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "20261118t032340z-impl016-s4"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "007-java-project-standardization"
partial: false
created: "2026-11-18T03:41:48Z"
summary: "PKG-S4 删除与归并完成：conifg/nginx 5 片段 100% rename 至 deploy/nginx；auth-it 迁 deploy/verify/auth-it（run-it.sh 自定位仓库根、去 /storage 硬编码、mode 100644→100755，无入口级 blocked 行）；verify-deployment.sh 迁 deploy/verify/sts "
---

## Review
PKG-S4 删除与归并完成：conifg/nginx 5 片段 100% rename 至 deploy/nginx；auth-it 迁 deploy/verify/auth-it（run-it.sh 自定位仓库根、去 /storage 硬编码、mode 100644→100755，无入口级 blocked 行）；verify-deployment.sh 迁 deploy/verify/sts 且 /token 扫描同步为 deploy/nginx；pytest.ini/.pytest_cache/tests/**/scripts/** 共 21 个受控文件删除，gitignore 补 .pytest_cache/；新增 layout-allowlist.json 与 LayoutContractTest（9 方法：LO-01…LO-08 + run-tests 白名单）全绿；T050 八项出口全过（全量 504 测试 0 失败、test_*.py 0 行、py 文件恰 1 行、bare 旧目录名 rc=1、顶层 23 项全在允许集、CS-11 diff 空）；golden / src/main+pom / CS-11 三处冻结 diff 均 0；门 decision=pass errors=0；提交 4470a19。

## Optimization Points
- 1) 铁律 5（test-assets.json 77 / baselines 419 冻结）与 T050 全绿存在规格冲突：T048 新增测试类触发 S2 契约 TM-04/TM-05/BL-03/BL-12/BL-13 的『同提交登记』硬约束；裁决为 append-only 登记（基线 +9→428 名、清单 +1 行→78），红→绿读数落 notes/red-first-evidence.md，S6/T073 沿同一机制继续登记。
- 2) LO-07 残余面 = 298 逐字载体（migration-map 211 + disposition 70 + 契约源 17）+ 1 行 T043 强制的 .gitignore 记账行；排除按源同源精确成立（source_id/source_module/rationale/module-count key、契约源注释与逐字 oracle 标记、.gitignore 唯一记账行），无整文件豁免；反向注入演练 hits=300→violations=1 点名后撤销复绿 299/0。
- 3) 环境适配两处已写入测试注释：/etc/gitconfig 的 submodule.recurse=true 使 git grep --untracked 报错，加 --no-recurse-submodules（无子模块，扫描面不变）；git ls-files 输出超管道缓冲，run() 以并发消费 stderr + 先读 stdout 避免死锁（首版曾 3 个子进程挂起，已修复）。
- 4) 入口级 blocked status 行唯一 owner 保持 bin/verify-all.sh 预检；两个迁移入口脚本均未输出该行，内部子记录语义原状保留。
