---
id: "20261118T035530Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "20261118T035449Z-impl016-s5"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "007-java-project-standardization"
partial: false
created: "2026-11-18T03:55:30Z"
summary: "PKG-S5 完成：application.yml 19 键逐值等价翻译（全值单引号保护，fallback ${SPRING_BUC_*:${BUC_*:<default>}} 逐字保留）；application.properties、XuanjiBucEnvironmentValidator、validateRequiredConfiguration 三处删除，spring.factories "
---

## Review
PKG-S5 完成：application.yml 19 键逐值等价翻译（全值单引号保护，fallback ${SPRING_BUC_*:${BUC_*:<default>}} 逐字保留）；application.properties、XuanjiBucEnvironmentValidator、validateRequiredConfiguration 三处删除，spring.factories FQCN 修正，pom 的 spring.profiles.active 计数归零（prod 为空标记）；ConfigSurfaceContractTest CS-01…CS-11 11/11 绿，env-contract 5 行于首次配置改动前落盘；13 条红先演练全 rc=1 且点名（CS-08 移除 @NotBlank 后应用真实启动→断言红；CS-10 注入 ORPHAN_DRILL_VAR→反向断言点名）；定向集 321/321，上下文冒烟 10/10；baseline 428→439（added=11 missing=0）、test-assets 78→79；golden 三文件与 deploy/** diff 空；门 decision=pass errors=0。

## Optimization Points
- 1) YAML 等价翻译应对所有值单引号化，防止 SnakeYAML 把 OFF/ON 解析为布尔导致逐值比对漂移。
- 2) 缺失必填项的启动失败断言应以命令行参数（最高优先级）清空必填项并显式关闭 enabled/dpop/sts 端口，使『移除校验后应用能真实启动』可复现，否则红先演练无意义。
- 3) env-contract 重抽取应在测试内执行 CS-08 的 bash 原命令，而非用 Java 重写正则，保证『命令原文』口径。
