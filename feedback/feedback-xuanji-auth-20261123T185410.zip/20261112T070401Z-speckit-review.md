---
id: "20261112T070401Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "r20261112T070156Z-7a1c"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-12T07:04:01Z"
summary: "goal-aligned MCP+CLI fresh review: CHANGES-REQUESTED (P1=8, P2=10); 002 suite 78/78 green alongside 8 DPOP tests; Acceptance Reality Check exits 2 on the SC **Path** schema (AS-01) and produces no fin"
---

## Review
goal-aligned MCP+CLI fresh review: CHANGES-REQUESTED (P1=8, P2=10); 002 suite 78/78 green alongside 8 DPOP tests; Acceptance Reality Check exits 2 on the SC **Path** schema (AS-01) and produces no final_path record.

## Optimization Points
- Post-merge review base resolution: git-delta-review.sh base --spec resolves the feature branch first commit (3759b71) and yields a 1275-file delta spanning .specify/ and unrelated features; a merged-feature goal review needs an explicit base/head or a recorded implementation range.
- Canonical runner run-tests.sh is pytest-only; a Maven project must fall back to ./mvnw test, leaving the --names-out/comm -13 name-level regression baseline unavailable (prior F8 recurrence).
- Closure schema migration gap: a pre-schema spec (002, 2026-08) lacks **Flow Class**, SC **Path** markers, Runtime Stack rows, ladder fields and smoke record; closure-acceptance-check.py exits 2 (AS-01) and there is no migration/waiver helper that lets the review copy a final_path record.
- Review composition vs stage write allowlist conflict: the composition mandates a separate code-review.md when triage=run, while the stage instruction allows only review.md + evidence + wrap-up records; the code segment had to be embedded in review.md and the deviation disclosed.
- Status carrier conflict: requirements.md claims Implemented while .specify/features.md and the feature detail say Planned; the checker resolves the spec own claim first and no gate reconciles the registry, so the Implemented -> Ready for Review judgement starts from contradictory claims.
- docs/design/index.md still describes XuanjiBucSSOFilter as pass-through after commit 4c45ad6 added a Bearer bypass, and its cookie-priority section lists only the DPoP exception; doc-code drift on the exact surface the review had to adjudicate.
