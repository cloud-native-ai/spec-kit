---
id: "20261117T194149Z-speckit-clarify"
unit_id: "/speckit.clarify"
unit_type: "command"
run_id: "20261117T194000Z-clr016-r3"
scope: "local"
probe: "speckit-clarify-wrapup"
kind: "internal"
slice: "commands"
feature: "007-java-project-standardization"
feature_id: "016"
partial: false
created: "2026-11-17T19:41:49Z"
summary: "clarify 第三轮（analyze 阻断项清偿，只改制品）：清偿 analyze 四单元 62 findings 中的 1 CRITICAL（T031 补 blockedBy T025–T030，堵住 S2 出口空转）、9 HIGH（布局允许集拆 tracked-must-exist/ambient-tolerated；FR-035 .yml 分层限定 src/main/resources；B"
---

## Review
clarify 第三轮（analyze 阻断项清偿，只改制品）：清偿 analyze 四单元 62 findings 中的 1 CRITICAL（T031 补 blockedBy T025–T030，堵住 S2 出口空转）、9 HIGH（布局允许集拆 tracked-must-exist/ambient-tolerated；FR-035 .yml 分层限定 src/main/resources；BL-07/BL-08 集合差方向纠正并双向演练；CS-10 补 4 个 fallback 裸名；S9/SC-010 证据改临时目录；空车道守卫统一名称集合差；baseline-pre 逐制品采集/freeze 命令；blocked 唯一 owner 限定入口级 status 行）与门禁类 MEDIUM（T009←T008、六个阶段出口 blockedBy、PKG-S0 串行边、STR 13、coverage-baseline/red-first 处置、checklist 13 STR、CHK 单布尔拆分登记、TM-04 ⊇ + executed_by、.pytest_cache 双口径 + rm -rf、deploy/nginx 独立目录 + CS-11 S4 出口必跑）及文本类 LOW；任务数保持 96（≤160，每包 ≤16）；四门重跑：pre-analyze pass/errors=0/advisories=114、decomposition proceed、validate-tasks PASS 0/0、validate-requirements ok 0/0；未改生产代码、未删移文件、未执行 pytest、未 push、未写状态脊。

## Optimization Points
- 1) 出口任务必须显式 blockedBy 全部上游（出口空转是 analyze 最易漏的 CRITICAL）。2) 集合差类契约必须写清算子方向并用双向演练钉死（删除 rc=1、新增 rc=0）。3) 允许集类断言要区分 tracked-must-exist 与 ambient-tolerated，避免 .git/.vscode 造成不可满足判据。4) 同一语义（空车道守卫、blocked owner、integration 清单）只保留一种权威口径并让 requirements/plan/research/contracts/tasks 同源引用。
