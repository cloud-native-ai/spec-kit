---
id: "20261116T093247Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "r20261116T092401Z-fa57"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
feature: "006-test-framework"
partial: false
created: "2026-11-16T09:32:47Z"
summary: "requirements 阶段一次通过：validate-requirements 0 error / 0 warning（id-contiguous、doc-order、ref-resolvable、marker-count、dup-id、path-marker 全 pass），scanned 339 lines、38 definition rows（FR 28 + SC 10）、8 share"
---

## Review
requirements 阶段一次通过：validate-requirements 0 error / 0 warning（id-contiguous、doc-order、ref-resolvable、marker-count、dup-id、path-marker 全 pass），scanned 339 lines、38 definition rows（FR 28 + SC 10）、8 shared strings；flow-class-check lookup 解析 spec:006-test-framework = execution（source=declaration，flow_type=-）。产出 requirements.md、checklists/requirements.md、feature-ref.md、test-evidence/baseline-2026-11-16.md，并把 Feature 006 台账与详情从 Draft 推进到 Planned。

## Optimization Points
- 1) 现状核验直接暴露默认并行形态缺陷：契约套件 xdist 并行 209 passed / 2 errors，串行 211 passed；根因是 test_compose_manifest.py 的 env_guard 在仓库内创建/删除 deploy/compose/.env.sidecar 引发跨 worker 竞态，requirements 已据此写成 FR-010/FR-011/FR-026 与 A-07。2) 项目侧无 pytest 配置（无 pytest.ini/pyproject.toml），run-tests.sh 缺省注入的 -m 'not slow' 与 serial 枚举依赖未注册标记，已写成 FR-012 并以既有 runner 为框架投影镜像、不予手改。3) run-tests.sh 是 pytest-only 镜像且明确禁止手改，与调用方『测试执行唯一入口』存在张力；已按车道收敛为 Python=run-tests.sh、Java=./mvnw test，并由 FR-016 的完整验证程序编排两车道（A-03），建议驱动侧在后续阶段沿用该口径。4) --names-out 只采集 FAILED 行，ERROR/收集错误在清单中不可见；已写 FR-019/SC-002 要求『退出码非 0 且清单为空』判为错误。5) 驱动简报称契约测试 12 个模块，实测 11 个 test_*.py + conftest，已在 A-02 记录修正。6) create-new-requirements.sh 仍会 checkout -b 006-test-framework 并需手工改名为 feature/006-test-framework（与宪法分支命名一致）；本阶段提交 a281071 停留在 feature 分支，未合并 main（权限策略拒绝 ff-merge，且调用方未授权共享分支推进）。
