---
id: "20261118T045201Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "20261118T045148Z-impl016-s8"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "007-java-project-standardization"
partial: false
created: "2026-11-18T04:52:01Z"
summary: "PKG-S8 终验完成：17 条 SC 全部有结论（17 pass / 0 blocked / 0 void，逐条带命令+as-of+证据路径）；baseline-pre 四项 diff 判定（surefire missing=0 added=378 全归属本特性，env-names 与 env-contract 逐行相等，jar 差异 3 行=properties→yml+FR-038 预声明 "
---

## Review
PKG-S8 终验完成：17 条 SC 全部有结论（17 pass / 0 blocked / 0 void，逐条带命令+as-of+证据路径）；baseline-pre 四项 diff 判定（surefire missing=0 added=378 全归属本特性，env-names 与 env-contract 逐行相等，jar 差异 3 行=properties→yml+FR-038 预声明 validator 删除并登记 B-1，runtime-shape 空）；黄金 diff=0 且 AM 提交唯一（S0 2f66cd7），三组断言并集对 FR-041/043/044 gap=0；package 产 xuanji-buc-1.0.0.jar、FROM/JAVA_TOOL_OPTIONS/依赖树不变；全量告警 0；两次连续全量 586/0/0/0（26.0/26.3s）失败集合空且相同、前后 git status 一致；framework/.github diff 0；quickstart S1/S2/S3/S7/S8/S9 实跑（S9 仓库内受控删除被写边界拦截，以夹具演练+历史真实演练取证并如实登记）；integration 两入口 blocked（rc=0、未执行、无 pass 伪造）；T082 五处台账追加且 006/014/013/015 状态未翻转；门 decision=pass errors=0。

## Optimization Points
- 1) 终验包的写边界与 quickstart S9 的破坏性演练天然冲突：任务应在验收前声明「仓库内受控删除演练只允许在实现包执行」，终验包以夹具契约测试+历史演练读数替代，避免现场裁决。
- 2) 制品比对口径要提前写明「计划内删除」通道：FR-049(b) 只列载体替换与新增类，未列 FR-038 强制删除，终验只能靠 FR-046 兜底登记；下一版应把已声明的删除面直接并入比对谓词。
- 3) tasks.md 勾选收口属编排层记账（GATE-7 依赖它），执行包写域不含 tasks.md 时终验只能披露而不能满足；应把 checkbox 收口作为实现收尾包的具名交付物。,
