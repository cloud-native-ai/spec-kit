---
id: "20261118T031316Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "20261118t031229z-impl016-s3"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "007-java-project-standardization"
partial: false
created: "2026-11-18T03:13:16Z"
summary: "PKG-S3 文档与口径切换完成：docs/testing.md 重写为 Java 单轨唯一载体（唯一入口 ./mvnw -B test、聚合 bin/verify-all.sh、0/1/2 退出码、四层 oracle、清单 77=63/10/4、基线 419 名源码扫描词边界、blocked 8 值原因码、覆盖率与串并行规则、新增测试三步）；docs/design/index.md 11 行旧路"
---

## Review
PKG-S3 文档与口径切换完成：docs/testing.md 重写为 Java 单轨唯一载体（唯一入口 ./mvnw -B test、聚合 bin/verify-all.sh、0/1/2 退出码、四层 oracle、清单 77=63/10/4、基线 419 名源码扫描词边界、blocked 8 值原因码、覆盖率与串并行规则、新增测试三步）；docs/design/index.md 11 行旧路径改 deploy/nginx、§2.5 裁决改「已纠正」并保留字符类复算命令；deploy/README.md 旧入口归零；技能文档 3 处路径同步且 sync-mirrors 相对基线无新增；T036 三文件复核（architecture.md 一处陈旧测试口径同步）；定向集 301/301 绿，golden/生产代码/Python 面/migration-map 四处 diff 全 0；LO-06 余 2 行（T040+S4 面）、run-tests 白名单外仅 S4 删除面、docs 两文件归零；门 pass。

## Optimization Points
- 1) LO-07 字面「0 行」与 S1/S2 逐字载体（migration-map 211 行 + disposition 70 行 + 契约测试注释 17 行）存在规格张力：MM-05/FR-032 要求 source_id 逐字保留且铁律冻结，S4 的 LayoutContractTest 需采用与 s3-exit Finding 1 同源的分类排除；2) docs/design as-of 已就地刷新为 2026-11-18，deploy/nginx 目录本体现由 S4 迁移，复算命令在迁移后逐字成立；3) 文本包无可红断言，机检落点 S4 T048/T096，已如实记录为「无断言可红」并附改前改后读数。
