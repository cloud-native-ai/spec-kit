---
id: "20261015T132213Z-speckit-sanitize"
unit_id: "/speckit.sanitize"
unit_type: "command"
run_id: "sanitize-20261015T132034Z"
scope: "local"
probe: "speckit-sanitize-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-15T13:22:13Z"
summary: "全量扫描运行：引擎判定 79 条确定性发现（66 dead-reference + 13 index-inconsistency，0 语义候选）；经地面真值核实后 53 条为误报、23 条为历史工件属实项、3 条活体材料属实项；经用户单批次确认执行 constitution 指针修正与 feedback 旧索引退役，台账 3 条自动收敛、其余按计划保持 pending。运行判定 qualified"
---

## Review
全量扫描运行：引擎判定 79 条确定性发现（66 dead-reference + 13 index-inconsistency，0 语义候选）；经地面真值核实后 53 条为误报、23 条为历史工件属实项、3 条活体材料属实项；经用户单批次确认执行 constitution 指针修正与 feedback 旧索引退役，台账 3 条自动收敛、其余按计划保持 pending。运行判定 qualified/complex。

## Optimization Points
- # Optimization Points — /speckit.sanitize run sanitize-20261015T132034Z
- sanitize 引擎确定性检测信噪比不足：本轮 79 条发现中 53 条为误报（67%）。三类根因：(1) `speckit.*` 斜杠命令引用未解析 `.qoder/commands/` 命令注册表（21 条）；(2) spec 任务清单中 `src/java/.../` 包省略写法未解析，目标文件实际全部存在（20 条）；(3) features.md 裸方括号 `[path]` 索引链接未按工作区根解析，12 个明细文件实际全部存在（12 条）。误报长期滞留台账并随每次 collect 重现，建议引擎为上述三类增加解析规则或申报类白名单。
- 破坏性桶经 owning-tool 通道执行（引擎 finding 自带修复命令，如 feedback reindex）时，cleanup-plan 缺少一等 item 类型承载"非 apply 机械执行"的审计语义，本次以自由 JSON 承载，建议引擎补充该 schema。
