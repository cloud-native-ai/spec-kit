---
id: "20261117T184128Z-speckit-checklist"
unit_id: "/speckit.checklist"
unit_type: "command"
run_id: "r20261117T172128Z-9205"
scope: "local"
probe: "speckit-checklist-wrapup"
kind: "internal"
slice: "commands"
feature: "007-java-project-standardization"
feature_id: "016"
partial: false
created: "2026-11-17T18:41:28Z"
summary: "checklist 阶段完成：生成 checklists/quality-gates.md（40 条，CHK001–CHK040，soft cap 40；40/40 可追溯；覆盖先迁后删、211 零丢失、黄金冻结、基线精度、006 能力等价、集成可达、布局闭环、配置面、行为不变、豁免诚实、追溯漂移、单一入口 12 个高风险质量面）。按 objective-analysis-gate 委派 2 个 "
---

## Review
checklist 阶段完成：生成 checklists/quality-gates.md（40 条，CHK001–CHK040，soft cap 40；40/40 可追溯；覆盖先迁后删、211 零丢失、黄金冻结、基线精度、006 能力等价、集成可达、布局闭环、配置面、行为不变、豁免诚实、追溯漂移、单一入口 12 个高风险质量面）。按 objective-analysis-gate 委派 2 个 fresh-context 只读检测器（FR-001…034 / FR-035…049 不相交范围），20 个 distinct findings：12 个提升为计分条目、8 个保留为 Residual Observations、0 个判伪；复核另发现覆盖增量 +89 应为 +106（删类带走 17 覆盖行）、SC-016 字面 f7ecb97 基准不可满足、conifg bare 16 与 slash 14 两种口径、T044 未依赖 T042 的 move-before-delete 边、62 项工具自测逐项理由无载体等硬缺口。门禁：pre-analyze-check --stage tasks = pass（errors=0 / advisories=96 / files=15，fr=49 sc=17 tasks=93 clauses=59），flow-class = execution。本阶段未写实现代码、未删除或移动任何文件、未执行 pytest。

## Optimization Points
- S1/S4 出口谓词不一致：MM-08 允许 014 名下的 dropped 行（migrated ≥199），而 T023 与 plan 的 S1 出口要求 migrated=211；analyze 前统一为一个谓词（要么 S1 明禁 dropped 并收紧 FR-033/MM-08，要么 T023 接受带三要素的 dropped）。
- 覆盖增量算术需按 post-deletion 口径更正：删除 XuanjiBucEnvironmentValidator（17 covered / 49 lines）后分子 1310、分母 1770，达 80% 需 +106 行；plan/tasks 的 +89 与 requirements A-21 的 +129 应分别标注 pre/post 口径。
- SC-016 的黄金文件 diff 基准应写入 requirements：字面 f7ecb97 对 S0 才创建的黄金文件永远不可满足，必须采用 S0 冻结提交 SHA（或定义变量），不能只在 plan 的兼容执行段落地。
- conifg 复算模式统一：bare `conifg` 活动面 16 行、`conifg/` 14 行；SC-012、LO-06、T002、T050 必须复用同一模式，并处置解释性裸提及。
- run-tests.sh 残留白名单需逐类枚举：`.claude/`、`.github/`、`.opencode/`、`.qoder/` 的 8 个 agent 投影文件与 `.specify/templates|shared` 等框架文件，否则零命中断言在不动 FR-048 禁改文件的前提下不可满足。
- integration blocked 的归属需唯一：明确是预检跳过入口还是入口脚本自记 blocked，并给 run-it.sh / verify-deployment.sh 补 blocked 模式与退出码要求，使 T079 的 `--with-integration` rc=0 与 VA-04/VA-12 一致。
- `notes/` 路径需锚定到允许根（如 `.specify/specs/007-java-project-standardization/notes/`），否则仓库根 `notes/` 会成为 FR-009 封闭顶层集合之外的受控目录并击穿 T050/SC-001。
- FR-027 的 blocked 原因码封闭集需增加 shellcheck 缺席码（或明确 T015 不记 blocked），避免产生集合外原因码。
- 62 项 006 工具自测的「逐项理由」载体需明确：migration-map.json 固定 211 行且模块枚举排除四模块；需另设逐项处置载体，或把 FR-032 明确为模块级。
- TM-09 的支撑类后缀规则与 T009 的 `TestSourceScanner` 冲突：补例外（命名或祖父条款）或改名。
- plan 的 FR 追溯表需修正悬空 section 引用：FR-019/FR-042/FR-048 指向不存在的「§ 非目标」，且 SC-003 不表达 no-failsafe/vintage/TestNG 义务。
- FR-001 的「唯一 Python 文件保留项」需补 `*.py` 枚举 oracle；当前 SC-002/T050 只查 `test_*.py`，残留非测试 `.py` 不会变红。
