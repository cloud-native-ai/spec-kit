---
id: "20261112T074033Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "r20261112T074023Z-review2"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-12T07:40:33Z"
summary: "focused round-2 P1 disposition verification: APPROVED (P0=0, P1=0 residual); 95/95 Maven + 211 contract green; closure rerun with Feature 012 carrier verdict=accept (pass=3/3); runtime MCP/ACL items remain honestly blocked; 12 residual P2 registered."
---

## Review
Focused round-2 review of the `0f16a21` + `68d19aa` fix set: all 8 Round-1 P1 items verified against code/tests/rendered artifacts rather than the fixer's self-report. Independent reruns: `./mvnw test` 95/95, `pytest tests/contract` 211 passed, `closure-acceptance-check.py` with `--feature-detail` = Feature 012 → verdict=accept, final_path pass=3/3. Verdict: APPROVED; Feature 012 may proceed to closure as Implemented (SC-001 deferred=supporting).

## Optimization Points
- Closure checker numbering collision is latent, not fixed: `_registry_status()` still accepts the numeric prefix, so any caller omitting `--feature-detail` silently reads Feature 002. The explicit carrier works and its precedence is correct (`closure-acceptance-check.py:557-559`), but the payload does not echo the registry line actually read — a mechanical `read_line`/`read_id` field would make "which row did it read" auditable in one glance.
- Fix-report claims need anchor-level verification: Round-1 P2 #5 was marked "fixed" while only `feature-ref.md` was corrected; the feature detail still points at `.specify/memory/features*` (lines 47-48). A disposition ledger that requires `path:line` anchors per claimed fix would have caught the partial fix during the fix round, not the next review.
- Red/green evidence provenance: the red run was captured against an uncommitted test version whose cookie-only assertion was later corrected (X-Acs-Userid expectation vs the SDK test-cookie mapping). The product-level red (cookie+Bearer → token snapshot identity) is genuine, but the red tree cannot be reproduced from git. Recommend capturing red states as a temporary commit or recorded stash ref so "first red" is replayable.
- Full-chain scope drift: R8#7 asked for "SSO filter + DPOP filter + controller"; the delivered `CheckBucInfoFullChainTest` covers the SSO half with `xuanji.dpop.enabled=false` and standalone MVC. The regression class that actually occurred (SSO bypass) is covered, but the mixed-filter interaction has no automated guard. A minimum chain-composition definition per integration-test task (which filters, which order, which are allowed to be disabled) would prevent silent under-delivery.
- Runtime-blocked items worked as designed: `verification.md` blocked acceptance rows (T032, deploy runtime assertions) with reduced-measurement fields made it possible to approve without conflating render-contract evidence with runtime evidence. Preserve this pattern.
- Canonical runner recurrence: `.specify/scripts/bash/run-tests.sh` remains pytest-only for a Maven project; each stage still falls back to `./mvnw test`. Runner-agnostic baseline capture remains an open framework gap (Round-1 F8/R1-P5).
- Documentation premise drift inside the fix: `XuanjiBucSSOFilter` javadoc still asserts EXCLUSIONS matching "is not effective for the bearer-only endpoints", while the new measured SPI contract records exclusion hits executing the inheritor wrapper. Behavior is test-locked; the two prose claims should be reconciled in one place.
