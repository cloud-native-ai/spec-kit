---
id: "20261117T191423Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "20261117T191000Z-ana016-w3"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
feature: "007-java-project-standardization"
partial: false
created: "2026-11-17T19:14:23Z"
summary: "W3 只读契约侧分析：实测复核覆盖数学（1327/1819，删 validator 后 1310/1770，80% 需 1416，+106）、@Test 精确 208 vs 前缀 209（StsLoopbackConnectorIntegrationTest:69 @TestConfiguration）、conifg 16 行（design 11/skills 3/java 1/tests-sts"
---

## Review
W3 只读契约侧分析：实测复核覆盖数学（1327/1819，删 validator 后 1310/1770，80% 需 1416，+106）、@Test 精确 208 vs 前缀 209（StsLoopbackConnectorIntegrationTest:69 @TestConfiguration）、conifg 16 行（design 11/skills 3/java 1/tests-sts 1，conifg/ 子集 14）、Python 面 19 文件（tests 16+scripts 2+deploy 1）、run-tests.sh 白名单外 8 文件 16 行、env 抽取 5 变量、@Value=0、三配置类已就位。发现契约缺陷：BL-07/BL-08 集合差算子与语义相反；CS-10 别名集缺 4 个裸 BUC_* 名。

## Optimization Points
- 1) 修正 baseline.contract BL-07/BL-08 的集合差方向（missing=基线−扫描，rc=1；added=扫描−基线，rc=0）；2) CS-10 别名集补 BUC_CLI_AUTH_TOKEN_TTL/BUC_CLI_AUTH_CONSENT_TTL/BUC_ACL_CREDENTIAL/BUC_ACL_TIMEOUT，或限定只校验最外层占位符；3) run-it.sh 迁移时补 chmod +x（当前 100644）；4) 明确 .pytest_cache 的观察面（git ls-files）并加入删除步骤；5) VA-06 入口存在性与 S2–S3 分阶段顺序需钉死。
