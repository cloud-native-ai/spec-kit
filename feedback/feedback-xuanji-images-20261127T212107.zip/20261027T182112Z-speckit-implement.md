---
id: "20261027T182112Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261027T092533Z-abcc-implement-p3"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "046-image-factory-build-optimizations"
feature_id: "046"
partial: true
created: "2026-10-27T18:21:12Z"
summary: "T012 only (Phase 3, last task): write-site artifact recording in generate/docker.py and generate/supervisor.py plus scan/docker.py for docker-build.json, wired through generate_build_scripts and _run_"
---

## Review
**Partial run** — T012 only (Phase 3, last task): write-site artifact recording in generate/docker.py and generate/supervisor.py plus scan/docker.py for docker-build.json, wired through generate_build_scripts and _run_supervisor_stage. Red-first: 4 new recorder tests failed with TypeError before the API existed; green: 15 passed across the three touched test files, 51 passed in neighboring suites; real docker-build generation exited 0 with planned=written=24407 and --check exited 0. Full Layer-1 baseline comparison remains T032.

## Optimization Points
- The post-generation planned fallback still records compose/image-list kinds; migrating those write sites would turn planned-vs-written into a true write-time check.
- The script-name to artifact-kind mapping lives in generate/docker.py while the closed enum lives in artifact_manifest.py; a single owned table would prevent drift.
- docker-build.json is recorded in scan/docker.py because that is its only write site, so the per-leaf set spans scan and generate; documenting that ownership split would help readers.
- In this worktree cws_py_cmd resolved the main checkout's cmdline module; worktree-aware command resolution would remove the need to call docker_build.main directly for validation.
- The compose mode test needs ten patches; a shared compose-generation fixture would cut that coupling.
