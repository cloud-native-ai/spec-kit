---
id: "20261016T034436Z-speckit-clarify"
unit_id: "/speckit.clarify"
unit_type: "command"
run_id: "032-prebuild-conversion-artifacts-clarify-amendment-20261016"
scope: "local"
probe: "speckit-clarify-wrapup"
kind: "internal"
slice: "commands"
feature: "032-prebuild-conversion-artifacts"
feature_id: "030"
partial: false
created: "2026-10-16T03:44:36Z"
summary: "修订跑（amendment），Mode A 显式目标覆盖：目录内存在 plan.md 使文件存在性探测报 Mode B，但该文件是停环 plan 阶段留下的**未填充模板脚手架**（27 个占位符），阶段指令又点名 requirements.md，故按技能的 mode-override 分支澄清 requirements.md，且无需向 plan.md 级联（其中无可级联内容）。本次是本规格**首"
---

## Review
修订跑（amendment），Mode A 显式目标覆盖：目录内存在 plan.md 使文件存在性探测报 Mode B，但该文件是停环 plan 阶段留下的**未填充模板脚手架**（27 个占位符），阶段指令又点名 requirements.md，故按技能的 mode-override 分支澄清 requirements.md，且无需向 plan.md 级联（其中无可级联内容）。本次是本规格**首个携带用户权威**的会话：plan 阶段发现 FR-004/FR-010/FR-029/SC-010 互不可满足并停环上送，用户裁决以「扩展 glibdeps 预取五资产」解之。落地为 FR-010 就地修订（**零网络从句逐字未改**，只替换被 D11 证伪的机制短语）、新增 FR-030/FR-031/FR-032、FR-029 与 SC-010 的既有模板编辑授权 0→3 并逐一具名、新增 SC-012/SC-013 及 Source 行、新增 D11、STR-049..051、US1 scenario 7、2 条新 Edge Case 加 1 条就地拓宽、Assumption 18；同步刷新 checklist 派生计数并更正 registry 中被证伪的「FR-029 授权 0 处编辑」现势陈述（features.md 030 行、features/030.md 两处）。未重编号任何既有 FR/SC，故无 旧→新 映射义务。制品正确性由 validate-requirements.py 兜住：首轮 5 findings（doc-order 1 + ref-resolvable 4）全部为真缺陷，修复后 status ok / 0 errors / 0 warnings，749 行 / 45 定义行 / 51 STR。运行判定四轴中三轴 not_evaluated（token 与 elapsed 无源，artifact_correctness 因无名字级基线不可评），**不报为良好也不报为零**；同趟结算上一轮 032 clarify 的满意度轴为 **rejected**——这是诚实测量而非苛评：该轮曾宣告「Planning inherits decisions, not options」并把 FR-029 收紧到 0，plan 随即证明其认证过的规格不可满足，且它自己写下过 "Clarify has no new host to measure from" 却未察觉核对 glibdeps 只需读本仓一个文件。trigger_feedback=false，故按 step 6 的合成规则（两个布尔须同时为真）本次不弹阈值通知。仅提交本特性产物；plan.md 属 /speckit.plan 的未提交产物，按 artifact-commit-step 规则**未纳入**本次提交并在此报告为上游遗留。未 push。

## Optimization Points
- **改点 1（unit-specific，最高价值）：Mode A 分类法缺一个「被引用机制是否真实存在」类目。** 本次修订跑之所以存在，是因为上一轮 `/speckit.clarify` 把一份 FR-010 声明「从 [[STR-013]] 预取的离线包缓存解析五件依赖」的规格判为可交给 plan，而该 fetcher 实际只预取三个文件、五件一件不在其中——plan 阶段一读 pin 源的**阶段体**就撞上四条出路各违一条 MUST 的死结并停环。根因不在上一轮的判断力，而在**扫描类目没有强制这一问**：Mode A 的 `Domain & Data Model` 与 `Integration & External Dependencies` 都最接近，但没有任何一条要求「当 FR 说某输入 *from X* 时，去核对 X 里真的有它」。上一轮的会话记录甚至写下了 "Clarify has no new host to measure from" 而仍然判绿——这是**类目缺失**，不是宿主缺失，因为核对 `images/fetcher/language/wasm/glibdeps/Dockerfile.tpl` 只需读本仓一个文件，不需要任何新宿主。建议在 `.specify/shared/constants/clarify-taxonomy.md` 的 Mode A 增一条独立类目（拟名 *Cited-Mechanism Existence*）：凡 FR/SC 以「由 X 提供 / 从 X 解析 / X 已预置」形态引用一个既有产物作为满足手段，扫描 MUST 打开 X 核对其内容确实覆盖被引用的对象，否则该项记 Missing 而非 Clear。判据可复现：两位评审对同一份规格须得出同一结论。
- **改点 2（unit-specific，机械陷阱）：追加式修订跑有两个 validator 才抓得到的落笔陷阱，本次各中一次。** (a) 新增 SC 行被写在**被编辑行的紧邻下方**（SC-010 之后），结果排到 SC-011 上方——`id-contiguous` 全程绿，只有 `doc-order` 变红；这正是该 anchor 存在的理由，但写的人不会想到「在 X 行后面追加」和「追加到系列末尾」是两件事。(b) 五枚 pin 以 en-dash **区间**形态引用（`[[STR-008]]–[[STR-012]]`），而反向一致性检查无法展开区间，于是 STR-009/010/011 的 `Consumed by` 指向了一个「看似没有引用它们」的行。建议在 clarify-artifact 的 Mode A 整合规则里把「追加到系列末尾，不追加到编辑点之后」和「被 `Consumed by` 指名的行必须逐枚引用，区间只可用于散文」写成两条落笔前约束——两者本次都靠引擎兜住，但引擎是最后一道，不是唯一一道。
- **改点 3 `token-efficiency`：确定性工作被 LLM 代做了一次，且做错了。** 残留陈旧计数扫描（Mode A 的 Derived-count revisit 要求「逐条断言被取代字面量零命中」）第一次由我手写 shell 循环实现，`hits=$(grep -c ... || echo 0)` 的退出码处理有缺陷，把 12 个零命中项全部误报为 STALE，噪音淹没了其中 2 个真命中，只能重跑一遍。计数与「字面量是否零命中」是纯固定规则判断，按 `.specify/shared/guidelines/token-efficiency.md` 的 Program-First 应交给程序；这里的问题不是「该不该写脚本」而是「一次性脚本也要先自证」——建议此类断言直接用 `grep -F -c` 的退出码配合 `set -e` 之外的显式分支，或由 `validate-requirements.py` 一类既有引擎承接。
- **改点 4 `token-efficiency`：单行超大字段被整体拉进上下文两次。** `.specify/memory/features.md` 的 030 行 `Last Updated` 单元格是一条数万字符的单行；本次先用 `grep -o` 定位陈旧片段、又在收尾核验时把整行回显了一次，等于同一份巨型字段原文转储两遍。第二次核验只需 `grep -c` 的计数或 `grep -o` 的窄投影即可判定，属可避免消耗。教训可推广：对**单行超大字段**（累积式 registry 单元格、生成的索引行）一律用窄投影核验，不用整行回显。
- **改点 5（正向，供保留）：把裁决落进「该 fetcher 自己的既有裁决」而不是省事，是本次唯一让扩展-vs-同级这一开放选项真正关闭的做法。** 用户裁决允许「glibdeps fetcher（或同级 fetcher）」两种落点，若按偏好选一种，plan 阶段会再开一次。本次改为去读 `docs/reference/images/images-project-oss-container2wasm-container2wasm.md` § "One fetcher, not two" 已记录的打包判据与拆分条件，逐条比对五资产全中、拆分条件未触发，并顺带发现同文 § "Build verification status" 已记录该 fetcher 三件资产**今天正处于** mirror-gap 待 `mirror_file` 补齐状态——即裁决里的「兜底通道」不是新设应急，而是该 fetcher 既有的运维现实。建议把「用户给出多选裁决时，先在仓内找该主题**已记录的裁决**作为判据来源」写进 clarify 的整合规则：它把「选择」降级为「比对」，是可复现的，且顺带产出本次 FR-030(e) 那样的下游一致性义务（引用某文档作为依据，就不得让它的内容被同一次改动证伪）。
