---
id: "20261031T193821Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261030T120500Z-b101-impl-s3f"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "051-xuanji-doc-build-chain"
feature_id: "048"
partial: false
created: "2026-10-31T19:38:21Z"
summary: "Spec 051 segment 3f fixed the /docs/ 404 at its C-side owner and re-verified T023/T024. The supervisor hugo.sh now starts with --baseURL http://127.0.0.1:${HUGO_PORT}/docs/ instead of the host-less /d"
---

## Review
Spec 051 segment 3f fixed the /docs/ 404 at its C-side owner and re-verified T023/T024. The supervisor hugo.sh now starts with --baseURL http://127.0.0.1:${HUGO_PORT}/docs/ instead of the host-less /docs/ that hugo server 0.148.2 cannot route; nginx was not touched. The L1 guard was updated to the equal-strength absolute literal plus a negative assertion against the host-less form. Generation --check exit 0; the xuanji_doc guard selection is 44 passed; the full suite failure set is identical to the full-suite-fix5 baseline (24 failed / 1625 passed, no regression). The shared payload, service leaf and project leaf were rebuilt so both runtime images carry the fix: shared sha256:c44fc0fb1335 (session 1793474501542789631), service sha256:c766f81b1743 (session 1793474514379877168), project sha256:566027bd4647 (session 1793475081638111233); the project source pin remains e6d88761 with lightrag 30e08fd2. Both containers reach 8/8 RUNNING. On both leaves the full T023 matrix is green: anon /, /docs/, /cgit/ = 401; cws /, /docs/, /cgit/ = 200; /docs without slash = 301; /docs/ returns a 26,793-byte Hugo 0.148.2 site page titled 璇玑智能运维平台; four health endpoints are 200/200 anon and Bearer with no business body; GET /api/v1/documents/query is 401 anon and 200 with Bearer q=probe; /mcp/v1/ handshake is 401/200; /api/kb/query is 404; ExposedPorts and docker-build.json are 80/443/10022. T024 re-verification on both leaves: 1313/28080/8854/9621/8900/44145 CLOSED, 80/443/10022 OPEN, no leaf EXPOSE or internal CWS_MICRO_PORT. The service leaf T022 runtime is clean (tools absent, source tree absent, entries/assets present). Disclosed drift: contracts/supervisor-roster.md C-24 still records the literal --baseURL /docs/; the contract was not edited in this segment per PLAN-EDIT: none. The project leaf was rebuilt beyond the literal service-only wording because the shared supervisor copy is baked into both leaves and T023 asks for both images. Evidence: notes/T023-{project,service}-s3f.log, T022-runtime-s3f.log, T024-s3f.log, T017-runtime-s3f.log, T017-project-build-s3f.log, T022-{shared-service,service}-build-s3f.log, green-T023-guard-s3f.log, notes/quickstart-run.md § Segment 3f.

## Optimization Points
- Keep the C-owned hugo parameters and the routing contract synchronized: C-24 still carries the host-less literal while the code now requires the absolute form; reconcile it in a later analyze rather than leaving a stale contract. When a shared config is baked into both leaves, a fix requires rebuilding both; the segment plan should say both leaves instead of service-only to avoid a stale build image. The guard duplicates the startup literal that the script owns; derive both from one owner or keep the equal-strength negative assertion so a host-less regression cannot pass. Reuse the same docs/cgit fixture commands across segments so matrices stay comparable. token-efficiency: the project rebuild was about three minutes and was required for both-image parity; no unnecessary prerequisite rebuilds were performed.
