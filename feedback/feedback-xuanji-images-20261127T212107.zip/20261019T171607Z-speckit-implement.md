---
id: "20261019T171607Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "20261020T012500Z-038-guest-agent-runtime-implement"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "038-guest-agent-runtime"
feature_id: "032"
partial: false
created: "2026-10-19T17:16:07Z"
summary: "038 implement run (2026-10-20): delivered the four-weave Debian guest leaf (guest -> nodejs -> dsh -> hermes), the hermes auto|uv|system selector with uv private venv and /usr/local/bin/hermes bridge,"
---

## Review
038 implement run (2026-10-20): delivered the four-weave Debian guest leaf (guest -> nodejs -> dsh -> hermes), the hermes auto|uv|system selector with uv private venv and /usr/local/bin/hermes bridge, three Layer-1 guards, the leaf publish contract, and Feature 032 evidence. L1: guards 25/25 green, full suite 0 new failing names. L2: build rc=0, 3 layers, 2,732,421,378 bytes, dsh 0.2.1-rc.2, hermes v0.19.0. T2/T3 recorded deferred with classification and unlock.

Friction worth noting:
1. The generated Dockerfile embeds cws.images.revision (commit + -dirty), so the literal pre-change Alpine sha256 gate is unsatisfiable across commits; used a controlled HEAD-vs-feature A/B and annotated GATE-2/DoD-3 as a falsified premise.
2. The direct `cws_py_cmd cmdline-generate-docker-build` entry fails without `cws_images_resolve_tag` in the same shell; the plan mentions it, but the first run still hit it. Consider making the entry self-resolve or failing with the documented hint at the CLI boundary.
3. The new guard's synthetic reverse-sentinel fixture needed three iterations (elif matching, missing hard-fail lines, auto-order scoping). The red-first evidence records only the final, correctly attributed red run.
4. Build log is large and was processed with grep/python rather than pasted into context.

## Optimization Points
- Generated Dockerfile embeds cws.images.revision (commit + -dirty), making literal pre-change generated-file hash gates unsatisfiable across commits; prefer semantic-key or controlled A/B drift checks in future specs.
- The direct cws_py_cmd cmdline-generate-docker-build entry requires cws_images_resolve_tag in the same shell; consider a boundary-level self-resolve or a clearer hint.
- Guard reverse-sentinel fixtures can self-fail before the subject is red; budget an explicit assertion-layer dry run before capturing red-first evidence.
- The hermes uv CPython download channel is slow on this host; record the channel and avoid re-downloading across experimental rebuilds where possible.
