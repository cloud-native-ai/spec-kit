---
id: "20261029T075127Z-speckit-clarify"
unit_id: "/speckit.clarify"
unit_type: "command"
run_id: "r20261029T071500Z-c3d4"
scope: "local"
probe: "speckit-clarify-wrapup"
kind: "internal"
slice: "commands"
feature: "048-dsh-guest-image"
feature_id: "030"
partial: false
created: "2026-10-29T07:51:27Z"
summary: "Unattended Mode A clarify on 048-dsh-guest-image: bound the spec to Feature 030 after a three-candidate scope/precedent comparison; verified sandbox-side contract facts read-only (loader initPack/inje"
---

## Review
Unattended Mode A clarify on 048-dsh-guest-image: bound the spec to Feature 030 after a three-candidate scope/precedent comparison; verified sandbox-side contract facts read-only (loader initPack/injection, OCI digest-pinning, c2w image-ref input); corrected three inherited defects (A-02 evidence overreach, A-08/FR-020 size derivation, FR-023 edit-surface omission) and re-derived the size bound (tar <= 1.5 GiB, OCI <= 1024 MiB) from the consumer hard envelope plus measured component sizes; validator green 0/0, 29 FR / 7 SC unchanged, no renumbering; artifact committed 836f971c.

## Optimization Points
- token-efficiency: the `.specify/memory/features.md` index rows carry very long cells; a plain `grep -E '^\| [0-9]{3}'` over them emitted 88.5 KB and spilled to a temp file before the needed columns were visible. The framework materials would benefit from a documented projection command (awk over ID/name/status columns) so agents do not dump the whole registry.
- run-determination's `--green-check` must exactly match one of the `--declared-check` identifiers, but the command template only shows `<DECLARED_CHECK>` / `<GREEN_CHECK>` placeholders; a descriptive green-check string was rejected. State the matching contract in the template or in `args-manifest`.
