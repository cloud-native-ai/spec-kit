---
id: "20261027T031059Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "r20261027T025408Z-7499"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-27T03:10:59Z"
summary: "Ran the command end-to-end unattended on spec 045. Blocked twice before the scaffold script would run (CWS_LIB_BASH_HOME not exported by bin/cws_images_env even though it puts cws-lib-bash/bin on PATH"
---

## Review
Ran the command end-to-end unattended on spec 045. Blocked twice before the scaffold script would run (CWS_LIB_BASH_HOME not exported by bin/cws_images_env even though it puts cws-lib-bash/bin on PATH), then found the scaffold always creates a feature branch which this project's git-workflow forbids (main-only), and finally could not make the validator green while keeping the guidelines' allowed <=3 [NEEDS CLARIFICATION] markers because marker-count reports every marker as an error. run-determination then rejected three argument forms in a row (--collected takes int not text, --green-check must be a member of --declared-check, --red-first-refs must be a readable file so 'none' is rejected) before accepting.

## Optimization Points
- 1) create-new-requirements.sh: accept a --no-branch flag (or honour a project setting) so main-only projects do not have to create-then-delete a branch; 2) have bin/cws_images_env (or .specify/scripts/bash/common.sh) export CWS_LIB_BASH_HOME itself, or state the two-hop requirement in the error message; 3) align marker-count with requirements-guidelines.md: either allow up to 3 markers as warnings and error only from the 4th, or state in the guidelines that 0 markers is the hard rule; 4) document run-determination's argument types (--collected int, --green-check subset of --declared-check, --red-first-refs paths) in the command template so an unattended run does not burn retries; 5) make account-clause-coverage.py say explicitly which lifecycle stage it is meaningful at (its baseline-freeze requirement reads as a gate at requirements stage where no downstream citation group exists yet).
