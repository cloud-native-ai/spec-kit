---
id: "20261019T030316Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "036-distro-support-tiers-20261019T030230Z"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
feature: "036-distro-support-tiers"
feature_id: "036"
partial: false
created: "2026-10-19T03:03:16Z"
summary: "Requirements run completed: single-source four-tier distro roster, consumer remediation, Alpine 3 on-demand acceptance and legacy dispositions specified; validator 0 error / 0 warning. Main friction w"
---

## Review
Requirements run completed: single-source four-tier distro roster, consumer remediation, Alpine 3 on-demand acceptance and legacy dispositions specified; validator 0 error / 0 warning. Main friction was the reserved-035 numbering requiring a temporary placeholder branch, plus brief-vs-repo leaf-count divergence (recorded in the spec).

## Optimization Points
- `token-efficiency` — 检查 `.specify/memory/features.md` 时两次用整行 grep，超长表格行触发输出截断；应改用字段投影（awk 取 ID/Name/Status）只读取所需列。
- 编号空间：035 被在途特性占用但本地不可见，scaffold 脚本只能靠临时占位分支才能产出 036；建议脚本支持显式 feature number 参数。
- 简报的 legacy 叶数是目录名计数（含 shared 配置目录），不是 `Dockerfile.tpl` 叶计数；本次已在 Recorded Divergences 记录，验证时应重测。
