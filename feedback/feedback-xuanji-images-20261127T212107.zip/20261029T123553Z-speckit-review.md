---
id: "20261029T123553Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "r20261029T071500Z-c3d4-review2"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
feature: "048-dsh-guest-image"
feature_id: "030"
partial: false
created: "2026-10-29T12:35:53Z"
summary: "Review of 048-dsh-guest-image (aa53f53f): 17 findings = 1 P0 + 12 P1 + 4 P2. P0 confirmed by a disjoint validator: FR-009 requires a same-session mechanical cross-tier node/dsh version comparison but "
---

## Review
Review of 048-dsh-guest-image (aa53f53f): 17 findings = 1 P0 + 12 P1 + 4 P2. P0 confirmed by a disjoint validator: FR-009 requires a same-session mechanical cross-tier node/dsh version comparison but no comparator exists anywhere in the repo; T019 closed on a manual table and verification SC-002 records pass, so a future latest-resolution drift would pass every gate. Key P1s: the implement-time compressed-layer size-gate correction was not propagated to data-model/quickstart; 23 contract sentinels vs 16 named fixtures with S-4.1..S-4.4 and C-1.4e unguarded; analyze finding ids unregistered and colliding with spec 046; SC-006 evidence is a pure cache-hit replay with no in-image smoke and an unarchived mismatched checksum baseline; Feature 030 registry frozen at the plan stage with undercounts; the implement commit gate contradicts the loop's single-full-suite budget and the test-budget ledger is absent; a mutation drill survived a run boundary because the done gate audits deletions only; the same-author gate is session-keyed and the confirmation-gate scanner scans zero files yet reports green. Detection was delegated to 3 fresh-context read-only detectors (24 raw candidates) plus 1 disjoint P0 validator (confirm, 0 downgrades). 13 REC ids registered.

## Optimization Points
- 1) Give multi-image invariants a post-build comparator task shape and make every gate row name the requirement's own measurable quantity plus a satisfiability probe. 2) When a gate is corrected, propagate it by grepping the quantity name across every artifact that states it. 3) Analyze findings need an append-only durable report and spec-qualified ids; bare F-NN ids collide across specs. 4) Evidence for replay/regeneration must archive the actual compared inputs and distinguish cache-hit from cold build. 5) Trigger same-author detection on author lineage/run id, and make governance scanners fail red when they scan nothing.
