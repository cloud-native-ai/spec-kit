---
id: "20261029T104109Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261029T071500Z-c3d4-analyze2"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-29T10:41:09Z"
summary: "Delta rerun of /speckit.analyze (read-only) on 048-dsh-guest-image after commits 45c4298d and 4645b63b. Prior HIGH F-03 is closed: FR-009 now requires a same-session mechanical comparison of the node "
---

## Review
Delta rerun of /speckit.analyze (read-only) on 048-dsh-guest-image after commits 45c4298d and 4645b63b. Prior HIGH F-03 is closed: FR-009 now requires a same-session mechanical comparison of the node and dsh version outputs, FR-013 states cross-tier equality is not constructively guaranteed, assumption A-13 and a corrected Q5 exist, plan PA-6 and the Constitution XIV row align, T008 does not pass DSH_VERSION, and T019 carries a hard equality assertion. F-01 and F-02 are closed (SC-007, US5 scenario 3, SC-007 Source and FR-026 now agree; SC-002 includes the dependency closure). F-04 is only partly closed: the envelope fix to 1720 MB is right, but the remainder was changed to 184 MiB, which mixes decimal MB and binary MiB; the correct remainder is 109.39 MB (104.32 MiB), re-raised as F-08 MEDIUM. New: C-05 MEDIUM (no contract clause owns the cross-tier version equality, so the T019 green tag on C-1.6 is unsupported), F-09 LOW (quickstart QS-2 omits the CWS_BUILD_SESSION premise), F-10 LOW (the session-fails wording has no writer and a same-session retry is deduped by build_session_is_built; validated as a downgrade from HIGH by one fresh-context validator). Final counts: 0 CRITICAL, 0 HIGH, 11 enumerated MEDIUM, 2 enumerated LOW. Coverage accountant: contract clauses 23 of 23 claimed, FR machine lane 6 of 29 (E-01 carried). Zero-finding floor: 8 coverage rows re-read (all 5 single-task FRs plus 3 multi-task samples), all sound. No file was modified.

## Optimization Points
- 1) Fix verification must re-derive numbers instead of copying the finding text: the prior F-04 finding itself proposed 184 MiB and the fix implemented it, so a wrong target propagated into two places; an analyze rerun should recompute every numeric it inspects. 2) Remediation must touch the contract layer: the F-03 fix added a task-level assertion but no contract clause, leaving T019 green-tagged to a clause that does not require it; treat contract ownership as part of any FR tightening. 3) Failure-path claims need a mechanism check: the Edge Case says the session fails, but session dedupe plus the post-session task placement make that unwritable; verify the mechanism before writing the procedure. 4) Validator calibration: one proposed HIGH became LOW; the propagation-surface rule needs a named downstream step that becomes blocked, which the proposal lacked. 5) Carry-over discipline: the feature registry still shows plan-stage counts (10 measurements vs 14, 19 sentinels vs 23); a stage-record check belongs in the analyze wrap-up.
