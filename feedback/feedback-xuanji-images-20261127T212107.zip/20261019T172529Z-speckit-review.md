---
id: "20261019T172529Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "20261019t172503z-038-review"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
feature: "038-guest-agent-runtime"
feature_id: "032"
partial: false
created: "2026-10-19T17:25:29Z"
summary: "# Specification-Driven Development (SDD) Process Review Report: Debian guest rootfs 织入 hermes agent 与 DeepSeek Harness（038-guest-agent-runtime）"
---

## Review
# Specification-Driven Development (SDD) Process Review Report: Debian guest rootfs 织入 hermes agent 与 DeepSeek Harness（038-guest-agent-runtime）

> **Audience**: spec-kit framework maintainers.
> **Purpose**: Identify concrete problems and improvement targets in spec-kit templates, command prompts, automation, and workflow as exposed by this feature's SDD lifecycle.
> **Intentionally problem-first**: this report omits long narrative summaries of artifact contents. If a sentence describes the feature instead of identifying a process gap, it does not belong here.

## 0. Portable Project Context (Self-Contained Snapshot)

| Field | Value |
|-------|-------|
| Requirement ID | 038 |
| Requirement Key | 038-guest-agent-runtime |
| Requirement Name | Debian guest rootfs 织入 hermes agent 与 DeepSeek Harness（guest-agent-runtime） |
| Related Feature | 032 Guest Node Supply for dsh（primary）；030 WASM Agent Sandbox Image Chain（secondary） |
| Repository | xuanji-images |
| Repository URL | `git@gitlab.alibaba-inc.com:kangaroo-xuanji/xuanji-images.git` (SSH-only remote; no HTTPS web URL is configured, so `blob/` citations cannot be rendered) |
| Reachability of COMMIT_SHA | **UNRESOLVABLE** — `git branch -r --contains HEAD` returns empty; the branch has not been pushed. All citations below use absolute paths plus `git show 98f0fa3a:<path>` recovery instructions. |
| Branch | 038-guest-agent-runtime |
| Commit SHA | 98f0fa3aa1008764f8ae17a6e8bb6593725d7656 (short: 98f0fa3a) |
| Repo Root (absolute) | `/storage/project/kangaroo-xuanji/xuanji-images` |
| Review Date | 2026-10-20 |
| Reviewer (Agent) | Qoder CLI agent, `review-sdd-process` skill (`/speckit.review`) |
| Environment | Linux `workspace_docker_baremetal_9` 5.10.134-19.3.1.al8.x86_64; Docker 29.8.1; git 2.43.7; host Python 3.11.13; project `.venv` active |
| spec-kit Source Snapshot | `specify_cli 0.0.22` installed in `/storage/project/kangaroo-xuanji/xuanji-images/.venv/lib/python3.11/site-packages/specify_cli/`; the project's runtime copy is `/storage/project/kangaroo-xuanji/xuanji-images/.specify/` at the same commit. This is a self-hosted project: the framework source and the client runtime live in one repository. |

### Artifact Inventory

| Artifact | Lines | Absolute Path | One-line Summary |
|----------|------:|---------------|-------------------|
| requirements.md | 667 | `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/requirements.md` | Five user stories, 23 FRs, 11 SCs, shared strings and recorded divergences. |
| plan.md | 556 | `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/plan.md` | Constitution check, file-level change set, 13 implementation steps, risk table. |
| tasks.md | 294 | `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/tasks.md` | 34 dependency-ordered tasks, 8 DoD rows, 6 completion gates. |
| verification.md | 163 | `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/verification.md` | Baseline, L1/L2 evidence, SC verdicts, deferred register, gate status. |
| research.md | 281 | `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/research.md` | R1–R12 measurements and D-037-01..15 decisions. |
| data-model.md | 276 | `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/data-model.md` | E1–E12 entities, relations, state transitions, validation rules. |
| quickstart.md | 411 | `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/quickstart.md` | S0–S11 executable scenarios with plan-time statuses. |
| feature-ref.md | 117 | `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/feature-ref.md` | Feature 032/030 binding, status handling, FR/SC traceability. |
| contracts/leaf-weave.md | 120 | `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/contracts/leaf-weave.md` | C-1..C-9 weave, runtime, drift and artifact clauses. |
| contracts/hermes-install.md | 137 | `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/contracts/hermes-install.md` | C-1..C-9 mode selector, uv venv, bridge, probes, cleanup. |
| contracts/guest-gates.md | 132 | `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/contracts/guest-gates.md` | G1/G2/G3 definitions, TCI evidence rules, deferred taxonomy. |
| contracts/published-contract.md | 109 | `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/contracts/published-contract.md` | C-1..C-7 leaf page / index publication contract. |
| checklists/requirements.md | 138 | `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/checklists/requirements.md` | Quality checklist with deterministic checker verdict. |
| notes/pre-change-measurements.md | 75 | `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/notes/pre-change-measurements.md` | T001–T003 baseline, writability probe, dirty-file inventory. |
| notes/red-first-evidence.md | 65 | `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/notes/red-first-evidence.md` | T007 red-first and T014 green evidence. |
| notes/alpine-zero-drift.md | 44 | `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/notes/alpine-zero-drift.md` | Premise-decay explanation and controlled A/B. |
| notes/consumer-drift.md | 1137 | `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/notes/consumer-drift.md` | 975-consumer diff classification and representative diff. |
| notes/quickstart-run.md | 33 | `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/notes/quickstart-run.md` | Executed S0–S11 status table. |
| features/032.md | 68 | `/storage/project/kangaroo-xuanji/xuanji-images/.specify/memory/features/032.md` | Feature 032 detail; status `Planned`; implementation record. |
| features.md | 53 | `/storage/project/kangaroo-xuanji/xuanji-images/.specify/memory/features.md` | Feature index; 032 row status `Planned`; duplicate 030 rows remain. |

## 1. Process Execution Timeline

The commits are exact evidence. Per-task attribution inside the implementation commits is reconstructed from `[X]`/`[~]` markers and the evidence notes, because the commits are phase-grouped rather than story-grouped (see F7); those rows are marked `inferred from artifact state`.

| # | Step / Event | Evidence (commit SHA, file, or quoted excerpt) | Deviation from prescribed flow? |
|---|--------------|------------------------------------------------|---------------------------------|
| 1 | Requirements stage | `e7ba311a` 2026-10-20 00:31:56; requirements + checklist; 6 self-adjudicated clarifications; checker `0 error / 0 warning` | **Yes** — the spec number `037` was allocated although `origin/037-distro-support-tiers` already existed (F2). |
| 2 | Clarify stage | `c3901398` 2026-10-20 00:32:32; five rulings; Feature 032 primary / 030 secondary | None (self-adjudication was explicitly sanctioned by the stage directive; assumption A11 records it). |
| 3 | `dsh web` residual | `d7fe8b1a` 2026-10-20 00:32:47; line B boundary recorded | None. |
| 4 | Plan stage | `12ec5f74` 2026-10-20 00:32:58; plan/research/data-model/4 contracts/quickstart/feature-ref; same-author audit 23 findings fixed in place | None at the time; the plan-phase zero-drift criterion later proved unsatisfiable (F4). |
| 5 | Renumber 037→038 | `7549eaf7` 2026-10-20 00:33:00; 11 files renamed, 26 insertions / 26 deletions | **Yes** — mid-flow renumber after the collision; residual `D-037-*` IDs and `/tmp/037-*` paths remain (F2). |
| 6 | Registry links repointed | `613faaee` 2026-10-20 00:33:21; Feature 032 detail + index | None. |
| 7 | Tasks stage | `65ca8108` 2026-10-20 00:42:41; 34 tasks, 8 DoD rows, 6 gates, baseline reconciliation | **Yes** — the DoD/GATE text asserted “nine” pre-existing dirty files; the T002 measurement later found 13 (F3). |
| 8 | Glossary registration | `8a3806b8` 2026-10-20 00:45:06; tasks-stage terms | None. |
| 9 | Implement Step 0 baseline | `notes/pre-change-measurements.md`; `bash bin/cws_images_test` → 20 failed / 1010 passed / 23 skipped, 6 unique names | **Yes** — the prescribed extraction regex matched zero lines; the implementer manually corrected the extraction (F1). |
| 10 | Red-first guards | `notes/red-first-evidence.md`, `notes/red-first-before.log`; rc=1, 5 failed / 20 passed | None; three first-draft guard defects were found and fixed before the recorded red run. |
| 11 | Layer-2 build | Runtime session `/storage/project/kangaroo-xuanji/xuanji-images/deployment/data/build/session/1792429514913001826/`; 01:05:14 → 01:08:18; rc=0; 2,732,421,378 bytes / 3 layers | None. |
| 12 | Post-implementation suite | `notes/after-failed.txt`, `notes/final-failed.txt`; 20 failed / 1016 passed / 23 skipped; same six names as baseline | None; independently reproduced by this review. |
| 13 | Implementation commits | `202e2602` (snippet + leaf + 3 guards), `63865fe6` (leaf page + index), `8008d433` (evidence + Feature registry + tasks + verification), `98f0fa3a` (gate close) | **Yes** for story attribution — `202e2602` mixes US1 (snippet, leaf) and US2 (three guards); `8008d433` mixes evidence, registry, tasks and verification. The implement-side commit gate permits phase boundaries, the review-side skill expects story grouping (F7). |
| 14 | Review stage | This report; HEAD `98f0fa3a`; working tree has 15 pre-existing/runtime dirty entries | None; no implementation file was modified. |

### 1.1 Focus-Area Evidence Checks (audit performed by this review)

| Focus area | Evidence checked | Result |
|------------|------------------|--------|
| Task closure / deferral honesty | `tasks.md` rows T001–T034; `grep -nE '^- \[[ >~]\]'`; T020–T022 inline `deferred:`/`unlock:`; `verification.md` deferred register | **Pass** — 31 `[X]`, 3 `[~]` with classification and unlock; no unrecorded row. GATE-3's mechanical check is weaker than its prose (F10). |
| Leaf weave correctness | Generated `.../debian-trixie/Dockerfile` import blocks; `ENV HERMES_INSTALL_MODE uv`; container probe; `notes/consumer-drift.md` | **Pass** — order is guest → nodejs → dsh → hermes; probe reproduced `node v25.9.0`, `dsh 0.2.1-rc.2`, `hermes v0.19.0`, CPython 3.12.13, bridge resolves to `/cws_env_hermes/venv/bin/hermes`, `uv` and `uv.tar.gz` absent; 975/975 diffs classified `revision+hermes` with the revision label explained. Wording/count issues in the evidence note (F6) and a latent VENV guard gap (F9). |
| Guards and verification | `bash bin/cws_images_test run <three guard files>`; red-first logs; full suite; Alpine note | **Pass** — independently reproduced 25/25 green; red-first 5 failed / 20 passed with FR-expected causes; reverse sentinels execute on temp fixtures; full suite 20 failed / 1016 passed / 23 skipped with the identical six failing names; Alpine controlled A/B note is internally consistent and the current Alpine hash equals the note's with-038 side. The gate premise is structurally flawed (F4). |
| L2 evidence | Build session `report.md` / `success.md`; `docker image inspect`; container probe; parent image labels | **Pass** — 184 s, 2,732,421,378 bytes, 3 layers; parent digest `sha256:a3bc1c0342ef…` labels record `workspace.code-workspace.cloud/library/debian:13.7`. The leaf page and verification explicitly state that the slim re-pin was **not** re-verified. |
| No-touch regression | `git diff --name-only origin/main -- images/slim src/build/const/cws.py test/unit/test_dist_roster.py test/unit/test_frozen_baseline_guard.py`; 037 guard trio; dirty-file inventory | **Pass** — scoped diff empty; 037 trio rc=0 (32 passed); the 15 dirty entries remain unstaged and unmodified by the feature commits. |
| Documentation / registry | Leaf page, index row, Feature 032 detail/index, requirements/feature-ref | **Pass** — leaf page and index are consistent; Feature 032 remains `Planned` with the `dsh web` acceptance explicitly unresolved; Feature 030 detail unchanged; no new Feature. Requirements still says `Draft` while the registry says `Planned` (F8); quickstart statuses are stale (F5). |

## 2. Findings Summary

| Severity | Count | Definition |
|----------|------:|------------|
| P0 | 0 | Blocks correct use of spec-kit, or creates silent corruption risk. Fix before next spec. |
| P1 | 4 | Recurring friction across specs. Fix when convenient — currently every spec writer pays the toll. |
| P2 | 6 | Quality-of-life. Compounding gains across many specs. |

| Category | Count |
|----------|------:|
| Template | 1 |
| Command Prompt | 1 |
| Automation / Scripts | 3 |
| Workflow | 2 |
| Documentation | 3 |

## 3. Findings (Problems & Improvement Targets)

### F1 — Baseline failure-name extraction command cannot match the runner's output format

- **Severity**: P1
- **Category**: Automation
- **Location**: `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/plan.md` (lines 231–233); `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/quickstart.md` (lines 45–48); runner log `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/notes/layer1-baseline.log` (lines 1114–1118)
- **Evidence** (verbatim quote):

  ```
  grep -E '^(FAIL|ERROR): ' /tmp/037-layer1-before.log \
    | sed -E 's/^(FAIL|ERROR): [^ ]+ \(([^)]+)\).*/\2/' | sort -u \
    > /tmp/037-fail-before.txt
  ```

  Actual runner output in the committed baseline log:

  ```
  FAILED test/unit/test_compose_dev_group_inventory.py::TestDevComposeSurfaceAbsent::test_no_dev_compose_aggregates
  SUBFAILED(fetcher='images/fetcher/build/binaryen', template='...') test/unit/test_fetcher_per_version_split.py::TestPerVersionFetcherSplit::test_version_leaf_set_matches_family_table
  ```

- **Why it's a problem**: The prescribed regex matches **zero** lines of the runner's actual output (verified: `grep -cE '^(FAIL|ERROR): '` = 0; the log has 20 `FAILED`/`SUBFAILED` lines). A literal run produces an empty `baseline-failed.txt`; the later `comm -13 baseline current` then passes vacuously even if the implementation introduced failures. In this run the implementer noticed the mismatch and used a corrected extraction, so the recorded gate is valid — but the artifact still carries the broken command for the next feature. This is why it is P1 rather than P0: the risk materialized only as rework, not as a false-green claim.
- **Proposed fix**: Add a normalized `--failed-names` mode to `/storage/project/kangaroo-xuanji/xuanji-images/bin/cws_images_test` (collapse `SUBFAILED` to its function, emit one fully-qualified test id per line), reference that mode from the plan/quickstart templates instead of an inline regex, and add a runner test with a fixture log that contains both `FAILED` and `SUBFAILED` lines.

### F2 — Remote branch number collision forced a mid-flow renumber and left 037 identifiers

- **Severity**: P1
- **Category**: Command Prompt
- **Location**: `/storage/project/kangaroo-xuanji/xuanji-images/.specify/skills/internal/create-requirements/SKILL.md` (lines 44–52); commits `e7ba311a` and `7549eaf7`; residue in `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/plan.md`, `quickstart.md`, `feature-ref.md` and `verification.md`
- **Evidence** (verbatim quote):

  ```
  - `git fetch --all --prune`
  - Derive the next number from `.specify/specs/` directories (**INCLUDING
    `.specify/specs/.archive/`** ...) plus branch names in the exact top-level
    `<NNN>-<slug>` form ONLY.
  ```

  Timeline: `origin/037-distro-support-tiers` existed from 2026-10-19 17:30; the local requirements commit `e7ba311a` allocated `037` at 2026-10-20 00:31:56; the renumber commit `7549eaf7` followed at 00:33:00. Residual identifiers include `D-037-01..15` (research, verification, Feature 032 detail) and `/tmp/037-status-before.txt`, `/tmp/037-consumers-before/` (plan, quickstart).
- **Why it's a problem**: The numbering step is documented as remote-aware, but the collision still happened, forcing a renumber of 11 files 64 seconds after the requirements commit. The renumber preserved file content but not the identifier namespace: decisions and temp paths still say `037`, so a reader cannot tell whether `D-037-11` belongs to this spec or to the unrelated `037-distro-support-tiers` spec that exists on origin.
- **Proposed fix**: Implement the numbering step as a deterministic script that enumerates `git for-each-ref refs/heads refs/remotes` and filters the exact `<NNN>-<slug>` form; add a regression fixture with a remote-only `037-*` branch. When a renumber is unavoidable, write a mapping note (`D-037-*` → this spec, or freeze and rename) into the spec's `research.md` and `feature-ref.md`, and normalize temp-path prefixes during the rename.

### F3 — Dirty-file gate count drifted from nine to 13/15 and GATE-6 passed by prose override

- **Severity**: P1
- **Category**: Workflow
- **Location**: `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/tasks.md` (lines 22, 33, 198); `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/notes/pre-change-measurements.md` (lines 19–23); `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/verification.md` (line 132)
- **Evidence** (verbatim quote):

  ```
  - DoD-8: ... 九个既存脏文件未被提交、还原或改写 ...
  - GATE-6: 九个既存脏文件未被 staged/还原 — check: `git status --porcelain` 与 `notes/pre-change-measurements.md` 的九项清单逐项比对
  ```

  The evidence file says:

  ```
  `git status --porcelain` measured **13 entries** (2 modified + 11 untracked).
  The task rows say "nine"; that premise is falsified by measurement and is
  recorded here more strictly (the full 13-item set is authoritative for GATE-6
  and DoD-8; the nine-item subset named in tasks.md is contained in it)
  ```

  Verification resolves the contradiction in prose:

  ```
  GATE-6_status=pass (13 pre-existing entries remain unstaged/untouched; T034 staging audit — the measured set is 13, not nine, notes/pre-change-measurements.md)
  ```

- **Why it's a problem**: GATE-6's written check names a “九项清单” that does not exist in the evidence file (which has 13 entries), and by review time the tree has 15 entries because the run created two more runtime records. The invariant itself holds, but a gate whose literal check cannot be executed as written is not a gate — it is a prose override. The same stale count appears in DoD-8 and T034, so three acceptance surfaces disagree with their own evidence.
- **Proposed fix**: Generate the dirty-file set at tasks time into a machine-readable evidence file (full paths, one per line) and make GATE-6 diff the current `git status --porcelain` against that set, allowing only runtime records created by this run; never encode a literal count in DoD/GATE text. Add the check to `/storage/project/kangaroo-xuanji/xuanji-images/.specify/skills/internal/create-tasks/SKILL.md` so the evidence path is created with the task list.

### F4 — Zero-drift gate is a literal sha256 over an artifact that embeds a commit-dependent revision label

- **Severity**: P1
- **Category**: Template
- **Location**: `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/contracts/leaf-weave.md` (line 96); `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/plan.md` (Step 5, lines 327–343); `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/quickstart.md` (line 259); `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/tasks.md` (GATE-2, line 29); `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/notes/alpine-zero-drift.md`
- **Evidence** (verbatim quote from the contract):

  ```
  - Alpine 叶子的生成 `Dockerfile` MUST 逐字节不变（硬判据）：改动前后 sha256 相等。
  ```

  The evidence note records why this cannot hold:

  ```
  The generator appends a `cws.images.revision` LABEL whose value is the git
  revision of the workspace at generation time (`<commit>` on a clean tree,
  `<commit>-dirty` on a dirty tree). It therefore changes on **every commit** and
  on every dirty/clean transition, independently of any source change.
  ```

- **Why it's a problem**: The plan-phase acceptance criterion is structurally unsatisfiable across commits. The implementer discovered the premise decay, replaced the literal criterion with a controlled worktree A/B, and documented it. The A/B is stronger evidence and the annotation is honest, but the contract still states the impossible criterion, and the gate redefinition exists only as an inline note in `tasks.md`/`notes/alpine-zero-drift.md`, not as a ratified decision. The next feature that copies this pattern will hit the same wall.
- **Proposed fix**: Put the premise probe into `/storage/project/kangaroo-xuanji/xuanji-images/.specify/templates/plan-template.md`: before naming a zero-drift criterion, identify volatile generator fields and either (a) compare a revision-normalized artifact, or (b) use a controlled worktree A/B with both sides at the same dirty state. Require any gate redefinition discovered during implementation to be recorded as a decision with an explicit authorization note, and update the owning contract in the same change set.

### F5 — Quickstart statuses were never backfilled; results live in a side note and one expectation is contradicted

- **Severity**: P2
- **Category**: Documentation
- **Location**: `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/quickstart.md` (lines 8–10, 146–148, 175–177, 264–266, 286, 291–293, 374–376, 393–395); `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/notes/quickstart-run.md`
- **Evidence** (verbatim quote):

  ```
  本文件给出本特性的可执行验证场景。每个场景都标注**执行状态**与**前提**；... 任何场景的“预期结果”都必须在实现阶段实际观测后回填，不得把 plan 阶段写下的预期当作通过证据。
  ```

  But the implementation-stage scenarios still say:

  ```
  **Status**: `deferred`（实现阶段执行）
  ```

  and S6 still predicts:

  ```
  - 层深门通过（层数 ≤ 100；预期本地 +3 层，从 3 层到约 6 层）；
  ```

  The actual build produced 3 layers total (2 parent, compacted).
- **Why it's a problem**: The artifact that calls itself the executable verification guide is now misleading on its face. A reader cannot tell which scenarios ran, and the side note becomes a second source of truth for scenario status. The contradicted layer-count expectation is exactly the kind of stale “expected result” the document says must be backfilled.
- **Proposed fix**: Add a quickstart-closeout step to `/storage/project/kangaroo-xuanji/xuanji-images/.specify/skills/internal/implement-feature/SKILL.md` (or the verification-log workflow): for every `S*` scenario, replace the plan-time status with the observed status and reconcile the expected/actual results in place; keep `notes/quickstart-run.md` only as raw output, never as the status owner.

### F6 — Consumer-drift evidence contains an unrendered `%d` and undercounts intentional behavior changes

- **Severity**: P2
- **Category**: Documentation
- **Location**: `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/notes/consumer-drift.md` (lines 20–23, 26–36); `/storage/project/kangaroo-xuanji/xuanji-images/snippets/docker/install/ai/agent/hermes-agent.dockerfile` (lines 59–68)
- **Evidence** (verbatim quote):

  ```
  Total snapshot files: %d. Every consumer carries the embedded
  `cws.images.revision` change (the snapshot predates the current commit);
  ```

  and:

  ```
  ## Two intentional tightenings
  ```

- **Why it's a problem**: A committed evidence artifact with an unrendered format placeholder shows the artifact was generated but never validated. The “two tightenings” count also omits a third behavior change: the auto/outside-window path's `${VENV_DIR}/bin/hermes` link is now created only when `VENV_DIR` is non-empty and `${VENV_DIR}/bin` exists, so consumers with an undeclared `VENV_DIR` no longer get the link (and may now fail the new hard probe). The note describes the guard in a later paragraph, but the summary count understates the consumer-facing change surface.
- **Proposed fix**: Render the count, replace “Two intentional tightenings” with an enumerated signature table (hard probes, PyPI egress, VENV_DIR link guard), and add a deterministic lint in the evidence-closure step that rejects leftover `%d`/`%s`/`TODO`/`TBD` tokens in `.md` evidence files.

### F7 — Implement-side phase commits vs review-side story grouping are inconsistent

- **Severity**: P2
- **Category**: Workflow
- **Location**: `/storage/project/kangaroo-xuanji/xuanji-images/.specify/skills/internal/implement-feature/SKILL.md` (lines 246–247); `/storage/project/kangaroo-xuanji/xuanji-images/.specify/skills/internal/review-sdd-process/SKILL.md` (lines 80–87); commits `202e2602` and `8008d433`
- **Evidence** (verbatim quote from the implement skill):

  ```
  - **Commit gate**: commit after each task or logical group; in multi-phase runs the
    **phase boundary** is the default commit unit — commit only after that phase's name-level
    regression diff (`comm -13 baseline current`) is empty ...
  ```

  The review skill expects the opposite granularity:

  ```
  **Degradation when commits exist but are NOT story/task-grouped** ... Record the missing
  story-grouped commit discipline itself as a Workflow finding citing the commit gate in
  the `/speckit.implement` command.
  ```

- **Why it's a problem**: `202e2602` contains US1's snippet and leaf plus US2's three guard files in one commit; `8008d433` mixes evidence, Feature registry, tasks and verification. That is compliant with the implement-side phase-boundary default, but it forces every review to degrade to artifact-state reconstruction and then report the allowed behavior as a finding. Two framework owners prescribe different granularities, so the process cannot be both compliant and reviewable.
- **Proposed fix**: Pick one contract. Preferred: require at least one commit per user story in multi-story runs (implementation, verification and docs for that story together), reserving phase commits for Setup/Foundational/Polish; update `/storage/project/kangaroo-xuanji/xuanji-images/.specify/skills/internal/implement-feature/SKILL.md`'s commit gate and the review skill's degradation rule together. If phase commits remain the default, make the review skill treat them as expected and stop emitting a finding for them.

### F8 — Requirements still assert Feature 032 stays Draft while the registry says Planned

- **Severity**: P2
- **Category**: Documentation
- **Location**: `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/requirements.md` (lines 22–24); `/storage/project/kangaroo-xuanji/xuanji-images/.specify/memory/features/032.md` (line 3); `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/plan.md` (Feature Integration); `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/feature-ref.md`
- **Evidence** (verbatim quote):

  ```
  端到端启动仍依赖 sandbox 线 B 的桥接，Feature 032 状态保持 Draft。
  ```

  The registry states:

  ```
  **Status**: Planned（2026-10-19：spec `038-guest-agent-runtime` 的 plan 阶段落地；实现与 Layer-2 证据归 `/speckit.implement`）
  ```

- **Why it's a problem**: The plan interprets the requirement sentence as “the `dsh web` acceptance remains unresolved” (D-037-11), and the registry correctly advances to `Planned`. But `requirements.md` itself was never updated or cross-referenced, so a reader who starts at the requirement sees a direct contradiction. The status fact has two owners (requirements prose and the Feature registry), which is exactly the drift the project's One Source Of Truth rule forbids.
- **Proposed fix**: Make the Feature registry the sole owner of life-cycle status and change the requirements sentence to a reference (“Feature 032 remains `Planned`; its `dsh web` acceptance is unresolved”) or add an explicit post-clarify consistency pass that updates the requirement when a downstream stage changes status. The plan's interpretation is sound; the artifact still needs the pointer.

### F9 — The “snippet must not require VENV_DIR” contract is not covered by the auto-branch guard

- **Severity**: P2
- **Category**: Automation
- **Location**: `/storage/project/kangaroo-xuanji/xuanji-images/snippets/docker/install/ai/agent/hermes-agent.dockerfile` (lines 59–68); `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/contracts/hermes-install.md` (line 70); `/storage/project/kangaroo-xuanji/xuanji-images/test/unit/test_sandbox_rootfs_agent_guard.py` (lines 286–289)
- **Evidence** (verbatim quote from the snippet):

  ```
  if command -v uv >/dev/null 2>&1; then \
    if [ -d "${VENV_DIR}/bin" ]; then \
      uv pip install --python ${VENV_DIR}/bin/python --index-url https://mirrors.aliyun.com/pypi/simple/ "${pkg}"; \
  ```

  The contract says:

  ```
  - snippet MUST NOT 要求 `VENV_DIR` 已定义；guest 叶子 MUST NOT 声明它。
  ```

- **Why it's a problem**: When `VENV_DIR` is unset, `[ -d "${VENV_DIR}/bin" ]` expands to `[ -d "/bin" ]`, which is true on Debian, so the uv sub-branch attempts `uv pip install --python /bin/python`. The new guard only pins the bridge line's `[ -n "${VENV_DIR:-}" ]`; the auto/uv sub-branch remains unguarded, so the contract sentence is broader than the implementation and the guard. The guest leaf uses `HERMES_INSTALL_MODE=uv`, so this does not affect the feature's own build; it is a latent auto-consumer hazard.
- **Proposed fix**: Apply the same `-n "${VENV_DIR:-}"` condition to the `[ -d "${VENV_DIR}/bin" ]` and `[ -x "${VENV_DIR}/bin/python" ]` tests in the auto branch (or narrow C-4 to say the requirement applies to the bridge link only), and add a reverse-sentinel mutation that removes the guard so the checker can prove the clause.

### F10 — GATE-3's mechanical check counts `[~]` rows without validating their reason/unlock fields

- **Severity**: P2
- **Category**: Automation
- **Location**: `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/tasks.md` (line 30; rows 149–151)
- **Evidence** (verbatim quote):

  ```
  - GATE-3: 无未关闭的任务行 — check: `grep -cE '^- \[[ >]\]' .specify/specs/038-guest-agent-runtime/tasks.md` 返回 0（`[~]` 必须带记录原因）
  ```

- **Why it's a problem**: The grep excludes `[~]` entirely, so a `[~]` row with no `deferred:`/`unlock:` annotation would pass the mechanical check. The prose says reasons are mandatory, but the only automated check cannot see them. The implementer verified the three rows manually; the gate itself does not enforce the rule.
- **Proposed fix**: Extend the gate to assert that every `[~]` row contains both `deferred:` and `unlock:` (or the template's canonical fields), and add a fixture task file with a reason-less `[~]` row to the check's self-test. The same pattern applies to any future deferred state vocabulary.

## 4. What Worked — Preserve (Brief)

- **Honest deferrals**: T020–T022 are `[~]` with explicit `deferred:` classification and `unlock:` conditions; SC-004, SC-005, SC-007 (`.data`) and the TCI conclusion are `deferred`, and the artifacts repeatedly state that T1 was not substituted for T2/T3.
- **L2 evidence is real and reproducible**: the runtime session `/storage/project/kangaroo-xuanji/xuanji-images/deployment/data/build/session/1792429514913001826/` records 184 s, 2,732,421,378 bytes, 3 layers; this review reproduced the container probe and `docker image inspect` values.
- **Parent-image provenance is declared honestly**: the leaf page and verification state that the local parent was built from the former `debian:13.7` and that the `debian:trixie-slim` re-pin was not re-verified; the parent labels corroborate this.
- **Guard red/green discipline**: the new/reversed guards were run red first (5 failed / 20 passed) with FR-expected causes, then green (25 passed); reverse sentinels execute on temp fixtures without modifying the repository.
- **Name-level regression comparison**: the full suite reproduced 20 failed / 1016 passed / 23 skipped with exactly the same six failing names as the committed baseline.
- **Structural zero-drift premise**: the Alpine closure guard proves the shared change cannot reach Alpine; the controlled A/B note explains the revision-label premise decay instead of hiding it.
- **No-touch boundary**: the scoped `git diff origin/main` is empty, the 037 guard trio is green, and the pre-existing dirty files were never staged, restored or rewritten.
- **Feature 032 stays `Planned`**: the registry explicitly records that the `dsh web` acceptance remains unresolved and that Feature 030 is unchanged; no new Feature was created.

## 5. spec-kit / SDD Improvement Recommendations

### 5.1 Template Improvements

- **REC-T1 — Make zero-drift criteria revision-aware** — Target: `/storage/project/kangaroo-xuanji/xuanji-images/.specify/templates/plan-template.md` (new "Premise probe for generated-artifact equality" guidance) and `/storage/project/kangaroo-xuanji/xuanji-images/.specify/templates/tasks-template.md` (gate redefinition rule). Change: require the planner to identify volatile generator fields (`cws.images.revision`, timestamps) before writing a byte-equality criterion, and prescribe a revision-normalized or controlled-worktree comparison; require a recorded decision when a gate is redefined mid-run. Source: F4. Expected impact: eliminates an unsatisfiable gate class and the ad-hoc mid-run redefinition.
- **REC-T2 — Give quickstart a closeout contract** — Target: `/storage/project/kangaroo-xuanji/xuanji-images/.specify/templates/plan-template.md` (quickstart section) and `/storage/project/kangaroo-xuanji/xuanji-images/.specify/templates/verification-log-template.md`. Change: add a mandatory "backfill every scenario status and expected/actual result in place" step, and declare the quickstart file — not a side note — the status owner. Source: F5. Expected impact: one source of truth for scenario outcomes.

### 5.2 Command Prompt Improvements

- **REC-C1 — Make requirement numbering remote-aware by construction** — Target: `/storage/project/kangaroo-xuanji/xuanji-images/.specify/skills/internal/create-requirements/SKILL.md` §2 and the underlying numbering command. Change: enumerate `git for-each-ref refs/heads refs/remotes` instead of relying on a fetch-and-inspect instruction; include a remote-only `NNN-*` fixture in the skill's self-test; on renumber, emit a mapping note and normalize temp-path prefixes. Source: F2. Expected impact: no more mid-flow renumbers and no orphan decision IDs.
- **REC-C2 — Align commit granularity across implement and review** — Target: `/storage/project/kangaroo-xuanji/xuanji-images/.specify/skills/internal/implement-feature/SKILL.md` (commit gate) and `/storage/project/kangaroo-xuanji/xuanji-images/.specify/skills/internal/review-sdd-process/SKILL.md` (step 2). Change: require one commit per user story in multi-story runs, or explicitly bless phase-boundary commits and have the review skill treat them as the expected granularity rather than a degradation finding. Source: F7. Expected impact: per-story attribution without a permanent review-side workaround.

### 5.3 Automation / Script Improvements

- **REC-A1 — Add a normalized failed-name mode to the test runner** — Target: `/storage/project/kangaroo-xuanji/xuanji-images/bin/cws_images_test` (and the corresponding runner wrapper). Change: `--failed-names` collapses `FAILED` and `SUBFAILED(...) test::Class::method` into one fully-qualified id per line; reference it from plan/quickstart; add a fixture log test. Source: F1. Expected impact: the baseline/regression comparison can no longer pass vacuously.
- **REC-A2 — Generate gate evidence as machine-readable sets** — Target: `/storage/project/kangaroo-xuanji/xuanji-images/.specify/skills/internal/create-tasks/SKILL.md` and `/storage/project/kangaroo-xuanji/xuanji-images/.specify/templates/tasks-template.md`. Change: create the dirty-file set and the baseline failure-name set as enumerated files at tasks time; make GATE-6 and GATE-1 diff sets, not counts; allow only this run's own runtime records as additions. Source: F3. Expected impact: gate text and evidence cannot diverge.
- **REC-A3 — Lint evidence artifacts for placeholders and validate `[~]` fields** — Target: `/storage/project/kangaroo-xuanji/xuanji-images/.specify/skills/internal/implement-feature/SKILL.md` (evidence closure) and the tasks gate. Change: reject leftover `%d`/`%s`/`TODO`/`TBD`; require `deferred:` and `unlock:` on every `[~]` row. Source: F6, F10. Expected impact: generated evidence is actually rendered and deferred rows are self-describing.
- **REC-A4 — Close the VENV_DIR guard gap** — Target: `/storage/project/kangaroo-xuanji/xuanji-images/snippets/docker/install/ai/agent/hermes-agent.dockerfile` and `/storage/project/kangaroo-xuanji/xuanji-images/test/unit/test_sandbox_rootfs_agent_guard.py`. Change: guard the auto branch's `${VENV_DIR}/bin` tests with `-n "${VENV_DIR:-}"` and add a reverse-sentinel mutation, or narrow contract C-4's wording. Source: F9. Expected impact: the contract sentence and the automated guard agree.

### 5.4 Workflow Improvements

- **REC-W1 — Add a post-clarify upstream-consistency pass** — Change: when clarify/plan advances a Feature status or resolves a binding that an upstream requirement sentence contradicts, update the requirement or insert a pointer to the registry as the status owner; record the pass in the plan's same-author audit. Source: F8. Expected impact: no contradictory status statements across the artifact chain.
- **REC-W2 — Require a decision record for gate redefinition** — Change: when implementation discovers a gate premise is false, the redefinition must be recorded as a decision (with the premise evidence and the authorization) and the owning contract/quickstart updated in the same commit, not only noted in a side file. Source: F4. Expected impact: gate changes are auditable and the next run inherits a valid criterion.

### 5.5 Documentation Improvements

- **REC-D1 — Make consumer-drift evidence exhaustive and rendered** — Target: `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/notes/consumer-drift.md` (and the evidence template it follows). Change: render the count, enumerate all intentional behavior changes as signature rows, and explain the failure-surface change for each. Source: F6. Expected impact: reviewers can reproduce the classification without re-deriving the omitted change.
- **REC-D2 — Record renumber provenance** — Target: `/storage/project/kangaroo-xuanji/xuanji-images/.specify/specs/038-guest-agent-runtime/research.md` / `feature-ref.md`. Change: add a short mapping note for `D-037-*` and the `/tmp/037-*` paths produced before the 038 rename. Source: F2. Expected impact: identifiers remain interpretable after a directory renumber.

## 6. Priority Roadmap

| Priority | Recommendation | Target File / Subsystem | Source Finding(s) |
|----------|----------------|--------------------------|-------------------|
| P1 | REC-A1 — runner `--failed-names` | `/storage/project/kangaroo-xuanji/xuanji-images/bin/cws_images_test` | F1 |
| P1 | REC-C1 — remote-aware requirement numbering | `.specify/skills/internal/create-requirements/SKILL.md` §2 | F2 |
| P1 | REC-A2 — gate evidence as enumerated sets | `.specify/skills/internal/create-tasks/SKILL.md`, `.specify/templates/tasks-template.md` | F3 |
| P1 | REC-T1 — revision-aware zero-drift criteria | `.specify/templates/plan-template.md`, `.specify/templates/tasks-template.md` | F4 |
| P2 | REC-T2 — quickstart closeout | `.specify/templates/plan-template.md`, `.specify/templates/verification-log-template.md` | F5 |
| P2 | REC-A3 — evidence placeholder / `[~]` lint | `.specify/skills/internal/implement-feature/SKILL.md` | F6, F10 |
| P2 | REC-C2 — commit granularity alignment | `.specify/skills/internal/implement-feature/SKILL.md`, `.specify/skills/internal/review-sdd-process/SKILL.md` | F7 |
| P2 | REC-W1 — post-clarify status consistency | `.specify/skills/internal/plan-feature` / `feature-ref` handling | F8 |
| P2 | REC-A4 — VENV_DIR guard closure | `snippets/docker/install/ai/agent/hermes-agent.dockerfile`, `test/unit/test_sandbox_rootfs_agent_guard.py` | F9 |

## 7. Self-Containment Check

- [x] Every file path in the report is absolute, or a remotely resolvable URL form.
      Because the commit is unpushed and the remote is SSH-only, this report uses absolute paths plus `git show 98f0fa3a:<path>` recovery instructions instead of URLs.
- [x] Every finding in Section 3 has a quoted excerpt that lets the reader judge the problem without opening the source file.
- [x] No bullet says "see attached", "as discussed earlier", or otherwise references context outside this document.
- [x] No placeholder tokens remain anywhere in the report.
- [x] Section 4 is short and bullet-only — no multi-paragraph narrative summaries leaked back in.
- [x] Section 5 recommendations each cite an exact target file in the spec-kit repo and at least one source finding ID.
- [x] **P0 validation status**: No P0 findings raised; the P0 independent-validation pass is vacuously satisfied.

## 8. Feedback

Please share the contents of this document with the spec-kit framework developers.

## Optimization Points
- F1 P1 Automation: plan/quickstart baseline failure-name extraction regex does not match the runner's FAILED/SUBFAILED output; literal use yields an empty baseline and a vacuous zero-new-failures gate.
- F2 P1 Command Prompt: requirement numbering collided with origin/037-distro-support-tiers, forcing a mid-flow renumber; D-037 IDs and /tmp/037 paths remain in the 038 artifacts.
- F3 P1 Workflow: DoD-8/GATE-6/T034 say nine dirty files while the evidence measured 13 and the review tree has 15; the gate passed by prose override.
- F4 P1 Template: the literal sha256 zero-drift criterion is unsatisfiable because generated Dockerfiles embed cws.images.revision; the gate was redefined mid-run to a controlled A/B.
- F5 P2 Documentation: quickstart statuses were never backfilled; implementation results live only in notes/quickstart-run.md and S6's layer expectation contradicts the observed 3 layers.
- F6 P2 Documentation: notes/consumer-drift.md contains an unrendered %d and summarizes two intentional tightenings while omitting the VENV_DIR link-guard behavior change.
- F7 P2 Workflow: implement-feature permits phase-boundary commits while review-sdd-process expects story-grouped commits; 202e2602 mixes US1 and US2 and 8008d433 mixes evidence, registry, tasks and verification.
- F8 P2 Documentation: requirements.md still says Feature 032 stays Draft while the registry says Planned; the divergence is interpreted only in plan/feature-ref.
- F9 P2 Automation: contract C-4 says the snippet must not require VENV_DIR, but the auto branch still tests [ -d "${VENV_DIR}/bin" ] unguarded; the guard only pins the bridge line.
- F10 P2 Automation: GATE-3's grep excludes [~] rows entirely and does not validate the mandatory deferred/unlock fields.
