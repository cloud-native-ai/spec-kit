---
id: "20261021T025804Z-speckit-instructions"
unit_id: "/speckit.instructions"
unit_type: "command"
run_id: "instructions-2026-10-21T1053Z-size-budget"
scope: "local"
probe: "speckit-instructions-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-21T02:58:04Z"
summary: "Size-budget convergence run: .specify/instructions.md 40,402 B -> 32,252 B (budget 32,768 B; 516 B headroom). Compressed Documentation Map, Tech Stack, CWS Image Authoring, Fetcher & Snippet, Build Se"
---

## Review
Size-budget convergence run: .specify/instructions.md 40,402 B -> 32,252 B (budget 32,768 B; 516 B headroom). Compressed Documentation Map, Tech Stack, CWS Image Authoring, Fetcher & Snippet, Build Session, and Common Workflow to map/pointer shape; owner docs verified to carry removed detail; 16/16 map locations exist; mirror contract tests 40 OK; heading-set coverage vs 6 backups showed only known supersessions, no lost content. Run axes were not measured (no session JSONL span, no frozen test baseline).

## Optimization Points
- R2's 4 KB per-section threshold did not fire even though the file was 7,634 B over budget; the inflation came from several 1.6–3.4 KB project sections plus framework template growth. Consider letting the over-budget trigger itself authorize pointer compression of any project-owned section whose owner document already carries the detail.
- The Documentation Map's former Key Content column carried a stale feature count (30 vs 35) and duplicated owner content; a 3-column map (Document/Location/Purpose) makes the map shape the path of least resistance.
