---
id: "20261031T164817Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261030T120500Z-b101-impl-s3c"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "051-xuanji-doc-build-chain"
feature_id: "048"
partial: true
created: "2026-10-31T16:48:17Z"
summary: "Spec 051 segment 3c (T017-T024) confirmed the new source premises and then stopped on a plan/source Hugo-version conflict. The pushed B branch origin/023-xuanji-doc-architecture@247b4482 is reachable "
---

## Review
**Partial run** — Spec 051 segment 3c (T017-T024) confirmed the new source premises and then stopped on a plan/source Hugo-version conflict. The pushed B branch origin/023-xuanji-doc-architecture@247b4482 is reachable through the canonical fetcher; the rebuilt fetcher carries HEAD 247b4482 with lightrag submodule 30e08fd2 initialized (recursive clone), and service/api, service/ingest/bin/xuanji-doc-ingest.mjs and service/lightrag/pyproject.toml are present. Generation plus --check, the graphicle builder and the fetcher build all succeeded. The project leaf then failed at the L2 pnpm run build:hugo step: the B (023) vendored Docsy 0.15.0 declares min_version 0.146.0 and uses layouts/_partials, while the plan/contracts pin Hugo 0.141.0 and alios-8 cannot run the only other fetched pin (0.163.2 requires GLIBC_2.33/2.34 and GLIBCXX_3.4.29). No fetched Hugo pin satisfies both constraints; per FR-006 this is an explicit failure. T017-T024 remain [~], no project/service image or container was produced, and the guard test was aligned to the B shape (25 passed). Evidence: notes/anomaly-T017-hugo-version.md, notes/T017-project-build-s3c.log, notes/quickstart-run.md.

## Optimization Points
- Hugo version premise: align the image's fetched Hugo pin with the delivered source's theme min_version (0.146.0) during upstream/binary alignment, not at the first build; the plan's 0.141.0 pin and the B source cannot both hold. Add a plan-level compatibility check that compares view/site/themes/docsy/theme.toml min_version with the fetched Hugo pin before building. If a compatible fetched pin cannot be found, decide between fetching 0.146.x (test glibc first), building Hugo from source on alios-8, or moving the leaves to a newer-glibc distro. Build-wrapper exit-code hygiene: the background launcher's trailing echo masked the docker-build.sh exit; rely on the log/build-session failed.md, not the wrapper exit. token-efficiency: the up-front source-pin/submodule probes were correct and the build failed at the first L2 Hugo step (~20s of build), so no long build was wasted.
