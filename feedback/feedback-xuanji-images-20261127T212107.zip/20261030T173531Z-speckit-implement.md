---
id: "20261030T173531Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261030T120500Z-b101-impl-s1"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "051-xuanji-doc-build-chain"
feature_id: "048"
partial: false
created: "2026-10-30T17:35:31Z"
summary: "Implemented spec 051 segment 1 (T001–T008) only, in task order, with no image build and no push. Re-measured the frozen baselines: the four pre-change reference hashes are unchanged since bf3af36c, no"
---

## Review
Implemented spec 051 segment 1 (T001–T008) only, in task order, with no image build and no push. Re-measured the frozen baselines: the four pre-change reference hashes are unchanged since bf3af36c, notes/no-change-set.sha256 verifies OK, and account-clause-coverage.py reports status=ok, fr-uncovered=0, coverage-baseline-delta=0 (341 baseline-internal uncovered; pre-existing clause-unparsable=52). Closed T001 by re-verification. Wrote the three red-first Layer-1 guards and recorded red evidence: test_xuanji_doc_build_chain.py 21 failed/3 passed, test_xuanji_doc_graphicle_dual.py 4 failed/1 passed, test_xuanji_doc_nginx_surface.py 11 failed/1 passed. Landed T005's six shared supervisor pairs (literal user=service/api/ingest/cgit, startsecs=0, no startup waits; six scripts pass bash -n) with -k supervisor 1 passed; T006's two baked nginx fragments with the full surface file 12 passed; T007's identity/volumes/ports snippets with the selected subset 3 passed; T008's narrowed 12-COPY supervisor snippet, extended test-first from 1 failed/1 passed to 2 passed. A full build-chain snapshot at T008 is 17 failed/8 passed; every remaining red belongs to T009–T021 subjects, not to this segment. Corrections made in passing: bin/cws_images_test swallows a leading positional test path as an unknown command (runs the whole directory and hits the pre-existing jsonschema collection error in test_ansm_debug_tooling.py), so every targeted run used the equivalent `bash bin/cws_images_test run <file> [-k ...]` form; and one ports guard assertion was scanning comment prose for CWS_MICRO_PORT/EXPOSE, so the assertion was narrowed to non-comment lines (the snippet was not changed to satisfy a fragile assertion). No generated Dockerfile, compose artifact, plan/research/data-model/contracts/quickstart file was modified; no docker-build.result existed in this worktree.

## Optimization Points
- Target a single module through the runner as 'bash bin/cws_images_test run <file>': a leading positional path is consumed as an unknown command, so the documented '<file>' form silently runs the whole test directory and trips unrelated pre-existing collection errors.
- Plan guard names against every -k selector the task rows use: a test name that merely contains another row's keyword is selected early and fails on a subject that row has not implemented yet.
- When two task rows share one selector (T005/T008 both use -k supervisor), add the later row's assertion inside that later row (test-first) instead of writing it in the earlier red-first guard, or the earlier row's verification command can never pass.
- spec 051 tasks.md has no row that creates install/nodejs-runtime.dockerfile or project/build/kangaroo-xuanji/corepack-pnpm.dockerfile, although C-02/C-08/C-39 and T013/T014 consume them; the version-owner guard stays red until a row authors them.
- The test runner's python lacks jsonschema, so whole-directory collection fails in test_ansm_debug_tooling.py; targeted module runs are unaffected and should be the evidence form until the dependency is pinned.
