---
id: "20261017T071139Z-speckit-sanitize"
unit_id: "/speckit.sanitize"
unit_type: "command"
run_id: "20261017T071139Z"
scope: "local"
probe: "speckit-sanitize-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-17T07:11:39Z"
summary: "S3 调协趟 sanitize 执行报告：apply 256 项全绿（8 归档/248 误报 dismiss），pending 365 为有意保留的 dated-record 积压；4 类引擎误报机制已定位（见 points），建议框架侧修复命令模板路径解析（类 B 影响 216 条为最大噪声源）与 features 索引链接单元格解析（类 A）。"
---

## Review
S3 调协趟 sanitize 执行报告：apply 256 项全绿（8 归档/248 误报 dismiss），pending 365 为有意保留的 dated-record 积压；4 类引擎误报机制已定位（见 points），建议框架侧修复命令模板路径解析（类 B 影响 216 条为最大噪声源）与 features 索引链接单元格解析（类 A）。

## Optimization Points
- 执行面：collect 全根扫描后 apply 计划 256 项全绿（8×archive + 248×dismiss，0 失败）；台账 645→resolved 280/pending 365
- 归档 8 目录（全部未跟踪物料，零 git 差异）：5 个前代平铺技能 draw-excalidraw/draw-mermaid/draw-plantuml/git-fleet/git-server-init（后继 draw-diagram/git-utils 已无损合并，活材料零引用，docs 引用均为 dated 溯源句）+ 3 个分层化平铺残影 archive-session/create-team/summarize-project（internal/ 嵌套版为严格超集且公共文件字节相同，宿主发现面经 internal/ 不受损——internal-only 技能如 sanitize-materials 本身在宿主清单中为证）
- dismiss 四类误报（机械证明 + 引擎缺陷定位）：
- A×30 features.md#missing-00X：30 个 .specify/memory/features/00X.md 实存；引擎把 Detail 列整格 markdown 链接 `[...](features/00X.md)` 当路径 is_file() 检查（sanitize-utils features-family 段）
- B×216 speckit.* 命令引用：15 个被点名命令在 .qoder/commands/speckit.<name>.md 全部实存；引擎查 (root)/templates/commands/<name>.md（sanitize-utils L412-415），该布局仅存在于框架仓库——客户端项目的命令副本在 .qoder/commands/
- C×1 register.md#shared/mysql.rc：/cws_shared/mysql.rc 是容器运行期路径非 repo 路径
- D×1 .specify/tools：其自引权威 tool-definitions.md §Terminology 明文 discovery inventories 即 .specify/tools/{system,shell,project}.json；目录仅 3 个机器生成 JSON、零 legacy 记录
- 留台账 pending 365：.specify/specs/* 与 .specify/archive/* 内 dated-record 类路径引用（历史规格记录描述过往状态，按 One Source of Truth 属合法 dated 记录；引擎级豁免与否属框架侧范围决策，不在客户端清理）
- 确认依据：sdd-project-setup S3 调协趟派发预授权「直接执行不要确认」，作为破坏性批（8×archive）的前置批量确认记入 cleanup-plan.json confirmedBy 字段
