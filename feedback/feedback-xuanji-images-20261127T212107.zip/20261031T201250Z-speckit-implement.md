---
id: "20261031T201250Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261030T120500Z-b101-impl-s4"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "051-xuanji-doc-build-chain"
feature_id: "048"
partial: true
created: "2026-10-31T20:12:50Z"
summary: "Spec 051 segment 4 verified T025-T032 on the two 2026-10 leaves."
---

## Review
**Partial run** — Spec 051 segment 4 verified T025-T032 on the two 2026-10 leaves.

T025: nginx -T shows /mcp/v1 proxy_buffering off + proxy_cache off + connect/send/read 3600s and /api/v1 60s on both leaves, with the daemon client_max_body_size 1G. An MCP system_health tools/call returned a chunked SSE event with the first byte before completion (project TTFB 0.040664 < total 0.041023; service 0.055567 < 0.056277); the pinned api emits a single SSE event per call (no long-running tool exists). The byte-exact boundary on the nginx-served static path /cgit-css/cgit.css measured at-limit 1073741824 B -> 405 (not 413) and limit+1 1073741825 B -> 413 on both leaves, with the nginx.stderr attribution line "client intended to send too large body: 1073741825 bytes ... POST /cgit-css/cgit.css". The no-secret container fails the C-30/T025 expectation: the browser face is 401, but the B api cannot boot without CWS_CONTEXT_KEY (app.main.load_deployment._required) and 051's api.sh exits when the file is unreadable, so api crash-loops and the four health endpoints return 502/502/502/502 while GET /api/v1/documents/query and /mcp/v1/ return 502 (no business content). T025 is recorded [~] and the cross-line conflict is surfaced as ANOMALY.

T026: both leaves stat 1100/1100/1100/1000/1101/1101/1100 for docs, git, git/repos, git/graphicle, config, config/api, config/ingest with modes 755/755/755/700/755/755/755 and 644 audit.jsonl; ingest writes docs and config/ingest/{jobs,jobs/keys,audit.jsonl} but is denied config root and config/api; api writes config/api but is denied config/ingest and docs; service writes git/graphicle but is denied config root, config/ingest and docs; cgit is denied repos and config root.

T027: five marker files plus an appended audit line survived docker rm/recreate on the same named volumes with 8/8 RUNNING; fresh empty volumes seed the image config defaults with owners 1101/1100 and render the Hugo home page (200, 26,793 B) and cgit's empty catalogue (404, body "No repositories found", upstream cgit behavior); existing config files are not overwritten on recreate.

T028: cgit cannot write /srv/knowledge/git/repos (touch rc=1, not writable); a demo.git fixture is listed by /cgit/ 200; /cgit-css/cgit.css is 200 text/css 14,987 B; nginx -T shows fastcgi to 127.0.0.1:28080 with SCRIPT_FILENAME /usr/lib/cgit/cgit.cgi; /etc/cgitrc has cache-size=0, scan-path=/srv/knowledge/git/repos and virtual-root=/cgit/; /var/cache/cgit is empty and outside the git volume.

T029-T031: the builder rebuilt rc=0 as image sha256:97c7cbbc0720 (all layers cached, and the logged RUN command names both --bin graphicle and --bin graphicle-graph); graphicle 0.1.8 (core) and graphicle-graph 0.1.8 both exit 0 in the builder and in both leaves, at /usr/local/bin; the legacy snippets/docker/project/install/alios-8/graphicle.dockerfile has an empty git diff and passes sha256sum -c against notes/no-change-set.sha256.

T032: two consecutive cws_images_generate_all runs with the tracked tag pinned (CWS_LIB_TAG_OVERRIDE=2026-10) exited 0; git status --short was identical before/after each run (diff NONE) and no tracked file changed; cws_images_generate_all --check exited 0.

No source, template, snippet or generated artifact was hand-edited; no image was pushed. Evidence: notes/T025-nginx-T.log, T025-body-limit.log, T025-mcp-stream-s4.log, T025-fail-closed.log, T025-service-s4.log, T026-ownership-s4.log, T027-persistence-s4.log, T027-empty-volumes-s4.log, T028-cgit-s4.log, T029-builder-build-s4.log, T029-T031-s4.log, generate-s4-run1.log, generate-s4-run2.log, generate-check-s4.log, notes/quickstart-run.md § Segment 4.

## Optimization Points
- Decide the owner of "health stays up without a secret": C-30/T025 require the four anonymous health endpoints to return 200/503 and business/MCP to return 401/403 when the secret is missing, but the pinned B api refuses to start without CWS_CONTEXT_KEY; either B boots fail-closed (serving health with an empty secret) or the contract accepts a 502 fail-closed state. Do not close T025 by weakening the assertion.
- The Q-09 streaming premise (a long-running MCP tool) is unavailable in the pinned api; a single SSE event only proves chunked framing and header/body separation. Consider a slow tool or a timed upstream delay if the streaming behavior must be proven behaviorally rather than by nginx -T.
- The builder rebuild was a full BuildKit cache hit. If T029's intent is a recompilation proof, add a cache-bust input to the builder build; otherwise state that the cached RUN line plus the in-image binaries are the evidence.
- cgit's empty catalogue is 404 "No repositories found", not a 200 empty list; align C-19's "空列表" wording with the upstream status or record it as the accepted representation.
- Keep the pinned rendering condition for generation (CWS_LIB_TAG_OVERRIDE=2026-10) in the run record: the unpinned auto tag on 2026-11-01 is amd64-2026-11 and would rewrite every generated tag.
- token-efficiency: the 2,484-template --check pass (~2 min) dominated the segment; the builder cache hit avoided a Rust rebuild, and the 1 GiB probes returned before the body upload (405/413 at header time), so only the status codes and the error-log line were consumed.
