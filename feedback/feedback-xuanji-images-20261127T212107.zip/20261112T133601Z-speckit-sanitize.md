---
id: "20261112T133601Z-speckit-sanitize"
unit_id: "/speckit.sanitize"
unit_type: "command"
run_id: "2026-11-12T09:40:17Z"
scope: "local"
probe: "speckit-sanitize-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-12T13:36:01Z"
summary: "sanitize 引擎在客户端工作区把合法命令/技能引用批量误判为 dead-reference（布局假设，非真实staleness）"
---

## Review
sanitize 引擎在客户端工作区把合法命令/技能引用批量误判为 dead-reference（布局假设，非真实staleness）

## Optimization Points
- 1. sanitize-utils.py 的引用检查 #3（命令）与 #4（技能目录）无条件使用框架源码布局：root/templates/commands/{name}.md 与 root/skills/{name}。
- 2. 客户端工作区（specify init 生成，workspace-kind=client）不存在这两个路径，导致所有合法的 speckit.* 命令引用与 skills/* 引用被判为 dead-reference（本次 514 + 71 条误报）。
- 3. 建议：与引擎既有的 client 感知一致（如 mirror pair 的 "client projects have no source root" 分支），按 workspace kind 选择解析根；命令改查各工具命令目录或已安装 CLI 资产，技能改查 .specify/skills/。
- 4. 附带观察：REPO_PATH_RE 会把句末句号并入路径（xxx.md.），修复路径后仍会产生新 finding；建议 _path_target_ok 剥离尾随标点。
