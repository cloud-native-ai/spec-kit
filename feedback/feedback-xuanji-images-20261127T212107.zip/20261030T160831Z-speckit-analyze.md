---
id: "20261030T160831Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261030T120500Z-b101-analyze"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
feature: "051-xuanji-doc-build-chain"
feature_id: "048"
partial: false
created: "2026-10-30T16:08:31Z"
summary: "Analyze run completed (read-only): 051 cross-artifact analysis — 22 findings (0 CRITICAL / 6 HIGH / 10 MEDIUM / 6 LOW); 14/14 checklist FAILs re-verified (13 upheld / 1 downgraded / 0 withdrawn); 8-ro"
---

## Review
Analyze run completed (read-only): 051 cross-artifact analysis — 22 findings (0 CRITICAL / 6 HIGH / 10 MEDIUM / 6 LOW); 14/14 checklist FAILs re-verified (13 upheld / 1 downgraded / 0 withdrawn); 8-row validation wave (6 confirm / 2 downgrade / 0 reject); FR 29/29 and clauses 50/50 claimed; no artifact modified, no build, no push.

## Optimization Points
- Analyze report schema: the skill requires a category-initial finding ID plus propagation_surface, while the run-record schema required ID/severity/location/summary/recommendation. The run had to merge both column sets by hand; consider publishing the union skeleton once so callers do not re-derive it.
- Category-initial IDs have no published mapping: the skill's example uses C-01/H-02, which do not correspond to the pass names (duplication/ambiguity/underspecification/constitution/coverage/inconsistency/feature). This run defined I/E/U/A/G prefixes locally; document the mapping or drop the example.
