---
id: "20261030T163801Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261030T120500Z-b101-analyze2"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
feature: "051-xuanji-doc-build-chain"
feature_id: "048"
partial: false
created: "2026-10-30T16:38:01Z"
summary: "Analyze2 read-only re-verification of the analyze-fix for 051: 5 of 6 HIGH repairs land (I-02 Node/pnpm split, I-03 single-owner versions, I-04 byte-exact 413 boundary, U-01 source-tree owner service "
---

## Review
Analyze2 read-only re-verification of the analyze-fix for 051: 5 of 6 HIGH repairs land (I-02 Node/pnpm split, I-03 single-owner versions, I-04 byte-exact 413 boundary, U-01 source-tree owner service 1000, E-07 API fail-closed); I-05 is NOT fixed - T031's replacement `sha256sum -c` checks a five-entry pre-change manifest that includes three files T012/T015 must change, so the gate is red after the intended implementation. The I-04 repair also introduces a new HIGH I-10: the at-limit 413 probe judges a bare status code that cannot distinguish nginx from an application 413 (the sibling API spec sets 200 MiB/request), so the positive control can false-fail or go vacuous. New MEDIUM E-08: the Node split drops the npm/corepack mirror registry configuration that the old chain carried via config/npm.dockerfile and COREPACK_NPM_REGISTRY. Validators pass (validate-requirements 0/0, validate-tasks PASS, account-clause-coverage FR 29/29 and clauses 50/50, pre-analyze-check pass with 2 pre-existing advisories). No artifact was modified outside the new run record; no image build; no push.

## Optimization Points
- Verify a replacement no-change gate by running its literal command against a simulated post-change state; a manifest-wide `sha256sum -c` over files that other tasks must edit is still an always-red gate. Extract the single protected path or keep a dedicated must-not-change checksum file.
- An at-limit positive control must define how a 413 is attributed: the bare status code cannot tell nginx from the application; use a route without an app-level limit or require a second signal (nginx log/error_page marker), and pin the app's documented limit.
- When splitting a shared install snippet, audit every nested configuration weave the old snippet transitively provided (npm/corepack registry, mirror, global tools, caches); a runtime-only replacement can silently drop the registry/mirror configuration.
- Version-owner uniqueness guards should assert both leaf-level zero literals and snippet-level single occurrence; a leaf-only guard cannot observe a duplicated literal inside the snippet body.
- Analyze-fix dispositions should distinguish 'text repaired' from 'gate verified'; mark a finding FIXED only after its acceptance command is shown green on a simulated post-change tree, otherwise mark it PARTIAL/NOT-FIXED.
