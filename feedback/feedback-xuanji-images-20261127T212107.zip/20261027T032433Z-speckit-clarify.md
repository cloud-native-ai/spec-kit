---
id: "20261027T032433Z-speckit-clarify"
unit_id: "/speckit.clarify"
unit_type: "command"
run_id: "20261027T032425Z-clarify-045"
scope: "local"
probe: "speckit-clarify-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-27T03:24:33Z"
summary: "clarify on 045: six dispatch-required decisions were closable from repo evidence, but two hard blockers only surfaced by reading the guards: partition leaf basenames must be DIST_ROSTER keys (dispatch"
---

## Review
clarify on 045: six dispatch-required decisions were closable from repo evidence, but two hard blockers only surfaced by reading the guards: partition leaf basenames must be DIST_ROSTER keys (dispatch's suggested debian-trixie-agent is illegal) and the family dsh guard unconditionally requires one NODEJS_VERSION weave per leaf (a Node-free leaf is red by construction).

## Optimization Points
- clarify should run a mechanical 'constraints scan' before proposing decisions: grep the guards that key on the artifact's plane (leaf naming census, family invariant registers) so naming/registration conflicts are found before the decision table is written. Also: the requirements-stage proposal carried a derived number (stack ~440 MB) with no reachable owner; derive only from cited owner text.
