---
id: "20261031T172504Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261030T120500Z-b101-analyze-fix5"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
feature: "051-xuanji-doc-build-chain"
feature_id: "048"
partial: true
created: "2026-10-31T17:25:04Z"
summary: "**Partial run** — analyze-fix5 resolved the Hugo version conflict and applied the single-point edits, but T017–T024 remain blocked by a mirror supply gap."
---

## Review
**Partial run** — analyze-fix5 resolved the Hugo version conflict and applied the single-point edits, but T017–T024 remain blocked by a mirror supply gap.

The candidate matrix (spec 051 `notes/hugo-version-matrix.md`) measured nine pins inside the alios-8 base: 0.146.0, 0.147.0, 0.147.9 and 0.148.2 require only GLIBC ≤ 2.14 / GLIBCXX ≤ 3.4.21 and all build the B Docsy site (0.141.0 reproduces the s3c `dark-mode-config.html` partial-not-found failure); 0.149.0, 0.155.0, 0.160.0 and 0.163.2 require GLIBC 2.33/2.34 and GLIBCXX_3.4.29 and do not run. The erroneous inherited premise "alios-8 has glibc 2.28" was corrected by measurement: the base is Alibaba Cloud Linux 3 with glibc 2.32. The highest pin satisfying Docsy `min_version=0.146.0` and runnable on the base is 0.148.2; its SHA256 matches the official release checksums.

Edits: the fetcher template adds `HUGO_VERSION_0148=0.148.2` (four assets, existing pins kept), the install snippet's default becomes `ARG HUGO_VERSION=0.148.2` (still the single owner), and plan/contracts C-07/C-05/FR-006/data-model/research/tasks carry PLAN-EDIT declarations. The Layer-1 guard literal moved to 0.148.2; both leaf templates still carry no version literal.

Validation: generate and `--check` exit 0; validate-requirements status ok 0/0; validate-tasks 0/0; pre-analyze-check decision=pass with the two pre-existing Txxx/Tyyy advisories; account-clause-coverage status ok (FR 29/29, baseline delta 0); the xuanji-doc guard is 25 passed; the full Layer-1 suite is 24 failed / 1625 passed / 23 skipped / 681 subtests, with a failure-name set identical to the s3c baseline (no new failures).

Blocked: the workspace mirror only caches 0.141.0 and 0.163.2. All four 0.148.2 release assets return 404 through the mirror, and the fetcher rebuild stops at the first download (`curl: (22) ... 404`, notes/T017-fetcher-build-fix5.log). Per mirror-supply §6 this is a `missing` item: the full URLs are recorded and a backfill is required; no fallback or bypass was used. The project leaf cannot COPY the new pin from the current fetcher image, so T017–T024 stay `[~]`, no project/service image or container was produced, and no route/port matrix was run. No push, no compose change, no running container was touched.

## Optimization Points
- Add a plan-level compatibility check that compares the delivered theme's min_version with the fetched Hugo pin before the first build, instead of discovering the conflict at the L2 Hugo step.|Measure the distro glibc from the actual base image, not from the distro name; the alios-8 label hid an ACL3/glibc-2.32 base and changed the usable pin range.|Treat mirror coverage as a build prerequisite: probe every new artifact URL through the mirror before editing the pin, and report a mirror 404 as a supply stop, not as a version failure.|Separate "no compatible pin exists" from "a compatible pin is not mirrored" in the decision path; the first needs a plan decision, the second needs a backfill action.
