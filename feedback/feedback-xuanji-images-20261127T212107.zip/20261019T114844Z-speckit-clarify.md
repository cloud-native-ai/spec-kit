---
id: "20261019T114844Z-speckit-clarify"
unit_id: "/speckit.clarify"
unit_type: "command"
run_id: "037-guest-agent-runtime-20261019-clarify"
scope: "local"
probe: "speckit-clarify-wrapup"
kind: "internal"
slice: "commands"
feature: "037-guest-agent-runtime"
feature_id: "032"
partial: false
created: "2026-10-19T11:48:44Z"
summary: "Completed /speckit.clarify for 037-guest-agent-runtime (Mode A, requirements.md). Five self-adjudicated rulings covered the six mandated topics: bound Feature 032 as primary (030 secondary) because 03"
---

## Review
Completed /speckit.clarify for 037-guest-agent-runtime (Mode A, requirements.md). Five self-adjudicated rulings covered the six mandated topics: bound Feature 032 as primary (030 secondary) because 032's Draft acceptance names the guest dsh/TCI gate and spec 036 handed dsh/G2/G3 to a 032-derived spec; fixed hermes as HERMES_INSTALL_MODE=uv with a ${HERMES_VENV_DIR}/venv and /usr/local/bin/hermes bridge; fixed dsh's node-to-dsh order, ${NODEJS_HOME} install location, pnpm defaults and version-probe fallback; made alpine zero-drift a hard criterion by confining edits to the hermes snippet; fixed G1/G2/G3 timeouts (120/180/600 s), the TCI static/runtime authority split and the unidentified-instruction rule; and recorded token-to-Cookie plus net=delegate WS relay as sandbox-line-B assumptions only. The requirements checker reports status ok, 0 errors / 0 warnings (666 lines, 23 FR, 11 SC, 21 STR); the checklist counts were refreshed; the Feature 032 detail and index rows were updated. No pre-existing dirty file was committed, reverted or altered; no push.

## Optimization Points
- clarify-artifact Mode A needs a binding template for a spec broader than the candidate Feature (032 is dsh-specific while 037 also adds hermes). The skill only says "compare candidates"; a required "scope extension / primary+secondary" note shape would make the adjudication reproducible.
- validate-requirements.py bidirectional STR check reports "that row does not cite [[STR]]" when the citation exists on a continuation line; the real rule is first-physical-line only. Naming that rule in the error message (or checking the whole bullet) would remove a guaranteed second validation iteration.
- token-efficiency: one whole-row grep against .specify/memory/features.md produced a ~75 KB output because registry rows are single long lines; the summary-first guidance for registry lookups should name field projection (awk -F"|" '{print $2,$3}') and forbid whole-row grep.
- The clarify checklist-derived-count rule requires refreshing counts from the spec, but the checklist count set is only discoverable by reading its prose; a validate-requirements.py --json projection (line/FR/SC/STR/story/scenario/edge/divergence/session counts) would make the refresh mechanical.
