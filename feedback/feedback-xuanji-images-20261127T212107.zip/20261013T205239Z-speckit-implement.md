---
id: "20261013T205239Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "20261013T205239Z-speckit-implement-030-registry-pass"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature_id: "030"
partial: false
created: "2026-10-13T20:52:39Z"
summary: "During spec 030's deferred-registry pass (T048-T051 + T060) I found that a verification note I had written in the SAME feature's earlier implement pass had blocked a lawful Planned->Implemented flip. "
---

## Review
During spec 030's deferred-registry pass (T048-T051 + T060) I found that a verification note I had written in the SAME feature's earlier implement pass had blocked a lawful Planned->Implemented flip. The note reasoned: SC-001/002/004/010 are deferred, DoD-4 is fail, GATE-10 is fail, therefore the Pre-Status-Flip Gate 'does not pass'. Re-reading .specify/shared/workflow/feature-integration.md:43-47 showed the gate enumerates FOUR conditions - zero [ ]/[>] rows, every SC statused, deferred registry complete, no void row folded into green - and none of them is 'every SC passes' or 'every DoD row is green'. All four held. The note had substituted a stricter test than the rule owner states. The error was not caught at authoring time because the gate section sits immediately above the DoD section and its item 6 discusses void DoD rows, which invites conflating 'DoD row failing' with 'gate check failing'.

## Optimization Points
- feature-integration.md's Pre-Status-Flip Gate is SILENT on a non-void failing DoD row or failing Completion Gate item. It explicitly says a *void* row 'does not block the flip' (item 6), but never says what a plain 'fail' does. That silence gets filled by the reader's assumption in either direction - over-strict (my case: a lawful transition stayed blocked) or over-loose (folding a real failure into green). Suggest one added line to the owner doc stating the intended semantics: a non-void fail does not block the flip either, but MUST be surfaced inline on the status row and in the wrap-up report, exactly as item 6 already requires for void rows - and that the four enumerated checks are the complete condition set, so no additional criterion may be invented at the call site. A contract test asserting the enumerated-check count would pin it.
