---
id: "20261101T034236Z-speckit-clarify"
unit_id: "/speckit.clarify"
unit_type: "command"
run_id: "r20261101T034150Z-i1a0"
scope: "local"
probe: "speckit-clarify-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-01T03:42:36Z"
summary: "clarify run on xuanji-images spec 049: five underspecified areas ratified from repo evidence alone (no user turn available), agent surface had to adjudicate. Two of the five (owner-set width, distro a"
---

## Review
clarify run on xuanji-images spec 049: five underspecified areas ratified from repo evidence alone (no user turn available), agent surface had to adjudicate. Two of the five (owner-set width, distro axis) were facts the requirements stage had already written down wrongly ("five pages", "four tiers only"), so the scan had to re-measure rather than re-read. The same-author scan was not delegated: the five candidate areas were found by targeted greps against the pages and constants, not by re-reading my own prose.

## Optimization Points
- 1) FR ceiling is checked only at plan/tasks entry: a clarify that adds 2 FRs can silently consume the whole budget (28->30 = ceiling). Worth surfacing the headroom at clarify time, not at plan. 2) run-determination refuses a second determine for the same run-id, so a first call that omits --declared-check/--green-check permanently records artifact_correctness=not_evaluated even though the checks ran green. A settle/amend action for correctness args would keep the record honest without breaking one-run-one-record. 3) determine's implicit settle of 'the unit's latest unsettled record' crossed feature lines: my --prev-user-turn-class topic_change was written onto another feature's (047-xuanji-agent-image) run record. Settle should be scoped to the same feature, or require an explicit --settle-run-id.
