---
id: "20261030T022645Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "r20261029T182500Z-a3f1"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
feature: "050-ansm-cni-debug-workspace"
partial: false
created: "2026-10-30T02:26:45Z"
summary: "Requirements for the ansm CNI debug workspace were produced and the deterministic checker reports ok. Two framework frictions were observed: the create-new-requirements script always creates and switc"
---

## Review
Requirements for the ansm CNI debug workspace were produced and the deterministic checker reports ok. Two framework frictions were observed: the create-new-requirements script always creates and switches a git branch, which conflicts with worktree line workflows that must stay on one branch; and the validate-requirements Consumed-by reverse check does not see STR citations placed inside inline code spans, a natural way to cite a filename.

## Optimization Points
- 1) Make branch creation in the create-new-requirements script opt-out or skip it when already on a managed line branch, so spec scaffolding does not switch branches. 2) In validate-requirements, treat STR citations inside inline code spans as citations for the Consumed-by reverse check, or state the placement constraint in the error message.
