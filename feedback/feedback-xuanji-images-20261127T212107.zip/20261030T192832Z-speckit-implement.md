---
id: "20261030T192832Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261030T120500Z-b101-impl-s3"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-30T19:28:32Z"
summary: "Implemented spec 051 segment 3 (T017–T024) only, in task order; no push and no compose change. Rebuilt the builder after fixing the dual-binary cargo invocation: graphicle builds in crates/graphicle; "
---

## Review
Implemented spec 051 segment 3 (T017–T024) only, in task order; no push and no compose change. Rebuilt the builder after fixing the dual-binary cargo invocation: graphicle builds in crates/graphicle; graphicle-graph is the cli member of the separate crates/graphicle-graph workspace and now builds with --locked from the workspace root; both binaries verify at 0.1.8. Rebuilt images-shared-service with the new supervisor pairs and nginx fragments and built the previously absent nodejs-20.20.2 fetcher. The project leaf build then exposed two more feature-owned defects: the daemon parent does not define CODE_DIR (the retired builder parent did), so the fetcher COPY expanded empty; and the identity snippet required daemon-owned UIDs 1000-1003 to be free instead of rejecting a new identity in that reserved range. Both were fixed; the build now reaches the C-39 validation and fails explicitly on the missing service/api/requirements.txt, which plan.md line 242 declares expected because the xuanji-doc source line has not landed service/api, service/ingest, bin[xuanji-doc-ingest] or service/lightrag/requirements.txt. No project image or container was produced, so T017-T019 are deferred. T020/T021 landed with green guards (6 and 1 passed). The service leaf L1 built but its runtime COPY correctly fails because the old project image lacks /cws_env/api, /cws_env/lightrag and /cws_config/xuanji-doc/runtime.env; T022-T024 are deferred, with T024's static no-CWS_MICRO_PORT/EXPOSE assertion verified. Static build_chain guard 25 passed; full suite 24 failed/1625 passed, of which three feature-attributable guard expectation gaps (dir_ownership_inventory, nginx_dead_writer_audit, nginx_hook_order) are not listed in T033.

## Optimization Points
- T033 scope gap: the full suite also fails test_dir_ownership_inventory (expects develop:develop), test_nginx_dead_writer_audit (allowlist lacks snippets/docker/config/xuanji-doc/nginx.dockerfile) and test_nginx_hook_order (cws-40-xuanji-doc.conf.tpl is build-time rendered). Extend T033 or add rows.
- T003/T012 guard only asserted the cargo command text, not that the targets exist; a build-level assertion or target-existence check would have caught the missing graphicle-graph bin before two long rebuilds.
- T013 removed the builder parent that carried CODE_DIR without re-declaring it; add a guard that every ${VAR} used in a project-leaf COPY is defined by the leaf or its parent.
- T007's identity guard asserted the literal 1000 1001 1002 1003 but not the semantics (the new identities must exclude the reserved range, not require it to be free); assert the collision behavior or add a build smoke.
- tasks.md T021's selector -k 'service payload' is not a valid pytest expression; use 'service and payload' or a single test name.
- token-efficiency: three builder rebuilds, three project builds and a full-suite mis-run without the venv dominated the token/time cost; a pre-build probe that the fetcher source carries the C-39 entries would have stopped T017 before any image build.
