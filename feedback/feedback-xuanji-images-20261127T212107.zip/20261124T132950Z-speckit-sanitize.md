---
id: "20261124T132950Z-speckit-sanitize"
unit_id: "/speckit.sanitize"
unit_type: "command"
run_id: "r20261124T132600Z-sntz"
scope: "local"
probe: "speckit-sanitize-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-24T13:29:50Z"
summary: "materials lane ran collect/status over a carried-over ledger: 2,190 findings total, 1,824 pending — all dead-reference / medium / repair — with 16 added and 3 auto-resolved this run and zero semantic "
---

## Review
materials lane ran collect/status over a carried-over ledger: 2,190 findings total, 1,824 pending — all dead-reference / medium / repair — with 16 added and 3 auto-resolved this run and zero semantic candidates. Verification of every class shows the bulk are layout-mismatch false positives: all 16 distinct referenced commands are installed (.qoder/commands/speckit.*.md) yet the checker resolves only against <root>/templates/commands; 411 of 511 shared/ refs resolve under images/shared/ but the checker tries the repo root only; skills resolve under .specify/skills while the checker looks at <root>/skills. A smaller true subset is stale old-generation references inside historical spec artifacts (.specify/templates/commands, memory/feedback, draw-mermaid, refactored src/ and scripts/ paths), plus 34 live docs-tree broken links (delegated to /speckit.docs) and one stale README anchor. No destructive items; no cleanup plan executed; goal/team residual probe clean (goal 0, teams 0). Engine defects reported: unreachable dismissed state (apply maps dismiss to resolved; record rejects programmatic findings), so persistent deterministic findings can never be durably adjudicated and reopen on every collect.

## Optimization Points
- sanitize-utils dead-reference grammar assumes the framework-source layout: commands are checked only at `<root>/templates/commands/<name>.md`, skills only at `<root>/skills/<name>`, and `shared/...` refs only at the repo root. In this client workspace the installed command surface is `.qoder/commands/speckit.*.md` (16/16 referenced commands exist), skills live in `.specify/skills/` (nested internal/), and image-factory shared assets live in `images/shared/` (411/511 refs). Result: ~1,000 re-detected false positives per run. Suggest resolving against the installed tool surfaces and configurable material roots instead of framework-source paths.
- The `dismissed` state is unreachable in the engine: `apply` maps a dismiss disposition to state `resolved` (reopened on the next re-detection — 1,241 reopened on 2026-11-12), and `record` accepts semantic verdicts only, so a user adjudication on a programmatic finding cannot be persisted durably. Suggest a durable adjudicated-dismissal path for programmatic findings so the ledger can converge.
- token-efficiency: this run re-projected the 1.6MB findings ledger across four separate passes (classification, grouping, resolvability, new/auto-resolved). A single grouped projection pass, or an engine-provided grouped pending digest, would remove the repeated reads without losing the digest-first signal.
