---
id: "20261018T061845Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "035-sandbox-rootfs-dsh-20261018-req"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
feature: "035-sandbox-rootfs-dsh"
partial: false
created: "2026-10-18T06:18:45Z"
summary: "本轮为 035-sandbox-rootfs-dsh 产出 requirements.md（499 行：18 FR / 9 SC / 5 用户故事 / 20 验收场景 / 9 边界 / 6 记录分歧 / 8 Shared Strings / 10 假设）+ 质量清单（75 行），并完成 glossary 渐进增补 2 条。运行到达 wrap-up，工件已按显式路径提交（5895a124），两处非本"
---

## Review
本轮为 035-sandbox-rootfs-dsh 产出 requirements.md（499 行：18 FR / 9 SC / 5 用户故事 / 20 验收场景 / 9 边界 / 6 记录分歧 / 8 Shared Strings / 10 假设）+ 质量清单（75 行），并完成 glossary 渐进增补 2 条。运行到达 wrap-up，工件已按显式路径提交（5895a124），两处非本轮产出的既存脏文件按纪律保持原样。确定性校验器首跑 17 ERROR（全部为 Shared Strings 的 Consumed-by 反向一致性），一轮修复后 0 error / 0 warning；清单在通过跑之后盖章。制品正确性轴因无名字级基线而 not_evaluated（requirements 阶段本无测试套件可跑，属该轴的诚实缺席而非缺陷）；token 与耗时两轴因无 session JSONL 源而 not_evaluated；满意度轴 pending_next_turn。运行判定 trigger_feedback=false，故本轮不上送阈值提示。本特性的实质发现是一条治理冲突：用户点名的 fetcher+builder+snippet 机制被 docs/design/images.md §4.2.1 与 frequent-release.list 对 deepseek-harness 的在册归类所禁止，且合规通路已存在并生效——已按 D1 裁决为「需求写结果面、机制归 plan」并记录推翻它所需的授权层级。

## Optimization Points
- 1. validate-requirements.py 的 Consumed-by 反向检查（C-15）有两条未在模板与 guidelines 中披露的语义，直接造成首跑 17 ERROR：(a) 它只在**定义行的首个物理行**上查找 [[STR-NNN]]，故硬折行的 FR/SC 行即使续行上有引用也一律判失败；(b) 它跑在**去除行内代码段**的视图上，故把引用写成反引号包裹形态（对 "dsh --version" 这类命令形字符串是最自然的写法）会被擦除而不计数。requirements-template.md 的 Shared Strings 示例行都是单行短值，永远不会踩中；spec 032/033 把 FR/SC 写成单行长行其实是**载荷性**约定，但没有任何文档告诉首次作者这一点。建议在模板的 Shared Strings ACTION REQUIRED 注释或 requirements-guidelines.md § Validation Process 补一句。token-efficiency
- 2. glossary 输入纠正的检索方向缺少约束：glossary.md §1 要求把变体映射到规范名，但没说明检索必须以「候选规范名 + 其已登记变体」为键。本轮以特性自身词汇（dsh/sandbox-rootfs/c2w）为检索式扫 glossary，漏掉 SpiderMonkey 已作为 mozjs 条目的变体在册，据此把「glossary 未收该词」写进了 D6，收尾复核时才发现并返工修正 D6 与清单开放项 (8) 两处。建议：glossary.md §1 增一句检索方向要求，或 glossary-utils.py 增 --action lookup --term（同时搜 canonical/variants/meaning）。token-efficiency
- 3. run-determination.py 的 --red-source 帮助文本写作 "the producer of a declared red"，读起来像可描述本轮任何一次红；引擎实际只接受它与 --unresolved-red true 搭配（本轮首跑的校验器红在轮内已解决，传 engine_nonzero_exit 被硬拒并要求改为 none）。报错信息本身自解释、可自愈，属低severity，但把帮助文本改成 "the producer of a declared **unresolved** red" 即可零成本消除这次往返。
