---
id: "20261030T171843Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261030T120500Z-b101-analyze-fix3"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
feature: "051-xuanji-doc-build-chain"
feature_id: "048"
partial: false
created: "2026-10-30T17:18:43Z"
summary: "Analyze-fix3 (spec text only) repaired the three acceptance-precision MEDIUMs from analyze3 for 051. I-11: the undefined POST /api/v1/documents was removed from every current normative surface; the up"
---

## Review
Analyze-fix3 (spec text only) repaired the three acceptance-precision MEDIUMs from analyze3 for 051. I-11: the undefined POST /api/v1/documents was removed from every current normative surface; the upload route is now the A-line Endpoint Matrix row 2 POST /api/v1/knowledge/push and the business/fail-closed probe is row 7 GET /api/v1/documents/query. I-12: the nginx 413 attribution line is now read with docker exec from ${OUTPUT_DIR:-/cws_output}/nginx.stderr (daemon nginx.conf error_log; OUTPUT_DIR=/cws_output from env/03-cws-daemon-path.rc), not docker logs; the at-limit/limit+1 status assertions and the /cgit-css/cgit.css static path are unchanged. I-06: all four A-line anonymous health endpoints (knowledge/documents/code/system) are now specified with security: [] and 200/503 (ok/degraded 200, unavailable 503), zero business-sensitive content; the no-secret fail-closed probe asserts 401/403 only on GET /api/v1/documents/query and /mcp/v1 and excludes all four health endpoints. Surfaces aligned: requirements (Edge, SC-004, SC-005, Measurement Sources), C-30, C-48, External Obligations, T023, T025, Q-05, Q-09, C-32, data-model §10, R-08, plan SC-005/SC-007 rows. Validators: validate-requirements status ok 0 error/0 warning; validate-tasks PASS 0/0; pre-analyze-check stage=tasks decision=pass with 0 errors and 2 pre-existing Txxx/Tyyy advisories; account-clause-coverage status ok with FR 29/29, 50/50 clauses and coverage-baseline-delta=0. No image build, no push, no code/template/test/generated artifact changed; no untracked docker-build.result touched. The A-line worktree HEAD advanced from the stated cfb9a677f to ffb6c8cb7, but requirements.md (the Endpoint Matrix owner) is unchanged between them; this was corrected in passing and disclosed.

## Optimization Points
- Copy cross-line route literals from the peer contract's Endpoint Matrix; an undefined business route can turn a fail-closed probe into a 404/vacuous pass (I-11).
- Collect a gate's corroborating evidence at the runtime surface that actually holds it: daemon nginx error_log is a file under ${OUTPUT_DIR}, not docker logs (I-12).
- Take health anonymity and status scope from the peer contract as a set (four endpoints, 200/503), not narrowed to the one endpoint used by the probe (I-06).
- When a named cross-line HEAD has advanced, verify the owning file's content across the range instead of assuming the stale SHA invalidates the contract.
