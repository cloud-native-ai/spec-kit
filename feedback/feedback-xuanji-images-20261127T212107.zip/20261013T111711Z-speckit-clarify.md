---
id: "20261013T111711Z-speckit-clarify"
unit_id: "/speckit.clarify"
unit_type: "command"
run_id: "020-ai-sre-dev-env-clarify-20261013"
scope: "local"
probe: "speckit-clarify-wrapup"
kind: "internal"
slice: "commands"
feature: "020-ai-sre-dev-env"
feature_id: "029"
partial: false
created: "2026-10-13T11:17:11Z"
summary: "Headless Mode-A clarify on spec 020: three preset rulings integrated (LightRAG form ratified against repo sources incl. the intentionally-empty lightrag services.yaml; Feature 029 created and bound af"
---

## Review
Headless Mode-A clarify on spec 020: three preset rulings integrated (LightRAG form ratified against repo sources incl. the intentionally-empty lightrag services.yaml; Feature 029 created and bound after evidence-based bind-vs-create scan; scope guard held — no new FR/SC), validator 0 errors/0 warnings, artifact committed 4475d78d. No question loop needed: rulings covered every Partial/Missing category, so coverage had no residual critical ambiguity. Same-author gate did not fire (spec authored in a prior session).

## Optimization Points
- 1. `check-prerequisites.sh` hard-fails on unset `CWS_LIB_BASH_HOME` even in `--paths-only` mode — a read-only path query that performs no validation is blocked by the lib-dependency check; the standard prelude `source bin/cws_images_env` never exports it. Workaround applied: `export CWS_LIB_BASH_HOME/CWS_LIB_PYTHON_HOME` to the existing `~/project/cloud-native-tools/` checkouts. Suggest skipping the dependency check for `--paths-only` (or covering the exports in the documented prelude).
- 2. token-efficiency — over-read of `bin/cws_images_env`: full 1471-line file read to learn which env vars it exports, where `grep -n CWS_LIB_BASH_HOME bin/cws_images_env` would have answered; rule going forward: grep first for env-var facts in large shell entrypoints.
- 3. `features.md` header drift: `Total Features: 27` vs 28 index rows (pre-existing), repaired in passing to the true count 29; the hand-maintained index has no drift guard — suggest a Layer-1 test asserting header count == index row count (literal-pinned drift-guard pattern).
