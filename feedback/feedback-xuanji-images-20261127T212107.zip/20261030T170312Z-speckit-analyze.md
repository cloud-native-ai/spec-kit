---
id: "20261030T170312Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261030T120500Z-b101-analyze3"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
feature: "051-xuanji-doc-build-chain"
feature_id: "048"
partial: false
created: "2026-10-30T17:03:12Z"
summary: "Analyze3 read-only re-verification of analyze-fix2 for 051: I-05 is closed (single-entry notes/no-change-set.sha256; hash and git diff green; no must-change file in the manifest; no stale manifest-wid"
---

## Review
Analyze3 read-only re-verification of analyze-fix2 for 051: I-05 is closed (single-entry notes/no-change-set.sha256; hash and git diff green; no must-change file in the manifest; no stale manifest-wide sha256sum -c). The I-10 attribution core is closed: the byte probes now target the nginx-served static path /cgit-css/cgit.css; an empirical nginx 1.24 probe on the local daemon-derived image produced at-limit=405 (not 413), limit+1=413, and the expected 'client intended to send too large body' error-log line. INC-03 is closed: config/ingest/ is an ingest-owned (UID 1100) writable subtree for jobs/, jobs/keys/ and audit.jsonl, config root stays api-owned (UID 1101), api is read-only on the subtree, and retention/program-to-mount references align with 023 C-55/C-07. I-06 is only partial: 051 carves out only GET /api/v1/system/health and requires 200, while the A-line 010 Endpoint Matrix and 023 C-03 define four anonymous health endpoints (knowledge/documents/code/system) with 200 or 503; the no-secret business probe and the upload-route exclusion use POST /api/v1/documents, which A does not define (its upload route is POST /api/v1/knowledge/push) - new MEDIUM I-11. New MEDIUM I-12: T025/Q-09 collect the nginx 'client intended to send too large body' line from docker logs, but daemon nginx.conf writes error_log to ${OUTPUT_DIR}/nginx.stderr (a file) and nginx.sh only redirects process stdout/stderr, so the retrieval point is wrong. Both new HIGH candidates were independently validated and downgraded to MEDIUM. Severity recalc: 0 CRITICAL / 0 HIGH / 13 MEDIUM / 7 LOW. Validators pass (validate-requirements 0/0, validate-tasks PASS, account-clause-coverage FR 29/29 and 50/50 clauses with baseline delta 0, pre-analyze-check pass with 2 pre-existing advisories). Read-only: no artifact changed outside this run record; no image build; no push.

## Optimization Points
- Re-run a repaired acceptance command's literal collection step against the actual runtime log destination; a status-code probe can be sound while its corroborating evidence is unretrievable (nginx error_log is a file, not docker logs).
- Copy route names from the peer contract's Endpoint Matrix rather than inventing defaults: POST /api/v1/documents does not exist in the A-line contract; the upload route is POST /api/v1/knowledge/push. An undefined business route turns a fail-closed probe into a possible 404/vacuous pass.
- Take health anonymity and status scope from the peer contract as a set (four endpoints, 200/503), not narrowed to the one endpoint used by the probe; a MUST-200 expectation is stricter than the A-line's 200/503 and can false-fail when a dependency is degraded.
- Use the B-line's config-volume subdirectory granularity (config/api/ vs config/ingest/) or state explicitly that the root-owner model is a superset; the ingest subtree alone closes the original cross-line defect.
- Refresh the Feature 048 detail when a cross-line decision reverses (INC-03); its Latest Review still records the superseded 'config api-only' statement and lacks the tasks/analyze stage entries.
