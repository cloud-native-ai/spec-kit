---
id: "20261031T222149Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "r20261101T062000Z-i1a0"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
feature: "049-l3-component-design"
feature_id: "046"
partial: false
created: "2026-10-31T22:21:49Z"
summary: "requirements stage for the xuanji-images L3 design page: repo survey measured 2475 templates / 1721 snippets / 55 services.yaml / 10 design pages; four input corrections (no existing index page; layer"
---

## Review
requirements stage for the xuanji-images L3 design page: repo survey measured 2475 templates / 1721 snippets / 55 services.yaml / 10 design pages; four input corrections (no existing index page; layered-not-blanket convergence because five pages self-declare as rule owners; overview.md counts expired; compose artifacts gitignored) each changed the requirement set; validator ok (28 FR / 7 SC / 6 strings), pre-analyze pass 0 error / 21 path advisory, decomposition proceed (28<=30).

## Optimization Points
- 1) doc-consistency evidence face is not-evaluated until the artifact has a commit (its clock is git log -1 -- path), so a pre-commit gate run necessarily exits 1; the gate order in the requirement stage should say commit-then-evidence or accept the pre-commit record as a declared degradation. 2) flow-class-check --action lookup accepts only /speckit.<stem> or skill:<dir>, so a spec deliverable cannot be looked up; the quartet's error slot then records invalid-unit-id while the class rests on the owner's reader-oracle rule — worth an explicit 'spec-level unit' form. 3) create-new-requirements.sh force-creates and switches to <NNN>-<slug>, which conflicts with a line/<id> branch convention; scripting the spec dir without the branch would remove the manual scaffold path used here.
