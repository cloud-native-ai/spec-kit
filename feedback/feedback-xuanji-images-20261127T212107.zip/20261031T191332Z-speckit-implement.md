---
id: "20261031T191332Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261030T120500Z-b101-impl-s3e"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "051-xuanji-doc-build-chain"
feature_id: "048"
partial: true
created: "2026-10-31T19:13:32Z"
summary: "Partial run — Spec 051 segment 3e rebuilt the chain on the final B source e6d88761 (merged main; lightrag 30e08fd2) and re-verified T017–T019/T022/T024; T023 remains [~] on the /docs/ route. Generatio"
---

## Review
**Partial run** — Partial run — Spec 051 segment 3e rebuilt the chain on the final B source e6d88761 (merged main; lightrag 30e08fd2) and re-verified T017–T019/T022/T024; T023 remains [~] on the /docs/ route. Generation --check exit 0; fetcher sha256:4e29f771 carries HEAD e6d88761; project sha256:4d7083c55951 (session 1793472956293758787) and service sha256:1e8ef445038c (session 1793473153589959113); both leaves 8/8 RUNNING. Verified ten byte-identical L1 blocks, 25 guard tests, Q-04 hugo self-heal with the other seven PIDs unchanged, all eight log prefixes (cgit/nginx via controlled bind-failure injection and restore), L1 capabilities and volume owners, the service leaf tool-free runtime, and the same-bridge-network port posture (six internal ports CLOSED; 80/443/10022 OPEN). The final source resolves the business-method conflict: GET /api/v1/documents/query is 401 anon and 200 with Bearer q=probe on both images; the rest of the matrix passes (browser 401/200, four health 200/200 with no business data, MCP 401/200, /api/kb/query 404, ExposedPorts 80/443/10022). cws /docs/ remains 404. Diagnosis on the final image: nginx proxies the raw /docs/ prefix as contracted and direct :1313 probes also 404; hugo 0.148.2 server registers a malformed ///docs/ prefix for a host-less baseURL, and only an absolute baseURL serves /docs/ (relative variants all 404; root baseURL serves only /). Every available workaround breaks a frozen clause (B C-02/C-06/C-46; 051 C-29/C-33), so T023 stays [~] and the line stops after T024. Disclosed test-side correction: named volumes were first pre-seeded at a nonstandard mount point, which skipped Docker copy-up and made graphicle crash-loop; the volumes were recreated and the image initialized the owners (graphicle stable thereafter). Evidence: notes/quickstart-run.md § Segment 3e plus notes/T017-*-s3e.log, T018-runtime-s3e.log, T019-s3e.log, T022-runtime-s3e.log, T023-{project,service}-s3e.log, T023-docs-diagnosis-s3e.log and T024-s3e.log.

## Optimization Points
- Freeze C-24 hugo runtime only after a live probe of the chosen baseURL form: hugo server 0.148.2 cannot route a host-less baseURL, so B C-46 baseURL=/docs with no port is unsatisfiable under the raw-prefix proxy contract; escalate at plan time instead of at T023. Derive KB_FETCHER_CACHE_BUST from the pinned SHA so a pin change automatically invalidates the clone layer. Provide a volume seeding helper that never pre-populates named volumes at nonstandard mount points, preserving Docker copy-up and image-init ownership. Compare the document query method in the pin check (GET vs POST) so a route-method drift is visible. token-efficiency: the diagnosis re-ran four hugo servers sequentially; one matrix of baseURL variants would have sufficed.
