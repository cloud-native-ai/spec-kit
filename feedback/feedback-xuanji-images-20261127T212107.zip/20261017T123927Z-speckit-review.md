---
id: "20261017T123927Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "20261017T123558Z"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
feature: "032-prebuild-conversion-artifacts"
feature_id: "030"
partial: false
created: "2026-10-17T12:39:27Z"
summary: "/speckit.review 命令跑（032-prebuild-conversion-artifacts，SDD 无人值守循环的最后执行阶段）。承载技能 review-sdd-process 的 7 步全部执行：① 可移植上下文（含 commit 可达性核验：`git branch -r --contains HEAD` 为空 + remote 为 SSH-only，故全报告用绝对路径 + `g"
---

## Review
/speckit.review 命令跑（032-prebuild-conversion-artifacts，SDD 无人值守循环的最后执行阶段）。承载技能 review-sdd-process 的 7 步全部执行：① 可移植上下文（含 commit 可达性核验：`git branch -r --contains HEAD` 为空 + remote 为 SSH-only，故全报告用绝对路径 + `git show <sha>:<path>` 恢复式，不用任何 blob/ URL）；② 过程执行史（`git log -- .specify/specs/032-*` 得 10 提交，**按阶段/故事分组**，故 §1 时间线为 commit-traced 而非 artifact 推断，未触发 SKILL.md §2 的降级路径；另纳入 1 条非本线提交的外部事件）；③ 核心产物加载（7524 行，超大单行文档一律窄投影 grep/sed 取段，未整读 requirements.md 160 KB / tasks.md 115 KB）；④ 问题优先诊断得 15 项发现；⑤ 2 项 P0 各派一个 fresh-context 只读验证子代理（与检测互斥；同作者门经判定**未触发**——产物均于 2026-10-16 由前序会话提交，本跑为 2026-10-17 新会话且非作者）；⑥ 按 review-template 填全 9 节 + 3 附录；⑦ 汇总。结果：1 P0（confirm，且被验证者加强）/ 10 P1 / 4 P2（其中 1 项由 P0 降级）；类别 Template 3 / Command Prompt 0 / Automation 5 / Workflow 6 / Documentation 1。P0 为 F1：三个 032 叶子的完整生成产物由 root 于 19:55:07–19:55:15 落地，而 verification.md 于 ~20:40 撰写、20:50:54 提交，仍断言「0 of 5 leaves generated」「No generated artifact exists for this leaf」；同时 GATE-4 作为「前提被推翻后更严格重指」而采纳的排除式 `-not -path '*/sandbox-rootfs-minimal/*'` 指向一个当前不存在、且 git 全历史从未存在的路径，raw 与 strict 两式同返 2408，即该「更严格」是空操作——已扩散到 8 个文件含 2 份已发布参考文档与长期特性注册表。阶段指令三项附加要求均已落地：开放问题全部自裁决并记于 §A1（8 条，各附 ①权威链/②仓库权威文档/③先例 的依据，未虚构用户裁决）；2 个在途脏文件的归属与处置建议记于 §A2（判为并发 sandbox-rootfs 流所有、非 032 产物、非丢弃候选，附 6 条证据；**未提交未还原**）；验证记录与降级率记于 §A3。本跑自查抓到并修复自身 1 处真实缺陷（§5 18 条建议 vs §6 17 行路线图，补齐第 18 行），另有 1 处「Source: 缺失」经查为 shell grep 对 `§` 的编码假警（Python 复核为 0），两者都在 §7 明写以免把假红当真红。仅提交本阶段产物；未 push；未合并（合并由主代理执行）；未读未改未提交 /cws_work/sandbox。

## Optimization Points
- 改点 A（run-determination.py 的 artifact_correctness 轴 / 无测试面阶段）: 该轴对纯文档阶段结构性不可评估。本跑声明 6 项检查（placeholder-token-census / location-field-absoluteness / finding-severity-category-census / rec-to-roadmap-count / finding-id-cross-reference / p0-validation-delegated-disjoint）并全部转绿，`--red-first-refs` 指向 review.md，引擎仍记 `declared_checks: 6` + `green_evidence.status: not_evaluated` + `reason: no_baseline`。轴的实现是 Layer-1 名字级 diff，而 review/docs 阶段不触代码，故无论红先证据多充分都恒为 not_evaluated。建议二选一：为无测试面的阶段开第二条评估路径（按 declared/green check 对账判定），或在 reason 词汇里把 `no_baseline`（缺基线）与 `axis_not_applicable`（该阶段无此面）分开——否则「诚实记为未评估」与「该轴根本不适用」在记录里不可分辨，下游改进无法定位。此为 272d744f 已上送的顺序缺陷（演练记录成文在 determine 之后、且 determine 拒绝重复）的第二次复发，按 fast-fail「一轮内复发即升级」处理。
- 改点 B（run-determination.py --action history --unsettled）: 无法跨 unit 枚举未结算记录。`--unsettled` 省略 `--target` 时报 `error: --target is required for history`，而结算纪律（本仓既有提交惯例「同趟结算上一轮…的满意度轴」）要求先找到未结算记录才能结算。本跑只能靠已知 unit-id 逐个试探，才发现一条 2026-10-13 的 /speckit.review 记录 `feature: None`，经 `git log --diff-filter=A -- '.specify/specs/*/review.md'` 比对判定属 020-ai-sre-dev-env 特性（commit 96b928a6），遂按 7d42697c 的先例（「跨特性且无证据判定其后那一回合的性质，猜测即伪造」）未代为结算。建议 `--unsettled` 允许省略 `--target` 并返回全库未结算清单，使「该不该结算」成为可枚举的判断而非靠记忆。
- 改点 C（review-sdd-process/SKILL.md §4 诊断步骤，规则覆盖面）: 「Counts are enumerated, never asserted」当前只写在 §5 验证步骤，只约束验证子代理的 brief，不约束评审者自己的诊断——本跑正是自己先犯了它。F12 初判 P0 时用 `grep -c 'UNCOVERED'` 得 107 并断言「107 of 107 属其他特性」，验证子代理逐 lane 枚举后发现是 `UNCOVERED:` 89 + `UNCOVERED-FR:` 18 的两 lane 混淆，其中 18 条恰是本特性自己的 FR，P0 因此下调为 P2（降级率 1/2）。建议把该规则同样写进 §4：凡一项发现声明 N 次出现，必须先逐条锚定每个实例再落严重级；`grep -c` 的行计数与 `grep -o | wc -l` 的串计数也必须分清（同一跑里 tasks.md 的锚点串就因此被记成 6 而实为 6 行 9 串）。
- 改点 D（token-efficiency）: 本跑可避免的消耗，按大小排序。（1）定向用 `git log --format='%h %s' -14` 花掉 10,899 字符，因为 032 线上有 4 个提交把整份跑报告写进 subject（3981 / 2661 / 1400 / 450 字符，body 仅 1 字符）——这笔开销正是随后立案的 F4 本身，本可用 `--format='%h %ad'` 拿排序、再按需 `git show -s --format=%b <sha>` 取单条正文来避免；同一特性后 6 个提交已是 subject≈200 + body 5k–16k 的正确形态，说明约定存在只是未被强制。（2）F1 的调查用了 5 次串行探针，而决定性事实（三个 032 叶子都已存在 root 生成的完整产物集）一条 `ls -l` 即可拿到，前 3 次窄探针（find 存在性、git 历史、build-session 时间戳）可合并为一次批处理。（3）`account-clause-coverage.py` 跑了两次（一次做条款普查、一次复核验证者的更正），首次即把输出落盘到 /tmp 再复用即可，第二次约 2 KB 重复输出属可避免。（4）读 `verification.md` 全文（207 行 / 31 KB）与 `tasks.md` 门禁段是必要开销，不列为可避免。
