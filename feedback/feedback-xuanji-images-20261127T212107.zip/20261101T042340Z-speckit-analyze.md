---
id: "20261101T042340Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261101T042332Z-a1a0"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
feature: "049-l3-component-design"
feature_id: "046"
partial: false
created: "2026-11-01T04:23:40Z"
summary: "analyze re-ran 9 gate families over 30 FR / 9 SC / 36 tasks / 48 CHK; all deterministic gates green (validate-requirements 0/0, validate-tasks 0/0, pre-analyze 0 errors at 86 missing-path advisories p"
---

## Review
analyze re-ran 9 gate families over 30 FR / 9 SC / 36 tasks / 48 CHK; all deterministic gates green (validate-requirements 0/0, validate-tasks 0/0, pre-analyze 0 errors at 86 missing-path advisories per stage, decomposition proceed 30/36, doc-consistency reader/evidence/duplicate pass, docs-utils 0 violations); findings 1 HIGH (FR-006 enumerates docker-scan.sh/docker-import.sh as current generated artifacts, but templates/docker has 6 tpl and docker-scan is guarded as removed), 7 MEDIUM, 4 LOW; verdict FAIL -> remediation-required

## Optimization Points
- analyze needs a fresh-context validation wave for CRITICAL/HIGH but this runtime exposes no subagent dispatch surface; direct re-read fallback was marked. The declared prerequisite script check-prerequisites.sh hard-depends on CWS_LIB_BASH_HOME, so it exits 1 in a client repo; analyze resolved the required artifacts by direct path check. The checklist stage left 48/48 items unchecked, so pass-H accounting fell to analyze; consider requiring checklist dispositions at its own wrap-up.
