---
id: "20261013T062831Z-speckit-feedback"
unit_id: "/speckit.feedback"
unit_type: "command"
run_id: "feedback-digest-20261013T0624Z"
scope: "local"
probe: "speckit-feedback-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-13T06:28:31Z"
summary: "消化运行：帽子判定=客户项目（根级缺 4/5 框架源目录，root templates/ 属镜像工厂；backlog 两行在案）。5 条 open 经自省分流入 introspection-20261013T061552Z.md（F-01/F-04 upstream、F-02 local-sink、F-03 同 run 已修、1 排除），用户确认后处置 5 条、mark-submitted 重置计"
---

## Review
消化运行：帽子判定=客户项目（根级缺 4/5 框架源目录，root templates/ 属镜像工厂；backlog 两行在案）。5 条 open 经自省分流入 introspection-20261013T061552Z.md（F-01/F-04 upstream、F-02 local-sink、F-03 同 run 已修、1 排除），用户确认后处置 5 条、mark-submitted 重置计数（10→0）、整批归档 feedback-20261013T062420Z.zip、客户帽清理后活动库清零；backlog 关 3 行（2026-10-07 包经用户确认送达）开 3 行。序列偏差如实披露：mark-submitted 先于本 run 打包执行，致包混入 local-sink 条目且报告未能嵌入（作为独立文件随包交付）；排除条目 ref 用了格式合法但虚构的 F-99（引擎无法清除，已披露）。积压直修：知识条目 probe-validate-reconcile-embed-02b0bfa2 落盘并关闭 2026-10-08 行。

## Optimization Points
- mark-submitted 的"归档 pending 批"语义与消化流时序冲突：在包仍未 produced 时运行会把 local-sink 与 upstream 条目一并扫进审计 zip 且无法事后用 --include-introspection 补报告；feedback-step.md/Path B 应加时序警示（mark-submitted 只能是本 run 的最后一步）。
- cleanup --package 的路径解析只认 packages/ 相对名或 latest 关键字，传 zip 文件名或 .specify/ 相对路径均报 not found，--help 未说明可接受形态。
