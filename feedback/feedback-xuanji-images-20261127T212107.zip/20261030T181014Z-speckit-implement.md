---
id: "20261030T181014Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261030T120500Z-b101-impl-s2"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-30T18:10:14Z"
summary: "Implemented spec 051 segment 2 (T009–T016) only, in task order; no image build and no push. T009 added the L1 nginx snippet (fragments copied from images-shared-service, envsubst-rendered SPA fragment"
---

## Review
Implemented spec 051 segment 2 (T009–T016) only, in task order; no image build and no push. T009 added the L1 nginx snippet (fragments copied from images-shared-service, envsubst-rendered SPA fragment, cgit asset assertion, nginx -t) after extending the nginx guard test-first (red 1 failed/12 passed → green 13 passed). T010 added the dual-binary install snippet (red FileNotFoundError → 1 passed). T011 fixed the CGIT_SCAN_PATH passthrough in install/cgit and the build-time scan-path write in config/cgit (red 1 failed/3 passed → 4 passed; full module 14 passed). T012 built graphicle and graphicle-graph from one pin and updated the builder template (red 2 failed/3 passed → 5 passed; legacy snippet sha256 OK). T013 rebuilt the project leaf on images-daemon-alios-8 with the ordered ten-snippet L1 block and the single corepack-pnpm L2 row (red 5 failed/1 passed → 6 passed); it also authored the plan-declared but task-unnumbered install/nodejs-runtime.dockerfile and project/build/kangaroo-xuanji/corepack-pnpm.dockerfile and the install/hugo.dockerfile default owner. T014 rewrote the project build snippet (red 2 failed/2 passed → 4 passed). T015 deleted the leaf-local supervisor tree, set services.yaml to bare 80/443 and the web app row to NGINX_HTTP_PORT (red 3 failed → 3 passed); because the residue guard also covers the T020/T021-owned service leaf and old service install snippet, two minimal pre-cleanups were landed and disclosed. T016 ran cws_images_generate_all (exit 0) and --check (exit 0); the generated project Dockerfile has the daemon parent, ordered L1 imports, corepack+npm L2 import, no leaf port macro/EXPOSE, six supervisor copies, both nginx fragments, three knowledge volumes; generated scripts pass bash -n. Step 0 re-capture: three of four reference hashes changed and are attributable to T012/T015; the no-change manifest verifies OK; coverage status=ok with fr-uncovered=0 and delta=0. Remaining guard reds are attributed forward: build_chain version/parity assertions wait for T020, and test_web_app_table's xuanji-doc expectation plus the bare-80 discovery ambiguity wait for T033. ANOMALY: the brief's 6 untracked docker-build.result files do not exist in this worktree (clean at start and end).

## Optimization Points
- tasks.md T015's residue selector scans the T020/T021-owned service leaf and old service install snippet, so T015 cannot pass as written until those rows run; scope such selectors to the row's owned surface or order the service rebuild earlier.
- tasks.md still has no row authoring install/nodejs-runtime.dockerfile, project/build/kangaroo-xuanji/corepack-pnpm.dockerfile or the install/hugo.dockerfile default owner even though plan.md declares them; either append rows or name them in T013.
- The web app table discovery maps bare daemon port 80 to xuanji-doc's new NGINX_HTTP_PORT row, making every other leaf's bare-80 services.yaml an unresolved ambiguity; T033 must fix the discovery heuristic (exclude daemon-inherited ports) rather than only the row expectation.
- Generated docker-build.json aggregates dependency-chain ports (web-workspace, cgit 28080/28443) beyond {80,443,10022}; the leaf Dockerfile still inherits only daemon EXPOSEs, so T023 must verify with docker inspect rather than the JSON port map.
- This worktree has no .venv; generation ran through cws_py_cmd's system Python 3.11.13, which has click/jinja2/yaml. The documented prelude should state the fallback instead of implying .venv is required.
