---
id: "20261030T165121Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261030T120500Z-b101-analyze-fix2"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
feature: "051-xuanji-doc-build-chain"
feature_id: "048"
partial: false
created: "2026-10-30T16:51:21Z"
summary: "Analyze-fix2 repaired the two analyze2 HIGH findings plus the cross-line CRITICAL and the health-口径 MEDIUM for 051. I-05: T031/GATE-5/T029 now share a single-entry no-change manifest (notes/no-change-"
---

## Review
Analyze-fix2 repaired the two analyze2 HIGH findings plus the cross-line CRITICAL and the health-口径 MEDIUM for 051. I-05: T031/GATE-5/T029 now share a single-entry no-change manifest (notes/no-change-set.sha256) plus git diff --exit-code; the old five-entry pre-change manifest is split and no longer fed to sha256sum -c. I-10: the 413 boundary probes now target the nginx-served static path /cgit-css/cgit.css (no upstream) and archive the nginx error-log line as attribution evidence; application upload routes and their own 413 limits stay owned by the xuanji-api contract. INC-03: config/ingest/ is now an ingest-owned (UID 1100) writable subtree with jobs/, jobs/keys/, audit.jsonl and 023 C-55 retention; the config root stays api-owned and a program-to-mount matrix is registered. I-06: GET /api/v1/system/health is the anonymous A-line endpoint (200, no business-sensitive content) and is excluded from the no-secret 401/403 set; fail-closed is asserted on a business /api/v1 route and /mcp/v1/. Validators pass: validate-requirements 0/0, validate-tasks PASS, pre-analyze-check decision=pass with 2 pre-existing advisories, account-clause-coverage FR 29/29, clauses 50/50, baseline delta 0. Spec text only; no image build, no push, no code/template/generated artifact change.

## Optimization Points
- Verify a replacement no-change gate by running its literal command on a simulated post-change tree; keep a dedicated must-not-change manifest so must-change files cannot make the gate red. An at-limit positive control for a proxy-layer limit needs intrinsic attribution: probe a route with no upstream and archive the proxy error log, not a bare status code from an application route. A cross-line External Obligation is not closed until the image-side contract names the owner, the writable subtree and the retention policy; an ANOMALY note alone is not alignment. When a sibling line declares an anonymous health endpoint, carve it out of the fail-closed probe set explicitly and assert its 200/no-sensitive-content behavior instead. Keep the app-level upload limits and the proxy body limit as separate owners, and exclude the app routes from the proxy-boundary judgment.
