---
id: "20261031T205345Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261030T120500Z-b101-impl-s3g"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "051-xuanji-doc-build-chain"
feature_id: "048"
partial: false
created: "2026-10-31T20:53:45Z"
summary: "Spec 051 segment 3g rebuilt the xuanji-doc chain on B source 31439e4b (023 review-fix8 locked mode) and closed T025 by measurement, with no assertion weakened."
---

## Review
Spec 051 segment 3g rebuilt the xuanji-doc chain on B source 31439e4b (023 review-fix8 locked mode) and closed T025 by measurement, with no assertion weakened.

Change: the fetcher template cache-bust moved 20261101c -> 20261101d and its pin comment now names 31439e4b (lightrag gitlink unchanged 30e08fd2). Generation ran first (cws_images_generate_all rc=0; --check rc=0). Four images were rebuilt: shared-service sha256:c83643e3a3e5 (session 1793479010887810766), fetcher sha256:24d6fcfb1a8b (session 1793479019020125211; in-image HEAD 31439e4b + lightrag 30e08fd2), project sha256:5305815f5178 (session 1793479063967588543), service sha256:d53383b45c0d (session 1793479240948531941). The project and service containers each show 8/8 RUNNING with the three named volumes and the secret mount; the project in-image source HEAD is 31439e4b.

T025 all four branches passed on both leaves. nginx -T shows /mcp/v1 proxy_buffering off + proxy_cache off + connect 60s/send 3600s/read 3600s, /api/v1 60s, and the daemon client_max_body_size 1G (lines 141/301). An MCP system_health tools/call returned 200 SSE with TTFB 0.055287 < total 0.056033 (project) and 0.055842 < 0.056592 (service), no secret or internal-port leak. The byte-exact probes on /cgit-css/cgit.css measured at-limit 1073741824 B = 405 (not 413) and limit+1 1073741825 B = 413 on both leaves, with the nginx.stderr attribution line "client intended to send too large body: 1073741825 bytes ... POST /cgit-css/cgit.css" read by docker exec. The no-secret containers (project and service; no secret mount, no CWS_CONTEXT_KEY_FILE env) now start the api in locked mode (023 C-15): api RUNNING with 8/8 programs; browser /, /docs/, /cgit/ = 401; the four health endpoints return 503 with the Health envelope (status=unavailable, version=1.0.0, auth check unavailable) and no business content, ports or secret, and health with the real Bearer still returns 503; GET /api/v1/documents/query with anon, the real Bearer, a random Bearer and Basic cws:secret all return 401, and MCP initialize anon/real/random plus tools/call with the real Bearer all return 401, none containing business content. This closes the s4 cross-line ANOMALY without relaxing the contract.

T023 was re-verified on both rebuilt leaves: anon /, /docs/, /cgit/ = 401; cws = 200; /docs no-slash = 301; /docs/ is a 26,793 B Hugo page titled 璇玑智能运维平台; four health anon+Bearer = 200/503 Health; documents/query anon=401 and Bearer q=probe=200; MCP initialize 401/200 SSE xuanji-doc-api 0.1.0; /api/kb/query = 404; ExposedPorts 80/443/10022 with matching docker-build.json rows. T024 was re-verified from a same-network container: 1313/28080/8854/9621/8900/44145 CLOSED and 80/443/10022 OPEN on both leaves; the generated leaves carry no EXPOSE and no internal-port CWS_MICRO_PORT. A demo.git fixture was seeded into the shared git volume so /cgit/ returns 200; the empty-volume 404 remains the disclosed upstream cgit behavior. T022's rebuilt service leaf recheck passed (8/8, no extra build tools, no source tree, entries and assets present). The xuanji_doc guard suite passed 44 tests; generation --check rc=0; the no-change set and coverage baseline remain green.

No image was pushed; no plan, contract or quickstart was edited (PLAN-EDIT: none); only explicit paths were staged. Evidence: notes/generate-s3g.log, generate-check-s3g.log, T022-{shared-service,service}-build-s3g.log, T017-{fetcher,project}-build-s3g.log, T017-runtime-s3g.log, T022-runtime-s3g.log, T025-{nginx-T,mcp-stream,body-limit,fail-closed}-s3g.log, T023-matrix-s3g.log, T024-s3g.log, green-T023-guard-s3g.log, and notes/quickstart-run.md Section Segment 3g.

## Optimization Points
- The interactive shell defines a `truncate` function that truncates output lines, not files; the first 1 GiB boundary attempt silently created no sparse files and measured 405/405. Use `command truncate` (alias-proof form) in every probe script, and assert the file size before posting.
- The no-secret branch's assertion set could also exercise the empty-file and unreadable-file variants that 023 C-15 names, not only the missing-file case; this run tested the missing-file case on both leaves and left the other two variants to the owner's contract tests.
- `/cgit/` returns 404 "No repositories found" on an empty repos volume; the T023 matrix needs a fixture repository to assert 200. Seed `demo.git` as the ingest identity before the matrix, as the prior segments did.
- The fetcher pin is branch-based; each B review-fix requires a cache-bust bump and a full clone. Recording the resolved commit in the pin comment keeps the rebuild auditable, but the build still depends on the branch tip at build time (the in-image HEAD check is the guard).
- token-efficiency: the four image rebuilds dominated wall time (the project leaf re-runs the pnpm/Hugo build), while the 1 GiB probes return at header time (405/413) so only status codes and the single attribution line were consumed; the MCP trace was reduced to timing lines and leak counters. Qualitative observation only; no token count was measured or claimed.
