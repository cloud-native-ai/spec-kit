---
id: "20261031T181946Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261030T120500Z-b101-impl-s3d"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "051-xuanji-doc-build-chain"
feature_id: "048"
partial: true
created: "2026-10-31T18:19:46Z"
summary: "Partial run — Spec 051 segment 3d (T017–T024) rebuilt the chain end to end and closed T017–T019, T022 and T024; T023 remains [~] on two frozen-interface conflicts. Verified the Hugo 0.148.2 mirror bac"
---

## Review
**Partial run** — Partial run — Spec 051 segment 3d (T017–T024) rebuilt the chain end to end and closed T017–T019, T022 and T024; T023 remains [~] on two frozen-interface conflicts. Verified the Hugo 0.148.2 mirror backfill (official SHA256 dff500ad…), rebuilt the Hugo fetcher, the source fetcher (cache-bust 20261101b; HEAD 247b4482; lightrag 30e08fd2), the graphicle builder and the shared-service image (so the current six supervisor pairs ship), then built project sha256:0f5de076… (session 1793469118341164305) and service sha256:d0d86842… (session 1793470032230390703). Both containers show 8/8 RUNNING; the source workdir is writable by service; api/ingest entries exist; L1 versions, UIDs, volume owners, six internal port ENVs, six supervisor pairs and nginx -t all pass. The route matrix on both images passes browser Basic auth, four anonymous health 200/200 with no business data, MCP 401/200 handshake, /api/kb/query 404 and ExposedPorts 80/443/10022; the C-17-intent port probe shows the six internal ports CLOSED from a same-bridge-network container. T023 fails on (1) cws /docs/ = 404: the delivered site sets enableGitInfo=true (the runtime image has no .git) and per-language contentDir ../../model/content/{zh,en} overrides --contentDir , and hugo 0.148.2 server only routes with an absolute baseURL, contradicting B FR-017 / C-24; (2) GET /api/v1/documents/query = 405 because the delivered B route table defines POST (POST anon=401, POST bearer=200). Corrections applied in passing: graphicle --host→--listen (v0.1.8 CLI), shared-service rebuild, cache-bust bump. Evidence: notes/quickstart-run.md § Segment 3d plus notes/T017-runtime-s3d.log, T018-runtime-s3d.log, T019-s3d.log, T022-runtime-s3d.log, T023-{project,service}-s3d.log and T024-s3d.log.

## Optimization Points
- Add a pre-build cross-line runtime gate that greps the delivered site config for enableGitInfo and language contentDir, launches hugo server with the frozen flags against a seeded docs volume and asserts /docs/ 200; the B line's own live probe was skipped, so its parameter set was never exercised. Align the business probe method across the A-line matrix, the B route table and its pinned OpenAPI (GET vs POST); the pin check compares only path sets, so a method drift is invisible — compare methods too. Replace Q-06's '--network container:' + 127.0.0.1 probe with a same-bridge-network container and the target container IP; the literal command joins the target network namespace and cannot observe CLOSED. Derive the fetcher cache-bust from the pinned SHA so a pin change automatically invalidates the clone layer. token-efficiency: the first project build was repeated after discovering the stale shared-service image; a pre-build digest check of the shared supervisor assets would have saved one L2 payload rebuild (~4 minutes).
