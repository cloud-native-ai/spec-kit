---
id: "20261023T025453Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "r20261023T024449Z-ae8e"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
feature: "042-nginx-layered"
partial: false
created: "2026-10-23T02:54:53Z"
summary: "Requirements 阶段在无人工确认下把技术简报转成 042-nginx-layered 规格：6 个用户故事（25 条 Given/When/Then）、38 条 FR（A–E 五组）、8 条 SC 与 16 条 Shared Strings；确定性校验器最终 status: ok（0 error / 0 warning）。主要裁决为 render 六引擎按 direct 行拆六条、gra"
---

## Review
Requirements 阶段在无人工确认下把技术简报转成 042-nginx-layered 规格：6 个用户故事（25 条 Given/When/Then）、38 条 FR（A–E 五组）、8 条 SC 与 16 条 Shared Strings；确定性校验器最终 status: ok（0 error / 0 warning）。主要裁决为 render 六引擎按 direct 行拆六条、grafana 走 in-image、deepseek-harness 保持 loopback、既有脏文件在 A7 登记为实施期须谨慎改写的目标。表格行数与 gateway 叶子数是口径而非验收目标，验收锚定覆盖率与九栈×两发行版。

## Optimization Points
- Shared Strings 引用形态：首轮把 [[STR-NNN]] 写进 code span，validate-requirements.py 报 35 个 ref-resolvable 错误（该脚本第 22 行明确“outside a code span”才计数）。同类 spec 直接写裸 [[STR-NNN]] 可省一轮校验往返；建议 create-requirements 在写 Shared Strings 的步骤里点名此约束。
- 简报口径：“render 六引擎”可被读成 1 行（多端口）或 6 行（单端口）；本阶段裁决为 6 个 direct 行并记入 Assumptions A1/A2。上游技术简报宜直接给出行数口径，减少下游自裁决。
- token-efficiency：一次 `git branch -a` + `features.md` tail 的组合探查产出 77KB 输出并被截断落盘，实际只用了前 30 行；后续同类探查应先限定字段（ID/名称列）与行数，避免整表进上下文。
- 脏树重叠：hermes web-proxy 与 dsh-web 的既存未提交修改正好落在 FR-007/FR-008 的目标文件上；已在 Assumptions A7 显式登记“实施阶段须在不丢失既有修改意图的前提下改写”，避免 implement 阶段静默丢弃用户在建工作。
