---
id: "20261031T063356Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261030T120500Z-b101-analyze-fix4"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
feature: "051-xuanji-doc-build-chain"
feature_id: "048"
partial: false
created: "2026-10-31T06:33:56Z"
summary: "Analyze-fix4 aligned 051 build inputs and entry commands with B (023) actual implementation. C-39 now validates root package.json (engines/packageManager/scripts.build, no root bin), pnpm-lock.yaml, s"
---

## Review
Analyze-fix4 aligned 051 build inputs and entry commands with B (023) actual implementation. C-39 now validates root package.json (engines/packageManager/scripts.build, no root bin), pnpm-lock.yaml, service/api/pyproject.toml, service/ingest/package.json bin xuanji-doc-ingest plus tsx, a populated service/lightrag submodule, view/site and build/; requirements.txt is no longer an input. C-40 installs service/api via pip install ./service/api (assert xuanji-doc-api) and ./service/lightrag[api] (assert lightrag-server), both non-editable, dropping cws-lib-python/cws_daemon. C-41/C-42 produce a self-contained ingest tree (package.json, tsconfig.json, src and the lockfile-resolved tsx closure) and argv XUANJI_DOC_API_BIN/XUANJI_DOC_INGEST_BIN; runtime.env maps CWS_API_PORT/CWS_CONFIG_DIR/CWS_DOCS_DIR/CWS_INGEST_URL/INGEST_BIND. C-24 runs xuanji-doc-api and node --import tsx with CWD the ingest tree, reads CWS_CONTEXT_KEY from /run/secrets/cws_context_key, all six programs loopback. The install snippet now copies argv.env and asserts both entries; services.yaml declares secrets cws_context_key; config/api is pre-created for api. Submodule acquisition verified at the pinned cws-lib-bash 2026-10 tag (git_clone_into already uses --recurse-submodules); T017 adds the fetcher cache-bust rebuild. Evidence: exact snippet one-liners executed against B (validation rc=0; tsx closure = tsx/esbuild/@esbuild/linux-x64; node --import tsx src/server.ts listened on 127.0.0.1:45146 and /health=200); pip install with C-40 flags produced xuanji-doc-api --help. Validators: validate-requirements ok 0/0, validate-tasks PASS 0/0, pre-analyze-check pass 0 errors with 2 pre-existing Txxx/Tyyy advisories. The Layer-1 guard observed 21 passed and 4 expected reds because tests were outside the allowed surface; T005/T014/T016/T018 are marked [~] with the guard/generation follow-up. No build, no push, no generated artifact hand-edit, no untracked file touched. Disclosed: brief HEAD e304df3e is an ancestor (actual 3ba6d3f2); 5 docker-build.result plus 1 notes/generate-T017.start = 6 untracked; B fix3 is staged uncommitted; the lightrag [api] extra is inferred from B README because the submodule is uninitialized.

## Optimization Points
- Copy build-input literals from the peer contract committed manifests, not a working tree; if the peer state is uncommitted, record the uncertainty and re-check at merge.|A TypeScript bin target cannot run under plain node; carry the loader tsx in the runtime tree and set CWD so resolution is deterministic.|Verify submodule acquisition at the pinned library tag rather than assuming the host checkout behavior.|When a non-root program consumes a mounted secret, specify the readability requirement (0444 or compose-secret default), not just the file path.|Keep the Layer-1 guard and the contract in lockstep; leaving tests outside the change surface produces expected reds that must be carried explicitly into the implement ledger.
