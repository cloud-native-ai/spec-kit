---
id: "20261030T153530Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261030T170000Z-e5f6"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-30T15:35:30Z"
summary: "implement 分段 S3（文档型 008）收口：C16/附录 A 落地后四面与结构门禁全过；发现三处框架侧口径摩擦：① efficiency-model 的 E3 stage-status 只在 clarify/plan/tasks/checklist/analyze/review 六阶段定义为必需，implement 阶段的必填字段只出现在驱动的 dispatch recipe，框架 ow"
---

## Review
implement 分段 S3（文档型 008）收口：C16/附录 A 落地后四面与结构门禁全过；发现三处框架侧口径摩擦：① efficiency-model 的 E3 stage-status 只在 clarify/plan/tasks/checklist/analyze/review 六阶段定义为必需，implement 阶段的必填字段只出现在驱动的 dispatch recipe，框架 owner 未定义；② doc-consistency-check 的 evidence 面只判定带 证据： 标记的行，无标记的状态断言不进入判定，『证据三件套完整率 100%』无法由该面机械证明；③ verification-log-template 的 status 词表无 pending-review，派发文本却要求记 pending-review，只能映射为 deferred 并双写 note。

## Optimization Points
- ① 把 implement 阶段的 E3 stage-status 必填字段（含 docs-only 六项缩减集与 faces[] 结构）并入 efficiency-model §2.4，或明确声明 implement 不适用；② evidence 面增加可选严格模式：对含状态性断言但无证据标记的行报 finding，使完整率可由单一面证明；③ verification 词表增加 pending-review，或在模板注释里给出 deferred + note 的单一映射。
