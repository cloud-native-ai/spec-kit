---
id: "20261030T122345Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261030T130000Z-e5f6"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
feature: "008-frontend-component-design"
partial: true
created: "2026-10-30T12:23:45Z"
summary: "Round-4 re-analysis of 008-frontend-component-design in an isolated line worktree: 5 prior findings verified closed (AN-14 four-form fix reproduces byte-identically; AN-08/AN-15/AN-16/AN-17 genuine), "
---

## Review
**Partial run** — Round-4 re-analysis of 008-frontend-component-design in an isolated line worktree: 5 prior findings verified closed (AN-14 four-form fix reproduces byte-identically; AN-08/AN-15/AN-16/AN-17 genuine), 3 new raised (AN-18 HIGH: target-resolution step drops 13 in-repo specifiers and undercounts violating/adjacent/jump/same to 62/138/24-26/474 vs the true 63/144/26-28/478; AN-19 LOW owner-discipline copies; AN-20 LOW registry count). Verdict FAIL (1 HIGH).

## Optimization Points
- F1: the flow-class read cannot resolve in this topology at all - flow-class-check --unit-id spec:<dir> returns framework-source-required because the line worktree carries no .specify/templates/commands/ and no skills/{external,internal}/, so every run starts in owner-unavailable; either the engine should fall back to the declared tuple or the analyze template should not require a framework-inventory read for a spec-scoped unit. F2: three consecutive rounds produced a HIGH in the same class (measurement completeness of a doc-embedded scan script: round 3 missed an import form, round 4 missed the target-resolution step). A doc-embedded script is re-typed each round and its gaps are invisible; program-first would suggest the scanner live as a checked-in script (or an evidence-engine lane) that both the artifact and the analyzer execute, so a gap shows up as a diff rather than as prose.
