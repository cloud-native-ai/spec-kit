---
id: "20261016T200221Z-speckit-instructions"
unit_id: "/speckit.instructions"
unit_type: "command"
run_id: "instructions-recover-2026-10-17"
scope: "local"
probe: "speckit-instructions-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-16T20:02:21Z"
summary: "recover 模式完整走完：setup 脚本因 CWS_LIB_BASH_HOME 缺失失败后按错误处理规则转手工等价路径；Documentation Map 死链清理、Tech Stack/Commands 事实刷新、8 个模板纪律章节插入、Resource Registry→Skills & Tools 收敛、4 个缺失基础设施文件（skills.md/tools.md/glossary.m"
---

## Review
recover 模式完整走完：setup 脚本因 CWS_LIB_BASH_HOME 缺失失败后按错误处理规则转手工等价路径；Documentation Map 死链清理、Tech Stack/Commands 事实刷新、8 个模板纪律章节插入、Resource Registry→Skills & Tools 收敛、4 个缺失基础设施文件（skills.md/tools.md/glossary.md/git-workflow.md）补建、10 个符号链接全部校验有效；备份历史比对确认无手写内容丢失（CDN 禁令已由宪法 XV 收编、auth 细节已过时）。最终 27313 字节，预算内。

## Optimization Points
- generate-instructions.sh 在本机因 CWS_LIB_BASH_HOME（cws-lib-bash）缺失直接退出，而其依赖的 common.sh 函数均有普通 bash 等价实现——建议为 cws-lib-bash 缺失场景增加优雅降级或前置探测提示，避免每次 /speckit.instructions 都要走手工等价流程（本次即手工完成了模板渲染、glossary/skills.md/tools.md/git-workflow.md 创建与符号链接校验）。
- token-efficiency：8 次顺序编辑后做了整文件重读（约 27KB）做连贯性校验，而每次编辑结果均已在上下文中；后续可用标题级 grep + 接缝抽查替代全文重读，节省一次全文注入。
