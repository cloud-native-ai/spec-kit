---
id: "20261030T124501Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261030T150000Z-e5f6"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-30T12:45:01Z"
summary: "Round-5 re-analysis of 008-frontend-component-design: AN-18 (HIGH), AN-19 and AN-20 (LOW) all closed and independently verified — the layer scan replays byte-identically, an independently rewritten re"
---

## Review
Round-5 re-analysis of 008-frontend-component-design: AN-18 (HIGH), AN-19 and AN-20 (LOW) all closed and independently verified — the layer scan replays byte-identically, an independently rewritten resolver/classifier reproduces 63 / 62 / 144 (89-40-12-3) / 26-28 / 474 (totals 707 / 709), and round 4's predicted same-layer 478 does not reproduce (474 is correct). Verdict PASS with 2 new LOW findings (AN-21: the completeness condition copied into plan C3 / T006 / CHK010 omits the 'three resolution entries' axis; AN-22: the round-4 fix residual dropped three live OIs and reused OI-5 for a different item).

## Optimization Points
- F1: the flow-class read still cannot resolve a spec unit — the template prescribes --unit-id "spec:<dir>" while flow-class-check.py accepts only /speckit.<stem> or skill:<dir>, so every round of this line starts degraded, and the reported label even changed between rounds (invalid-unit-id in r3, framework-source-required in r4) for the same call. F2: run-determination accepts --declared-check / --green-check but the command wrap-up has no documented way to feed a read-only analysis run's gate verdicts, so artifact_correctness stays not_evaluated (no_declared_checks) even though this run produced 9 gate verdicts and a full re-measured literal set; a --collected style digest for non-test runs would close it.
