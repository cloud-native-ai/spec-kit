---
id: "20261030T120234Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261030T121500Z-e5f6"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-30T12:02:34Z"
summary: "Round-3 re-analysis of 008-frontend-component-design: AN-11/AN-12/AN-13 closed and verified, AN-08 still partial (3 residual copies), 1 new HIGH (AN-14: layer-scan regex omits dynamic import(), underc"
---

## Review
Round-3 re-analysis of 008-frontend-component-design: AN-11/AN-12/AN-13 closed and verified, AN-08 still partial (3 residual copies), 1 new HIGH (AN-14: layer-scan regex omits dynamic import(), undercounting 60/59/137/88 by 2/2/1/1). Verdict FAIL (1 HIGH). Two friction points this run.

## Optimization Points
- F1: the analyze command template mandates --unit-id "spec:<spec-dir>" for the flow-class read but flow-class-check.py accepts only /speckit.<stem> or skill:<dir>, so the documented call always exits 2 and every run starts in owner-unavailable degradation; either the engine should accept spec:<dir> or the template should pass /speckit.analyze. F2: run-determination/exec-quant/feedback engines have no way to accept a caller-supplied evidence digest, so a read-only analysis run records not_evaluated for artifact_correctness (no_baseline) even though the run produced 11 gate verdicts and 29 re-measured literals; consider letting --collected carry that.
