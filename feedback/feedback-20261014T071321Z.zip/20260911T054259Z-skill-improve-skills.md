---
id: "20260911T054259Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "profiles-agents-memory-attr-20260911"
scope: "local"
probe: "skill-improve-skills-wrapup"
kind: "internal"
slice: "skills"
partial: false
created: "2026-09-11T05:42:59Z"
summary: "为 profiles-agents 设计跨 Agent 记忆共享机制。按 Step 2 先做实现调研（四属性接线框架 + 新增属性 Checklist），据 Checklist 第 4 条『先只读探测确认载体形态』逐 Agent 实测，得出四档载体（pool/native/vendor-db/annotated）而非想当然的『全部接到一起』：三个办公 Agent 早已 inode 同体，真正断裂只"
---

## Review
为 profiles-agents 设计跨 Agent 记忆共享机制。按 Step 2 先做实现调研（四属性接线框架 + 新增属性 Checklist），据 Checklist 第 4 条『先只读探测确认载体形态』逐 Agent 实测，得出四档载体（pool/native/vendor-db/annotated）而非想当然的『全部接到一起』：三个办公 Agent 早已 inode 同体，真正断裂只有 Qoder 家族，Codex 是厂商派生库属禁区。产出只读探针 wire_memory.sh + 设计文档 memory-sharing.md，并同步拓扑总表/引擎契约/平台矩阵/session-groups 四处。硬约束 7 的『执行而非目检』是本轮唯一有效缺陷发现手段——首跑即暴露两个跨平台缺陷。另订正了两处与实测不符的既有记载（Qoder 工作区级记忆库完全未记录、Codex 被记为无记忆档）。

## Optimization Points
- 跨平台脚本的「平台探测」必须显式分支，不可用 `cmd -flagA … || cmd -flagB …` 回退：本轮
- 实测发现 GNU `stat -f` 是 `--file-system`（合法、退出码 0、`%i` 返回文件系统 ID），回退分支
- 永不触发，会让 Linux 侧把不同目标全判成同体（假 OK）。建议把这条写进
- `references/hardening-examples.md` 作为具名反例——它属于「反向用例：在领域合法样本上必须
- 不误报」的同族，但现有条目只覆盖 DOM/live-surface，未覆盖 POSIX 工具同名 flag 语义分裂。
- 硬约束 7「参考代码必须执行」本轮产出了全部真实价值：首次执行即抓到两个可上线的缺陷
- （`stat` 默认不跟随符号链接 → 三个已同体目标全报 GAP；上述 GNU flag 语义）。建议在 Step 8
- 增一句可检查的口径：**新增探针类脚本必须同时跑「预期命中」与「预期不命中」两组真实目标**，
- 仅跑一组容易把假 OK 当通过。
- token-efficiency：本轮首个探测命令 `find ~/.qoder* ~/.qwen* -path '*memory*' -name '*.md'`
- 直接回灌了 60 行原始路径（实际总量 756 条），其中绝大部分是同一目录下的同类文件，信息增量
- 为零；应先按目录聚合计数（`| xargs -n1 dirname | sort | uniq -c`）再按需下钻。建议在
- Step 3 的证据采集提示中明确：**探测文件系统规模时先出「目录 × 计数」摘要，再定向取样**，
- 避免把可聚合的清单原文注入上下文。
