---
id: "20261009T132504Z-skill-create-docs"
unit_id: "skill:create-docs"
unit_type: "skill"
run_id: "docs-structure-bootstrap-20261009T131057Z"
scope: "local"
probe: "skill-create-docs-wrapup"
kind: "internal"
slice: "skills"
partial: false
created: "2026-10-09T13:25:04Z"
summary: "create-docs 执行全量 Bootstrap 调谐：观察快照→目标声明引导（R4 全量批准）→18 项行动收敛（4 根入口、7 类型目录、notes/decisions 索引模板、3 篇 ADR 补记、git mv 重命名 + fix-links 机械修链、死链句清理）→validate 违规归零、审计追加。容忍带依据外部入链实测，skill-system.md 与 docs/skills"
---

## Review
create-docs 执行全量 Bootstrap 调谐：观察快照→目标声明引导（R4 全量批准）→18 项行动收敛（4 根入口、7 类型目录、notes/decisions 索引模板、3 篇 ADR 补记、git mv 重命名 + fix-links 机械修链、死链句清理）→validate 违规归零、审计追加。容忍带依据外部入链实测，skill-system.md 与 docs/skills/ 登记为项目扩展，避免大范围搬迁 churn。

## Optimization Points
- docs-utils.py 的内置保留名注册表对同类 C 区兼容符号链接口径不一致：根级 AGENTS/CLAUDE/QODER/QWEN.md 四个同族别名中仅 QWEN.md 被报 reserved-name-misuse，其余三个不报——调用方只能在 R0 试探后才能确定 --allow-special 集合。建议内置注册表收齐主流工具别名名，或让 validate 在 detail 中列出全部候选名，一次性锁定容忍集。（token-efficiency：本次三问自查无原文转储、无 LLM 代做确定性工作、无重复读取）
