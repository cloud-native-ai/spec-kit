---
id: "20261012T021433Z-skill-merge-skills"
unit_id: "skill:merge-skills"
unit_type: "skill"
run_id: "merge-aliyun-document-20261011"
scope: "local"
probe: "skill-merge-skills-wrapup"
kind: "internal"
slice: "skills"
partial: false
created: "2026-10-12T02:14:33Z"
summary: "merge-skills：将 profiles 全局技能 aliyun-document（阿里云官方文档查询前门，委托 aliyun-py-docs）并入 aliyun-workspace，成为其「文档维度」（新建 references/documentation.md）。双向覆盖门禁 exit 0：正向 70 token/0 missing（源技能名 aliyun-document 经补 doc"
---

## Review
merge-skills：将 profiles 全局技能 aliyun-document（阿里云官方文档查询前门，委托 aliyun-py-docs）并入 aliyun-workspace，成为其「文档维度」（新建 references/documentation.md）。双向覆盖门禁 exit 0：正向 70 token/0 missing（源技能名 aliyun-document 经补 documentation.md 来源note 真实存活，强于 allow）；反向 412 token/0 unresolved/6 allow FP（浏览器机器层启动细节按前门约定委托 profiles-browsers）。退役：git rm 实体、skill-categories.yaml C1 移除、wire --apply 剪 qoder 策展+codex 各 1 条悬空、复跑 --check 缺口=0、scan_dangling exit0、check_agents 漂移=0。改指活跃面 ~22 文件：17 份 NN_*/AGENTS.md 内部技能清单（python 从名单实况 split 重算计数并去重，防机械替换损坏）、skill-priority.md(20→19)、awareness-baseline.md(19→18)、instructions.md 登记表、DE capabilities.md、aliyun-services.md、normandy capability-limits.md、docs/skills/qoder.md·qwenworkcn.md 快照(26→25)、skill-system.md 现状行、skill-management.md R4 表；dated R1/R2/R3 首例叙述与退役 agent 知识页(wukong/qoderwork)按存档保留。

## Optimization Points
- 内部技能清单链条（skill-priority.md + awareness-baseline.md + 16 份 NN_*/AGENTS.md，各带独立头部计数）是 profiles 内部全局技能退役的高频改动面；用「从名单实况 split 重算计数 + 去重」的单一 python 脚本批量处理是安全模式（历史实测机械替换曾把计数写坏 24→3）。建议 decommission playbook 收录此脚本模式。
- merge-skills Phase 7 对「profiles 内部全局技能」的退役影响面（~22 活跃文件，横跨 docs/data/projects/rules/其他技能）远大于「外部市场技能」（仅清本地链接、上游保留）。建议 decommission-and-wiring 显式区分 internal-global vs external-market 两类退役范围与清单。
