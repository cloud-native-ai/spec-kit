---
id: "20261011T020911Z-skill-create-docs"
unit_id: "skill:create-docs"
unit_type: "skill"
run_id: "docs-fanout-20261009T174221Z"
scope: "local"
probe: "skill-create-docs-wrapup"
kind: "internal"
slice: "skills"
partial: false
created: "2026-10-11T02:09:11Z"
summary: "create-docs 执行扇出调谐：基线零收敛（反 churn 生效）→ 4 路并行勘察 → 14 篇新文档按六类型目录落位（每篇有勘察证据、无 filler；不写清单防 near-duplicate）→ 6 索引+CHANGELOG+声明 managed-block 盘点刷新 → validate/scan 归零、审计追加。实况纠正 6 项（aliyun/、backup.sh、计数、envs/"
---

## Review
create-docs 执行扇出调谐：基线零收敛（反 churn 生效）→ 4 路并行勘察 → 14 篇新文档按六类型目录落位（每篇有勘察证据、无 filler；不写清单防 near-duplicate）→ 6 索引+CHANGELOG+声明 managed-block 盘点刷新 → validate/scan 归零、审计追加。实况纠正 6 项（aliyun/、backup.sh、计数、envs/daemon、PROFILES_PYTHON 悬空）分别落 reference/tasks/notes，漂移残渣进 notes 而非丢弃。

## Optimization Points
- 扇出页嵌入了大量派生计数（45 个 .sh、19 账号目录、62 DDL、8872 文件等）——这些确定性事实会随仓库演进腐烂，而引擎只有 notes 生命周期与链接校验，没有「派生事实复测」动作。建议 docs-utils.py 增加 stats/freshness 类 action：按声明的测量命令复测并在偏差超容忍带时产出 finding（对应 reconcile-pattern 的 derived-fact refresh hook 组件，当前无承载）。本次已在各页标注实测日期作为缓解。
