---
id: "20260921T083108Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "improve-manage-timer-rename-2026-09-21"
scope: "local"
probe: "skill-improve-skills-wrapup"
kind: "internal"
slice: "skills"
feature: "manage-timer-rename"
partial: false
created: "2026-09-21T08:31:08Z"
summary: "改名+重定位循环：collect-process-handle→manage-timer，重定位为定时任务管理元技能（管理面+执行面，collect 必须/process·handle 可选）。调研→规范优化→用户要求优化→终检全链路完成；shape gate 由基线 5358 优化到 4994（exit 0），redline PASS，validate_flow.py 放宽段可选性后对 8 个存"
---

## Review
改名+重定位循环：collect-process-handle→manage-timer，重定位为定时任务管理元技能（管理面+执行面，collect 必须/process·handle 可选）。调研→规范优化→用户要求优化→终检全链路完成；shape gate 由基线 5358 优化到 4994（exit 0），redline PASS，validate_flow.py 放宽段可选性后对 8 个存量 flow 零回归、合成样例 RED/GREEN 通过；下游接线 wire_agents 缺口归零、8 条千问办公 cron 载荷先备份后改并验证。

## Optimization Points
- 改名类改进的下游影响面必须包含「Agent 运行时调度器载荷」检查点：本次 collect-process-handle→manage-timer 改名的最大爆破半径不在仓内文档，而在千问办公 agents.db 的 8 条 scheduled_tasks.payload（message 按名解析技能）。建议 improve-skills 步骤 7 的改名下游清单显式加入「运行时调度器/cron 载荷」一项——先备份原载荷再改，改后逐条验证 JSON 完整性。
