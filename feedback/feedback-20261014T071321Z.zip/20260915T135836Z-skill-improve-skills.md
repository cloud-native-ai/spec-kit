---
id: "20260915T135836Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "profiles-browsers-inv-2026-09-15"
scope: "local"
probe: "skill-improve-skills-wrapup"
kind: "internal"
slice: "skills"
partial: false
created: "2026-09-15T13:58:36Z"
summary: "改进 profiles-browsers：新增只读 profile_inventory.sh 让技能执行时读取本机 Chrome profile 实况（存在/运行中/独有启动参数/badge，值实时取自 path.rc+env.rc），把 SSOT 指针写入 SKILL.md/chrome.md/agent.md，补齐 public/aieg 两个缺失 profile 文档。脚本经 JSON 合法"
---

## Review
改进 profiles-browsers：新增只读 profile_inventory.sh 让技能执行时读取本机 Chrome profile 实况（存在/运行中/独有启动参数/badge，值实时取自 path.rc+env.rc），把 SSOT 指针写入 SKILL.md/chrome.md/agent.md，补齐 public/aieg 两个缺失 profile 文档。脚本经 JSON 合法性、bash<4.3 与缺 rc 负向、只读性实测；SKILL.md 形状门 exit 0。

## Optimization Points
- 当目标技能所文档化的配置存在于外部 SSOT 文件时，应优先加"运行时读取脚本"而非在技能内复述其值。本轮手工做到了（profile_inventory.sh 读 path.rc/env.rc），建议把这条固化进 improve-skills 的 step-5 检查项，使其成为系统性动作而非临场判断。
- 覆盖缺口检测缺失：skill-shape.py 与质量清单都未能发现 SKILL.md 的 profile 表比其引用的 SSOT（path.rc）少了 public/aieg 两个 profile。建议增加一个确定性交叉核对——"被引用 SSOT 的枚举项 vs 技能文档表行"，自动暴露这类漂移。
