---
id: "20260924T025158Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "profiles-project-04-11-boundary-2026-09-24T10-51-57"
scope: "local"
probe: "skill-improve-skills-wrapup"
kind: "internal"
slice: "skills"
partial: false
created: "2026-09-24T02:51:58Z"
summary: "Loop ran clean end-to-end on a spec-clarity request: research note first, then user-requirement pass. Baseline evidence run (ev-20260920-135918-profiles-project) was degenerate — 0 findings across 5 l"
---

## Review
Loop ran clean end-to-end on a spec-clarity request: research note first, then user-requirement pass. Baseline evidence run (ev-20260920-135918-profiles-project) was degenerate — 0 findings across 5 lanes — so the driver was the user requirement plus direct file/disk observation; no before/after finding comparison is possible and the outcome stays pending, not fixed. The load-bearing discovery came from reading the target's own derivation script rather than from any step in this skill: the edited reference file sits inside a signed fact-source region with 18 derived copies, which no gate in steps 4-8 asks the improver to detect. Shape and red-line gates both exit 0 with SKILL.md untouched (4186 controllable tokens, delta 0), which is the correct outcome since the change is domain logic and belongs in L2.

## Optimization Points
- [step-8 gate gap] improve-skills has no gate for **signed derived-copy regions**. The target's `references/projects-registry.md` is wrapped in `<!-- PANORAMA-FACT-SOURCE:BEGIN … END -->` and 18 `data/projects/*/PANORAMA.md` copies are md5-signature-derived from it by `scripts/panorama_sync.py`. Editing reference prose inside that region silently invalidates every derived copy, but nothing in steps 4–8 tells the improver to look for derivation markers or to re-run the owner's derive+verify script. I only caught it by reading `panorama_sync.py`'s parser. Suggest: step 8 gains a deterministic pre-check — grep the touched reference files for derivation/signature markers (`FACT-SOURCE`, `BEGIN … END`, `sig`, `md5`, `勿手改`) and, on a hit, require running the target skill's own sync `--action verify` before finishing, with `changed: 0` as the pass condition.
- [token-efficiency] Two avoidable costs this run. (1) **原文转储**: I ran `head -30 artifacts/INDEX.md` on `data/projects/11_技术前沿/` to confirm what the project actually holds; that file's `digests/` rows are single-line multi-thousand-character prose blobs, so ~30 lines pulled a very large payload into context for what I needed (directory names + the fact that "领域外遗珠" items are kept). A `cut -c1-200` or column-limited extraction would have answered it at a fraction of the cost. Rule worth adding: when sampling machine-generated index/digest files as *evidence of what exists*, cap line width, never `head` them raw. (2) **重复读取**: I re-read `11_技术前沿.md` in three separate offset slices (42, 70, 100) after already reading it whole; batching the post-edit verification into one read would have avoided two round trips.
- [pressure-test applicability] Step 8 mandates a RED-GREEN pressure re-test for behavior-changing edits and points at `create-skills/references/pressure-testing.md`, but that reference is written for skills whose behavior is *executable*. Here the behavior change is a prose decision procedure (`§(f)` ordered tie-breaker) executed later by an LLM, so the only honest test is a line-trace against real on-disk artifacts. The step should say explicitly that for spec/prose-rule edits, the pressure test = trace N real cases (including ≥1 reverse case that must NOT be re-routed) through the new ordered rule and show old-rule-RED → new-rule-GREEN per case; otherwise improvers either skip the test or fake it.
