---
id: "20260917T043117Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "improve-skills-2026-09-17-profiles-code-dual-view"
scope: "local"
probe: "skill-improve-skills-wrapup"
kind: "internal"
slice: "skills"
partial: false
created: "2026-09-17T04:31:17Z"
summary: "本轮为上轮 profiles-code 改动的用户细化：把单一跟踪表改为跨 12_代码管理/05_环境管理 的双视图（代码库维度+环境维度，内容相同侧重不同），角色由 primary_env 升级为 dev/test/prod 全人工指定。按工作流：调研 05 项目结构与治理→就角色数据来源与 05 落位授权两处真歧义 AskUserQuestion 澄清→重构配置 schema+脚本双视图投影→"
---

## Review
本轮为上轮 profiles-code 改动的用户细化：把单一跟踪表改为跨 12_代码管理/05_环境管理 的双视图（代码库维度+环境维度，内容相同侧重不同），角色由 primary_env 升级为 dev/test/prod 全人工指定。按工作流：调研 05 项目结构与治理→就角色数据来源与 05 落位授权两处真歧义 AskUserQuestion 澄清→重构配置 schema+脚本双视图投影→真实数据执行验证（两视图三元组程序化核验互为精确反转、坏快照/无profiles降级、幂等）→shape gate exit 0→按 05『一条反馈一个 target』拆两条 feedback 声明布局与授权冲突。运行干净。

## Optimization Points
- 当被改技能的产物需写入**第二个项目**（非其归属项目）的数据目录时，improve-skills 缺一个「跨项目写入授权门」：动手前须先读目标项目的 AGENTS.md 技能选用红线 + 布局约束 + 工具清单，确认该技能是否被授权、落位是否合规。本轮 profiles-code 要写 05_环境管理，而 05 的内部技能清单未含 profiles-code、且禁 artifacts/ 根平铺——靠 AGENTS.md 升级规则 + 目标技能自身硬约束兜住并以 feedback 双条声明，但 improve-skills 侧宜在 Step 4/6 显式增此门，避免静默破坏第二项目的红线。
