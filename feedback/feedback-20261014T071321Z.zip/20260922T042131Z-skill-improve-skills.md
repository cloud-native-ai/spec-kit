---
id: "20260922T042131Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "improve-manage-timer-intent-routing-2026-09-22"
scope: "local"
probe: "skill-improve-skills-wrapup"
kind: "internal"
slice: "skills"
feature: "manage-timer-intent-routing"
partial: false
created: "2026-09-22T04:21:31Z"
summary: "第二轮改进：四核心意图路由化 + 裸执行盘点校验脚本化。意图 1 属性变更规程落 task-management.md §四（字段映射矩阵+四步规程），意图 2/3 落 §五，意图 4 固化为 audit_timers.py（只读、确定性）；SKILL.md 新增意图路由节并守住 shape 预算（≈4997/5000 exit 0）；audit 实跑 8 任务全部合规并发现 1 个真实失败任务（"
---

## Review
第二轮改进：四核心意图路由化 + 裸执行盘点校验脚本化。意图 1 属性变更规程落 task-management.md §四（字段映射矩阵+四步规程），意图 2/3 落 §五，意图 4 固化为 audit_timers.py（只读、确定性）；SKILL.md 新增意图路由节并守住 shape 预算（≈4997/5000 exit 0）；audit 实跑 8 任务全部合规并发现 1 个真实失败任务（每周稳定性巡检 consecutive_errors=2）。

## Optimization Points
- 元技能的管理面意图应显式路由化：manage-timer 第二轮改进把「何时用」重构为「意图路由」表（执行面/管理面分流 + 四意图→规程指针），比散文式用途列举更可执行。其中「裸执行默认动作」（全面盘点校验）属确定性动作，按项目规范脚本化为 audit_timers.py（只读、--json、退出码阶梯），首次实跑即发现 1 个真实失败任务——脚本化审计的即时收益证据。教训：给技能加管理面时，每个意图都应有「信号→规程入口」的映射行，且默认动作必须无歧义。
