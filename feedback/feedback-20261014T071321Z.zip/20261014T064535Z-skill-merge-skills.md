---
id: "20261014T064535Z-skill-merge-skills"
unit_id: "skill:merge-skills"
unit_type: "skill"
run_id: "merge-fbi-20261014"
scope: "local"
probe: "skill-merge-skills-wrapup"
kind: "internal"
slice: "skills"
partial: false
created: "2026-10-14T06:45:35Z"
summary: "执行 /merge-skills 将两个 a1 市场官方技能（fbi-dev-assistant 6.6MB/361文件、fbi-platform-skill 868KB/68文件）合并进 profiles 本地技能 fbi-workspace。用户裁决采用全量 vendoring 复制代码 + 保留市场实体安装。8 阶段完成：调查→提取(scratch+pre-merge快照)→映射→重写(ve"
---

## Review
执行 /merge-skills 将两个 a1 市场官方技能（fbi-dev-assistant 6.6MB/361文件、fbi-platform-skill 868KB/68文件）合并进 profiles 本地技能 fbi-workspace。用户裁决采用全量 vendoring 复制代码 + 保留市场实体安装。8 阶段完成：调查→提取(scratch+pre-merge快照)→映射→重写(vendor/ 两套源码树逐字节复制 + 5份 references 按 target 惯例重表达 + SKILL.md 重写为六维度统一前门/路由器，Part A 原 DataMate 内容逐字保留)→双向覆盖门禁→继承记录+baseline→decommission(市场实体 externallly-managed 保留不动，profiles 侧无接线可清)→终验。三门禁全绿：正向 dev-assistant 442 token/0 unresolved、platform-skill 728 token/0 unresolved、反向 pre-merge 190 token/0 unresolved；provenance_check exit 0(18 verified rows)；skill_categories --validate 错误=0；wire_agents --check 缺口=0 变更=0；内部链接 0 断链；vendor 无 .git/pycache/.coverage。抽验 vendored 脚本 --help 仅因依赖未装失败(ModuleNotFoundError)，印证 references 安装前置准确，并据此补正 report-data-query 需先 pip install -e . fbi-report-manage 的隐含依赖。未 git commit(用户未要求)。

## Optimization Points
- provenance-record.md 应补充一条 destination 单元格书写约束：provenance_check.py 把 destination 里**每个反引号跨度**都当作「从技能根解析的路径」，故单元格内混用简写子路径（tools/x.py）、裸文件名（README.md）或 glob（auth_*.py）会产生假 finding（本次 6 处 finding 全属此类，改全路径/去反引号后 exit 0）。建议在 schema 节明示：destination 只对「可从技能根解析的完整路径」加反引号，文件枚举写进非反引号散文。
