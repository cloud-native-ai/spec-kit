---
id: "20261009T071043Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "improve-skills-profiles-project-remote-rule-20261009"
scope: "local"
probe: "skill-improve-skills-wrapup"
kind: "internal"
slice: "skills"
partial: false
created: "2026-10-09T07:10:43Z"
summary: "用户显式要求驱动的改进循环：为 profiles-project 技能新增『ssh 远程环境禁用裸远程命令操作代码项目、改用 ssh+qodercli（仓库根为 workdir、headless subagent、复用仓库 harness）』规则。流程完整：调研三层现状（references SSOT / 双模板 / 根级+项目运行时）→ 按双层下发机制四处齐改（project-delegatio"
---

## Review
用户显式要求驱动的改进循环：为 profiles-project 技能新增『ssh 远程环境禁用裸远程命令操作代码项目、改用 ssh+qodercli（仓库根为 workdir、headless subagent、复用仓库 harness）』规则。流程完整：调研三层现状（references SSOT / 双模板 / 根级+项目运行时）→ 按双层下发机制四处齐改（project-delegation.md 执行位点节+八要点⑧+R3/R6 判据 → awareness 模板⑧双副本 → project 模板新增固定契约段+生成规则 10 → 运行时根级⑧+18 个项目文件）→ 批量下发脚本化并实测 18/18 成功 → 渲染段与模板逐字节一致性校验 0 偏差 → 模板⑧两处与根级运行时⑧一致 → shape/redline 双门禁 PASS（tokens 4259→4269，预算内）。Token 效率自评：无原文转储、确定性工作全交脚本（插入/校验/门禁）、无重复读取，干净运行。

## Optimization Points
- # improve-skills 运行优化点 — 2026-10-09（profiles-project 远程规则下发循环）
- 1. 记忆「profiles-project 五动作契约新规则添加的单一事实源」中「根级 + 17 个 NN_*/AGENTS.md」的计数口径与实测不符——运行时实际是 18 个（00_默认项目–17_数字员工，含 00_默认项目），沿用旧口径的下次下发会漏发 00_默认项目；已修正记忆为 18 并补记本次新增的「远程代码操作」契约域（SSOT 位置、双落下发形态、生成规则 10 判据）。
