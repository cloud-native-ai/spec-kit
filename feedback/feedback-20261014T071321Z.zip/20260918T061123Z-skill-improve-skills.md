---
id: "20260918T061123Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "improve-skills-profiles-project-exec-locus-2026-09-18"
scope: "local"
probe: "skill-improve-skills-wrapup"
kind: "internal"
slice: "skills"
partial: false
created: "2026-09-18T06:11:23Z"
summary: "改 profiles-project 全局意识/委派机制：为『委派只到办公项目、真实工作目录可能是代码项目』的缺口新增两层执行模型（主 agent 委派留办公项目、对代码项目 cd+subagent 就地执行并回写），落为委派契约第⑧要点 + project-delegation.md 执行位点节 + 12_代码管理 领域说明 + SKILL.md 概念索引，并把 8 处七要点计数锁步升为八要点（"
---

## Review
改 profiles-project 全局意识/委派机制：为『委派只到办公项目、真实工作目录可能是代码项目』的缺口新增两层执行模型（主 agent 委派留办公项目、对代码项目 cd+subagent 就地执行并回写），落为委派契约第⑧要点 + project-delegation.md 执行位点节 + 12_代码管理 领域说明 + SKILL.md 概念索引，并把 8 处七要点计数锁步升为八要点（豁免历史日志）。shape gate pass、两契约副本对齐、fence 平衡、live data 仍 7 要点（待 reconcile 传播）。

## Optimization Points
- 当改动「带计数引用的枚举契约」（如委派契约 N 要点）时，新增/删除一项会牵动全仓多处「N要点/N 个要点」文字引用与 R3/R6 校验语义；本次靠人工 grep 才锁齐 8 处并排除历史变更日志（feedback-inbox.md）。建议在 improve-skills 的 Step 5/Step 7 增一条通用前置门：改动枚举契约条目数前，先 grep 所有计数词引用（中文数字+阿拉伯数字+N要点/N项/N-point），锁步更新，且显式豁免历史 change-log 类文件（不改写既成历史）。
- 元技能（meta-skill）类目标的改进只在技能侧（spec+template）生效，运行时需 reconcile 才把新契约渲染进 data 目录；本次已核实 live data/projects/AGENTS.md 仍为旧 7 要点。建议 improve-skills 报告模板对「元技能/契约下发类」目标固定输出一行「生效前置：需运行 <下发动作> 才传播到运行时数据面」，避免用户误以为改完即生效。
