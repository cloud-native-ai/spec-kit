---
id: "20261011T131128Z-skill-merge-skills"
unit_id: "skill:merge-skills"
unit_type: "skill"
run_id: "merge-alibabacloud-error-troubleshoot-20261011"
scope: "local"
probe: "skill-merge-skills-wrapup"
kind: "internal"
slice: "skills"
partial: false
created: "2026-10-11T13:11:28Z"
summary: "将阿里云门户外部技能 alibabacloud-error-troubleshoot（官方 aliyun CLI openapiexplorer 插件的 OpenAPI 调用失败诊断）合并进 profiles 全局技能 aliyun-workspace。源 SKILL.md + 4 篇 references 按目标约定重组为 2 篇（openapi-troubleshooting.md 诊断 pl"
---

## Review
将阿里云门户外部技能 alibabacloud-error-troubleshoot（官方 aliyun CLI openapiexplorer 插件的 OpenAPI 调用失败诊断）合并进 profiles 全局技能 aliyun-workspace。源 SKILL.md + 4 篇 references 按目标约定重组为 2 篇（openapi-troubleshooting.md 诊断 playbook + openapi-troubleshoot-setup.md 前置/RAM），SKILL.md 5 处编辑（description 触发词、分层约定第5条例外、意图路由新增诊断行并与文档层消歧、安全红线补日志脱敏、维护分工补来源）。三处约定冲突按目标优先调和：凭证机制（aliyun configure/ALIBABA_CLOUD_* → aliyun_account 唯一通路）、官方 CLI 使用（纳入既有"回落官方 aliyun CLI"兜底口径）、UA slug（重指向 aliyun-workspace）。双向覆盖门禁 exit 0：正向 202 token/0 unresolved/18 allow FP，反向 154 token/0 missing。源为外部一次性下载、staged 在 /tmp、从未独立接线，退役=保留上游 + scratch 无需清理接线。能力骑 aliyun-workspace 现有接线（qoder+codex）自动扩散，wire --check 缺口=0。

## Optimization Points
- coverage_probe.py 的路径模式会把散文斜杠（error code/message→/message、and/or→/or）与 PascalCase 的 camelCase 碎片（GetCallerIdentity→etCallerIdentity）当作 fact token，落入 residual missing 需人工 allow；建议 probe 增过滤：紧邻字母且无真实路径上下文的 /word 视为散文伪 token，camelCase 碎片若为其 PascalCase 全名子串则丢弃，可减少 allow 噪声。
- Phase 7 decommission 文案默认源有独立接线待清理；对"外部门户一次性下载、staged 在 /tmp、从未接线"的源，退役实为 scratch 清理。建议 Phase 1 关系定性显式增加 externally-staged（无本地接线）分支：decommission 仅保留上游 + 清 scratch，避免去找不存在的接线。
