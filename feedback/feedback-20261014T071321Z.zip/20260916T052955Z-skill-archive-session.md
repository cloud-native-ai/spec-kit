---
id: "20260916T052955Z-skill-archive-session"
unit_id: "skill:archive-session"
unit_type: "skill"
run_id: "archive-session-20260916-de-sandbox"
scope: "local"
probe: "skill-archive-session-wrapup"
kind: "internal"
slice: "skills"
feature: "qoder-ide-transcript-subdir"
partial: false
created: "2026-09-16T05:29:55Z"
summary: "导出当前 Qoder IDE 会话：自动识别误落 copilot(退出4)；--tool qoder-cli 后因适配器只扫顶层 jsonl 而 transcript/ 子目录未覆盖报 not found；以临时符号链接桥接后成功导出 851 消息会话并补写总结、落位 11_技术前沿 artifacts/session-archives/。"
---

## Review
导出当前 Qoder IDE 会话：自动识别误落 copilot(退出4)；--tool qoder-cli 后因适配器只扫顶层 jsonl 而 transcript/ 子目录未覆盖报 not found；以临时符号链接桥接后成功导出 851 消息会话并补写总结、落位 11_技术前沿 artifacts/session-archives/。

## Optimization Points
- [{"point":"qoder-cli 适配器的会话 glob 只扫 ~/.qoder/projects/<enc>/*.jsonl 顶层，而 Qoder IDE 实际写在 transcript/ 子目录 → --session 精确导出报 not found；本次靠临时符号链接桥接完成，应在适配器 rel_glob 增加 transcript/*.jsonl 并移除桥接需求","scope":"local"},
- {"point":"工具自动识别在 Qoder IDE 宿主下误判为 copilot（未落盘适配器）直接退出码 4；应在探测顺序中先验 qoder-cli 存储存在性再回落 copilot","scope":"local"}]
