---
id: "20261008T061142Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "dingtalk-recall-cli-recheck-20261008"
scope: "local"
probe: "skill-improve-skills-wrapup"
kind: "internal"
slice: "skills"
partial: false
created: "2026-10-08T06:11:42Z"
summary: "用最新 CLI 重新固化 dingtalk-workspace 消息撤回章节。核对 --help 后发现并修正三处漂移（recall 参数名 --message-id vs Shortcut --msg-id、--conversation-id 必填性、群/单聊撤回命令分流、一次一条限制），并把上一轮过度断言的「recall 可撤机器人消息」降级为带置信度的观测。新暴露一个跨单元问题：托管鉴权模式"
---

## Review
用最新 CLI 重新固化 dingtalk-workspace 消息撤回章节。核对 --help 后发现并修正三处漂移（recall 参数名 --message-id vs Shortcut --msg-id、--conversation-id 必填性、群/单聊撤回命令分流、一次一条限制），并把上一轮过度断言的「recall 可撤机器人消息」降级为带置信度的观测。新暴露一个跨单元问题：托管鉴权模式下凭证覆盖被模式级拒绝，现有发送路径文档的 dws api 建议失效。

## Optimization Points
- **托管鉴权模式（authMode=managed）会模式级拒绝 --client-id/--client-secret 覆盖**：实测 `dws auth status` 返回 source=host/authMode=managed 时，带凭证覆盖的命令（含假密钥、含 --dry-run）一律报 "DWS command is not supported in managed authentication mode"；不带覆盖时 send-by-bot/dws api 用宿主注入的 app token 可跑。现有 global-reference.md / chat-message-send.md / card.md 把「凭证被拒→改用 dws api 传自有凭证」写成无条件建议，在托管模式下是死路。应补鉴权模式前置判定。
- **能力断言要区分「契约承诺」与「单次观测」**：上一轮把「recall 能撤机器人消息」写成确定能力，本轮原子 `message recall --help` 的 Avoid-when 明确「撤回机器人消息用 recall-by-bot」，与之冲突。已降级为带两种未验证候选解释的一次性观测。教训：写「实测 X 可行」前先读该命令自己的 help 契约，别用一次成功覆盖官方边界声明。
- 默认 msgKey 实为 sampleMarkdownDX（dry-run 实测），card.md:76 记的 sampleMarkdown 不准——属发送路径，本单元未改，留待专门修正。
