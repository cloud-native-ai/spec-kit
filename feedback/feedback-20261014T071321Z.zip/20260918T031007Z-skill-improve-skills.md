---
id: "20260918T031007Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "okr-manage-weekreport-20260918"
scope: "local"
probe: "skill-improve-skills-wrapup"
kind: "internal"
slice: "skills"
feature: "okr-manage-report"
partial: false
created: "2026-09-18T03:10:07Z"
summary: "以用户指定的钉钉官方文档为来源，强化 okr-manage 的写周报能力：新增文档内创作四步法(§7)、进展先行编排(write-progress→create 使 OKR 进展自动引用)、分享(钉钉/邮件)与委托边界。全部改动落在 references，SKILL.md 仅加指针；shape gate exit 0，符号链接传播已验证。"
---

## Review
以用户指定的钉钉官方文档为来源，强化 okr-manage 的写周报能力：新增文档内创作四步法(§7)、进展先行编排(write-progress→create 使 OKR 进展自动引用)、分享(钉钉/邮件)与委托边界。全部改动落在 references，SKILL.md 仅加指针；shape gate exit 0，符号链接传播已验证。

## Optimization Points
- 当优化来源是一篇需登录的钉钉文档时，WebFetch 会被登录墙拦截；应优先用 `dws doc read --node <url>` 走已登录态取正文，比浏览器自动化更快更稳，可作为 improve-skills 取外部参考文档的默认通道。
- 对「文档内创作类」能力（在第三方站点如 alidocs 编辑正文），改进时应显式声明技能不做程序化写入、以引导用户为主，避免凭空捏造接口；分享等外发动作委托给对应 workspace 技能并标注确认门禁。
