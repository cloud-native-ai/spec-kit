---
id: "20260908T050040Z-skill-create-skills"
unit_id: "skill:create-skills"
unit_type: "skill"
run_id: "profiles-site-20260908"
scope: "local"
probe: "skill-create-skills-wrapup"
kind: "internal"
slice: "skills"
feature: "profiles-site"
partial: false
created: "2026-09-08T05:00:40Z"
summary: "已创建并全局扩散 profiles-site，完成迁移、状态机门禁、调用面改造和压力复验。"
---

## Review
已创建并全局扩散 profiles-site，完成迁移、状态机门禁、调用面改造和压力复验。

## Optimization Points
- 新建“统一前门”类技能时，create-skills 应在首次 GREEN 前自动扫描调用方的 SKILL.md、references 与模板，避免只改入口文档后留下传递性直调。
- token-efficiency：本次因首次验证未覆盖深层 references 与嵌套数组脱敏，产生多轮重复审计；应把递归敏感值测试和跨技能引用扫描加入创建期固定检查。
