---
id: "20260916T023432Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "improve-profiles-agents-3platform-20260916"
scope: "local"
probe: "skill-improve-skills-wrapup"
kind: "internal"
slice: "skills"
feature: "profiles-agents-three-platform"
partial: false
created: "2026-09-16T02:34:32Z"
summary: "按用户要求把 profiles-agents 从双平台扩展为三平台（macOS/Linux/cloud-DE），提取 config/aieg/_common 类级资产（参数化下行脚本/sandbox-ssh 模板/awareness 模板），DE 实例与千问办公同级 roster；顺带 slim SKILL.md 使 shape 门禁由 exit 10 转 exit 0。行为变更经实跑验证（syn"
---

## Review
按用户要求把 profiles-agents 从双平台扩展为三平台（macOS/Linux/cloud-DE），提取 config/aieg/_common 类级资产（参数化下行脚本/sandbox-ssh 模板/awareness 模板），DE 实例与千问办公同级 roster；顺带 slim SKILL.md 使 shape 门禁由 exit 10 转 exit 0。行为变更经实跑验证（sync/cdp_patch_role slug 参数化、bash -n、py_compile）。

## Optimization Points
- [{"point":"改善循环开始前应先跑 skill-shape 基线：本次 SKILL.md 基线即 exit 10（正文超预算+硬约束超长），若不先测基线易把既有红误归因于本次编辑","scope":"local"},
- {"point":"类级/实例资产分层（config/aieg/_common vs <slug>）后，下游指针散落在 ssh config 注释、知识页、site notes、调查报告四处；rename/move 的 downstream checklist 应扩展为全仓 grep 跨技能引用迁移","scope":"local","tag":"token-efficiency：一次 grep 定位全部残留，避免逐文件 eyeball 往返"}]
