---
id: "20260914T045003Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "improve-profiles-project-knowledge-precipitation-20260914"
scope: "local"
probe: "skill-improve-skills-wrapup"
kind: "internal"
slice: "skills"
feature: "profiles-project"
partial: false
created: "2026-09-14T04:50:03Z"
summary: "纯用户指令驱动的 improve-skills 环：为 profiles-project 新增『知识必沉淀』普适写侧规则。基线两条 findings 均非缺陷(session Exercised/0 corrections、feedback Present/0 themes)，按红线锁定为不据计数扩展改进面。四处协同编辑(principles.md#14 SSOT、SKILL.md#11 L1 指"
---

## Review
纯用户指令驱动的 improve-skills 环：为 profiles-project 新增『知识必沉淀』普适写侧规则。基线两条 findings 均非缺陷(session Exercised/0 corrections、feedback Present/0 themes)，按红线锁定为不据计数扩展改进面。四处协同编辑(principles.md#14 SSOT、SKILL.md#11 L1 指针、project/AGENTS.md 契约段、awareness/AGENTS.md ③ 两处副本)；shape gate exit 0(3762/5000)、6 链接解析、无 contract test 受阻；自查发现并修正 awareness ③ 初版与 ⑤ 写边界的冲突。行为端到端效果待真实 reconcile 与消费方会话验证，本轮不宣称 fixed，已写 intervention.json。

## Optimization Points
- [improve-skills] 跨「同源」契约段迁移规则时须按宿主写权限重新派生，而非逐字镜像。本次将 project/AGENTS.md『本地优先』的写侧义务复制到 awareness 根级 ③ 时，初版直写「命中项目时写该项目 artifacts/memory」，与同段 ⑤ 写边界（全局消费方对项目核心文件只读、会话记忆恒写根级）冲突，靠自查修正为经 project/feedback 通道回流。建议在 improve-skills 步骤 5/6 对「声明为同源但宿主约束不同」的契约段增加一条一致性核查提示：镜像的是意图，落位动作须按该消费方的写边界重写。
- [token-efficiency] 会话在上下文截断后恢复，为保证正确性重读了已编辑文件并 grep 核对 4 处落点；recovery 场景下重读编辑目标是必要的（HC 要求 re-read canonical before editing），无需优化，但可优先用定向 grep 而非整文件 Read 以压缩复读成本。
