---
id: "20261011T022501Z-skill-improve-skills"
unit_id: "skill:improve-skills"
unit_type: "skill"
run_id: "improve-skills-profiles-project-run-account-3step-20261011"
scope: "local"
probe: "skill-improve-skills-wrapup"
kind: "internal"
slice: "skills"
partial: false
created: "2026-10-11T02:25:01Z"
summary: "用户补充条款驱动的改进循环（续 2026-10-09 远程规则）：为「远程代码操作」契约新增运行账号与三步启动子条款（多数 ssh 环境禁 root，qodercli 以 agent/develop 运行；ssh 登录后按序 ①cd ②chown -R 赋权按环境形态 agent:agent/develop:develop ③su 切用户执行 headless qodercli，顺序强制；环境形态"
---

## Review
用户补充条款驱动的改进循环（续 2026-10-09 远程规则）：为「远程代码操作」契约新增运行账号与三步启动子条款（多数 ssh 环境禁 root，qodercli 以 agent/develop 运行；ssh 登录后按序 ①cd ②chown -R 赋权按环境形态 agent:agent/develop:develop ③su 切用户执行 headless qodercli，顺序强制；环境形态从 profiles-code _fleet form 字段解析）。沿用既有双层下发链路四处齐改：SSOT（project-delegation.md 变体节+八要点⑧+R3/R6 判据）→ 根级模板⑧双副本（中英）+规则5 → 项目模板新子条目+规则10 过时判定 → 运行时根级⑧ + 18 个项目文件（insert_run_account_bullet.py 脚本化，18/18 成功）。终验：项目级整段与模板逐字节一致 0 偏差、模板⑧两副本与根级运行时⑧一致且均含新子句、SSOT 四承载点齐备、两生成规则过时判定同步、redline PASS（本循环未触碰 SKILL.md，shape 门禁不适用）。Token 效率自评：无原文转储、批量下发与一致性校验全交脚本、无重复读取，干净运行。

## Optimization Points
- No significant optimization points identified this run.
