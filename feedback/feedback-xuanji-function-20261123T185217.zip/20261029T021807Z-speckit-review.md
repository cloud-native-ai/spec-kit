---
id: "20261029T021807Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "r20261028T160500Z-fd02"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-29T02:18:07Z"
summary: "两段式 review 在同一 worktree 上被迫交叉阅读两份 skill：命令的 triage 只有 run/not-applicable/not-evaluated 三值，而 code-review skill 规定 delta 缺失即停，本机 delta 缺失，只能走 note/report 旁路；另外状态机要求 review 时没有未解决的 [~]，但驱动把全量闭包排在 review "
---

## Review
两段式 review 在同一 worktree 上被迫交叉阅读两份 skill：命令的 triage 只有 run/not-applicable/not-evaluated 三值，而 code-review skill 规定 delta 缺失即停，本机 delta 缺失，只能走 note/report 旁路；另外状态机要求 review 时没有未解决的 [~]，但驱动把全量闭包排在 review 之后，判定必然撞墙。

## Optimization Points
- ① triage 应以判断路径所需能力为准（git + diff），delta 降级为渲染增强并在报告里记一行降级；② 状态机为 Ready for Review 增加 closure-plan 处置（owner + 产物路径 + 日期）；③ review 命令在派发层应收到命令而非结论（本轮两次派发前提与事实不符）。
