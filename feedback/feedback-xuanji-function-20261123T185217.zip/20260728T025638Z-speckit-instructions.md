---
id: "20260728T025638Z-speckit-instructions"
unit_id: "/speckit.instructions"
unit_type: "command"
run_id: "instructions-2026-07-28-105432"
scope: "local"
partial: false
created: "2026-07-28T02:56:38Z"
summary: "Full reconcile after constitution v1.3.0.1 amendment: converged Documentation Map (constitution version/principles, Glossary row), fixed stale Root Path, added Task Complexity Rubric / Dogfooding Prac"
---

## Review
Full reconcile after constitution v1.3.0.1 amendment: converged Documentation Map (constitution version/principles, Glossary row), fixed stale Root Path, added Task Complexity Rubric / Dogfooding Practice / symlink-protection bullets from latest template, referenced Principle II in data-flow; seeded glossary with 5 proposed terms; no user-authored content lost.

## Optimization Points
- Grep tool binary unavailable in this environment (EACCES on vendored ripgrep); command fell back to shell grep — consider documenting a fallback path in the command workflow.
