---
id: "20261031T025629Z-speckit-clarify"
unit_id: "/speckit.clarify"
unit_type: "command"
run_id: "r20261031T023000Z-f8b2"
scope: "local"
probe: "speckit-clarify-wrapup"
kind: "internal"
slice: "commands"
feature: "008-function-l3-design"
feature_id: "025"
partial: false
created: "2026-10-31T02:56:29Z"
summary: "Mode A clarify on a hand-written requirements spec: coverage scan found Feature Linkage and four decision clusters underspecified. The most material discovery was that the spec's five-flow model does "
---

## Review
Mode A clarify on a hand-written requirements spec: coverage scan found Feature Linkage and four decision clusters underspecified. The most material discovery was that the spec's five-flow model does not match the code — akeops re-exports asiops.main.handler (one import, no second implementation) and the legacy handlers read OSS event fields inline, so a whole-repo isolation rule would have been false. Binding the isolation criterion to the two existing boundary tests instead of restating token lists kept the spec from duplicating a fact owned by tests.

## Optimization Points
- For expression-class design specs, run the coverage scan against the code layout before writing requirements: directory names (kb vs knowledge, dashboard vs ads/) and handler re-exports are cheap to measure and change the spec's own vocabulary. When a spec pre-registers a Feature ID in a clarifying row, discharge the registry binding as an integration obligation rather than spending one of the five question slots on it.
