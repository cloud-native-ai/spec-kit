---
id: "20261031T024917Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "r20261031T023000Z-f8b2"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
feature: "008-function-l3-design"
partial: false
created: "2026-10-31T02:49:17Z"
summary: "requirements 阶段在 line worktree 内一次跑通：validate-requirements ok（29 FR / 10 SC / 39 definition rows），pre-analyze-check decision=pass errors=0（16 条 missing-path advisory 全部是尚未创建交付物 docs/design/* 与兄弟线未跟踪文件"
---

## Review
requirements 阶段在 line worktree 内一次跑通：validate-requirements ok（29 FR / 10 SC / 39 definition rows），pre-analyze-check decision=pass errors=0（16 条 missing-path advisory 全部是尚未创建交付物 docs/design/* 与兄弟线未跟踪文件 docs/concepts/architecture.md），decomposition-check --mode plan proceed（29/30）。三处环境/工具摩擦：① create-new-requirements.sh 依赖 CWS_LIB_BASH_HOME，未设置即 exit 1，命令与技能文档均未声明该前置；② 同脚本在 git 仓库内无条件 git checkout -b <NNN>-slug，在 SDD 线 worktree（分支 line/<id>）里会切走声明分支，本次需手动切回并删除临时分支；③ validate-requirements 的 [[STR-NNN]] 引用只认正文（内联代码 span 被剥离），把引用写成 `[[STR-001]]` 会被判成「未引用」，文档里的常见写法反而失败。

## Optimization Points
- ① 在 create-requirements 技能与环境前置中显式声明 CWS_LIB_BASH_HOME（或让 common.sh 在该变量缺失时降级而非 hard fail）；② 为脚本增加 --no-branch（或检测当前分支已是 line/<id> 时不建分支）开关，避免与 sdd-loop-driver 的分支约定冲突；③ 校验器遇到 Shared Strings 的引用时接受代码 span 形式，或在错误文案中直接点明「引用不要放在反引号内」；④ token-efficiency：本轮为定位 design-map.md 的仓库归属多读了一次 meta 仓路径，建议在跨仓引用约定里固定 kangaroo-xuanji/ 前缀写法。
