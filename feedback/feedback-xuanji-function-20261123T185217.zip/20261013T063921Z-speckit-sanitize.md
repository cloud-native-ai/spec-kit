---
id: "20261013T063921Z-speckit-sanitize"
unit_id: "/speckit.sanitize"
unit_type: "command"
run_id: "sanitize:20261013T063831Z"
scope: "local"
probe: "speckit-sanitize-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-13T06:39:21Z"
summary: "全量扫描运行完整收尾:collect 新增 53 条 pending(19 dead-reference / 34 index-inconsistency),语义候选 0,破坏性项 0——未建清理计划、未触发确认门,未改动任何资料;逐组判读均为引擎假阳性或日期化历史记录。唯一实质产物是暴露了 sanitize-utils.py 的三处检查缺陷。"
---

## Review
全量扫描运行完整收尾:collect 新增 53 条 pending(19 dead-reference / 34 index-inconsistency),语义候选 0,破坏性项 0——未建清理计划、未触发确认门,未改动任何资料;逐组判读均为引擎假阳性或日期化历史记录。唯一实质产物是暴露了 sanitize-utils.py 的三处检查缺陷。

## Optimization Points
- 1. `sanitize-utils.py` `check_index_consistency` 双重缺陷(sanitize-utils.py:453-471):索引行第 5 列的原始 markdown 单元 `[label](url)` 被原样当路径判存在、且按工作区根而非索引文件所在目录解析;反向检查拿详情文件 stem(`001-<slug>`)对照索引行三位 ID(`001`)。结果:健康的特性注册表每次运行都产出 34 条假阳性(本轮实测)。
- 2. `CMD_RE = speckit\.([a-z][a-z-]*)`(sanitize-utils.py:347)要求工作区根存在 `templates/commands/<name>.md`,该布局仅在框架仓库成立;客户端工作区里一切 `/speckit.*` 命令提法都成为假 dead-reference(本轮 6 条)。
- 3. `REPO_PATH_RE`(sanitize-utils.py:803-805)从更长路径与 e.g. 示例中截取片段(`api/scripts/generate.sh` → `scripts/generate.sh`),示例路径被当活引用。
- 4. token-efficiency:本轮把同一份 53 条台账摘要打印了两遍(collect 的 store 与 status 输出完全重复);status 应投影增量或逐条明细而非重印全量 store。[token-efficiency]
