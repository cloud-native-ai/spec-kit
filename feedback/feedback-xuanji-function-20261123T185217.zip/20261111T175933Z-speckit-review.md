---
id: "20261111T175933Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "cred-sidecar-20261111T132500Z"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
feature: "009-credential-sidecar"
partial: false
created: "2026-11-11T17:59:33Z"
summary: "Composed the four segments and the ARC. Friction: the review template's documented ARC command reads the claimed status from the wrong registry row when the spec key digits differ from the feature id "
---

## Review
Composed the four segments and the ARC. Friction: the review template's documented ARC command reads the claimed status from the wrong registry row when the spec key digits differ from the feature id (reproduced: Draft vs Blocked); passed --feature-detail manually. Code gate refused on one blocking (/healthz stale-cycle 503).

## Optimization Points
- ARC claimed-status resolution should use the spec-feature binding; template invocation should pass --feature-detail; the artifact/implementation slots worked as specified; capture step correctly disclosed hat=framework and posted nothing.
