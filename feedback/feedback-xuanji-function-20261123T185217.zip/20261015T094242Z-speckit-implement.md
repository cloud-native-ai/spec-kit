---
id: "20261015T094242Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "implement-004-t027-daemon-20261015"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-15T09:42:42Z"
summary: "T027:函数守护进程改 cws_daemon 机制(用户裁定,对齐 daemon/aliyun/sts/router.py 范本)。新建 daemon/local/deployment/router.py(CwsDaemonRouter,POST 空/斜杠双注册 = invoke + GET /healthz),cmdline 经 CwsDaemonRoot.load_router(发现式挂载 "
---

## Review
T027:函数守护进程改 cws_daemon 机制(用户裁定,对齐 daemon/aliyun/sts/router.py 范本)。新建 daemon/local/deployment/router.py(CwsDaemonRouter,POST 空/斜杠双注册 = invoke + GET /healthz),cmdline 经 CwsDaemonRoot.load_router(发现式挂载 /api/v1/local/deployment)+ uvicorn;src/local/process.py(ThreadingHTTPServer)与旧契约测试删除。TDD:4 路由测试红到绿;e2e 重写为 TestClient+ASGI opener(26 本地测试全绿,全仓回归零新增);实跑冒烟:healthz 200 + 真实事件 500(DB 门控,对象源供数成功)。根因披露:排障中定位 cws-lib-python 环境缺陷——cws_vendor.typing_extensions 垫片缺 sentinel 且导入顺序敏感(uvicorn 先导入即毒化),require_dependency 以 from None 吞根因;测试已绕开,缺陷详情上送反馈。提交 e31e7f5(xuanji-function)/ a22f92fd(xuanji-images)。token:机制研读 2 文件全文,其余定向;测试走 TestClient 无网络线程;无 token-efficiency 标记。

## Optimization Points
- cws_vendor.typing_extensions 垫片缺陷(环境级,值得上送):垫片缺 anyio 所需的 sentinel,且导入顺序依赖——uvicorn 先于 cws_common 系导入时,垫片别名抢占 sys.modules["typing_extensions"] → fastapi 链炸;require_dependency 又以 from None 吞掉根因,排障成本高。建议 cws-lib-python 升级垫片至含 sentinel 的版本,或别名改为不覆盖已加载的真实模块。
- 实例指针价值:sts/router.py 范本的 @router.get("/") 与 @router.get("") 双注册是尾斜杠 307 的既解——新路由照抄即免坑;本 run 首版只注册 "/" 被 curl 实测抓出。
