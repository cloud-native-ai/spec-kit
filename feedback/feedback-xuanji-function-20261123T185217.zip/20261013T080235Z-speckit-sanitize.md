---
id: "20261013T080235Z-speckit-sanitize"
unit_id: "/speckit.sanitize"
unit_type: "command"
run_id: "sanitize:2026-10-13T07:43Z"
scope: "local"
probe: "speckit-sanitize-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-13T08:02:35Z"
summary: "/speckit.sanitize 全量扫描:53 项 pending 全部处置(1 项 repair 已执行,52 项误报/历史类已 dismiss 带注),验证 collect pending=0。发现 sanitize-utils.py 引擎缺陷 4 类并上送:"
---

## Review
/speckit.sanitize 全量扫描:53 项 pending 全部处置(1 项 repair 已执行,52 项误报/历史类已 dismiss 带注),验证 collect pending=0。发现 sanitize-utils.py 引擎缺陷 4 类并上送:

1. check_index_consistency features 族将 markdown 链接字面 [t](u) 当路径 is_file(),反向检查用文件 stem(001-slug) 与行 ID(001) 严格相等比对,真实索引上永不通过(每次 34 误报)。
2. 命令引用检查按框架仓布局验证 <root>/templates/commands/,client 仓库命令装于 compat 面(.qoder/commands 等),恒误报。
3. REPO_PATH_RE 缺 api/ 前缀且从 api/scripts/... 子串捕获内层路径,子模块内部引用在主仓恒误报。
4. apply 的 dismiss 落 state=resolved 而非 schema 声明的粘滞 dismissed,导致 dismiss 下轮即 reopen(粘滞分支为不可达死代码)。

就地修正披露:因 (4),52 项裁定结果以直写台账方式落 state=dismissed+注(与 merge 语义的 dismissed 分支一致,本地可逆),未改任何引擎代码。

已执行修复:003 spec plan.md 资源清单中 /cws_work/xuanji-function/docs/function-type.md → docs/reference/function-type.md(仓相对、存在路径)。

历史类裁定:003 tasks/plan 中 [X] 完成任务与设计陈述引用的 model_sync 形态已在后续重构中移除(全仓无实现),按历史记录保留不改写。

token:全程摘要优先,仅一次性消费 pendingTargets 清单与定向行摘录。

## Optimization Points
- 引擎判定先于人工判读:同一趟先跑确定性 collect,再对每类 pending 做地面真值核验(文件存在性/命令清单/子模块状态),避免按台账字面修复健康材料。
- 历史类死引用(已完成任务 [X]、设计陈述)不应改写;裁定为"历史记录"并落注,优于路径重写造成的历史失真。
- client 仓库中 sanitize 引擎的框架布局假设(templates/commands、features 索引解析、api/ 前缀缺失、dismiss 粘滞态不可达)是结构性误报源,应在框架源修复而非逐仓绕过。
