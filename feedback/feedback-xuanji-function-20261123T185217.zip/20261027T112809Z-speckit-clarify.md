---
id: "20261027T112809Z-speckit-clarify"
unit_id: "/speckit.clarify"
unit_type: "command"
run_id: "clarify-006-20261027t1927"
scope: "local"
probe: "speckit-clarify-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-27T11:28:09Z"
summary: "无人值守 clarify（Mode A）按派发契约的六个疑点逐项裁决并写回 requirements.md。源码实测确认：网关 governanceRegister 永不抛出（每类治理失败只产生 governance:* 告警且 HTTP 200），注册一致性无法逐请求自证；引擎 /documents/text 按 file_source 的 basename 判重并对重复来源返回 409，网关把"
---

## Review
无人值守 clarify（Mode A）按派发契约的六个疑点逐项裁决并写回 requirements.md。源码实测确认：网关 governanceRegister 永不抛出（每类治理失败只产生 governance:* 告警且 HTTP 200），注册一致性无法逐请求自证；引擎 /documents/text 按 file_source 的 basename 判重并对重复来源返回 409，网关把它透传为 5xx，因此重复摄入既不幂等成功也不新增 staging/文档。据此新增 unknown 幂等态、把读超时定为不重试、把 basename 唯一性写成显式约束，并新增可配置正文字节上限。

## Optimization Points
- clarify 的问题上限（5）与派发契约要求的 6 项裁决冲突，本轮把「成功语义」与「治理前置」合并为一条以满足上限；若派发方需逐项可追溯，建议在技能层允许无人值守模式按派发项数记录（仍不面向用户提问）。另：上游 requirements 阶段的「网关未按摄入去重」假设只对已受理摄入成立，本阶段纠正为「引擎来源级去重以拒绝呈现」，说明需求阶段对跨仓源码的实测粒度不足，建议 requirements 阶段对每个外部依赖至少实测一条失败路径。
