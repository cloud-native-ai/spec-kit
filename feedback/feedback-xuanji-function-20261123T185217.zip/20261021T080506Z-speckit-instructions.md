---
id: "20261021T080506Z-speckit-instructions"
unit_id: "/speckit.instructions"
unit_type: "command"
run_id: "instructions-reconcile-2026-10-21"
scope: "local"
probe: "speckit-instructions-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-21T08:05:06Z"
summary: "Full reconcile on framework 5e5cd0d8. Injected 3 template sections; refreshed stale facts (features 17→20, constitution v1.4.0.1→v1.5.0.1, removed doc/ submodule, added akeops/dashboard/daemon paths);"
---

## Review
Full reconcile on framework 5e5cd0d8. Injected 3 template sections; refreshed stale facts (features 17→20, constitution v1.4.0.1→v1.5.0.1, removed doc/ submodule, added akeops/dashboard/daemon paths); converged 40,910→35,064 B via R2 (Architecture) + R3 (Project Overview, Tech Stack) mechanical migrations with line-level uniqueness assertions; 17 other sections byte-identical; heading coverage vs 6 backups passed; 10 symlinks intact; docs validate violations=[]; final BUDGET over by 2,296 B → pending.

## Optimization Points
- 1. Budget/template structural mismatch: rendered template ≈32,008 B vs 32,768 B budget (760 B headroom), while the mandatory Documentation Map alone is 4,006 B — `within` is unreachable without deleting project content or framework sections. Recommend a framework decision: raise INSTRUCTIONS_BUDGET_BYTES or slim ambient template sections.
- 2. R2's "4 KB" relocation threshold is ambiguous (4,000 vs 4,096 B); Architecture sat at 4,064 B and was promoted. State the threshold in bytes.
- 3. R3 migration of Overview/Tech Stack (1.5-1.8 KB each) did not converge the file; consider gating R3 on an estimated post-migration size.
- 4. Setup-script auto-injection of the 3 new sections worked cleanly.
- 5. Stale doc/ submodule references survived in Documentation Map and Git Submodules; reconcile caught both.
