---
id: "20261027T111353Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "req-006-20261027T1913Z"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
feature: "006-knowledge-ingestion"
feature_id: "022"
partial: false
created: "2026-10-27T11:13:53Z"
summary: "create-requirements 全流程执行：脚手架上，创建脚本按分支名推导出 007（006 已被本特性分支与并存的 006-fc-infra-ingestion 占用），并在新分支 007-knowledge-ingestion 上自动 checkout，与派发契约固定的 006 目录/分支不一致；已用 git branch -f 快进 006 并把提交迁回，删除多余分支。确定性校验器首"
---

## Review
create-requirements 全流程执行：脚手架上，创建脚本按分支名推导出 007（006 已被本特性分支与并存的 006-fc-infra-ingestion 占用），并在新分支 007-knowledge-ingestion 上自动 checkout，与派发契约固定的 006 目录/分支不一致；已用 git branch -f 快进 006 并把提交迁回，删除多余分支。确定性校验器首轮即 status=ok（5 项检查 0 发现），需求正文 30 FR / 10 SC / 10 Shared Strings，无 active 澄清标记。

## Optimization Points
- 创建脚本的编号推导应把「当前所在分支自身」排除或识别为已占用目标，否则「先建分支再跑 requirements」这一常规顺序必然多推一号；且脚本自动 checkout 新分支属未被调用方预期的副作用，建议在 --json 输出中显式标注将从哪个分支切到哪个分支，或提供 --no-checkout。
