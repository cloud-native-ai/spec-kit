---
id: "20261015T115510Z-speckit-instructions"
unit_id: "/speckit.instructions"
unit_type: "command"
run_id: "instructions-daemon-naming-20261015-token"
scope: "local"
probe: "speckit-instructions-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-15T11:55:10Z"
summary: "消耗观察(token-efficiency):本次运行可避免开销两处——①generate-instructions.sh 为查看报告头尾各跑一次,产生一份冗余备份与重复计算;②收尾引擎调用缺调用方声明参数(--run-id/--complexity/--points)试错三趟。均为一次性代价,无制品影响。"
---

## Review
消耗观察(token-efficiency):本次运行可避免开销两处——①generate-instructions.sh 为查看报告头尾各跑一次,产生一份冗余备份与重复计算;②收尾引擎调用缺调用方声明参数(--run-id/--complexity/--points)试错三趟。均为一次性代价,无制品影响。

## Optimization Points
- generate-instructions.sh 报告一次性完整输出即可,无需分头尾两次调用;收尾引擎调用前先查 --help 汇总所需声明参数,一趟完成
