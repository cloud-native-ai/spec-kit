---
id: "20260817T034951Z-speckit-instructions"
unit_id: "/speckit.instructions"
unit_type: "command"
run_id: "instructions-reconcile-2026-08-17"
scope: "local"
probe: "speckit-instructions-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-08-17T03:49:51Z"
summary: "Full reconcile (no args). Setup script ran non-destructively, injected two new template sections, created backup. Section-by-section refresh converged 3 sections (Project Overview, Documentation Map, "
---

## Review
Full reconcile (no args). Setup script ran non-destructively, injected two new template sections, created backup. Section-by-section refresh converged 3 sections (Project Overview, Documentation Map, Framework Map placeholder row), tolerated all hand-authored and managed-range sections, recovered nothing (base is superset of all 3 backups). All paths and symlinks verified OK. One glossary term proposed. Clean run.

## Optimization Points
- 1. Documentation Map Key Content cells drift silently (constitution version v1.3.0.1, feature count 15 survived the 2026-07-28 refresh as-is until this run re-verified them against source files). The command text already instructs re-verifying numeric facts, but the setup script's scripted existence check only covers Location paths - extending generate-instructions.sh to also flag Key Content numeric tokens (version/count) that disagree with constitution.md/features.md would make this drift mechanically detectable instead of relying on agent diligence.
