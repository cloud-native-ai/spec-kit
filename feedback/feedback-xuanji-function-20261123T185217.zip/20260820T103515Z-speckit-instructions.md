---
id: "20260820T103515Z-speckit-instructions"
unit_id: "/speckit.instructions"
unit_type: "command"
run_id: "instructions-reconcile-2026-08-20"
scope: "local"
probe: "speckit-instructions-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-08-20T10:35:15Z"
summary: "Targeted reconcile with user input (cmdline = first-class execution entry). Converged 10 sections incl. template-shape compressions and Git Workflow migration to .specify/git-workflow.md; coverage che"
---

## Review
Targeted reconcile with user input (cmdline = first-class execution entry). Converged 10 sections incl. template-shape compressions and Git Workflow migration to .specify/git-workflow.md; coverage check vs 4 backups passed; symlinks intact; session+knowledge memory recorded.

## Optimization Points
- ## Optimization Points
- 1. Template-shape drift detection: the setup script auto-injects only *absent* sections; sections whose *shape* drifted from the latest template (inline tables → summary+pointer) required manual comparison with instructions-template.md. A programmatic section-shape diff (e.g. flag sections whose body contains full tables while the template body is pointer-form) would surface these converge candidates at observation time instead of during manual read-through.
