# Feedback Package Manifest

> This feedback targets the Spec Kit framework itself (templates, commands, skills, scripts, docs) — not the LLM, agent CLI, harness, or any user project code.

- **Generated**: 2026-11-24T04:23:27Z
- **Entries**: 2
- **Time range**: 2026-11-23T17:55:49Z → 2026-11-23T17:55:55Z
- **spec-kit version**: 0.0.22
- **Install source**: https://gitlab.alibaba-inc.com/cloud-native-ai/spec-kit.git @ df1b204f5ba6ad696e7bb330a2cfb418961bb0b4
- **Excluded (non-framework, kept local)**: 1 entry — skill:sanitize-materials

| Created | Unit | Partial | Probe | Slice | Summary |
|---------|------|---------|-------|-------|---------|
| 2026-11-23T17:55:49Z | /speckit.sanitize | False | speckit-sanitize-wrapup | commands | materials lane 完整七阶段：collect 739 项（682 pending，语义候选 0）；单批前置确认后执行 A 组 3 项活文档断链修复（README/contribute 旧锚点路径改写为 .specify/ 根现路 |
| 2026-11-23T17:55:55Z | /speckit.sanitize | False | gate-sanitize-destructive-cleanup | commands | confirm-gate 门控观察事实：单批确认触发并获用户裁定（执行 A+B，C 留 pending）；批次仅含可逆 repair/dismiss，无真正 delete；引擎 exit-2 拒绝被尊重且零副作用。 |
## Exec-Quant Payload

- **Records**: 57
- **Source forms**: records-dir 57, legacy-jsonl 0
- **Skipped unreadable**: 0
- **Truncated**: 0
- **Cap**: 1000 records / 16777216 bytes (triggered: no)
- **Source project**: xuanji-api
- **Collected range**: 2026-10-29T04:15:11Z → 2026-11-23T17:55:48Z

