---
id: "20261123T175549Z-speckit-sanitize"
unit_id: "/speckit.sanitize"
unit_type: "command"
run_id: "20261123T175521Z-sanitize"
scope: "local"
probe: "speckit-sanitize-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-23T17:55:49Z"
summary: "materials lane 完整七阶段：collect 739 项（682 pending，语义候选 0）；单批前置确认后执行 A 组 3 项活文档断链修复（README/contribute 旧锚点路径改写为 .specify/ 根现路径）与 B 组 115 项镜像 data-URI 误报 dismiss；apply 首拒 README 目标（材料根外）后按引擎契约改道自动解决；C 组 564"
---

## Review
materials lane 完整七阶段：collect 739 项（682 pending，语义候选 0）；单批前置确认后执行 A 组 3 项活文档断链修复（README/contribute 旧锚点路径改写为 .specify/ 根现路径）与 B 组 115 项镜像 data-URI 误报 dismiss；apply 首拒 README 目标（材料根外）后按引擎契约改道自动解决；C 组 564 项历史 spec 记录按用户裁定留 pending。终态 pending 679 / resolved 60。运行判定四轴均 not_evaluated（源不可得），trigger_feedback=false。

## Optimization Points
- collect/apply 材料根契约不一致：docs-utils 断链 lane 对 README.md 产出发现，但 apply 以 "target outside material roots" 拒绝 README.md 计划行（exit 2，item #115/#116）；本轮以「内容先修复 + collect 自动解决」绕过。建议对齐两侧根集或在 collect 阶段标注不可入计划的目标。
- dismiss 对程序性重检不持久：115 项 docs/mirrors data-URI 误报 dismiss 成功后，验证性 re-collect 全部 reopened（deterministic.reopened=115）。根因是 docs-utils 断链检查把 data:image/... URI 当路径；建议检查器跳过 data: URI，或合并状态机对证据未变的 dismiss 项不重开。
- token-efficiency：findings.json 在三个独立 Bash 调用中被重复解析（分桶、镜像细分、other 细分），一次程序化 digest 即可携带全部桶分布，减少重复读取。
