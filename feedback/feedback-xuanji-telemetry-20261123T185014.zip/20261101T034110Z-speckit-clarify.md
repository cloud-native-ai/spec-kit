---
id: "20261101T034110Z-speckit-clarify"
unit_id: "/speckit.clarify"
unit_type: "command"
run_id: "r20261101T062000Z-t3a0"
scope: "local"
probe: "speckit-clarify-wrapup"
kind: "internal"
slice: "commands"
feature: "003-l3-component-design"
feature_id: "004"
partial: false
created: "2026-11-01T03:41:10Z"
summary: "Clarify（Mode A）五个欠指定项一次裁决成功：写面三区、pin 取证口径、Aone 记录归属、双环境轴与预发读法、摄取契约四层归属；五项均有跨仓上游证据支撑，无一需要向用户回问。首次 doc-consistency evidence 面因 FR-019 误写双等级失败，pre-analyze 因把 submodule 树内路径写成裸仓内路径产生 12 条假悬空引用，两处均就地修复后复跑全"
---

## Review
Clarify（Mode A）五个欠指定项一次裁决成功：写面三区、pin 取证口径、Aone 记录归属、双环境轴与预发读法、摄取契约四层归属；五项均有跨仓上游证据支撑，无一需要向用户回问。首次 doc-consistency evidence 面因 FR-019 误写双等级失败，pre-analyze 因把 submodule 树内路径写成裸仓内路径产生 12 条假悬空引用，两处均就地修复后复跑全绿。

## Optimization Points
- ① 客户仓的 requirements 引用 xuanji-function/xuanji-api 树内文件时，裸路径会被 pre-analyze 判成本仓悬空引用；建议 missing-path 判定对同名子模块目录降级或提示，或模板默认要求跨仓路径加仓名前缀（本轮已手工按后者处理，开销约一轮复跑）。② run-determination 的 artifact_correctness 轴要求 names-current/names-baseline（失败用例名集），docs-only 阶段无法提供，只能记 not_evaluated；建议提供 not-run-docs-only 显式值域，让'本阶段无测试'与'未测量'可区分。③ token-efficiency 自评：本轮两轮门禁复跑均属可机械提前发现的写法问题（证据等级写成双值、跨仓路径未加前缀），各浪费一轮全量门禁；已省项是全程用 git show <pin>:<path> 读 submodule 而非初始化整个 submodule，避免一次 clone 与工作树变更。无精确 token 计数来源，不报数值。
