---
id: "20261101T055446Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261101T062000Z-t3a0"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "003-l3-component-design"
feature_id: "004"
partial: false
created: "2026-11-01T05:54:46Z"
summary: "review-fix retro record: /speckit.implement ran S1-S5b (8 commits, ~2400 inserted lines) and executed none of the six mandated wrap-up steps, so run determination, exec quant, feedback and docs-sync w"
---

## Review
review-fix retro record: /speckit.implement ran S1-S5b (8 commits, ~2400 inserted lines) and executed none of the six mandated wrap-up steps, so run determination, exec quant, feedback and docs-sync were all blind for the largest stage of the line. This record is written during review-fix (same run id), and it must not be read as a reconstruction of implement-time measurements.

## Optimization Points
- Make the wrap-up machine-checkable, not prose: emit a machine-readable wrap-up manifest (unit + run_id + the record ids) and have the stage runner refuse to mark a stage done, or advance the state spine, while the manifest is absent. The spine should enumerate every stage with an explicit 'not recorded' instead of omitting one.
