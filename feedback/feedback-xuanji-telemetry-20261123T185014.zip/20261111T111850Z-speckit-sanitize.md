---
id: "20261111T111850Z-speckit-sanitize"
unit_id: "/speckit.sanitize"
unit_type: "command"
run_id: "20261111T1115Z-sanitize-materials"
scope: "local"
probe: "speckit-sanitize-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-11T11:18:50Z"
summary: "Materials lane completed: collect re-detected the full 2026-11-06 dismissal set (182 pending, 0 new, 0 semantic candidates), classified into historical 001/003 artifacts (175), old-gen feature-index r"
---

## Review
Materials lane completed: collect re-detected the full 2026-11-06 dismissal set (182 pending, 0 new, 0 semantic candidates), classified into historical 001/003 artifacts (175), old-gen feature-index rows (3) and structural false positives (4), then applied 182 state-only dismissals with 0 failures. Layout check run read-only: convergence blocked by init-created placeholder anchors.

## Optimization Points
- sanitize-utils.py apply maps disposition dismiss to state=resolved, so the next collect re-opens every dismissed finding as "reopened (re-detected)"; the dismissed state exists in STATES and merge treats it as authoritative, so apply likely should set dismissed. Effect: the same 182-finding digest repeats each run. [token-efficiency]
- Command-ref and skill-ref checks resolve templates/commands/<name>.md and skills/<name> against the repo root; a client runtime keeps them under .specify/templates|.qoder/commands and .specify/skills, so 45 of 182 findings are structural false positives the agent had to classify by hand. [token-efficiency]
- Index-consistency treats the raw markdown-link cell "[001](features/001.md)" as a repo-root path; either parse the link target or document the bare-path cell format in the detector contract.
- anchor-layout-migrate refuses moves whose target exists, and specify init created placeholder .specify/features.md and .specify/constitution.md over legacy anchors, so layout convergence cannot run without a manual placeholder decision.
