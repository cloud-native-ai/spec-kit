---
id: "20261031T222300Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "r20261101T062000Z-t3a0"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-31T22:23:00Z"
summary: "requirements 阶段整体顺畅：脚手架脚本在客户仓缺 CWS_LIB_BASH_HOME 时直接硬失败，需手工 source profiles 的 cws/path.rc 才能继续；doc-consistency 的 evidence 面对未提交文件只能报 not-evaluated，必须先提交再复跑一次；flow-class owner 在客户仓不可解析（framework-source"
---

## Review
requirements 阶段整体顺畅：脚手架脚本在客户仓缺 CWS_LIB_BASH_HOME 时直接硬失败，需手工 source profiles 的 cws/path.rc 才能继续；doc-consistency 的 evidence 面对未提交文件只能报 not-evaluated，必须先提交再复跑一次；flow-class owner 在客户仓不可解析（framework-source-required）。

## Optimization Points
- ① create-new-requirements.sh 的 common.sh 依赖检查可给出可执行修复提示（如提示 source ${PROFILES}/config/cws/path.rc），而不是只报变量未设置；② requirements 阶段的 evidence 面建议明确"提交后复跑"为固定节奏，避免把 not-evaluated 误读成通过；③ 客户仓无 templates/commands 时 flow-class check 的措辞可补一句"降级显示 owner-unavailable，门禁不变"。
