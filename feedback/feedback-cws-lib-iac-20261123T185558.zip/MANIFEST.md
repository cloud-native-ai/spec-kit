# Feedback Package Manifest

> This feedback targets the Spec Kit framework itself (templates, commands, skills, scripts, docs) — not the LLM, agent CLI, harness, or any user project code.

- **Generated**: 2026-11-23T10:55:58Z
- **Entries**: 1
- **Time range**: 2026-11-06T06:51:33Z → 2026-11-06T06:51:33Z
- **spec-kit version**: 0.0.22
- **Install source**: https://gitlab.alibaba-inc.com/cloud-native-ai/spec-kit.git @ cdc79cdb52c892e8ed43145860cea2cd6ffdbfdf

| Created | Unit | Partial | Probe | Slice | Summary |
|---------|------|---------|-------|-------|---------|
| 2026-11-06T06:51:33Z | /speckit.feedback | False | speckit-feedback-wrapup | commands | Client-project hat detected from the root-directory criterion (no root templates/skills/shared/src/specify_cli). All 34  |
## Exec-Quant Payload

- **Records**: 29
- **Source forms**: records-dir 29, legacy-jsonl 0
- **Skipped unreadable**: 0
- **Truncated**: 0
- **Cap**: 1000 records / 16777216 bytes (triggered: no)
- **Source project**: cws-lib-iac
- **Collected range**: 2026-11-03T12:14:07Z → 2026-11-06T06:51:27Z

