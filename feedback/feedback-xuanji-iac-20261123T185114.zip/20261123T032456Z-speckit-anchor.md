---
id: "20261123T032456Z-speckit-anchor"
unit_id: "/speckit.anchor"
unit_type: "command"
run_id: "r20261123T032146Z-e005"
scope: "local"
probe: "speckit-anchor-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-11-23T03:24:56Z"
summary: "Wrote semantic four-pillar decisions into all anchors with concrete criteria and initial targets; complete criteria sets restored after discovering replace semantics."
---

## Review
Wrote semantic four-pillar decisions into all anchors with concrete criteria and initial targets; complete criteria sets restored after discovering replace semantics.

## Optimization Points
- Document criteria replacement prominently: repeated --criterion flags must be passed in one invocation; sequential single-criterion calls leave only the last criterion and can silently erase the set.
