---
id: "20261018T094047Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "003-de-mechanism-boundary-rereview-20261018"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
feature: "003-de-mechanism-boundary"
feature_id: "F-003"
partial: false
created: "2026-10-18T09:40:47Z"
summary: "Focused re-review of F1-F4 at 234431e: reproduced 250 passed and the 107-test baseline, independently probed readback presence, derived-view mutations, residual-archive counts, and receipt hardening. "
---

## Review
Focused re-review of F1-F4 at 234431e: reproduced 250 passed and the 107-test baseline, independently probed readback presence, derived-view mutations, residual-archive counts, and receipt hardening. All four P1 findings closed; four P2 residuals recorded (IPv6/single-label/non-string edges, uneven seed coverage, prerequisite script, archive/authority residual). Only review.md was updated.

## Optimization Points
- Re-review mode gap: the review template's replacement rule 8 says to overwrite `review.md` when regenerating, but a focused re-review of a prior report must preserve the first-round findings it verifies. Define an explicit re-review mode (append a clearly delimited closure section, or a separate closure artifact) with a closure-evidence matrix: code anchor + test + independent probe + residual risk.
- Prior-finding closure has no standard evidence contract: the command's finding schema is problem-only, so "Closed" can be claimed from a commit message. Require, per finding, the fix location, the test that fails before and passes after, an independent probe output, and a named residual or "none".
- Recurring friction: `.specify/scripts/bash/check-prerequisites.sh` still exits 1 with `CWS_LIB_BASH_HOME` unset in this environment; the first review recorded the same issue. The command should degrade to direct feature-directory discovery with a recorded warning.
