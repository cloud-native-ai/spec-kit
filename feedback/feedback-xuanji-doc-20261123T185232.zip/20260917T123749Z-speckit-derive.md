---
id: "20260917T123749Z-speckit-derive"
unit_id: "/speckit.derive"
unit_type: "command"
run_id: "oss-code-graphrag-20260917"
scope: "local"
probe: "speckit-derive-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-09-17T12:37:49Z"
summary: "Derivation ran the full pipeline on a handed-in architecture document with no source list: 18 sources grounded online (16 primary, 2 unverified recorded not dropped), 9 reasoning moves newly issued vi"
---

## Review
Derivation ran the full pipeline on a handed-in architecture document with no source list: 18 sources grounded online (16 primary, 2 unverified recorded not dropped), 9 reasoning moves newly issued via moves-add, 12-step chain terminated on condition (b) at budget, 9 architecture elements (7 derived, 2 provisional), 4 open questions, validate converged to zero errors with A11/A14 attested. Scope kept to .specify/derive/ artifacts only; no user source touched. Two wrong arXiv IDs in circulation were caught by content-level verification, and the handed-in UniXcoder/LLM-shortlist claims were demoted to open questions rather than inherited.

## Optimization Points
- Handed-in input was a conclusion document without a source list; the run had to construct the candidate source list itself from the document's technology claims — a source-list-free intake path that the command docs mention only implicitly (Handoffs: "可来自任何渠道"); worked, but cost extra judgment on which claims deserved grounding.
- Engine parse_blocks silently drops multi-line field continuations; first validate pass failed A3/A10/A8 partly because derivations were written as wrapped multi-line text. A one-line note in the scaffold template ("fields are single-line") would save one full rewrite cycle.
- Two arXiv IDs commonly cited for BGE-M3/UniXcoder in LLM-written docs (2402.03289, 2205.08474) resolved to entirely different papers; content-level verification caught both. Reinforces that probe liveness alone (HTTP 200) is insufficient grounding for arXiv links.
- A8 (element confidence == step minimum) plus blocked-element downgrade forces blocked elements to own at least one provisional step; this pushed two genuinely-ungrounded claims (concept layer, framework adapters) into explicit provisional steps D-11/D-12 instead of hiding them in element prose — the rule worked as designed.
- Step budget (12) was exactly consumed; --max-steps default is tight for a topic with four storage/model layers plus license filtering. Future runs on similarly broad topics may want --max-steps 16 upfront.
