---
id: "20261031T070652Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "r20261030T120500Z-d101-review-fix4"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
feature: "023-xuanji-doc-architecture"
feature_id: "029"
partial: false
created: "2026-10-31T07:06:52Z"
summary: "Review-fix4 of 023-xuanji-doc-architecture / Feature 029: converge review3 R3-01/R3-02/R3-03. R3-01: REST push now forwards multipart bytes to ingest; push/pull/job/cancel serve xuanji-api's pinned Jo"
---

## Review
Review-fix4 of 023-xuanji-doc-architecture / Feature 029: converge review3 R3-01/R3-02/R3-03. R3-01: REST push now forwards multipart bytes to ingest; push/pull/job/cancel serve xuanji-api's pinned Job with 202+Location or 200 dry-run; system/openapi.json is the pinned YAML projection with info.version 1.0.0, x-contract-sha256 and Cache-Control no-cache; test_wire_pin.py validates every field against the pin; api:openapi:verify prints verified with served-projection passed; a live ingest+api probe confirmed the chain. R3-02: bin.xuanji-doc-ingest points to a realpath-resolving JS launcher that starts src/server.ts with tsx, forwards signals and propagates non-zero failures; three bin tests exercise a .bin-shaped symlink. R3-03: .gitignore covers *.egg-info/ and the worktree is clean.

## Optimization Points
- 1. A response contract must be tested with a schema validator over the pinned document, including negative mutations; path-only or shape-only checks hide request/response drift. 2. Serving a discovery document from the owner's pin requires a runtime projection whose packaging is part of the deployment contract; test/ fixtures are not installed with an app package. 3. A no-arg bin that exits 0 without listening is indistinguishable from a clean shutdown; entry tests must invoke the same symlink mechanism consumers use and assert a listener or a non-zero failure. 4. Fixing a response wire exposes adjacent request-side and per-domain method mismatches; record them explicitly as follow-ups instead of claiming full contract alignment.
