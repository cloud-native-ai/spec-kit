---
id: "20261028T111335Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "r20261028T083000Z-7c1a-requirements"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
feature: "021-code-cgit-urls"
feature_id: "026"
partial: false
created: "2026-10-28T11:13:35Z"
summary: "为 Feature 026（Code cgit URLs）创建 requirements：先核验 U1 事实（仓内无 cgit/compose 引用、repos.json local_path 为 macOS 路径、活跃检索面是外部 graphicle mcp、mcp-adapter.ts 为 dormant CodeRLM），再按 020 先例直接落盘 spec 021；将用户列出的 a–i 未"
---

## Review
为 Feature 026（Code cgit URLs）创建 requirements：先核验 U1 事实（仓内无 cgit/compose 引用、repos.json local_path 为 macOS 路径、活跃检索面是外部 graphicle mcp、mcp-adapter.ts 为 dormant CodeRLM），再按 020 先例直接落盘 spec 021；将用户列出的 a–i 未知项登记为 Q-001–Q-009，未擅自定案，其中输出面/实现位置、ref 策略、凭据注入三项以 NEEDS CLARIFICATION 内联标记；新建并绑定 Feature 026（Draft），补齐 feature-ref、checklist 与可复现结构检查（FR=9 SC=8 US=5 markers=3 open_questions=9 PASS）。

## Optimization Points
- 命令模板默认在 requirements 阶段把 Related Feature 保持为 Need clarification，但编排流要求本阶段创建并绑定 Feature；建议为 /speckit.requirements 增加显式 --bind-feature 输入，避免每次以偏差记录收口。
- create-new-requirements.sh 无条件 git checkout -b，在“分支已预创建”的 worktree 流程中不可用（020 已有同类记录）；建议提供 --no-branch/--spec-dir 模式。
- requirements 结构检查脚本再次按 spec 复制（020 一份、021 一份）；建议提升为 .specify/scripts/python/requirements-structure-check.py，以 spec 目录为参数复用。
- token-efficiency：为对齐 house 约定读取了 020 requirements 全文（484 行）与 025 详情（92 行）等大文件，未先用标题/片段摘要抽样；建议生成每仓的“spec 约定摘要”以减少上下文注入。
