---
id: "20261031T055432Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "r20261030T120500Z-d101-review2"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
feature: "023-xuanji-doc-architecture"
feature_id: "029"
partial: false
created: "2026-10-31T05:54:32Z"
summary: "Review 2 (read-only recheck) of 023-xuanji-doc-architecture / Feature 029 against review-fix 355070a4. F1/F5/F6 closed; F2/F3/F7/F8 closed with residuals; F4 and F9 remain open. P0 0 / P1 3 / P2 4. Ne"
---

## Review
Review 2 (read-only recheck) of 023-xuanji-doc-architecture / Feature 029 against review-fix 355070a4. F1/F5/F6 closed; F2/F3/F7/F8 closed with residuals; F4 and F9 remain open. P0 0 / P1 3 / P2 4. New P1s: (R2-01) INGESTION_REVIEW_MODE carrier/test exists but review-mode.ts has no production call site and admin deployment_view omits the key; (R2-02) C-13/E12/Q-05 require A Health wire shape and six dependencies while runtime/tests still emit top-level domains/profile and five dependencies; (R2-03) C-11 requires job/audit reads via config/ingest but the handler still uses the ingest adapter. P2: analyze ledger counts are 31 not 32; 022 C-3 has no supersession pointer; verification still lists E-1 as absent; no durable commit-chain ledger. Gates reproduce: api 392, ingest 61, parity 10, React 34, openapi pin-only/verified, validate-tasks 0 warnings, coverage 63/63.

## Optimization Points
- 1. A closure ledger must be verified against the production path, not just the document it names; contract-only edits can leave all gates green.
- 2. When aligning a clause with an external owner, update the implementing tests in the same round (Health shape, job read).
- 3. Counts in closure ledgers must be recomputed from enumerated rows; the analyze ledger claims 32 unique but has 31.
- 4. Cross-spec supersession must be reachable from the superseded spec (022 C-3), not only from the new ledger.
- 5. Keep a durable commit-chain ledger instead of relying on handoff messages.
- 6. Reconcile deferred-table status (E-1) when a prerequisite is delivered.
