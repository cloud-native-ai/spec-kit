---
id: "20261031T180955Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "r20261030T120500Z-d101-review6"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
feature: "023-xuanji-doc-architecture"
feature_id: "029"
partial: false
created: "2026-10-31T18:09:55Z"
summary: "Review6 (final recheck) of 023-xuanji-doc-architecture / Feature 029 at 0433418f rechecks review-fix6 7538043a and f23c1974. All five review5 findings are closed and all twelve carried P2s are closed:"
---

## Review
Review6 (final recheck) of 023-xuanji-doc-architecture / Feature 029 at 0433418f rechecks review-fix6 7538043a and f23c1974. All five review5 findings are closed and all twelve carried P2s are closed: R5-01 (pinned read bodies), R5-02 (lang/path_prefix/tags/limit/cursor, total/next_cursor, 200 miss), R5-03 (version equality -> version_conflict, source_url, heading/anchor normalization, citation_id, front-matter persistence), R5-04 (atomic push envelope, include minItems, symlink skip, doc_path placement), R5-05 (L-8/W-6-01 named waiver); R4-02 1001-count invariant, R4-03 20-file push and 10000/2GiB pull caps, R4-04 part allowlist and header escaping, R4-05 header/body request-id equality, R4-06 package-data pin and wheel discovery, R2-04 18/13/31/26, R2-05 dated 022 pointer, R2-06 one current verification block with E-1, R2-07 commit-chain. New counts: P0 0 / P1 1 / P2 4. R6-01 (P1): write and read surfaces use three different doc_path identities; a real-ingest probe pushing doc_path docs/rt.md writes zh/docs/rt/index.md, the Job item reports zh/docs/rt, the query item reports docs/rt/index.md, and resolve docs/rt.md returns 200 found=false (only docs/rt/index.md resolves); the pin push/Job/query/resolve examples all use docs/ops/pod-restart.md and C-32 mandates the bundle directory, so the identity is undefined and the generated suite cannot see it. R6-02 (P2): code/search returns backend order, not the pinned (repo,path,line,end_line) order. R6-03 (P2): 21 file parts with 21 descriptors returns 400 invalid_metadata instead of the pinned/C-34 413 for the count limit. R6-04 (P2): the generated two-sided suite validates Job responses against a Python fake and read bodies against flat seeded files, so the real ingest -> docs-volume -> read chain is outside the gate. R6-05 (P2): tasks.md:306 and verification.md:220 still say L-1...L-6 while the obligation ledger owns L-8. Gates (exit 0): api 490 passed 1 skipped, ingest 99, parity 10, react 35, pin-only check and verified owner verify, validate-tasks 0/0, validate-requirements 0/0, clause coverage ok (1 pre-existing warning), carryover 18/13/31/26, generated suite 44 collected, tsc clean, corpus frozen, whitespace clean. Merge recommendation: NO-GO for an unconditional merge; conditional GO only after R6-01 is fixed or explicitly waived with an obligation row. No ANOMALY.

## Optimization Points
- 1. Validate cross-surface identity with a real round-trip, not only per-operation schema conformance. 2. A generated suite with one side faked is a schema test, not an integration test; keep at least one real-service lane. 3. Enforce pinned ordering in the service, never delegate it to an untrusted backend. 4. Count multipart parts before parsing metadata cardinality so the pinned count-limit status (413) is the first determinable failure. 5. An error status is part of the contract; 400 where the owner requires 413 is a contract break even with no job. 6. Recompute ledger ranges and carried counts from the rows, not from prose.
