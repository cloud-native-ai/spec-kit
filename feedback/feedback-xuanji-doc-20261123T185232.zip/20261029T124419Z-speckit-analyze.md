---
id: "20261029T124419Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261028T162000Z-c1a2-analyze"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
feature: "022-citation-architecture"
feature_id: "027"
partial: false
created: "2026-10-29T12:44:19Z"
summary: "Analysis phase for 022-citation-architecture / Feature 027. Read requirements (28 FR / 12 SC / 7 US / 31 STR / 23 A), plan (344 lines, Implementation Boundary A/B, Known Spec Tension), research (R-1.."
---

## Review
Analysis phase for 022-citation-architecture / Feature 027. Read requirements (28 FR / 12 SC / 7 US / 31 STR / 23 A), plan (344 lines, Implementation Boundary A/B, Known Spec Tension), research (R-1..R-10), data-model (9 entities), all 7 contracts (186 C-N), quickstart (11 sections), tasks (33 tasks: 31 open + 2 deferred; E-1..E-7), the 50-item checklist (14 findings) and the Feature 027 three surfaces. Reproduced validate-tasks PASS 0/0, requirements structure PASS FR=28 SC=12 US=7 markers=0 open_questions=8 local_strings=31, and the 186/186 one-off clause accounting (162 repo + 24 external, 0 missing/extra/duplicate/unresolved); reproduced clause_extract.py UNPARSABLE-NAMED on all 7 contracts. Independently reviewed all 14 checklist findings (13 CONFIRMED, 1 ADJUSTED, 0 REJECTED) and all 5 known tensions; found 15 new issues. Final: 3 HIGH (F-001 locator shape, F-002 heading existence, F-003 C-20/C-30 409), 14 MEDIUM, 12 LOW, 0 CRITICAL; GATE=fail. Five HIGH candidates were validated by fresh-context read-only subagents: 3 confirm, 2 downgrade (F-004 HIGH->MEDIUM, F-021 HIGH->LOW), 0 reject, 40% downgrade rate. No spec/code/doc/registry file was modified; no push.

## Optimization Points
- 1) HIGH cascade: the locator shape (ingest flat citation vs C-33 citation.locator), heading existence (C-7 allows unresolved headings; doc-url has no 'heading not found' branch), and C-20 vs C-30 auto-fill + partial unique index are the three blockers; fix them in one owner each before implement. 2) One-source-of-truth: four predicates are normatively duplicated across contracts (capabilities gating, off byte-identity, STR-014 fail-fast, doc_url off) while plan Gate 4 labels them 'reference only'; convert to pointers and correct the XIV check. 3) Accounting: data-model's OpenAPI consistency enum omits pin-only; 2 clauses (openapi-pin C-6/C-7) are owned only by deferred T019; SC-005's robot leg is not mapped to E-2. 4) Boundary: C-28's doc-summary/batch-ingest half is in-repo but wholly assigned to external E-3; C-20/C-21 credential clauses mix in-repo and deployment halves. 5) Decidability: SC-008/DoD-4 byte-identity needs a canonical baseline fixture with response_time/track_id fixed; T001 currently records only exit codes and shapes. 6) token-efficiency: used programs for counts/claims/structure and targeted excerpts for evidence; no machine-managed store dumps.
