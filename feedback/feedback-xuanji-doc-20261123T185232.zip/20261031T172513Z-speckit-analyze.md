---
id: "20261031T172513Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261101T050000Z-l3a2"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
feature: "023-xuanji-doc-l3-design"
feature_id: "029"
partial: false
created: "2026-10-31T17:25:13Z"
summary: "analyze2 on 023: every deterministic gate re-ran green (validate-requirements ok; validate-tasks PASS; pre-analyze pass on all three stages with 34 missing-path advisories; decomposition proceed fr 29"
---

## Review
analyze2 on 023: every deterministic gate re-ran green (validate-requirements ok; validate-tasks PASS; pre-analyze pass on all three stages with 34 missing-path advisories; decomposition proceed fr 29 <= 30 and tasks 39 <= 40; doc-consistency reader+evidence exit 0 on all four artifacts; count face pass with --spec-dir and not-evaluated exit 1 without it; docs-utils 763 = 747/13/2/1, by path 733/24/6). Of the 21 first-round findings, 18 are fully closed against the files, 2 are partial at the file level, 1 is correctly carried as OI-1. Partial 1: AN-01's replacement criterion (evidence face exit 0 after T024 commits the page) is narrower than its stated condition - probed live, a committed file with uncommitted edits passes, and a future as-of (2099-01-01) passes, so the gate can still be green on content that is not in HEAD. Partial 2: AN-05's wrong path split survives in the frozen baseline evidence and gate ledger (721/23/744 presented as the path split; 744 + 6 = 750 != 763) and in features/029.md, although plan F-15 itself was corrected. Fix-introduced issues: the registry still says 2 Partial while the plan now has 3 (VI flipped by AN-03), plan cites T005/T024 for the H2/H3 equality checks that live in T004/T024, tasks still pin plan.md at 2e45ba93 (the pre-fix commit whose G14/C-2 the fix corrected), T008's declared gate-* channel does not reproduce the baseline's value, and the new row T008 has no traceability anchor. Verdict PASS (0 CRITICAL / 0 HIGH / 3 MEDIUM / 6 LOW).

## Optimization Points
- 1) When a finding is closed by rewriting a narrative, rewrite every artifact that restates the same fact (frozen baseline, gate ledger, registry summary) in the same pass - a corrected plan with an uncorrected baseline is a cosmetic closure and the analyze rerun will find it. 2) Replacing a findings-based judge with an exit-code judge needs a content-provenance clause: add 'git status --porcelain <page>' empty (or HEAD blob sha256 == working file) and an as-of upper bound, because the evidence face reads the working tree and only lower-bounds as-of. 3) A fix that flips a Constitution row must propagate the Partial count to the registry copies; validate-* gates never compare plan rows to features.md. 4) Re-pin every commit hash cited in downstream artifacts after revising the cited file. 5) Give the checklist at least one row per FR sub-obligation with its own carrier - the review-face clause had none and only the stage sequence covered it.
