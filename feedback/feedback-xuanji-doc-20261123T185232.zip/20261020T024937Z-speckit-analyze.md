---
id: "20261020T024937Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "014-bailian-embedding-rerank-analyze-2026-10-20"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
feature: "014-bailian-embedding-rerank"
feature_id: "023"
partial: false
created: "2026-10-20T02:49:37Z"
summary: "Cross-artifact analyze of requirements/plan/tasks/data-model/contracts/checklists/feature registry. Structural checks passed (four gate tables 9/14/11/12 rows with 0 empty cells; DDL identical at 334 "
---

## Review
Cross-artifact analyze of requirements/plan/tasks/data-model/contracts/checklists/feature registry. Structural checks passed (four gate tables 9/14/11/12 rows with 0 empty cells; DDL identical at 334 chars; 26/26 Shared Strings resolve; FR->contract trace 26/26; 0 broken links/JSON). Round-3 findings I-006..I-010 are closed. Semantic detection plus an independent validation wave left 2 CRITICAL and 2 HIGH open: (B-04) runtime provider 4xx has no applicable 503 reason in the six-value enum; (B-07) retry classification is restated operatively in embedding-api §4 and rerank-api §5 despite REC-T4 declaring provider-config §5 the single owner (Constitution XIV); (B-01) embedding-identity §3 and §8.3 contradict each other on openai+existing-identity-row; (B-03) generic_rerank_api collapses empty and all-invalid results to [], so empty_result vs invalid_response cannot be distinguished downstream. Validation sent 14, confirmed 5, downgraded 9, rejected 0. The feature is not ready for implement until these four are repaired.

## Optimization Points
- Analyze prerequisites: `check-prerequisites.sh --json --require-tasks --include-tasks` still aborts on unset `CWS_LIB_BASH_HOME` before resolving paths. Give the analyze path a read-only fallback that resolves `REQUIREMENTS_DIR` from the branch/feature key, or emit an actionable hint that does not block a read-only cross-artifact run.
- Detection-wave dedup: the three disjoint scopes still produced four overlapping findings (ingest semantics, Shared Strings, feature anchor, RERANK_TOP_N), which then require duplicate validation. Add an explicit canonicalization/dedup step between detection and the §5.5 validation wave, keyed by evidence location. `token-efficiency`: overlap caused the same artifact sections to be re-read by multiple agents.
- Same-author/resumed-run gate: a resumed unattended run has no recorded per-artifact provenance, so the delegation decision is inferred. Persist a produced-by command/run marker alongside each artifact so the gate is deterministic.
- Severity calibration: 9 of 14 CRITICAL/HIGH candidates were downgraded by validators, mostly because detector agents treated wording/coverage gaps as HIGH. Tighten the detector prompt's HIGH definition (must misdirect implementation or make a criterion untestable) before the validation wave.
