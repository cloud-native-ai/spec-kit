---
id: "20261031T175520Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "r20261030T120500Z-d101-review-fix6"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
feature: "023-xuanji-doc-architecture"
feature_id: "029"
partial: false
created: "2026-10-31T17:55:20Z"
summary: "Review-fix6 of 023-xuanji-doc-architecture / Feature 029 is a full A-pin contract alignment at fix commit 7538043a. The pin was moved to service/api/app/contracts as package data and the generated con"
---

## Review
Review-fix6 of 023-xuanji-doc-architecture / Feature 029 is a full A-pin contract alignment at fix commit 7538043a. The pin was moved to service/api/app/contracts as package data and the generated contract suite (test_pin_generated_contract.py) now derives all 17 operations' request/response cases from openapi.pinned.yaml. Runtime outcomes: R5-01 fixed (DocumentQueryResponse/DocumentResolve/CodeSearchResponse/CodeResolve/CodeRepoList/AdminConfig/AdminConfigUpdate bodies), R5-02 fixed (lang/path_prefix/tags/limit/cursor filtering, total/next_cursor, (doc_path,lang) order, 200 miss/unpublished semantics, cursor binding for documents and code), R5-03 fixed (version equality -> item version_conflict, source_url validation, heading/anchor normalization, citation_id, entry_type/citation/version persistence), R5-04 fixed (atomic push envelope: parts/20 files/duplicate/zero-byte/MIME/basename, include minItems, doc_path placement, symlink skip), R5-05 fixed by named dispositions plus waiver W-6-01/L-8. Carried P2: R4-02 counts complete at 1001, R4-03 push 20 + pull caps, R4-04 part allowlist + header escaping, R4-05 header/body request id equality, R4-06 wheel discovery, R2-04 counts 18/13/31 + checker, R2-05 022 pointer, R2-06 current verification block, R2-07 commit chain. Gates (exit 0): api 490 passed 1 skipped, ingest 99, parity 10, react 35, pin-only check, verified owner verify, validate-tasks 0/0, clause coverage ok, carryover checker, tsc, whitespace. No ANOMALY.

## Optimization Points
- 1) Use one generated contract suite as the closure gate for a pinned external wire; point patches were the root cause of five review rounds.
- 2) Pin files belong in package data (app/contracts) so an installed wheel can serve the discovery document; keep a wheel-layout test.
- 3) Define the document version hash over the front-matter-free body so persisted version/citation metadata cannot self-reference the hash.
- 4) Enforce the request envelope at the public boundary even when the loopback writer also validates it; 'accepted but inert' fields need a test-visible effect.
- 5) Register every residual as an obligation row with owner/scope/review-expiry before writing the closure summary.
- 6) Keep one authoritative verification gate block; mark older blocks historical instead of editing their numbers.
