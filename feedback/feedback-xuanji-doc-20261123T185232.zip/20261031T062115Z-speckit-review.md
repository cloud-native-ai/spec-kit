---
id: "20261031T062115Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "r20261030T120500Z-d101-review-fix3"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
feature: "023-xuanji-doc-architecture"
feature_id: "029"
partial: false
created: "2026-10-31T06:21:15Z"
summary: "Review-fix3 of 023-xuanji-doc-architecture / Feature 029: supply the executable entry points C 051 needs. Added service/ingest/src/server.ts (loopback bind via INGEST_BIND/INGEST_PORT, multipart push,"
---

## Review
Review-fix3 of 023-xuanji-doc-architecture / Feature 029: supply the executable entry points C 051 needs. Added service/ingest/src/server.ts (loopback bind via INGEST_BIND/INGEST_PORT, multipart push, JSON pull, job read/cancel, health, no query route) plus a standalone multipart parser; declared bin xuanji-doc-ingest and start node --import tsx src/server.ts, moving tsx to production dependencies. Added the xuanji-doc-api console script (app.main:main), build-system/package discovery, and a --help startup-exit probe. Recorded commands and caveats in cross-repo-obligations L-7, C-30, service READMEs, and docs/configuration.

## Optimization Points
- 1. A TypeScript bin target requires its loader in production dependencies and a package-root cwd, not just a start script. 2. A console script is not real until packaging metadata (build-system + package discovery) can produce the shim; the --help probe alone only proves the target. 3. HTTP job-id path params need the same id-pattern guard as the file reader before any filesystem join. 4. Cross-repo entry commands must name the remaining C-side reconciliation (cws_py_daemon argv, missing package-local lockfile) instead of claiming the image build is closed.
