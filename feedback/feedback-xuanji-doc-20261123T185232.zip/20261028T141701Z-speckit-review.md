---
id: "20261028T141701Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "r20261028T083000Z-7c1a-review"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
feature: "021-code-cgit-urls"
feature_id: "026"
partial: false
created: "2026-10-28T14:17:01Z"
summary: "Read-only SDD process review of 021-code-cgit-urls / Feature 026 at HEAD fd1ff878 (branch 021-code-cgit-urls; commit unpushed). Reviewed requirements, clarify, plan, research, data-model, four contrac"
---

## Review
Read-only SDD process review of 021-code-cgit-urls / Feature 026 at HEAD fd1ff878 (branch 021-code-cgit-urls; commit unpushed). Reviewed requirements, clarify, plan, research, data-model, four contracts, quickstart, two checklists, tasks, verification, all run records, test-evidence and git history 394f26a5..HEAD. 9 findings: P0 0; P1 3 — (F1) the pre-implement checklist gate was bypassed: checklists/cgit-url-quality.md still has 40 open CHK items and no waivers.md exists; (F2) wrap-up accounting is non-atomic: requirements/plan/implement-p1 each needed a finalize-only rerun, 4 of 5 implement session records remain `settled_at: null`, p4 verification evidence was backfilled in p5, and the root cause (worktree lacks run-determination.py/exec-quant.py; the main checkout's feedback engine migrates the tracked index.json into state/) is visible only in exec-quant argv and one run-record note; (F3) the phase-boundary regression gate was skipped for p2–p4, so a genuine storage T-04 regression was first found in p5. P2 6 — (F4) SC-007_note claims T018 rows 1–2 injected all five keys, but row 1 sets three cgit keys and row 2 sets one; (F5) Feature 026 status/index/detail disagree (index row and detail say Implemented; Recent Spec Bindings still says Draft→Planned; Latest Review opens with “尚未进行端到端评审（Feature 处于 Planned）” and Status Tracking has a duplicate generic Implemented bullet); (F6) analyze round 1 reported 16 findings but analyze-fix closed 10 groups/11 IDs and no artifact maps the remaining 6 or re-lists all 16; (F7) RED evidence is partly absence-based (ERR_MODULE_NOT_FOUND, missing test file) and T012 RED was reconstructed by temporarily substituting the pre-T011 module; (F8) the living plan.md keeps stale counts/checksums without an inline supersession marker (research 140 vs 142; cgit-url 130 vs 132; mcp-wrapper 215 vs 218; two checksum prefixes no longer match) and disagrees with its own Phase 1 table; (F9) the storage T-04 guard matches comments and test titles, forcing behavior-neutral wording churn (guard itself was not weakened). What worked: the frozen-surface diff is exit 0 over 99 changed paths with zero out-of-surface files; T-00 and the optional live cgit layer are recorded skipped and never pass; T018's fake-upstream substitution is explicitly labeled; every PLAN-EDIT anchor was verified truthful; mechanical gates are reproducible (21/21 [X], 0 open, 8 SC statuses, validate-tasks 0 error/1 intentional warning, code-graph:cgit:test 72/72, code-graph:check 0). Report: .specify/specs/021-code-cgit-urls/review.md.

## Optimization Points
- Framework: make the pre-implement checklist gate and its waiver part of the Completion Gate, with a recorded verdict in verification.md (source F1).
- Framework: make wrap-up accounting a single atomic entry that writes feedback + session + exec-quant and verifies all three; resolve engines from the workspace and fail fast when missing, instead of requiring the main checkout (source F2).
- Framework: in segmented runs, run the full baseline regression suite (e.g. storage:test) at every phase boundary, not only at baseline and close (source F3).
- Verification notes must cite the exact command and artifact; add a lint for claims that overstate the recorded command set (source F4).
- Feature integration must update the index row, the Recent Spec Bindings table and the detail Status Tracking in the same transaction (source F5).
- Persist the analyze compact report (or a findings ledger) to the spec directory, with stable IDs and dispositions; a second round must re-list every prior ID (source F6).
- Tasks/implement templates should distinguish absence-red (module/file missing) from assertion-red (stub exists, assertion fails) and require assertion-red for behavior rows; label reconstructed red explicitly (source F7).
- Replace copied line counts/checksums in living plan artifacts with references or an explicit historical-snapshot marker (source F8).
- Storage T-04 guard should strip comments or scope to string literals/imports, or support a justified allow annotation (source F9).
- token-efficiency: the review used program verdicts (grep counts, validate-tasks, test suite, frozen diff) for mechanical claims and read only the artifacts needed for the findings; no machine-managed store was bulk-injected and no token counts were fabricated.
