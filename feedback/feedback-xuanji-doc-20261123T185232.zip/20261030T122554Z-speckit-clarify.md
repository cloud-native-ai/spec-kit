---
id: "20261030T122554Z-speckit-clarify"
unit_id: "/speckit.clarify"
unit_type: "command"
run_id: "r20261030T120500Z-d101-clarify"
scope: "local"
probe: "speckit-clarify-wrapup"
kind: "internal"
slice: "commands"
feature: "023-xuanji-doc-architecture"
feature_id: "029"
partial: false
created: "2026-10-30T12:25:54Z"
summary: "Unattended Mode A clarify for an architecture spec: integrated 8 user-supplied decision directives as Q-001–Q-008, wrote them back into Clarifications/15 FR amendments/4 new FRs/8 SC amendments/4 assu"
---

## Review
Unattended Mode A clarify for an architecture spec: integrated 8 user-supplied decision directives as Q-001–Q-008, wrote them back into Clarifications/15 FR amendments/4 new FRs/8 SC amendments/4 assumptions/6 edge cases, and re-ran the deterministic validator (0/0). The flow worked, but the skill text gives conflicting question caps (max 5 per run vs max 10 per session) and does not say whether user-supplied decision directives count against them; an unattended run with 8 directives must decide this locally.

## Optimization Points
- clarify-artifact states "Never exceed 5 total questions" but also "Maximum 10 total across session", and its workflow first integrates user-provided decisions — yet it never says those directives are exempt from the generated-question cap. This run had 8 user directives; state the exemption (or align the two numbers) so unattended runs do not have to reinterpret the rule.
- The Mode A "Derived-count revisit" rule only cross-checks checklists/requirements.md against the spec, but this run also had to hand-sync FR/SC counts in the Feature registry row and Feature detail file; add a deterministic drift check (or fold the registry counts into the same revisit rule) so feature-index counts cannot silently diverge.
