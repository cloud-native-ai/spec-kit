---
id: "20261028T113018Z-speckit-clarify"
unit_id: "/speckit.clarify"
unit_type: "command"
run_id: "r20261028T083000Z-7c1a-clarify"
scope: "local"
probe: "speckit-clarify-wrapup"
kind: "internal"
slice: "commands"
feature: "021-code-cgit-urls"
feature_id: "026"
partial: false
created: "2026-10-28T11:30:18Z"
summary: "无人值守 clarify：Mode A（post-requirements），对 Q-001–Q-009 逐题裁决并写回 requirements.md、质量清单、Feature 026 注记与 run-record-clarify。裁决遵循用户六条原则：基址不内置主机/端口、部署注入并列为 A-020；映射用 CODE_GRAPH_CGIT_REPO_MAP env JSON 数组；ref 固定"
---

## Review
无人值守 clarify：Mode A（post-requirements），对 Q-001–Q-009 逐题裁决并写回 requirements.md、质量清单、Feature 026 注记与 run-record-clarify。裁决遵循用户六条原则：基址不内置主机/端口、部署注入并列为 A-020；映射用 CODE_GRAPH_CGIT_REPO_MAP env JSON 数组；ref 固定 manifest commit；行锚点 #n<line> 默认关闭；输出面仅 MCP wrapper、字段 web_url；降级为 web_url:null + web_url_reason；认证带外、零凭据键；wrapper-first；不交付 cgit 服务。结构检查 FR=9 SC=8 US=5 markers=0 open_questions=9 local_strings=10 PASS；未改代码/docs/compose，未 push。

## Optimization Points
- `/speckit.clarify` 的默认形态是交互式“选项 + Recommended”访谈；无人值守命令需要在输入协议中显式提供 unattended 模式与裁决原则，否则执行者只能自行解释“自行裁决”的边界（本轮按用户六条原则逐题定案并以 9 行 Q→A 记录收口）。建议在命令模板中增加 `--unattended --decision-principles <file>` 的契约形态，并把裁决行数计入执行摘要。
- `requirements-structure-check.py` 以 `Open Questions`、`markers<=3` 为通过条件，clarify 后仍能通过，但无法区分“已登记未裁决”与“已裁决”；建议在检查中加入“每条 Q 行必须有裁决列/对应 Clarifications 行”的断言，避免结构检查对已裁决状态给出虚假安全感。
- token-efficiency：本轮为裁决 ref 策略与配置 owner 读取了 `docs/code-retrieval.md` 全文（334 行）与 `docs/code-storage.md` 的部分章节；虽然都是 owner 文档，仍可先按标题抽取“环境变量/清单/脱敏”片段再决定是否读全文。建议为常见决策（ref、config、security）维护一份 owner 指针摘要，减少整篇注入。
