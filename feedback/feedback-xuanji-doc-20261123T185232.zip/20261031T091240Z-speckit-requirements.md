---
id: "20261031T091240Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "r20261031T090000Z-d0c1"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
feature: "023-xuanji-doc-l3-design"
feature_id: "029"
partial: false
created: "2026-10-31T09:12:40Z"
summary: "L3 组件设计 requirements 生成顺畅：create-requirements 的六步与三道门禁全部一次通过，validate-requirements ok（0 error/0 warning，28 FR/8 SC/11 STR），pre-analyze pass（0 error，4 条 advisory 全为交付物路径尚未创建），decomposition proceed（28 ≤"
---

## Review
L3 组件设计 requirements 生成顺畅：create-requirements 的六步与三道门禁全部一次通过，validate-requirements ok（0 error/0 warning，28 FR/8 SC/11 STR），pre-analyze pass（0 error，4 条 advisory 全为交付物路径尚未创建），decomposition proceed（28 ≤ 30）。摩擦点集中在环境而非流程：(1) scaffold 脚本因 CWS_LIB_BASH_HOME 未设直接 exit 1，需先指到本机 cws-lib-bash 才能运行；(2) 脚本无条件 git checkout -b 新分支，与本线 line/* 工作树约定冲突，需手动切回；(3) 验收轴 artifact_correctness 只有测试绿证据通道，纯文档运行只能记 not_evaluated。

## Optimization Points
- 1) 让 create-new-requirements.sh 在 CWS_LIB_BASH_HOME 缺失时给出可操作提示（或退化为不 source common.sh），并把该依赖写进 skill 的前置检查；2) 为 number-only 场景提供 --no-branch 开关，或在非顶层 NNN 分支的工作树上只建目录不切分支；3) 为表达类运行提供一条可声明的证据通道（门禁退出码即可），使 artifact_correctness 可判而非只能 not_evaluated。
