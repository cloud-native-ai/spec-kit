---
id: "20261031T060735Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "r20261030T120500Z-d101-review-fix2"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
feature: "023-xuanji-doc-architecture"
feature_id: "029"
partial: false
created: "2026-10-31T06:07:35Z"
summary: "Review-fix2 of 023-xuanji-doc-architecture / Feature 029: converge the three review2 P1 findings in the runtime. R2-01 wires INGESTION_REVIEW_MODE into createIngestService (direct->docsRoot; legacy->i"
---

## Review
Review-fix2 of 023-xuanji-doc-architecture / Feature 029: converge the three review2 P1 findings in the runtime. R2-01 wires INGESTION_REVIEW_MODE into createIngestService (direct->docsRoot; legacy->isolated model/draft draft root with fail-fast on missing/non-isolated root; no retrieval indexing) and exposes ingestion_review_mode in the admin deployment view. R2-02 emits xuanji-api's Health envelope (status/service/version/checks[]/timestamp) from all four health endpoints with an admin check and six dependency checks carrying internal state and profile in detail. R2-03 reads knowledge job status from the read-only config/ingest/jobs file mount and narrows the ingest adapter to push/pull/cancel.

## Optimization Points
- 1. A contract-vs-runtime closure must be re-verified against the production path and its call site, not only the carrier module. 2. External-owner wire alignment must update the runtime and its tests in the same commit. 3. File-level read paths need id validation and secret/source stripping before returning backend records.
