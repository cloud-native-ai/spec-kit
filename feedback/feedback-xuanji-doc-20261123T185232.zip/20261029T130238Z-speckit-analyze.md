---
id: "20261029T130238Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261028T162000Z-c1a2-analyze-fix"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
feature: "022-citation-architecture"
feature_id: "027"
partial: false
created: "2026-10-29T13:02:38Z"
summary: "Authorized analyze-fix round for 022-citation-architecture / Feature 027 (run r20261028T162000Z-c1a2-analyze-fix), baseline 5878b788. Fixed all 3 HIGH and 12 of 14 MEDIUM findings plus all 12 LOW, tou"
---

## Review
Authorized analyze-fix round for 022-citation-architecture / Feature 027 (run r20261028T162000Z-c1a2-analyze-fix), baseline 5878b788. Fixed all 3 HIGH and 12 of 14 MEDIUM findings plus all 12 LOW, touching only the spec artifacts, the two plan-owned pointer sets, and accounting. F-001: ingest now normalizes the flat citation into a nested citation_locator (citation_request preserved; new C-31) and C-33 reads the normalized column. F-002: doc-url C-24 adds heading/anchor existence validation and an unreadable-source branch. F-003: version_source (explicit/backfilled/none) confines the partial unique index and 409 to explicit versions; FR-023/SC-007 and the Known Spec Tension were updated. F-005/F-006/F-008: source_unavailable becomes a typed document URL reason; storage failure yields web_url=null + source_unavailable and never produces or masks degradation; degradation stays global-only. F-004: SC-001 now states the code-URL capability is carried by Feature 026's MCP suite and that code_url_disabled has no v1 query output surface. F-007: E-1 must reconcile the file_source pattern and non-null track_id; openapi-pin C-21/C-22 record drift scope. F-009: removed 28 inline clause lists, made the claim table authoritative, allow verify rows to own clauses. F-010/F-011 (not in the mandated list) were also fixed minimally: SC-002 live/deferred wording and the Owner Map split. F-012: data-model consistency is now a pointer to C-18. F-013: C-26 now owns the full truncate-body-then-drop-whole-reference-line algorithm. F-014: four duplicated predicates collapsed to single owners with pure pointers. F-015: doc_url_disabled short-circuits ahead of resolution. F-016: in-repo batch-ingest/doc-summary compatibility split to T026/C-33; E-3 keeps only the external connector. F-017: deterministic canonical-JSON baseline fixture in T001, referenced by T009/T030. LOW: F-018 flow-style _build and v1 future/expired statement; F-019 new FR-029 for entry_type; F-020 acceptable (one-off clause script retained, non-standard engine recorded); F-021 legacy track_id tension; F-022 language-root page mapping; F-023 citations-null and index-missing owners; F-024 T031/T032 blockedBy; F-025 render only from references[].citation; F-026 label fallback C-39; F-027 structural 195 vs executable 167+2; F-028 credential clauses split; F-029 503 on any read-requiring citation verification. Gates all green: validate-tasks 0/0, validate-requirements 0 errors, structure PASS FR=29 SC=12 US=7, pre-analyze pass 0/0, decomposition proceed (29 FR/33 tasks), clause claims 195/195 (169 repo + 26 external, 0 missing/extra/duplicate/unresolved). Feature 027 remains Planned; no code/docs/model change; no push.

## Optimization Points
- 1) HIGH cascade resolved in single owners: locator normalization at the ingest boundary, heading/anchor existence inside doc-url, and version_source separation of explicit vs backfilled 409 semantics.
- 2) One-source-of-truth: four duplicated predicates (capabilities gating, off byte-identity, STR-014 fail-fast, doc_url off) converted to a single owner plus pure pointers; plan Gate 4 and Constitution XIV evidence corrected.
- 3) Accounting: 9 new and 36 modified clauses re-claimed (195/195; 169 repo + 26 external; 167 executable + 2 deferred); SC-005 now maps the robot leg to E-2; data-model enum duplication removed.
- 4) Boundary: in-repo batch-ingest/doc-summary compatibility moved to T026/C-33; credential clauses split into repo-verifiable and deployment halves.
- 5) Decidability: canonical-JSON baseline with fixed clock/sentinel track_id makes SC-008/DoD-4 measurable; truncation and label fallback algorithms are now testable.
- 6) token-efficiency: counts, clause continuity, claims and structure were verified by programs; only targeted excerpts were read.
