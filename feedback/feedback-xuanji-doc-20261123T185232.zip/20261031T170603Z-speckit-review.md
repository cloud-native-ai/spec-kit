---
id: "20261031T170603Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "r20261030T120500Z-d101-review5"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
feature: "023-xuanji-doc-architecture"
feature_id: "029"
partial: false
created: "2026-10-31T17:06:03Z"
summary: "Review5 of 023-xuanji-doc-architecture / Feature 029 is a read-only recheck of review-fix5 b8906232. R3-01 closed with residual: A PushMetadata {} and the pinned example return 202 and place documents"
---

## Review
Review5 of 023-xuanji-doc-architecture / Feature 029 is a read-only recheck of review-fix5 b8906232. R3-01 closed with residual: A PushMetadata {} and the pinned example return 202 and place documents at the requested doc_path/title, unknown/internal keys are 400 invalid_metadata, local pull include/exclude/defaults work, .. and outside allow-root are 403 before a job, and OSS endpoint is optional; residuals are inert citation/default semantics and unenforced envelope/shape validations (duplicate names, zero-byte, MIME mismatch, name basename, include minItems, doc_path corpus prefix). R4-01 closed with residual: the four read operations are GET with query binding and the pin check compares method sets, but the served pin's four response schemas are not produced (domain-native bodies) and pinned dimensions (lang/path_prefix/tags/cursor/heading/anchor) are silently ignored with miss and language mismatch returning 404 instead of 200. Counts: P0 0, P1 2 (R5-01, R5-02), P2 12. Gates: api 437 passed 1 skipped, ingest 87, parity 10, react 35, pin verified with six checks, tasks and clause coverage clean.

## Optimization Points
- 1. When the served discovery document is the owner's pin, changing methods without shaping response bodies leaves the contract broken; validate live bodies against every advertised schema. 2. Parameters that a handler accepts and an adapter silently drops are worse than unsupported ones; bind-or-reject must be tested by effect, not status. 3. Accepting owner fields without their effects (version equality/version_conflict, source_url validation, citation_id) is a closure overclaim; implement or register an owned obligation. 4. A run record cannot say closed in section 1 and not as closure in section 7; apply the closure vocabulary uniformly and give every deferral an owner and expiry.
