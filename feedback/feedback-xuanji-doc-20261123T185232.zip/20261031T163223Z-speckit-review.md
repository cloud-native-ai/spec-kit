---
id: "20261031T163223Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "r20261030T120500Z-d101-review4"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
feature: "023-xuanji-doc-architecture"
feature_id: "029"
partial: false
created: "2026-10-31T16:32:23Z"
summary: "Review4 of 023-xuanji-doc-architecture / Feature 029, read-only recheck of review-fix4 247b4482. R3-02 and R3-03 are closed (bin launcher through a .bin symlink: 3 tests; gitignore and clean status). "
---

## Review
Review4 of 023-xuanji-doc-architecture / Feature 029, read-only recheck of review-fix4 247b4482. R3-02 and R3-03 are closed (bin launcher through a .bin symlink: 3 tests; gitignore and clean status). R3-01 is NOT closed: the response Job wire and served pinned OpenAPI are correct and verified, but A's canonical PushMetadata {} and the pin's push example still return 400 because ingest keeps its own metadata dialect; pull local include/exclude are silently ignored (a.md and b.md both published), defaults.entry_type returns 400, and local-source violations do not return 403. A new P1: the served pinned OpenAPI advertises GET for documents/query, documents/resolve, code/search and code/resolve while the runtime serves POST, so GET returns 405 and the path-only pin check stays green. New P2s: >1000-item JobResult counts do not close; pinned 20-file push and 10000-file/2GiB pull limits are not enforced; the public push passthrough accepts an operator multipart part that lands in the audit ledger; Job.error.request_id differs from the job-read X-Request-Id; a pip-installed api package cannot ship the pinned YAML. R2-04..R2-07 remain open. Gates: api 423 passed 1 skipped, ingest 77 passed, parity 10, react 34, pin verified with all six checks.

## Optimization Points
- 1. A request wire is not fixed by accepting its envelope: validate the pinned request body end-to-end against a real ingest, or the owner's own example still 400s. 2. Serving the owner pin as discovery makes method and parameter divergence visible; compare methods and request schemas in the pin gate, not only paths. 3. Reject contract-extra multipart parts at the public boundary; an operator part can rewrite audit facts. 4. A stage that marks a finding fixed while its residual list says a primary request path is unimplemented must use 'not closed' or 'closed with residual', never 'fixed'.
