---
id: "20261028T131243Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261028T083000Z-7c1a-implement-p1"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "021-code-cgit-urls"
feature_id: "026"
partial: false
created: "2026-10-28T13:12:43Z"
summary: "Implement p1 segment (T001–T004) of 021-code-cgit-urls / Feature 026 — setup and shared offline test infrastructure only; no rewrite source exists yet. T001 seeded `.specify/specs/021-code-cgit-urls/v"
---

## Review
Implement p1 segment (T001–T004) of 021-code-cgit-urls / Feature 026 — setup and shared offline test infrastructure only; no rewrite source exists yet. T001 seeded `.specify/specs/021-code-cgit-urls/verification.md` (baseline commit 394f26a5, branch 021-code-cgit-urls, Node waiver W-2026-10-28-CGIT for v26.7.0 vs declared >=20.19.0 <21) with the four baseline commands and exit codes: `pnpm install --frozen-lockfile --offline --ignore-scripts` exit 1 (ERR_PNPM_ABORTED_REMOVE_MODULES_DIR_NO_TTY — node_modules is a symlink to the main checkout; lockfile SHA-256 unchanged, tsx/tsc usable through the symlink, recorded as an environment deviation kept out of the feature commit), `pnpm code-graph:check` exit 0 (tsc no diagnostics), `pnpm storage:test` exit 0 (426 tests, 419 pass, 0 fail, 7 not_applicable with reasons C-14/C-15/C-16/C-17/C-18/C-19/C-21), `pnpm code-graph:doctor` exit 1 (CODE_GRAPH_DATA_ROOT required, stdout/stderr captured and sha256-pinned). `git status` after baseline showed no runtime writes. T002 ran the T-00 Upstream Shape Gate: `CODE_GRAPH_GRAPHICLE_BIN` unset, contract default `graphicle` resolved via `command -v` → exit 1, so verdict is `skipped` (never pass) with the probe command/date in `test-evidence/t-00-shape-probe.md`, a deferred probe procedure for a host with the binary, and a source-surface check confirming no `cgit-*.ts` file yet; W-22 recorded as skipped. T003 authored `service/code-graph/test/fixtures/fake-graphicle-mcp.mjs`: a Node-builtins-only newline-delimited JSON-RPC stdio server with `initialize`, a pinned 11-tool `tools/list` order (graph_episodes … shortest_path), `tools/call` success shapes (sources[] with path/line/end_line, structuredContent, parseable JSON text, non-JSON text, isError, no-location), `_meta`/nested-path/existing-web_url cases, invalid JSON, empty line, batch array, CRLF, spawn marker `{spawned,argv,cwd}`, stderr and exit-code knobs; acceptance pipeline emitted two JSON lines and exited 0; static scan shows only node:fs/node:readline, no network API. T004 extended `service/code-graph/tsconfig.json` `include` to `["*.ts","test/**/*.ts"]` only; `pnpm code-graph:check` exit 0. Frozen surfaces verified unchanged; changes confined to the spec-owned evidence/bookkeeping surfaces plus T004's compatibility §5-authorized tsconfig line. No push. Findings requiring attention: none functional in-scope; the two environment items below stay open as recorded deviations.

## Optimization Points
- Environment ANOMALY (T001): `pnpm install --frozen-lockfile --offline --ignore-scripts` exits 1 with ERR_PNPM_ABORTED_REMOVE_MODULES_DIR_NO_TTY because this worktree's node_modules is a symlink to the main checkout and pnpm refuses to remove it without a TTY. Lockfile SHA-256 stayed unchanged (4a747fd8f13437826688840ed42d39ead2703dff0056c5452b51618fb3f27523), no file was modified, and tsx 4.23.0/tsc remain usable through the symlink — the baseline is usable but must be cited as an environment/upstream deviation, never as a clean dependency install.
- T-00 Upstream Shape Gate (T002 / W-22) is recorded `skipped`, never `pass`: no graphicle binary exists on this host (`command -v` exit 1 @ 2026-10-28T13:01:20Z). The evidence file carries the deferred probe procedure; any later live-shape claim must run it on a host with the binary, and this skipped state must not be upgraded retroactively.
