---
id: "20260811T072721Z-speckit-instructions"
unit_id: "/speckit.instructions"
unit_type: "command"
run_id: "instr-20260811-152447"
scope: "local"
partial: false
created: "2026-08-11T07:27:21Z"
summary: "定向刷新：按用户输入将'本地化轻量级知识库'定位并入 Project Overview 并挂接宪法原则 III；从备份恢复被占位符替换的 Documentation Map；补 Glossary 行并播种 5 个术语；符号链接全部有效。"
---

## Review
定向刷新：按用户输入将'本地化轻量级知识库'定位并入 Project Overview 并挂接宪法原则 III；从备份恢复被占位符替换的 Documentation Map；补 Glossary 行并播种 5 个术语；符号链接全部有效。

## Optimization Points
- 备份历史检测发现 Documentation Map 曾被旧版脚本退化为模板占位符；本次按 Action 3 从 2026-07-08 备份增量恢复并补全缺失行，验证了 archive-not-delete 恢复路径的有效性。
