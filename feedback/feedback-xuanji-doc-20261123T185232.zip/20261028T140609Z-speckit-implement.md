---
id: "20261028T140609Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261028T083000Z-7c1a-implement-p5"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "021-code-cgit-urls"
feature_id: "026"
partial: false
created: "2026-10-28T14:06:09Z"
summary: "Implement p5 segment (T019 → T018 → T020 → T021) of 021-code-cgit-urls / Feature 026. T019 added exactly two package scripts (code-graph:cgit-mcp, code-graph:cgit:test) and ran the full offline suite:"
---

## Review
Implement p5 segment (T019 → T018 → T020 → T021) of 021-code-cgit-urls / Feature 026. T019 added exactly two package scripts (code-graph:cgit-mcp, code-graph:cgit:test) and ran the full offline suite: pnpm code-graph:cgit:test exit 0 with 72 tests / 72 pass / 0 fail / 0 skipped, and pnpm code-graph:check exit 0. T018 executed the owner-document walkthrough using only docs/code-retrieval.md §13 through the new script with the offline fake upstream substituted via CODE_GRAPH_GRAPHICLE_BIN: enable produced the exact documented URL (…/tree/service/code-graph/config.ts?id=0123…4567) with 11 tools and no banner; disable was byte-identical to the direct upstream (cmp exit 0, zero web_url); an unmapped slug yielded exit 0 with all hits web_url:null + unmapped_repo; userinfo and query bases failed closed with exit 2, zero stdout, one redacted error line and zero secret occurrences. Missing documentation steps = 0; no docs fix needed. The external bm9 injection checklist was recorded without touching compose/images. T020 verified the frozen surfaces: git diff --exit-code 394f26a5 over config.ts/cli.ts/doctor.ts/storage-cli.ts/mcp-adapter.ts/repos.json/service/storage/service/gateway/view/model exited 0 with zero bytes; an allowed-surface audit found 0 out-of-surface files across 99 changed paths. The first pnpm storage:test run exposed a genuine new regression (426/416/3/7) from the storage T-04 layout-literal guard matching a new source comment, two test titles and one /tmp fixture in our files; fixed behavior-neutrally inside the allowed surface (comment/test-title/fixture only, guard untouched) and storage:test returned to the exact baseline 426/419/0/7. pnpm code-graph:doctor reproduced exit 1 with byte-identical stdout/stderr sha256 (05e13621…, 34a9ee81…). T021 closed evidence: SC-001…SC-008 all pass, exactly one verdict per C/U/W pin (C 10, U 21, W 24; W-22 skipped, never pass), deferred_tasks empty, all 21 task rows [X], validate-tasks.py exit 0 with only the intentional T018→T019 warning, and Feature 026 advanced Planned → Implemented per the canonical state machine in 024.md. T-00 and the optional live graphicle/cgit layer remain skipped with reasons. Commits: feature 2da0b8da, wrap-up accounting follows.

## Optimization Points
- T020 caught a cross-subsystem invariant (storage T-04 layout literals) that segment-scoped pin runs could not see; run pnpm storage:test at every segment boundary, not only at baseline and close. The T-04 guard is textual, so even comments and test titles in service/code-graph/** count as violations — keep storage-layout wording out of that tree. The owner-doc walkthrough needs no extra scaffolding beyond the documented CODE_GRAPH_GRAPHICLE_BIN override, which already lives in code-retrieval §3. token-efficiency: contracts and docs were read in targeted span; no machine-managed store was bulk-injected and no token counts were fabricated. Node v26.7.0 still exceeds the declared engine range; waiver W-2026-10-28-CGIT applies and no install or lockfile change was made. No functional anomalies; no ANOMALY lines.
