---
id: "20261029T104914Z-speckit-clarify"
unit_id: "/speckit.clarify"
unit_type: "command"
run_id: "r20261028T162000Z-c1a2-clarify"
scope: "local"
probe: "speckit-clarify-wrapup"
kind: "internal"
slice: "commands"
feature: "022-citation-architecture"
feature_id: "027"
partial: false
created: "2026-10-29T10:49:14Z"
summary: "无人值守 clarify（Mode A，post-requirements）：对 Q-001–Q-008 逐题裁决并写回 requirements.md、质量清单与 Feature 027 注记。裁决固定 cgit 沿用 Feature 026；Hugo 文档 URL = 基址 + zh 根/en /en + page_path + anchor；引用以可选 citation 对象附加 refer"
---

## Review
无人值守 clarify（Mode A，post-requirements）：对 Q-001–Q-008 逐题裁决并写回 requirements.md、质量清单与 Feature 027 注记。裁决固定 cgit 沿用 Feature 026；Hugo 文档 URL = 基址 + zh 根/en /en + page_path + anchor；引用以可选 citation 对象附加 references[]（citation_id = cit_ + SHA-256(规范化 kind+locator+version)）；robot 渲染 [label](web_url)；OpenAPI owner = xuanji-api 并做 pinned 0 drift 校验；文档/代码存储 profile 与 PG/ADB PG 能力矩阵显式降级；ingest 保留 /api/kb/ingest + 可选 citation + 幂等键；参考部署 nginx、Pages 备选。结构检查 FR=28 SC=12 US=7 markers=0 open_questions=8 local_strings=31 PASS；主仓 validate-requirements.py 0 error/0 warning；未改代码/docs/service/view/compose，未 push。

## Optimization Points
- /speckit.clarify 仍以交互式“选项 + Recommended”为默认形态；无人值守运行缺少显式的 `--unattended --decision-principles <file>` 契约，执行者只能自行把用户原则翻译成 8 条裁决。建议在命令模板中增加该模式，并把裁决行数计入执行摘要。
- validate-requirements.py 的 `Consumed by` 反向一致性检查要求每个被点名的 FR/SC 在行内出现 [[STR-nnn]]，但代码跨度内的 token 不算；新增契约字段/原因枚举时容易触发“已引用却报错”。建议在检查器说明中明示代码跨度规则，或为契约字段提供显式豁免。
- requirements-structure-check.py 在 clarify 后仍输出 `open_questions=8`，无法区分“已登记未裁决”与“已裁决”；建议增加“每个 Q 行必须有裁决列/对应 Clarifications 行”的断言（与 021 反馈同题，仍未修复）。
- token-efficiency：本轮为格式对齐读取了 021 requirements 的 Assumptions/Open Questions 段与 021 run-record-clarify 全文（约 180 行）；建议提供可复用的 clarify run-record 模板/摘要指针，减少同类对齐注入。
