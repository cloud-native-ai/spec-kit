---
id: "20261018T123608Z-speckit-clarify"
unit_id: "/speckit.clarify"
unit_type: "command"
run_id: "009-unify-kb-three-stores-clarify-20261018"
scope: "local"
probe: "speckit-clarify-wrapup"
kind: "internal"
slice: "commands"
feature: "009-unify-kb-three-stores"
feature_id: "018"
partial: false
created: "2026-10-18T12:36:08Z"
summary: "Headless clarify run for 009: 4 pre-set rulings (A-001 workspace isolation, A-002 hierarchy-axis unification, design-feature scope, new Feature binding) written back to requirements.md; Feature 018 cr"
---

## Review
Headless clarify run for 009: 4 pre-set rulings (A-001 workspace isolation, A-002 hierarchy-axis unification, design-feature scope, new Feature binding) written back to requirements.md; Feature 018 created and fully registered (index row, detail, neighbor 017 reverse reference, Recent Spec Bindings); Clarifications append-only 0→4 rows; deterministic spec validator 0 ERROR; checklist updated; commit 0f35ae36; no scope expansion or implementation commitment. Friction: the dispatch's "run the validator to zero ERROR" has no concrete validator bound in the clarify template, so a run-local deterministic check had to be assembled; check-prerequisites.sh --json (without --paths-only) fails Mode A by demanding plan.md with a misleading "run /speckit.plan first" message.

## Optimization Points
- **Bind a concrete requirements validator**: `/speckit.clarify` (and `/speckit.requirements`) define validation only as LLM-judged checklist review; headless dispatches that say "run the validator to zero ERROR" therefore require each run to assemble its own checks. Ship or name a deterministic validator (structural markers, FR/SC continuity, STR integrity, registry consistency) so the gate is reproducible across runs.
- **Make `check-prerequisites.sh` full-validation Mode-aware**: in MODE=A the script's non-`--paths-only` path demands `plan.md` and tells the caller to run `/speckit.plan`, which would skip clarify. It should require `requirements.md` for MODE=A and reserve the plan requirement for MODE=B/C.
