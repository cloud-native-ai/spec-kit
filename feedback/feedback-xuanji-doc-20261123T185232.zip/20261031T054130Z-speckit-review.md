---
id: "20261031T054130Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "r20261030T120500Z-d101-review-fix"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
feature: "023-xuanji-doc-architecture"
feature_id: "029"
partial: false
created: "2026-10-31T05:41:30Z"
summary: "review-fix of 023-xuanji-doc-architecture / Feature 029: F1-F9 were dispositioned. F1 re-pointed the OpenAPI pin to A master 5b77c9024 and verified it (pin-only without owner, verified with owner); FR"
---

## Review
review-fix of 023-xuanji-doc-architecture / Feature 029: F1-F9 were dispositioned. F1 re-pointed the OpenAPI pin to A master 5b77c9024 and verified it (pin-only without owner, verified with owner); FR-002/C-04 now defer the 404 migration hint to A as wire owner. F2/F3 added checklist-dispositions.md (14 FAIL: 13 fixed, 1 waived) and analyze-carryover.md (all MEDIUM/LOW from five passes). F4 added INGESTION_REVIEW_MODE=direct|legacy with direct/legacy isolation tests and fixed the legacy skill docs. F5 tightened GATE-1/4/6/9; GATE-4 now runs 61 ingest tests. F6-F9 fixed R-14, the cross-repo ledger/gateway legacy status, and the stale/derived facts. Gates rerun: api 392, ingest 61, parity 10, React 34, openapi pin-only/verified, validate-tasks 0 warnings, coverage 63/63.

## Optimization Points
- 1. Re-probe cross-repo prerequisites at every segment; require verified (or a dated accepted-risk) for cutover. 2. Every checklist FAIL and every carried finding needs a fixed/accepted-risk/deferred closure state; raised-as-finding is not closure. 3. Make ingest:test include the contract glob and record the combined count. 4. Replace count-only grep gates with a negating grep whose exit is the verdict, and treat validate-tasks warnings as non-green. 5. Keep one dated cross-repo ledger and reference it from all artifacts.
