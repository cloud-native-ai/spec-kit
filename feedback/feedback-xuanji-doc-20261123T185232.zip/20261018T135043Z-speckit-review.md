---
id: "20261018T135043Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "009-unify-kb-three-stores-20261018-review"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
feature: "009-unify-kb-three-stores"
feature_id: "018"
partial: false
created: "2026-10-18T13:50:43Z"
summary: "The review completed with a clean artifact chain and four independently confirmed P0 findings. The main unit-level friction was step 1: check-prerequisites.sh aborted in a clean shell because CWS_LIB_"
---

## Review
The review completed with a clean artifact chain and four independently confirmed P0 findings. The main unit-level friction was step 1: check-prerequisites.sh aborted in a clean shell because CWS_LIB_BASH_HOME was unset, and the error did not name the required path. The same-author detection gate correctly did not fire because the artifacts predated this session; P0 validation subagents were disjoint and all four returned confirm. The report itself required manual normalization of relative paths in navigation fields and a manual check for unresolved placeholders.

## Optimization Points
- Add a preflight to /speckit.review step 1 that detects CWS_LIB_BASH_HOME and prints the exact required path/install command before invoking check-prerequisites.sh; the current failure aborts the first step with an unactionable dependency message.
- Teach the review template/generator to treat the spec-kit source URL as optional: when .specify/source.json records only a commit, emit the commit-plus-git-show recovery form instead of leaving a [SPECKIT_REPO_URL] placeholder that must be resolved manually.
- Add a mechanical self-containment checker for review.md that enforces absolute navigational paths outside verbatim quotes and rejects unresolved placeholder tokens; the current checklist is manual and easy to issue a false pass.
