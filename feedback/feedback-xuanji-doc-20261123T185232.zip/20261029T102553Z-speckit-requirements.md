---
id: "20261029T102553Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "r20261028T162000Z-c1a2-requirements"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
feature: "022-citation-architecture"
feature_id: "027"
partial: false
created: "2026-10-29T10:25:53Z"
summary: "Requirements-stage run for a new architecture feature (citation model spanning frontend/backend/middleware). The command flow worked, but two framework surfaces forced manual adaptation: (1) create-ne"
---

## Review
Requirements-stage run for a new architecture feature (citation model spanning frontend/backend/middleware). The command flow worked, but two framework surfaces forced manual adaptation: (1) create-new-requirements.sh cannot target a pre-created branch, so the spec was scaffolded manually to keep the required 022 key; (2) validate-requirements.py treats the 3 sanctioned NEEDS CLARIFICATION markers as errors, so this run ends with a red validator exit by design. The requirements template also lacks the Assumptions/Open Questions and architecture sections used by recent specs.

## Optimization Points
- Framework: `create-new-requirements.sh` has no "use the existing/pre-created branch" mode. It derives the next number from existing branches, so a worktree branch `022-citation-architecture` would have produced `023-*`; the spec had to be scaffolded from the template manually. Add an explicit `--branch <existing>` / no-new-branch mode.
- Framework: `validate-requirements.py` reports every active `[NEEDS CLARIFICATION]` marker as an error (`marker-count`), even when the requirements flow intentionally hands ≤3 sanctioned markers to `/speckit.clarify`. Add `--allow-pending-clarify` or treat markers that cite a registered Q-ID as pending rather than failed.
- Template: `requirements-template.md` has no Assumptions / Open Questions section and no architecture section, although the requirements skill and recent specs use both. Add optional sections so authors stop hand-inserting them.
- token-efficiency: for convention alignment this run read all of `021-code-cgit-urls/feature-ref.md` and `checklists/requirements.md` (≈260 lines) where heading-level excerpts plus one sampled FR/SC would have sufficed; use summary-first sampling for sibling-spec alignment.
