---
id: "20261029T175202Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261028T162000Z-c1a2-implement"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "022-citation-architecture"
feature_id: "027"
partial: false
created: "2026-10-29T17:52:02Z"
summary: "Implementation closure for 022-citation-architecture / Feature 027 (run r20261028T162000Z-c1a2-implement). T001-T032 are [X]; T019 (pinned OpenAPI, owner 1.1.0 unpublished) and T033 (live Hugo/cgit/PG"
---

## Review
Implementation closure for 022-citation-architecture / Feature 027 (run r20261028T162000Z-c1a2-implement). T001-T032 are [X]; T019 (pinned OpenAPI, owner 1.1.0 unpublished) and T033 (live Hugo/cgit/PG/ADB PG/OSS/nginx/Pages) remain [~] with skip/not-run evidence. Gates: kb:citation:test 206/205 pass/1 skip; gateway:test 142/128/14 EADDRINUSE with zero new failures vs T001 baseline; React 17/17; kb:openapi:check skipped; GATE-4 5/5; GATE-6 frozen surfaces zero diff; validate-tasks 0/0; structure FR=29 SC=12 PASS; clause claims 195/195; open rows 0; owner-doc links 44/44. verification.md records SC-001/003/004/007/008/011/012 pass, SC-002/005/009/010 partial (live/external pending), SC-006 deferred; 17 entity/invariant blocks. Residual yaml devDependency floor ^2.8.2 not landed (D-003/D-016). Feature moved Planned->Implemented->Ready for Review. No push, no store migration.

## Optimization Points
- 1) Token efficiency (`token-efficiency`): the implement loop re-read tasks.md, p1–p4 evidence and contract sections across phases; a machine-generated per-phase digest (task IDs, gate commands, counts, deviation IDs) injected instead of raw bodies would cut repeated context without losing evidence. No token counts were fabricated.
- 2) Classifier resilience: the tool layer intermittently blocked `git add`, `git commit --dry-run` and read-only test commands with "Stage 2 classifier error" (p4 and p5). The workflow contract does not distinguish a transient classifier failure from a policy denial; add a documented retry/cooldown path and an explicit-path staging fallback so a phase commit is not silently lost.
- 3) Deviation identity: per-phase restart of D-numbers produced collisions (D-018, D-022…D-025) and a gap (D-019), forcing a phase-qualified index after the fact. A run-scoped allocator or mandatory phase prefix in the evidence template would keep IDs unique mechanically.
- 4) Verification vocabulary: the verification template offers pass/fail/partial/deferred/unknown while task/SC rules speak of `pending(live)` and `skipped`; define a canonical mapping so live/external halves cannot be mistaken for `pass` or rejected as an unknown status.
- 5) Known-environmental-failure baseline: GATE-2 is specified as `comm -13` against a baseline name list, but the baseline artifact recorded only category counts (US2 ×4 / US3 ×7 / US4 ×3), so the check was reconstructed from the current run. Require the baseline file to carry the literal failing-test names, making the gate purely mechanical.
- 6) Test-command forms: `pnpm utils:test:react -- --testPathPattern=...` forwards the literal `--` into react-scripts/jest and changes what runs; document the supported per-suite invocation form in the command template so evidence commands do not silently widen scope.
