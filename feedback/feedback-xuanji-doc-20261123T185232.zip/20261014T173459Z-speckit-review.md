---
id: "20261014T173459Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "008-kb-mvc-pivot-review-20261015"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-14T17:34:59Z"
summary: "# /speckit.review 自省（008-kb-mvc-pivot，2026-10-15）"
---

## Review
# /speckit.review 自省（008-kb-mvc-pivot，2026-10-15）

评审全链产物（requirements/clarify/plan/tasks/implement + verification）：12 项发现（1 P0 / 5 P1 / 6 P2）。P0 = 运行级提交范围豁免致 MUST 交付物（宪法 MAJOR 修订、instructions.md 重写、docs/architecture.md、glossary 行）滞留工作区，已提交树不满足本特性 SC-004 清零门、README 引用不存在的宪法 v2.0.0.1——经独立只读验证子代理 confirm。

## 过程摩擦点（改进导向）

1. 运行级「仅提交 X」指令无机制承接任务合法修改的被豁免文件：唯一痕迹是 prose note + HTML 注释，无任务行/结构化清单承接落地。建议 implement 提交门增加 pending_user_commits 结构化清单 + 待落地任务行。
2. implement 命令模板 0 处提及 features.md：features/017.md canonical 状态机声明 implement 为 Planned→Implemented owner，但命令不携带该步骤——系统性漏执行（本次评审已按状态机补记 Implemented (deferred: T017)）。
3. clarify「非提问修复」写出错误枚举（4 个 :check vs package.json 实存 5 个）且未回写 requirements owner；plan/tasks/verification 三产物绕行后 owner 仍错。建议事实修复强制粘贴确定性命令输出为证。
4. verification-log-template 未定义 tasks.md sigil 契约引用的 deferred_tasks= 字段；run 留空该字段与 features.md deferred 后缀、DoD Status 三处结构化位。

## token-efficiency 自省

11 个 spec 产物全文加载（约 1.2k 行）属必要评审面；HEAD 树旧路径核对以单条 git show|grep 完成；P0 验证仅派发 1 个子代理。无明显可避免消耗。

## Optimization Points
- 运行级提交范围豁免指令缺承接机制：任务修改的被豁免文件无任务行/结构化清单落地，已提交树不满足 SC-004（P0，已验证）。建议 implement 提交门增加 pending_user_commits 字段化清单。
- implement 命令模板 0 处提及 features.md：canonical 状态机 implement 段（Planned→Implemented、deferred 后缀、DoD Status）系统性漏执行。
- clarify「非提问修复」无源头复核：错误枚举（4 :check vs 实存 5）写入 FR/SC 且未回写 requirements owner。
- verification-log-template 缺 deferred_tasks= 字段定义：tasks.md sigil 契约引用不存在的模板字段，run 留空三处结构化记账位。
- scan-refs 整目录豁免吞掉 glossary.md 活跃登记面：本特性新增 glossary 行携带退役路径 tools/lightrag/ 未被清零门捕获。
- token-efficiency：产物全文加载属必要评审面；git show|grep 单条核对、单验证子代理，无明显可避免消耗。
