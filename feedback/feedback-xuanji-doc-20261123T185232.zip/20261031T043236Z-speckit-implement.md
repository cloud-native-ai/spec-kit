---
id: "20261031T043236Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261030T120500Z-d101-impl-s3"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-31T04:32:36Z"
summary: "Implementation segment 3 executed T017-T024 in tasks order. T017 ported the 022 citation family to Python (canonical identity, locator resolution, doc URL, version relation, assembly) and wired degrad"
---

## Review
Implementation segment 3 executed T017-T024 in tasks order. T017 ported the 022 citation family to Python (canonical identity, locator resolution, doc URL, version relation, assembly) and wired degradation into the query path; T018 froze eight baseline-555d2c46 golden scenarios and proved a zero-line-diff parity run with no legacy query path; T019 authored six ingest contract suites as recorded RED; T020-T023 implemented deterministic converters, multipart push validation, page-bundle building with atomic commit, six-state durable jobs with single-winner idempotency and append-only audit, and bounded OSS/local pull with cursors and post-commit indexing, reaching 49/49 ingest contract tests and a clean tsc; T024 authored the SPA router/client/Config and admin-config red suites, which fail only on the modules T025/T026 own. pnpm api:test exits 2 solely because the T024 admin suite imports the not-yet-created app.admin; the same suite ignoring that file is 295 passed. pnpm utils:test:react exits 1 solely on the three T024 red suites with 13 unrelated tests passing. model/, service/lightrag/ and view/site/themes/ are untouched, no /api/kb route was added, and plan/research/data-model/contracts/quickstart/requirements are unchanged (PLAN-EDIT: none).

## Optimization Points
- A red-first row whose subject was already implemented (T018 parity after T016/T017) MUST record the front-loaded closure honestly instead of manufacturing a RED. | When a row's verify command measures a union of owned and out-of-segment checks, record the exit code and the attributed subset separately (pnpm api:test exit 2 vs 295 passed ignoring the T024 red file). | Generated golden fixtures are reproducible only when the generator's baseline commit, stubbed transport and fixed clock live next to the fixtures (README + generate script). | Keep the ingest service's wire validator and its service-level envelope fields (idempotency_key/operator) separated; the first green failure was a validator rejecting a legitimate job-admission key. | Content-hash slugs are a contract rule, not a missing-title bug: tests must assert the C-32 fallback instead of assuming filename-derived paths.
