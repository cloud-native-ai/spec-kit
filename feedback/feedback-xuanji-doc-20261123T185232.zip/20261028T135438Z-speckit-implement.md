---
id: "20261028T135438Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261028T083000Z-7c1a-implement-p4"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "021-code-cgit-urls"
feature_id: "026"
partial: false
created: "2026-10-28T13:54:38Z"
summary: "Implement p4 segment (T015–T017) of 021-code-cgit-urls / Feature 026 — docs behavior owner, deployment env example, configuration pointer. T015 appended §13 (13.1–13.8) to `docs/code-retrieval.md` as "
---

## Review
Implement p4 segment (T015–T017) of 021-code-cgit-urls / Feature 026 — docs behavior owner, deployment env example, configuration pointer. T015 appended §13 (13.1–13.8) to `docs/code-retrieval.md` as the cgit behavior owner: scope limited to the active stdio MCP wrapper (CLI/doctor/gateway/site excluded), config-entry pointer to `service/code-graph/cgit-config.ts` and requirements Shared Strings without a second key table, URL shape/ref/anchor/end_line semantics, degradation enum and precedence, security boundaries (zero credentials, out-of-band auth, zero network, redaction owner pointer), enable/disable/rollback/troubleshooting steps, and known limits (session manifest drift, no cgit-side probe, non-JSON results, upstream field collision). §1–§12 are untouched (diff is 119 insertions, 0 deletions). T016 placed a fenced example with exactly the five keys inside §13.3, non-default placeholders for base/map, defaults marked on ref strategy and line anchors, zero credential keys, no built-in host/port, explicit Q-009 external-prerequisite statement, pnpm --silent/direct-tsx stdout-purity caution, and an adjacent non-normative/owner-pointer paragraph. T017 added only a two-line pointer paragraph to `docs/configuration.md` naming the code owner and the behavior owner; it contains no key literal, default value, or enumeration. Verification: git diff is additive; the five key names match requirements Shared Strings; credential-key scan zero; host/port scan none; `git diff --exit-code -- service/code-graph/doctor.ts` exits 0; `scanDocsOwners()` returns CODE_T08_OK. Commit 079638f0. Deferred by pin ownership: T018 walkthrough depends on T019's package script; package scripts remain T019.

## Optimization Points
- Docs are behavior-owner only: key literals appear once (the T016 example) with an adjacent owner pointer, and `docs/configuration.md` stays a pointer so no fact needs a second edit site.
- T015–T017 are forward-looking on the `code-graph:cgit-mcp` script that T019 creates; the T018 walkthrough therefore remains correctly blocked until T019 lands.
- token-efficiency: the three contracts were read in full to pin exact docs literals, but no machine-managed store was bulk-injected and no token counts were measured or fabricated.
- Node v26.7.0 still exceeds the declared engine range; the recorded waiver W-2026-10-28-CGIT applies and no install or lockfile change was made.
- No functional anomalies; no ANOMALY lines.
