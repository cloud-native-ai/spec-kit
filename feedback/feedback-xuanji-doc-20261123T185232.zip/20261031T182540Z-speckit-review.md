---
id: "20261031T182540Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "r20261030T120500Z-d101-review-fix7"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
feature: "023-xuanji-doc-architecture"
feature_id: "029"
partial: false
created: "2026-10-31T18:25:40Z"
summary: "review-fix7 of 023-xuanji-doc-architecture / Feature 029 at 4954b18c closes review6 R6-01 (P1) and R6-02…R6-05 (P2). R6-01: A's language-root-relative doc_path is now the only identity — ingest writes"
---

## Review
review-fix7 of 023-xuanji-doc-architecture / Feature 029 at 4954b18c closes review6 R6-01 (P1) and R6-02…R6-05 (P2). R6-01: A's language-root-relative doc_path is now the only identity — ingest writes a doc_path document as a flat file at {lang}/{doc_path} (no bundle-directory alias, no lang prefix), Job item doc_path is bundle.docPath for push and pull, the api Hugo adapter reads and echoes the same path, documents/resolve hits by it and misses the .../index.md alias, and non-doc_path bundle routes report their physical main-file identity so write and read agree. A new real-ingest lane starts the actual TypeScript ingest server in a temp root and proves push -> real Job -> query -> resolve with the same doc_path, plus pull dry-run and cancel semantics. R6-02: code/search sorts by (repo, path, line or 0, end_line or 0) before slicing and an unsorted backend test asserts it. R6-03: multipart part count precedes metadata parsing, and 21 descriptors (with 21 parts or 1 part) return 413 payload_too_large/file_count with no job. R6-04: the real-ingest lane covers the jobs the Python double cannot; the inventory labels the fake-based cases. R6-05: tasks.md and verification.md use a range-free ledger reference and the carryover checker recomputes the last L row and rejects stale ranges (negative case verified). Contracts C-32/C-08 updated under PLAN-EDIT r20261030T120500Z-d101-review-fix7; no FR/SC/clause/task count change; no constitution change. Gates all exit 0: api 495 passed 1 skipped (real-ingest lane included), ingest 101, parity 10, react 35, pin-only check and owner verified, validate-tasks 0/0, clause coverage ok with one pre-existing warning, carryover 18/13/31/26 with obligations ending at L-8, ingest tsc clean, whitespace clean. Waiver W-6-01 (L-8) unchanged. No ANOMALY.

## Optimization Points
- 1. Prove cross-surface identity with a real writer-to-reader round trip; per-operation schema conformance cannot see an identity mismatch. 2. Keep at least one real-service lane in a generated contract suite; a faked side makes it a schema test. 3. Enforce advertised ordering in the service, never forward untrusted backend order. 4. Count request parts before parsing metadata cardinality so the pinned count-limit status is the first determinable failure. 5. Treat an error status as contract: 400 where the owner requires 413 is a break even with no job. 6. Recompute ledger ranges from rows and make prose range-free so a stale literal cannot survive.
