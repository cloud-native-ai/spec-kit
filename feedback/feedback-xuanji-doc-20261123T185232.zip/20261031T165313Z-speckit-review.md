---
id: "20261031T165313Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "r20261030T120500Z-d101-review-fix5"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
feature: "023-xuanji-doc-architecture"
feature_id: "029"
partial: false
created: "2026-10-31T16:53:13Z"
summary: "Review-fix5 of 023-xuanji-doc-architecture / Feature 029 converges review4's two P1s. R4-01 closed: documents/query, documents/resolve, code/search and code/resolve are GET with the pin's query parame"
---

## Review
Review-fix5 of 023-xuanji-doc-architecture / Feature 029 converges review4's two P1s. R4-01 closed: documents/query, documents/resolve, code/search and code/resolve are GET with the pin's query parameters; openapi_pin compares per-path method sets in route-table and served-projection, and served discovery methods equal the runtime route table. R3-01 closed: public push accepts A's PushMetadata {} and the pinned example, maps per-file doc_path/title and rejects unknown/internal metadata keys; local pull include/exclude and defaults are honored; local path escapes return 403 before a job; OSS endpoint is optional. Gates: api 437 passed 1 skipped, ingest 87 passed, parity 10, react 35, pin verified with all six checks, tasks and clause coverage clean.

## Optimization Points
- 1. A request wire is closed only when the owner's own examples traverse the real public boundary; keep pin examples as request-side fixtures. 2. Serving the pin as discovery makes method divergence visible; compare method sets in both the raw pin and the served projection. 3. Enforce the public metadata key set at the HTTP entry, not only in the library parser, so contract-extra keys cannot ride the passthrough. 4. When per-file descriptors override placement, test both the override and the default path.
