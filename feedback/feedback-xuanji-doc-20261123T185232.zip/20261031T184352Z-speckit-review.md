---
id: "20261031T184352Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "r20261030T120500Z-d101-review7"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
feature: "023-xuanji-doc-architecture"
feature_id: "029"
partial: false
created: "2026-10-31T18:43:52Z"
summary: "review7 of 023-xuanji-doc-architecture / Feature 029 at ac7918bb is a read-only final acceptance recheck of review-fix7 (fd37b6fd + ac7918bb). R6-01 (P1) is closed: live real-ingest probes show push d"
---

## Review
review7 of 023-xuanji-doc-architecture / Feature 029 at ac7918bb is a read-only final acceptance recheck of review-fix7 (fd37b6fd + ac7918bb). R6-01 (P1) is closed: live real-ingest probes show push doc_path docs/ops/rt.md -> Job item docs/ops/rt.md -> file zh/docs/ops/rt.md with no bundle directory -> documents/query docs/ops/rt.md -> documents/resolve found=true with the same citation locator; the alias docs/ops/rt/index.md and the language-prefixed zh/docs/ops/rt.md both miss. Bundle pushes (no doc_path) report docs/incoming/<slug>/index.md and read back identically; a non-dry-run pull reports docs/incoming/local-note/index.md with query/resolve agreement; a mixed multi-file push keeps one identity per item. R6-02 is closed (code/search sorts by repo,path,line or 0,end_line or 0 before slicing; the unsorted-backend test passes). R6-03 is closed (part count precedes metadata parsing; 21 descriptors with 21 parts or 1 part return 413 payload_too_large/file_count, no job; generated test passes). R6-04 is closed (test_real_ingest_contract.py starts the real TypeScript ingest server and validates the real Job wire plus the push->query->resolve round trip; the lane ran, not skipped; the inventory labels the Python double cases). R6-05 is closed (tasks.md and verification.md are range-free; the carryover checker exits 0 with obligations ending at L-8 and a temp-copy stale literal exits 1). Gates all exit 0: api 495 passed 1 skipped (console shim), ingest 101, parity 10, react 35/4 suites, pin-only check and six-check owner verified against the byte-identical pin cf7b16a8 at A master 5b77c9024, validate-tasks 0/0, validate-requirements 0/0, clause coverage ok FR 30/30 with one pre-existing warning, carryover 18/13/31/26 with L-8, ingest tsc clean, generated suite 45 collected/45 passed, corpus frozen vs 555d2c46, worktree clean. No new P0/P1. Four new P2s: R7-01 an accepted non-canonical doc_path with a . segment splits the identity (Job docs/./dot.md vs query docs/dot.md; reproduced live; validators accept . segments); R7-02 the flat-file+assets commit is two renames and the race branches leave orphan assets (inspection evidence, not reproduced); R7-03 the write-shape change is not reflected in data-model.md E10, plan.md D-3, quickstart.md Q-07, docs/architecture.md and docs/kb.md; R7-04 contract-test-inventory.md still says 44 collected cases while the suite collects 45. Final merge recommendation is GO; the P2s are narrow and non-blocking. No push, no git add -A, no fixes.

## Optimization Points
- 1. Identity fixes need one shared canonicalisation rule, not only a new physical layout: an accepted non-canonical doc_path (dot segment, Unicode form) can still split the write identity from the read identity. 2. A two-rename commit is not one atomic unit: define cleanup over both renames and test the race when a document carries side assets. 3. When a contract gains a shape branch, update the design documents that restate it in the same change (data model, plan, quickstart, architecture summaries). 4. Every hand-maintained count drifts; derive it or add a checker (generated-case count 44 vs 45). 5. Keep at least one real-service contract lane in the default gate: it is what separated review6's schema-green state from the identity break.
