---
id: "20261031T170345Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261101T040000Z-l3a"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
feature: "023-xuanji-doc-l3-design"
feature_id: "029"
partial: false
created: "2026-10-31T17:03:45Z"
summary: "Analyze on 023: substance is coherent (29 FR / 8 SC / 38 tasks / 48 CHK reconciled, 0 orphans, all five clarify rulings landed in requirements/plan/tasks/checklist, counts reproduce: 10 H2 / 45 H3 / 5"
---

## Review
Analyze on 023: substance is coherent (29 FR / 8 SC / 38 tasks / 48 CHK reconciled, 0 orphans, all five clarify rulings landed in requirements/plan/tasks/checklist, counts reproduce: 10 H2 / 45 H3 / 587-line budget). Four HIGH gate-design defects found: (1) the evidence face cannot be evaluated on the not-yet-committed page, so G2/T025 can record 'findings 0' while the command exits 1; (2) T027/GATE-6's count command omits --spec-dir and the delegate only scans the spec dir, so the page's counts are outside its measurement; (3) the expression class's three mandated baselines (gate-call count / manual confirmations / requirements-to-analyze wall clock) appear nowhere and no task creates them; (4) the format gate is declared not-applicable on markdownlint grounds while the repo's runnable operator is prettier --check ., which also reflows prose and interacts with the hand-wrapped line budget. Also: requirements.md currently fails the evidence face on two stale as-of lines (A-1, A-8) although an earlier stage recorded 'evidence pass, findings 0'.

## Optimization Points
- 1) Make 'not-evaluated' a first-class DoD outcome in plan/tasks templates so an empty findings list plus a nonzero exit cannot be recorded as pass. 2) Have analyze re-run each gate claim that earlier stages recorded and flag non-reproducible greens explicitly (a recorded pass is a claim, not evidence). 3) Reserve a slot in the expression-class template for the three baselines (owner: expression-gates section 三项基线) plus its closeout comparison, so the MUST cannot be silently skipped. 4) Resolve gate operator names from package.json scripts rather than from dependency presence (prettier utils:format:check vs an unused markdownlint devDependency), and reserve 'not-applicable' for the build layer only. 5) When a plan's evidence grammar template is itself parsed as an annotation by the checker, mark the template as fenced so spec-dir-wide runs are not red by construction.
