---
id: "20261028T134644Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "r20261028T083000Z-7c1a-implement-p3"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "021-code-cgit-urls"
feature_id: "026"
partial: false
created: "2026-10-28T13:46:44Z"
summary: "Implement p3 segment (T011–T014) of 021-code-cgit-urls / Feature 026 — degradation and security. T011 extended `service/code-graph/cgit-rewrite.ts` so every location evidence object receives exactly o"
---

## Review
Implement p3 segment (T011–T014) of 021-code-cgit-urls / Feature 026 — degradation and security. T011 extended `service/code-graph/cgit-rewrite.ts` so every location evidence object receives exactly one outcome under the fixed priority `unmapped_repo` > `unresolved_ref` > `invalid_path`: a null `repoPath` now degrades instead of bypassing, `buildCgitUrl` failure now emits `web_url:null` + `invalid_path` (previously dropped silently), success never carries `web_url_reason`, upstream-owned `web_url` still wins, and the unit matrix pins that absence in disabled mode is produced by the wrapper not calling the rewrite, not by any disabled branch inside it. T012 added the `contracts/mcp-wrapper.md` §9 end-to-end matrix through the fake upstream: unmapped slug (empty valid map, all three reasons applicable) yields all `unmapped_repo`; missing/short-commit manifests yield `unresolved_ref` even for invalid paths; resolved manifests yield `invalid_path` only for the fixture's dot-dot/empty-segment/absolute entries while valid hits keep golden URLs; precedence is asserted across runs; fail-closed rows (config error, underivable data-dir, missing upstream, abnormal exit, non-JSON lines) and disabled field absence are covered; every matrix run asserts other hits, ordering and line values are unchanged, no URL is forged and no added value carries the workspace/data root. T013 added the injectable `formatConfigError(error, redactor = redact)` to `cgit-config.ts` (structural shape covers both config and session errors, fixed internal fallback, `[REDACTED]` on redactor throw/empty/whitespace, default `redact()` masks userinfo) and moved wrapper startup failures onto it; enabled upstream stderr is now piped and redacted line by line (Bearer tokens replaced, both lines preserved in order) while disabled stderr still inherits byte-identically. C-09 pins no raw base/map/slug echo plus the failure-injection fallback; W-17 pins userinfo/query/fragment base rejection before output and zero credential matches in successful stdout/stderr and error stderr. T014 added `cgit-security.test.ts`: a static scan of the five runtime sources for network imports/calls with a negative-control scanner self-test, a fake-upstream runtime test preloading a socket/DNS/fetch observer through `NODE_OPTIONS=--require` (load marker present, zero application-code events; tsx's own `/tmp/tsx-*.pipe` local IPC excluded by stack), and W-18 unit/E2E pins that absolute, data-root-prefixed, dot-dot and dot paths degrade to `invalid_path` and that every `web_url`/`web_url_reason` value avoids data roots and absolute paths. Evidence is committed under `.specify/specs/021-code-cgit-urls/test-evidence/p3/` (per-task RED/GREEN/check plus the 72/72 full suite); `pnpm code-graph:check` exits 0. Code commit: 902b3ef8. Strictly deferred by pin ownership: docs/code-retrieval.md and docs/configuration.md → p4 (T015/T017), package scripts → T019.

## Optimization Points
- No functional anomalies in p3: the full offline suite is 72/72 green with 0 skipped and `pnpm code-graph:check` exits 0; every task has committed RED and GREEN evidence.
- W-21 required switching enabled upstream stderr from `inherit` to `pipe`; disabled mode intentionally keeps `inherit` so C-10/W-04 byte equality is preserved. The line splitter keeps a trailing CR so CRLF stderr lines survive redaction unchanged apart from the replacement.
- The T014 runtime observer caught tsx's own `net.createConnection` to `/tmp/tsx-*.pipe` before any user code ran. That is the dev-runner's local Unix-domain IPC, not an outbound network call, so the observer ignores stacks under `node_modules/tsx/` and still records every application-code socket/DNS/fetch attempt; the static scan independently rejects network imports in the five runtime sources. Running the wrapper via tsx is a T019 packaging concern, not a network surface.
- T012 is a checkpoint, not a pin owner, and its new E2E cases pass once T011 lands. To keep the RED honest the cases were run once against the pre-T011 `cgit-rewrite.ts` (HEAD substituted into the worktree, then restored byte-identically from a temp copy); 3 of the new pins failed there (unmapped, invalid_path, precedence).
- token-efficiency: contract/spec files were read in full because the pins quote exact literals, but no machine-managed store was bulk-injected and no token counts were measured or fabricated in this segmented subagent run.
- Every `pnpm` invocation prints "Unsupported engine" because Node v26.7.0 exceeds the declared range; this is the recorded waiver W-2026-10-28-CGIT, and the symlinked node_modules/lockfile were not modified.
