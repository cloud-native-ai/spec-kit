---
id: "20261030T124740Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "r20261030T120500Z-d101-requirements-fix"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
feature: "023-xuanji-doc-architecture"
feature_id: "029"
partial: false
created: "2026-10-30T12:47:40Z"
summary: "Unattended bounded requirements-fix: folded four supplemental FRs (031-034) back into their owning rows (008/010/011/030), 34 to 30 FR with zero normative-segment loss; validate-requirements 0 error/0"
---

## Review
Unattended bounded requirements-fix: folded four supplemental FRs (031-034) back into their owning rows (008/010/011/030), 34 to 30 FR with zero normative-segment loss; validate-requirements 0 error/0 warning and decomposition-check --mode plan returned proceed. The merge was safe, but the framework offered no deterministic way to prove that no normative content was lost when definition rows are deleted/merged; the run had to build an ad-hoc sentence-containment check.

## Optimization Points
- decomposition-check.py only counts FR definitions; when a fix merges rows to satisfy the ceiling, nothing verifies that every normative segment from the removed rows survives. Add a documented merge protocol plus a reusable no-loss check (sentence-segment containment between pre-merge and post-merge artifacts) so unattended fixes do not rely on ad-hoc scripts.
- A requirements-fix that folds FR ids leaves checklists/requirements.md and the feature-registry note citing deleted ids, yet the fix stage's write scope excludes them and no rule states whether to refresh or annotate derived artifacts. Declare the ownership rule so stale ids are repaired by the owning stage instead of drifting silently.
