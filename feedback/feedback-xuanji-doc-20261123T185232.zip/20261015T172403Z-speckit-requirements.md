---
id: "20261015T172403Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "011-memory-index-system-20261016"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
feature: "011-memory-index-system"
feature_id: "020"
partial: false
created: "2026-10-15T17:24:03Z"
summary: "补规格运行（Feature 020 Memory Index System → spec 011）：勘察（宪法/房规/代码锚点 7 项核对）→ 脚本生成 spec 目录与分支 → 正文（现状基线+6US+17FR+7SC+5 STR）→ 机械化核查（[NEEDS CLARIFICATION]=0、STR 引用对账一致）→ checklist 首轮全绿（sanctioned in-session 路"
---

## Review
补规格运行（Feature 020 Memory Index System → spec 011）：勘察（宪法/房规/代码锚点 7 项核对）→ 脚本生成 spec 目录与分支 → 正文（现状基线+6US+17FR+7SC+5 STR）→ 机械化核查（[NEEDS CLARIFICATION]=0、STR 引用对账一致）→ checklist 首轮全绿（sanctioned in-session 路径实证）→ 产物提交 34f53bd3。运行干净无中断。Token 效率三问自查：(1) 原文转储——docs/memory.md 全文注入，例外成立（任务指令要求完整读+设计权威引用目标），改进点见 points；(2) 确定性工作——引用对账与标记统计交 grep 程序完成；(3) 重复读取——无（工作目录残留导致的一次 find 失败已即时纠正）。

## Optimization Points
- 编号双轨无承接位：/speckit.requirements 的编号推导基于 specs 目录序（本运行 011），Feature 注册表 ID（020）与之历史双轨（先例 017→008、019→010）；当用户输入已显式指称 Feature（"020 Memory Index System"）时，命令模板没有承接位登记该映射线索，Related Feature 一律留 Need clarification 全量推给 /speckit.clarify。建议在 User Input Protocol 或 Feature Integration § Binding Rules 增加「输入含明确 Feature 指称时登记为绑定线索（bind-hint）」的轻量约定，降低 clarify 阶段重复考古成本。
- token-efficiency：补规格（retrospective formalization）场景下设计权威文档已存在，本运行将 docs/memory.md 全文（约 682 行）注入上下文——属纪律允许例外（任务指令明确要求完整读 + 该文即引用目标），但命令模板可对此类场景提示「先抽样权威文档章节锚点（grep 标题结构），再按 FR 需要定点读取」的摘要优先路径，替代默认全文注入。定性代理：该文件为本次运行最大单点上下文开销；精确 Token 计数不可得，不编造数值。
