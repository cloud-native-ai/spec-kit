---
id: "20261029T131913Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "r20261028T162000Z-c1a2-analyze2"
scope: "local"
probe: "speckit-analyze-wrapup"
kind: "internal"
slice: "commands"
feature: "022-citation-architecture"
feature_id: "027"
partial: false
created: "2026-10-29T13:19:13Z"
summary: "Round-2 analyze for 022-citation-architecture / Feature 027 (run r20261028T162000Z-c1a2-analyze2), baseline a1754a26. Strictly read-only. Verified all 29 analyze-fix dispositions against their declare"
---

## Review
Round-2 analyze for 022-citation-architecture / Feature 027 (run r20261028T162000Z-c1a2-analyze2), baseline a1754a26. Strictly read-only. Verified all 29 analyze-fix dispositions against their declared landing files: 28 LANDED, 0 PARTIAL, 0 NOT-LANDED, 1 ACCEPTABLE (F-020). The three prior HIGH owners are landed: ingest C-31 assembles citation_locator from the flat citation and C-33 reads it; doc-url C-24 adds heading/anchor existence and unreadable-source branches; version_source confines the partial unique index and 409 to explicit versions. Regression scans passed for clause numbering (195 clauses, 39/24/28/33/23/26/22, continuous and unique), cross-contract references, task claims (195/195; 169 repo + 26 external; 167 executable + 2 deferred), FR-029 presence in plan/tasks (FR count 29 <= 30), STR-029 consistency (single-document source_unavailable never produces or masks degradation), version_source propagation (DDL/contract/idempotency key/FR-023/SC-007/tasks/fixture), Owner Map split, task verify/DoD/GATE/T032/T001 baseline, and PLAN-EDIT coverage. Eight new findings: 0 CRITICAL, 0 HIGH, 4 MEDIUM, 4 LOW. MEDIUM: plan Gate 2 still carries the old UNIQUE(file_source,version) WHERE version IS NOT NULL predicate without version_source='explicit' (stale copy, owner contract correct; F-101); C-24 does not define heading match normalization and covers only ATX headings, not setext (F-102); no rule selects the authoritative ingest record when several records share a file_source (F-103); explicit-version replay after the document changes conflicts with C-17 because current-hash validation runs before replay lookup (F-104). LOW: C-31 assembly condition omits the valid omitted-kind case (F-105); FR-029 lacks SC/Shared Strings/citation-group coverage and T024 does not name the invalid entry_type branch (F-106); plan.md:322 and quickstart.md:16 retain FR-028/FR=28 counts (F-107); Feature 027 registry/detail still record 186/28 and features/027.md:44 plus checklists/requirements.md:69 retain the old docs/kb.md §6 external-API owner attribution (F-108). Two fresh-context read-only subagents independently confirmed F-101, F-102, F-103 as MEDIUM. Gate: CRITICAL=0 / HIGH=0 / MEDIUM=4 / LOW=4, GATE=pass. No files modified except this record and accounting; no push.

## Optimization Points
- 1) Disposition verification: all 29 declared landings checked line-by-line; 28 LANDED + 1 acceptable (F-020), no PARTIAL/NOT-LANDED; the three prior HIGH owners (C-31 locator, C-24 existence, version_source/409) are landed.
- 2) Accounting: 195 clauses (39/24/28/33/23/26/22), 195/195 claims (169 repo + 26 external; 167 executable + 2 deferred), validate-tasks 0/0, validate-requirements 0/0, structure PASS FR=29 SC=12, pre-analyze pass 0/0, decomposition proceed 29/33; clause and reference checks done by read-only scripts.
- 3) New MEDIUM residuals: plan Gate 2 stale index predicate (F-101); C-24 heading match semantics and setext gap (F-102); multi-ingest-record selection undefined (F-103); replay vs explicit-version current-hash validation order (F-104).
- 4) New LOW residuals: C-31 omitted-kind assembly (F-105); FR-029 SC/Shared Strings/citation-group coverage (F-106); stale FR counts in plan/quickstart (F-107); Feature registry/detail stale counts and F-011 owner residual (F-108).
- 5) Gate: 0 CRITICAL / 0 HIGH / 4 MEDIUM / 4 LOW, GATE=pass; MEDIUM/LOW listed but non-blocking per user rule; independent read-only subagents confirmed F-101/F-102/F-103.
- 6) Token efficiency: counts, clause continuity, claims and structure were verified by programs; only targeted excerpts were read; no full artifact dumps into context.
