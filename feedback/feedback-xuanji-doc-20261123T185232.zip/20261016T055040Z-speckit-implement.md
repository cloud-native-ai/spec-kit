---
id: "20261016T055040Z-speckit-implement"
unit_id: "/speckit.implement"
unit_type: "command"
run_id: "011-implement-20261016"
scope: "local"
probe: "speckit-implement-wrapup"
kind: "internal"
slice: "commands"
feature: "011-memory-index-system"
partial: false
created: "2026-10-16T05:50:40Z"
summary: "implement 阶段自省（Feature 020 / 011-memory-index-system，31 任务全闭环，GATE-1..6 全过，DoD met）"
---

## Review
implement 阶段自省（Feature 020 / 011-memory-index-system，31 任务全闭环，GATE-1..6 全过，DoD met）

做得好（保持）：
- premise-falsified-writeback 纪律：T012（--offline 触发语义）、T021（graph sync 默认 dirs）、T025（mem-archive --sources 相对语义）三处任务行前提被实测否定后全部回写任务行并登记 verification.md，未静默绕过
- 探针即造即清对账表（GATE-6 九项逐条证据）+ 三面终态复核（git 树 / 库行 / 检索幽灵）运转良好
- 证据门（IDENTIFY→RUN→READ→VERIFY→CLAIM）全程执行，含对照组实验（T007 合法路径不拒绝）

摩擦（改进建议）：
1. 任务行内嵌精确调用形态易与代码语义漂移：T025 任务行写 `--sources model/draft/daily/...`（repo 相对），而 readCard join(WORKSPACE, relPath) 是 workspace 相对——首跑 not found。建议任务行引用契约节（C X.1）而非字面命令，形态判定交给执行时对照代码
2. tasks.md Notes 清理配方带隐性缺陷：node-pg `ANY($1)` 多路径形式触发 08P01（JS 数组展平为多参数），执行时才发现。配方类内容宜在 /speckit.tasks 生成时做一次冒烟执行
3. 边界类测试被 harness 分类器拦截（T007 绝对路径越界 live 形态两次 DENY）：建议此类任务在任务行预声明安全证据形态（同一判定面函数级断言 + 对照组），避免执行中往返

## Optimization Points
- [pattern] 任务行内嵌精确调用形态易与代码语义漂移（T025 mem-archive --sources 实为 workspace 相对，任务行写 repo 相对致首跑 not found）→ 建议任务行引用契约节而非字面命令，由执行时对照代码判定形态
- [defect] tasks.md Notes 标准清理配方 node-pg ANY($1) 多路径触发 08P01（JS 数组展平）→ 配方类内容应在 /speckit.tasks 生成时冒烟执行一次（本轮已就地修为 IN 占位符形式并回写）
- [friction] 边界类测试（T007 绝对路径越界 live 形态）被 harness 分类器两次拦截 → 此类任务宜预声明安全证据形态（同一判定面函数级断言+对照组），减少执行往返
- [practice] premise-falsified-writeback（T012/T021/T025 三处前提修正回写）与 GATE-6 探针对账表 + 三面终态复核有效，建议保持为 implement 默认纪律
