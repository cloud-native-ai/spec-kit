---
id: "20261014T073220Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "20261014T1430-spec-008-kb-mvc-pivot"
scope: "local"
probe: "speckit-requirements-wrapup"
kind: "internal"
slice: "commands"
partial: false
created: "2026-10-14T07:32:20Z"
summary: "两项预检裁决（站点退化为 View 并动态化、允许彻底重排）在写 spec 前经 AskUserQuestion 固化并并入 Input 行，spec 仅剩 1 个 NEEDS CLARIFICATION（兼容期策略），避免了 plan 阶段返工；输入事实核查纠正了『原本只是静态网站』的表述（KB v4.1 起已是生产端+服务端），spec 定位为『固化既有身份 + 目录架构重构』；house 约"
---

## Review
两项预检裁决（站点退化为 View 并动态化、允许彻底重排）在写 spec 前经 AskUserQuestion 固化并并入 Input 行，spec 仅剩 1 个 NEEDS CLARIFICATION（兼容期策略），避免了 plan 阶段返工；输入事实核查纠正了『原本只是静态网站』的表述（KB v4.1 起已是生产端+服务端），spec 定位为『固化既有身份 + 目录架构重构』；house 约定通过抽样 007 spec 对齐，checklist 同构复用。

## Optimization Points
- git fetch 离线失败时编号推导退化为仅本地 specs 目录，分支名检查不完整——建议 create-new-requirements.sh 在离线时显式输出『分支名检查已跳过』警示，避免远端 NNN-slug 分支导致的编号低估。
