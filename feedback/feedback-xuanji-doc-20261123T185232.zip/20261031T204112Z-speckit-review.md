---
id: "20261031T204112Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "r20261030T120500Z-d101-review8"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
feature: "023-xuanji-doc-architecture"
feature_id: "029"
partial: false
created: "2026-10-31T20:41:12Z"
summary: "review8 of 023-xuanji-doc-architecture / Feature 029 at 31439e4b is a read-only locked-mode recheck of review-fix8 (6127ed40 + 31439e4b). R8-01 is closed: a missing, empty or unreadable deployment sec"
---

## Review
review8 of 023-xuanji-doc-architecture / Feature 029 at 31439e4b is a read-only locked-mode recheck of review-fix8 (6127ed40 + 31439e4b). R8-01 is closed: a missing, empty or unreadable deployment secret no longer stops startup; startup_sequence reaches bind at 127.0.0.1:8900 and a real python3 -m app.main bound 127.0.0.1:18977; all four health endpoints return 503 and their bodies validate against the pinned Health schema (one fixed auth check, detail status=unavailable; reason=secret_missing; profile=pgvector); every non-anonymous REST route returns 401/403 with the flat Error envelope and no business body (admin Bearer 403, Basic/no-header 401); /mcp/v1 returns 401 JSON without SSE or tool result; no anonymous fallback; the stale secret and 127.0.0.1 are absent from responses and headers; the configured control is not locked (health 200, system/openapi.json 200 with Bearer). The closed statuses missing/empty/unreadable (including a directory and non-UTF-8/invalid-env cases) are covered by the 9-case locked lane and 21 config tests. Gates all exit 0: api 511 passed 1 skipped (console shim), ingest 101, parity 10, react 35/4 suites, pin-only check and six-check owner verified against the byte-identical pin cf7b16a8 at A master 5b77c9024, validate-tasks 0/0, validate-requirements 0/0, clause coverage ok FR 30/30 with one pre-existing warning, carryover 18/13/31/26 with L-9, ingest tsc clean, whitespace clean, generated suite 45 and locked lane 9 collected, corpus frozen vs 555d2c46, 10 SC rows partial, worktree clean. Cross-line xuanji-images b2813dbf removes the api.sh secret gate and defers 051 C-30/SC-005/Edge Case to 023 C-15; T025 live rerun and image rebuild remain open under L-9. No new P0/P1. Three new P2s join four carried review7 P2s: R8-02 C-15's details.reason=auth_unavailable is absent for malformed Basic/Bearer/unsupported schemes and admin Bearer keeps basic_only, while C-13's detail also carries status=unavailable and no test asserts the reason; R8-03 data-model E12 and quickstart Q-01 were not synced with the locked health/startup branch; R8-04 C-15's log clause (no internal address) is contradicted by uvicorn's bind line, and the wrapper can log the secret path when the secret path is a directory. Carried R7-01 non-canonical doc_path identity, R7-02 flat+assets atomicity, R7-03 write-shape docs, R7-04 inventory 44 vs 45 remain open and unchanged. Final merge recommendation is GO. Observed origin/main a584b99f does not contain HEAD 31439e4b although the brief says it was FF-merged; origin/023 does contain it. No push, no git add -A, no fixes.

## Optimization Points
- 1. A degraded-mode contract needs fixed-word tests, not only status tests: assert details.reason and the exact health detail, and place the locked check before credential parsing. 2. A new startup branch is a design-artifact branch: propagate it to E12/Q-01 or reference C-13/C-15 instead of restating it. 3. 'No internal address in logs' collides with default server logging; decide the policy and test it, and make the wrapper use -f so a directory secret logs no path. 4. Cross-line supervisor behavior deserves a committed regression test; the static C guard passes for both old and new wrappers. 5. Carry the review7 lessons: canonicalise doc_path once, make the flat+assets commit one cleanup scope, sync design docs when a contract gains a shape, and derive or check hand-maintained counts.
