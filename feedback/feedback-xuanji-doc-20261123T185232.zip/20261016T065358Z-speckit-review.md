---
id: "20261016T065358Z-speckit-review"
unit_id: "/speckit.review"
unit_type: "command"
run_id: "011-review-20261016"
scope: "local"
probe: "speckit-review-wrapup"
kind: "internal"
slice: "commands"
feature: "011-memory-index-system"
feature_id: "020"
partial: false
created: "2026-10-16T06:53:58Z"
summary: "review 相自省（Feature 020 / 011-memory-index-system 补规格全周期收口）：32 过程发现（P0×2/P1×15/P2×15）落盘 review.md 并提交 de7b9a77；4 项 P0 候选经独立验证 2 confirm + 2 downgrade + 0 reject（50% 降级率）；implement 登记 4 项发现逐项裁决；Feature "
---

## Review
review 相自省（Feature 020 / 011-memory-index-system 补规格全周期收口）：32 过程发现（P0×2/P1×15/P2×15）落盘 review.md 并提交 de7b9a77；4 项 P0 候选经独立验证 2 confirm + 2 downgrade + 0 reject（50% 降级率）；implement 登记 4 项发现逐项裁决；Feature 020 → Ready for Review。做得好：同作者门 5 路互斥检测 + 独立验证双层过滤有效，两个降级均来自验证代理核出的传播面/词表事实；证据快照在检测时固化、验证无漂移误拒。摩擦：检测代理引用逐字性执行不均（L547 归属错置与检测间冲突），计数断言需预置枚举锚点。

## Optimization Points
- [pattern] 检测简报未把「引用逐字性+行号」上升为硬性输出要求时，检测代理产出出现引用错置：C1 把 docs/memory.md L547 列为 search 漂移对手（实为 rag traditional 链路行）、D 检测与 C 检测对同一 L547 归属结论冲突——主会话逐条亲验载重引用后修正。建议 review 命令检测简报模板固定要求：每条发现的 Evidence 必须带当前工作树行号且可被验证代理逐字重读。
- [defect] 计数类断言（如「N 条建议落地 M 条」）若不在检测简报中预置枚举锚点与核验命令，验证代理必须全量重算且可能修正分母口径（本轮 R-A1 的 grep "STR" 检测报 0、验证实测 1 命中 "STRICTLY"；落地率 1/24 经分母修正为 1/20）——枚举即锚点，先锚后发。
- [friction] P1/P2 无验证义务，但部分同样载重（如 F8 rag-file 默认值解析、F5 checklist 失真四处）——本轮以主会话亲验补位；可考虑对「检测代理之间结论冲突」的发现自动升级为验证对象，冲突信号即复查信号。
- [practice] 同作者门+互斥检测+独立验证三层在本轮运转良好：4 项 P0 候选 2 confirm、2 downgrade（50% 降级率），两个降级均出自验证代理核出的传播面/词表事实而非检测错误——保持为 review 默认纪律，并在报告中声明降级率（objective-analysis-gate.md 规则 6）。
- [token-efficiency] 主会话为撰写检测简报与裁决子代理发现而全文读取 10 份 spec 产物（约 935 行），与 5 路检测子代理的读取存在结构性冗余；裁决质量依赖全文熟悉度故本轮保留，后续可权衡「主会话仅读 inventory 摘要+载重段落」模式。定性观察，无精确计数。
