---
id: "20260730T082133Z-speckit-instructions"
unit_id: "/speckit.instructions"
unit_type: "command"
run_id: "instructions-refresh-20260730T1619"
scope: "local"
partial: false
created: "2026-07-30T08:21:33Z"
summary: "Full reconcile after constitution v1.4.0.1 amendment: converged Constitution row (11 principles) and stale feature count (25→26), inserted missing Dogfooding Practice template section, proposed 'Bette"
---

## Review
Full reconcile after constitution v1.4.0.1 amendment: converged Constitution row (11 principles) and stale feature count (25→26), inserted missing Dogfooding Practice template section, proposed 'Better Harness' glossary term; all other sections within tolerance; no backup content loss.

## Optimization Points
- Documentation Map numeric facts (feature count) drifted silently again; consider having generate-instructions.sh emit a machine-checkable facts manifest (e.g. feature count, constitution version) so the refresh can diff facts mechanically instead of re-deriving them by hand.
