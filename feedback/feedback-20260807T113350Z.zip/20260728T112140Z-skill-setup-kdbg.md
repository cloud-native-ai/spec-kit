---
id: "20260728T112140Z-skill-setup-kdbg"
unit_id: "skill:setup-kdbg"
unit_type: "skill"
run_id: "skills-test-round1-kdbg-container-20260728"
scope: "local"
feature: "skills-test-round1"
partial: false
created: "2026-07-28T11:21:40Z"
summary: "setup-kdbg executed from framework-only to passing on a pure containerd container: fresh kdbg build composed into new testing/xuanji/kdbg-trace image, outdated receiver config discovered and replaced "
---

## Review
setup-kdbg executed from framework-only to passing on a pure containerd container: fresh kdbg build composed into new testing/xuanji/kdbg-trace image, outdated receiver config discovered and replaced with modern rund_stats shape, collector serving pod/container-labeled metrics for a live rund sandbox on :9274. Two criteria met, K8s pod-labels and restart-safety remain open.

## Optimization Points
- assets/rund-extend.yaml 已过期（receiver 更名为 rund_stats）——技能资产应随 kdbg 主线版本演进定期用 `kdbg-trace components` 校验。
- kdbg_stat 硬编码 /etc/kdbg-trace/config.yaml；已把"配置必须落规范路径"写入 Workflow 第 3 步。
- rund shim 的 rec-shared remount 导致 docker cp mount ENOSPC——流式传输规避法已写入 §1.6，同样适用于 setup-rund 场景。
- 遗留：K8s 目标 pod 名标签与重启自愈两条验收未闭环，状态表已如实标 🚧。
