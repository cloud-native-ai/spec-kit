---
id: "20260731T032104Z-skill-code-review"
unit_id: "skill:code-review"
unit_type: "skill"
run_id: "convert-qemu-review-20260731"
scope: "local"
partial: false
created: "2026-07-31T03:21:04Z"
summary: "对未提交的 docker-convert 重写 + qemu 源码切换变更做四阶段审查：size guard 通过(305 行)，按 P0-P6 记录 11 条意见，门禁拦下 1 条 blocking(硬编码版本号违反 AGENTS.md MUST 规则)并完成修复与镜像重建验证，1 条 question 交用户决策后沉淀为 knowledge。"
---

## Review
对未提交的 docker-convert 重写 + qemu 源码切换变更做四阶段审查：size guard 通过(305 行)，按 P0-P6 记录 11 条意见，门禁拦下 1 条 blocking(硬编码版本号违反 AGENTS.md MUST 规则)并完成修复与镜像重建验证，1 条 question 交用户决策后沉淀为 knowledge。

## Optimization Points
- report 子命令是纯 append-only，没有 resolve/ack 机制：blocking 修复后汇总仍显示未清零，导致门禁结论无法自动收敛，只能靠人工判断。建议增加 `note --resolves <n>` 或 `report --resolve <severity>:<index>` 以标记已解决项，并让 --summary 区分「未解决 blocking」与「历史 blocking」。
- `diff --worktree` 默认排除未跟踪文件且只提示 `git add -N`；新增文件往往是 review 的高价值对象，建议提供 `--include-untracked` 自动做 intent-to-add。
