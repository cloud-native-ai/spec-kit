---
id: "20260807T030640Z-speckit-requirements"
unit_id: "/speckit.requirements"
unit_type: "command"
run_id: "016-refactor-dev-snippets-2026-08-07"
scope: "local"
feature: "016-refactor-dev-snippets"
partial: false
created: "2026-08-07T03:06:40Z"
summary: "Ran /speckit.requirements on a dev-layer snippet reorganisation request. Grounded the spec in a repository scan before drafting (10 dev leaves, consumer counts for every snippet named in the request),"
---

## Review
Ran /speckit.requirements on a dev-layer snippet reorganisation request. Grounded the spec in a repository scan before drafting (10 dev leaves, consumer counts for every snippet named in the request), which surfaced a conflict the request text hid: the container-tools snippet is shared with 12 daemon leaves whose descendants are all production images. Produced .specify/specs/016-refactor-dev-snippets/requirements.md with 4 prioritised stories, FR-001..031, SC-001..010 each with a measurement source, 5 shared strings, 10 assumptions; raised exactly 3 NEEDS CLARIFICATION markers (all scope-level, all resolved in one round) and folded the answers back in, including a user-requested naming split between 'tools in container' (daemon) and 'tools that manage containers' (dev). Related Feature left as Need clarification per the command contract.

## Optimization Points
- ## Optimization Points
- 1. **Add a shared-artifact blast-radius scan to the Outline (step 5) for refactor-type requests.**
- The single most spec-shaping fact in this run was invisible in the user's request: the snippet
- the user asked to extend (`install/container-tools.dockerfile`) is woven by 12 `images/daemon/*`
- leaves, not only by the 10 `images/dev/*` leaves the request was about — and `daemon` is the
- ancestor of every production image. Had the spec been drafted from the request text alone, it
- would have mandated pushing developer tooling into every production image, contradicting
- Constitution Principle VII. The command already has a "Reserved identifier check" for *new*
- identifiers; it needs the symmetric check for *existing* ones: for any artifact the request
- proposes to move, merge, rename, or extend, enumerate every consumer first and record the
- counts in the spec. Concretely: extend Outline step 5 with a sub-step "Shared-artifact consumer
- scan" and let it feed a `Verified baseline` note block, which is what turned three vague risks
- into three answerable questions here.
- 2. **The "no implementation details" quality gate misfires on path-as-DSL repositories.**
- `requirements-guidelines.md` asks the checklist to assert "No implementation details (languages,
- frameworks, APIs)" and "Written for non-technical stakeholders". In this repository the snippet
- path *is* the contract (Path-as-DSL, `docs/design/images.md`) and the stakeholders are image
- maintainers, so a path-free spec would be unverifiable. I had to add a manual exemption note to
- the checklist to stop the item reading as a violation. Recommend the guidelines acknowledge an
- "artifact-path-as-contract" exemption (or reword the item as "no premature *design* decisions"),
- otherwise every spec in this repo either fails the gate or carries a hand-written excuse.
- 3. **Dictation artifacts should be corrected in clarification *answers*, not just in the request.**
- The Glossary step covers correcting the user's initial input, but two of the three answers in
- this run's clarification round contained speech-to-text noise ("第一微层" / "低微这一层" for
- "dev 这一层"). Nothing in the command told me to re-apply the glossary correction protocol to
- answers. Recommend stating explicitly that the glossary/correction protocol applies to every
- user turn in the session, and that applied corrections are surfaced in the spec (I recorded mine
- in the input-sanity note) so a misread cannot silently become a requirement.
