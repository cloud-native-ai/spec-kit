---
id: "20260807T033909Z-speckit-clarify"
unit_id: "/speckit.clarify"
unit_type: "command"
run_id: "016-refactor-dev-snippets-clarify-2026-08-07"
scope: "local"
feature: "016-refactor-dev-snippets"
partial: false
created: "2026-08-07T03:39:09Z"
summary: "Ran /speckit.clarify Mode A on .specify/specs/016-refactor-dev-snippets/requirements.md. Writability probe passed before question generation. Coverage scan found Feature Linkage missing, Functional Sc"
---

## Review
Ran /speckit.clarify Mode A on .specify/specs/016-refactor-dev-snippets/requirements.md. Writability probe passed before question generation. Coverage scan found Feature Linkage missing, Functional Scope partial (FR-023 was an unresolved either/or), and a version-pin ownership gap; the other 8 taxonomy categories were clear. Grouped the 3 independent residuals into one prompt per the few-and-independent rule. All 3 answered: bound to Feature 024 (evidence: Feature-to-spec precedent map showed Implemented features absorbing follow-on specs), froze images/dev/alios-7 as legacy, and extended the single-pin rule to dev-group CLIs. Detected that the freeze plus the rename would silently swap gosu/bwrap for Docker CLI in the frozen leaf, and encoded guards (User Story 5, FR-023, FR-027 exemption, SC-011). Spec grew to FR-032/SC-012/STR-006 with 5 user stories; append-only invariant held (6 to 9 clarification rows); features.md and features/024.md updated.

## Optimization Points
- ## Optimization Points
- 1. **Add a "does the answer stay true under the other answers?" consistency pass before integration.**
- This run's biggest value came from work the command never asked for. The user chose "freeze
- `images/dev/alios-7` as legacy" (Q2). Taken literally that is a no-op — but Q1's answer renames
- `install/container-tools.dockerfile` and repurposes the freed name for the dev layer. Since
- `images/daemon/alios-7` happens to be the only daemon leaf that never weaves that snippet, the
- frozen leaf is the sole provider of `gosu`/`bwrap` in its chain, so "change nothing" would have
- silently swapped those helpers for Docker CLI + nerdctl. Nothing in the Integration Rules prompts
- the agent to cross-check a new answer against previously accepted answers; they are applied
- section-by-section, independently. Recommend an explicit integration sub-step: "for each accepted
- answer, re-read the other accepted answers of this and prior sessions and state whether any
- combination produces an unintended outcome; if so, surface it and encode the guard." Cheap to run,
- and here it was the difference between a correct spec and a latent corruption.
- 2. **The "one question at a time" rule and the "group few independent residuals" rule conflict without
- a stated precedence.** Question Generation step 1 says to group residuals into one prompt when
- they are few and independent; the Interactive Loop then says "present ONE question at a time". I
- had 3 independent residuals and chose grouping, but the command gives no rule for which
- instruction wins. Recommend stating the precedence explicitly (e.g. "grouping overrides the
- sequential loop when residual count <= 3 AND no residual's options depend on another's answer"),
- otherwise behavior varies per run and users see inconsistent interaction styles.
- 3. **Feature-binding evidence gathering should be a named step, not folded into a taxonomy bullet.**
- The Feature Linkage bullet says to "list candidate Features with their Status and a one-line scope
- summary", and the Feature Integration Protocol adds a binding-precedent heuristic. Producing that
- evidence well required building a Feature-to-spec precedent map across all 26 feature detail files
- (which revealed that Implemented features here routinely absorb follow-on specs: 002<-010,
- 003<-014, 019<-011 — the decisive argument for binding rather than creating). That is a concrete,
- scriptable step buried in prose. Recommend promoting it to a Phase 0 sub-step with the exact
- command, so every clarify run presents bind-vs-create on evidence instead of on the agent's
- recall of feature names.
- 4. **`check-prerequisites.sh` reports `FEATURE_NAME` as the literal string "Need clarification".**
- The script echoed `"FEATURE_ID":""` and `"FEATURE_NAME":"Need clarification"` — it is parsing the
- spec's placeholder text as data. Harmless here because Mode A is precisely the phase that resolves
- it, but a downstream consumer that trusts `FEATURE_NAME` would propagate the placeholder into an
- artifact. Recommend the script emit an empty string (or a `feature_bound: false` flag) rather than
- the placeholder prose.
