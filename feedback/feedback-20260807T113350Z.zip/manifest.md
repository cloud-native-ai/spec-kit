# Feedback Package Manifest

> This feedback targets the Spec Kit framework itself (templates, commands, skills, scripts, docs) — not the LLM, agent CLI, harness, or any user project code.

- **Generated**: 2026-08-07T11:33:50Z (rebuilt from archived entries after local package deletion)
- **Entries**: 12
- **Time range**: 2026-07-28T11:21:40Z → 2026-08-07T09:25:20Z
- **spec-kit version**: project-local .specify snapshot
- **Install source**: git@gitlab.alibaba-inc.com:cloud-native-ai/spec-kit.git

| Created | Unit | Summary |
|---------|------|---------|
