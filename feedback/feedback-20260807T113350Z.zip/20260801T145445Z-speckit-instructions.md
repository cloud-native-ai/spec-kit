---
id: "20260801T145445Z-speckit-instructions"
unit_id: "/speckit.instructions"
unit_type: "command"
run_id: "instructions-20260801T145431Z"
scope: "local"
partial: false
created: "2026-08-01T14:54:45Z"
summary: "局部更新运行：按用户输入将 fetcher 构建 404→Mirror 缺件的处理约定写入 .specify/instructions.md 的 Fetcher & Snippet Rules 小节，其余小节保持字节不变；对 4 份历史备份做丢失检测未发现用户手写内容缺失；6 个兼容性符号链接均有效。非破坏性保证与 refresh-base 机制按预期工作。"
---

## Review
局部更新运行：按用户输入将 fetcher 构建 404→Mirror 缺件的处理约定写入 .specify/instructions.md 的 Fetcher & Snippet Rules 小节，其余小节保持字节不变；对 4 份历史备份做丢失检测未发现用户手写内容缺失；6 个兼容性符号链接均有效。非破坏性保证与 refresh-base 机制按预期工作。

## Optimization Points
- ## Optimization Points
- 局部更新（args 非空）时，命令仍要求执行完整的备份覆盖比对（Action 6）。在本项目已有 4 份备份且文件约 170 行时尚可，但备份数增长后成本会线性上升；建议对局部更新只比对"被改动小节 + registry 受管区间"，或提供 `--skip-coverage-check` 之类的显式开关。
- Action 5 要求对 Documentation Map 逐行做 `test -e` 存在性校验，但在局部更新路径下又要求"不得改动无关小节"，两者边界不清：校验发现路径失效时是否应当修复？建议明确区分"只读校验并在 residual 报告中提示"与"直接修复"。
