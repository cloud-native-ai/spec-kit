---
id: "20260730T033202Z-skill-setup-rund"
unit_id: "skill:setup-rund"
unit_type: "skill"
run_id: "kdtool-integration-20260730"
scope: "local"
partial: false
created: "2026-07-30T03:32:02Z"
summary: "First integration pass of kdtool (kdbg-tool) into the image factory and setup-rund flow: fetcher/builder/snippets created, rund alios-8 ships kdtool, smoke builds pass, kdtool runs in-image. Requireme"
---

## Review
First integration pass of kdtool (kdbg-tool) into the image factory and setup-rund flow: fetcher/builder/snippets created, rund alios-8 ships kdtool, smoke builds pass, kdtool runs in-image. Requirement gaps for the early-stage tool collected as points.

## Optimization Points
- kdtool-requirement: container-target log discovery — auto-detect kind/container log locations (/cws_work/log, journald, containerd stdout) instead of /var/log/*.log defaults.
- kdtool-requirement: static musl release build so one binary runs on any node image regardless of glibc.
- kdtool-requirement: machine-readable output (--json) for info/diagnose so env-check drop-ins can assert on kdtool results.
- kdtool-requirement: sqlite rpmdb support for info component versions on newer OS images (current parser is BerkeleyDB-only).
- kdtool-requirement: non-root graceful degradation notes per subcommand surfaced in --help.
