---
id: "20260807T052023Z-speckit-analyze"
unit_id: "/speckit.analyze"
unit_type: "command"
run_id: "016-refactor-dev-snippets-analyze-2026-08-07"
scope: "local"
feature: "016-refactor-dev-snippets"
partial: false
created: "2026-08-07T05:20:23Z"
summary: "Ran read-only /speckit.analyze over spec 016 (32 FRs, 12 SCs, 60 tasks, 5 stories, 2 contracts). Built a semantic coverage map after discarding a misleading ID-citation pass. Produced 12 findings: 1 C"
---

## Review
Ran read-only /speckit.analyze over spec 016 (32 FRs, 12 SCs, 60 tasks, 5 stories, 2 contracts). Built a semantic coverage map after discarding a misleading ID-citation pass. Produced 12 findings: 1 CRITICAL, 1 HIGH, 4 MEDIUM, 6 LOW. Dispatched three independent fresh-context validators in one parallel wave for the CRITICAL/HIGH candidates: two confirmed, one downgraded HIGH to MEDIUM on the grounds that the defect is external, one-line, and fully disclosed with an owning task. The CRITICAL finding is a real build-breaking propagation: task T020 moves the Node.js weave into a shared snippet that images/builder/tools/gnu/alios-7 weaves directly, so Node.js 25 reaches a CentOS-7-era image whose build hard-gates on node --version; requirements.md asserts the opposite with a factually false rationale, and the guarding task diffs a template that never changes while the artifact that does change is untracked. The HIGH finding is a gate command whose grep allowlist pre-whitelists the exact lines the tasks must delete, making it unable to fail; the validator additionally proved a recorded baseline metric is understated by 10. Feature linkage verified 100% consistent across five sources. No files modified.

## Optimization Points
- ## Optimization Points
- 1. **The validation-subagent pass should also be pointed at high-risk *silences*, not only at drafted findings.**
- §5.5 validates findings the detector already produced. But this run's CRITICAL finding (C1) came from
- asking a question the detection passes do not prompt: "which files outside the spec's declared scope
- consume a snippet this spec modifies?" Pass E covers "requirements with zero tasks; tasks with no
- requirement" — a spec-internal view. C1 was a *repository-external* consumer of a changed shared
- file, invisible to any artifact-to-artifact comparison, and the spec confidently asserted the
- opposite. Recommend adding a detection pass: "for every shared artifact the tasks modify, enumerate
- all consumers in the codebase and verify each one's stated impact against the code" — and note that
- this pass reads the repository, not just the three spec files. A same-context reviewer would have
- accepted the spec's assertion; the fresh-context validator disproved it with citations.
- 2. **`grep -v` allowlists in gate commands need an explicit adversarial check.**
- Both blocking findings involved a check command that returns success while the condition it claims to
- prove is false (H1) or a guard that inspects a file the change does not touch (C1). The command's
- detection passes look for missing coverage, not for *coverage that cannot fail*. Recommend a pass
- that, for each machine-checkable GATE item, requires constructing one concrete violating input and
- reasoning whether the command would flag it. My H1 validator did exactly this and additionally proved
- the recorded baseline number was off by 10 — a defect no artifact comparison would ever surface.
- 3. **Citation-based coverage matching produces a false picture and should be explicitly de-prioritized.**
- My first mechanical pass showed "23 of 32 FRs not cited in tasks.md", which would have been a wildly
- misleading finding table — most were covered semantically without the literal `FR-NNN` token. Step 3
- does say mapping is "inference by keyword / explicit reference patterns", but nothing warns that the
- explicit-ID signal alone is near-useless in projects that don't cite IDs in task rows. Recommend
- stating that ID-citation counts MUST NOT be reported as coverage, and that coverage requires a
- semantic mapping pass.
- 4. **No guidance on analyzing artifacts the analyzing agent itself authored.**
- I wrote all the artifacts under review in this same session, which is the common case for a
- single-agent Spec Kit run. The risk of confirming my own intent instead of reading what I actually
- wrote is high and structural. §5.5's fresh-context rule mitigates it for CRITICAL/HIGH only, after a
- finding exists — it does nothing about findings never drafted. Recommend stating that when the
- analyzer authored the artifacts, the detection passes themselves (not just validation) should be
- delegated to fresh-context subagents for at least the coverage and constitution passes.
