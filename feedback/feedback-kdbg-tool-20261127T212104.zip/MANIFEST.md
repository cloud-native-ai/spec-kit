# Feedback Package Manifest

> This feedback targets the Spec Kit framework itself (templates, commands, skills, scripts, docs) — not the LLM, agent CLI, harness, or any user project code.

- **Generated**: 2026-11-27T13:21:03Z
- **Entries**: 1
- **Time range**: 2026-07-28T11:51:40Z → 2026-07-28T11:51:40Z
- **spec-kit version**: unknown
- **Install source**: unknown
- **Excluded (non-framework, kept local)**: 1 entry — skill:memory-record

| Created | Unit | Partial | Probe | Slice | Summary |
|---------|------|---------|-------|-------|---------|
| 2026-07-28T11:51:40Z | /speckit.instructions | False | - | - | Bootstrap run: fresh instructions rendered from template, filled Project Overview, Documentation Map, Tech Stack from di |
## Exec-Quant Payload

Exec-Quant Payload: none (无量化数据).
The source store had no readable exec-quant records at package time.
- **Skipped unreadable**: 0
- **Truncated**: 0
- **Cap**: 1000 records / 16777216 bytes (triggered: no)
- **Source project**: kdbg-tool (KDTool, binary `kdtool`)

